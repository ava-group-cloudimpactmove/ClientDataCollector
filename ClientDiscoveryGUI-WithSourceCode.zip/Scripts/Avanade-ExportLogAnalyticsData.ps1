<#
.SYNOPSIS
    This script will download log analytics data and save the output to a CSV file.  The directory structure that it saves the files to is defined in the CSV input
    The ServerList input takes the form of a list of Servers
    You will need to have access to the log analytics workspace in order for this script to function correctly!

.DESCRIPTION
    Usage: .\ExportLogAnalyticsData.ps1 -ServerList serverlist.csv -OutputDir "Output directory Path" -CheckType Pre -Timespan 30d/14d/7d/24h/1h -JsonProject "..\JSON\configRSG.json" -JsonPersonal "..\JSON\config-Ryan.json"
    OR (legacy): .\ExportLogAnalyticsData.ps1 -ServerList serverlist.csv -OutputDir "Output directory Path" -CheckType Pre -Timespan 30d/14d/7d/24h/1h -SubscriptionName "name" -WorkspaceRG "name" -WorkspaceName "name"
    
    -ServerList serverlist.csv          CSV or text file containing a list of servers Servers - one per line.  Use -GenerateSampleCSV to generate a template file to use.
                                        Default is serverlist.csv
    -JsonProject                        Path to the project JSON configuration file containing LASubscriptionName, LAWorkspaceName, LAWorkspaceRG
    -JsonPersonal                       Path to the personal JSON configuration file (optional, for authentication)
    -OutputDir                          Specify the directory for the output files.
                                        Default is .\ (the current directory)
    -CheckType [Pre/Post/Dashboard/Verify]  This sets the checks to either pre or post migration.  This is important for the naming of files.
                                        [Pre] -> This will set the check type to Pre Migration which will output the Pre_LogAnalytics file as well as the PortScanInput.csv
                                        [Post] -> This will set the check type to Post Migration which will output the Post_LogAnalytics file
                                        [Dashboard] -> This will set the check type to Dashboard which will output the Dashboard_LogAnalytics file
                                        [Verify] -> This will simply verify if the servers in serverlist.csv have data in LA.  If they don't, the server is written to errorlist.csv
    -Timespan  [##d/##h]         ]      This sets how long the query will look back.  You can use any number followed by d or h.  30d = 30 days, 14d = 14 days, 7d = 7 days, 24h = 24 hours, 1h = 1 hour.  
                                        Default is 30d.
    
    LEGACY PARAMETERS (for backward compatibility - use JSON instead):
    -SubscriptionName                   This is the name of the subscription that LogAnalytics resides
    -WorkspaceRG                        This is the name of the resource group that holds the log analytics workspace
    -WorkspaceName                      This is the name of the Log Analytics Workspace we will query
    
    -ErrorList ErrorList.csv            This is the name of the files that servers with no data will be written to.  ErrorList.csv can be used as an input to this script to re-run the errors.
                                        Default is ErrorList.csv
    -ServerName                         This is the name of the server you want to run the script against.  This will override the serverlist.csv file.                                      
    -GenerateSampleCSV                  This will generate a sample serverlist.csv so you can modify it.                               
    -Help                               These usage instructions are displayed.

.PARAMETER ServerList
    CSV or text file containing a list of servers Servers - one per line. Default is serverlist.csv

.PARAMETER JsonProject
    Path to the project JSON configuration file

.PARAMETER JsonPersonal
    Path to the personal JSON configuration file

.PARAMETER OutputDir
    Specify the directory for the output files. Default is .\ (the current directory)

.PARAMETER CheckType
    This sets the checks to either pre or post migration. This is important for the naming of files.

.PARAMETER Timespan
    This sets how long the query will look back. You can use any number followed by d or h. Default is 30d.

.PARAMETER SubscriptionName
    (Legacy) This is the name of the subscription that LogAnalytics resides

.PARAMETER WorkspaceRG
    (Legacy) This is the name of the resource group that holds the log analytics workspace

.PARAMETER WorkspaceName
    (Legacy) This is the name of the Log Analytics Workspace we will query

.PARAMETER ErrorList
    This is the name of the files that servers with no data will be written to. Default is ErrorList.csv

.PARAMETER ServerName
    This is the name of the server you want to run the script against. This will override the serverlist.csv file.

.PARAMETER GenerateSampleCSV
    This will generate a sample serverlist.csv so you can modify it.

.PARAMETER Help
    These usage instructions are displayed.

.EXAMPLE
    .\ExportLogAnalyticsData.ps1 -CheckType Post -OutputDir C:\Temp -JsonProject "..\JSON\configRSG.json"
    This will generate the Post Migration Log Analytics output using serverlist.csv as an input and files are written to c:\temp using JSON config

.EXAMPLE
    .\ExportLogAnalyticsData.ps1 -ServerList MyServerList.csv -CheckType Pre -JsonProject "..\JSON\configRSG.json"
    This will generate the Pre Migration Log Analytics output using MyServerList.csv as an input file with JSON config

.EXAMPLE
    .\ExportLogAnalyticsData.ps1 -CheckType Pre -SubscriptionName "MySubscription" -WorkspaceRG "MyRG" -WorkspaceName "MyWorkspace"
    This will generate the Pre Migration Log Analytics output using legacy command-line parameters

.EXAMPLE
    .\ExportLogAnalyticsData.ps1 -GenerateSampleCSV
    This will create a new serverlist.csv file that you can use as a template. It will not overwrite a file if it is there already.

.NOTES
    Organization    - Avanade
    Owner           - Cloud Managed Services
    Author          - Ryan Ferguson
.Link
    Repo Link to this Script: https://dev.azure.com/CMSMigrations/AMDM%20-%20LiftAndShift/_git/AMDM%20-%20LiftAndShift?version=GBmain&path=05%20-%20Migration/03%20-%20Dependency%20Analysis/ExportLogAnalyticsData.ps1
#>

Param(
    [string]$ServerList = 'serverlist.csv',
    # JSON configuration files (new - preferred method)
    [string]$JsonProject,
    [string]$JsonPersonal,
    # Legacy parameters for backward compatibility
    [string]$SubscriptionName,
    [string]$WorkspaceRG,
    [string]$WorkspaceName,
    [string]$OutputDir = '.\',
    [string]$ErrorList = 'ErrorList.csv',
    [string]$CheckType = "Dashboard",
    [string]$Timespan = '30d',
    [switch]$GenerateSampleCSV,
    [string]$ServerName,
    [switch]$Help
)
$ScriptVersion = "26.02.13"
$TimestampFormat = 'yyyyMMdd-HHmmss'

if ($GenerateSampleCSV) {
    write-host "Generating sample CSV:  $ServerList"
    $Header = "Server`n"
    $Header += """localhost""`n"
    $Header | out-file $ServerList -NoClobber -encoding UTF8 
    return
}


elseif ($Help ) {
    # -or ($PSBoundParameters.count -eq 0)) {
    write-host 'ERROR: No CheckType Selected.' -ForegroundColor Red
    Get-Help $MyInvocation.MyCommand.Definition
    return
}

# Write-Log function for consistent logging (aligned with PortConnectivity-Windows.ps1)
function Write-Log {
    param(
        [Parameter(Mandatory = $true)][string]$Message,
        [ValidateSet("Info", "Warning", "Error", "Debug")][string]$Level = "Info",
        [ConsoleColor]$Color = "White"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $colorToUse = if ($Color) { $Color } else {
        switch ($Level) {
            "Info" { "White" }
            "Warning" { "Yellow" }
            "Error" { "Red" }
            "Debug" { "Cyan" }
            default { "White" }
        }
    }
    Write-Host "[$timestamp] [$Level] $Message" -ForegroundColor $colorToUse
}

# This function will create a directory provided it doesn't already exist
function CreateDir {
    param(
        [string]$NewPath  
    )
    If (!(test-path $NewPath)) {
        Write-Log -Message "Creating directory: $NewPath" -Level "Info" -Color Green
        New-Item -ItemType directory -force -Path $NewPath | Out-Null
    } 
}

# This function downloads data from Log Analytics.  Since this is done multiple times, we put this into a function.
function DownloadData {
    param(
        [string]$Query,
        [string]$Timespan,
        [string]$WorkspaceID
    )
    Write-Log -Message "Downloading data using query: $Query" -Level Debug -Color Cyan

    try {
        if ($Timespan.Contains('d')) {
            $days = $Timespan.Replace('d', '')
            Write-Log -Message "Using timespan of $days days" -Level Debug -Color Cyan
            $DownloadData = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkspaceID -Query $Query -Timespan (New-TimeSpan -Days $days) -ErrorAction Stop
        }
        else {
            $hours = $Timespan.Replace('h', '')
            Write-Log -Message "Using timespan of $hours hours" -Level Debug -Color Cyan
            $DownloadData = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkspaceID -Query $Query -Timespan (New-TimeSpan -Hours $hours) -ErrorAction Stop
        }
        return $DownloadData
    }
    catch {
        $errorMessage = $_.Exception.Message
        if ($errorMessage -like "*Forbidden*" -or $errorMessage -like "*403*") {
            Write-Log -Message "❌ Access denied to Log Analytics workspace. Current user may not have 'Log Analytics Reader' role or higher." -Level Warning -Color Yellow
            Write-Log -Message "   Required permissions: 'Log Analytics Reader' role on workspace: $WorkspaceID" -Level Warning -Color Yellow
            Write-Log -Message "   Current Azure context: $((Get-AzContext).Account.Id)" -Level Warning -Color Yellow
        }
        elseif ($errorMessage -like "*NotFound*" -or $errorMessage -like "*404*") {
            Write-Log -Message "❌ Log Analytics workspace not found or inaccessible: $WorkspaceID" -Level Warning -Color Yellow
        }
        else {
            Write-Log -Message "❌ Failed to query Log Analytics: $errorMessage" -Level Warning -Color Yellow
        }
        Write-Log -Message "   Full error details: $_" -Level Debug -Color Red

        # Return empty result structure to prevent downstream errors
        return @{ results = @() }
    }
}



# Configuration: Support both JSON files and legacy command-line parameters
$JsonConfigData = $null

# If JSON files are provided, load and merge them
if ($JsonProject -and (Test-Path $JsonProject)) {
    Write-Log -Message "Loading JSON project configuration from: $JsonProject" -Level Info -Color Green
    $JsonProjectData = Get-Content -Path $JsonProject | ConvertFrom-Json
    $JsonConfigData = $JsonProjectData | Select-Object *
    
    # Load personal JSON if provided
    if ($JsonPersonal -and (Test-Path $JsonPersonal)) {
        Write-Log -Message "Loading JSON personal configuration from: $JsonPersonal" -Level Info -Color Green
        $JsonPersonalData = Get-Content -Path $JsonPersonal | ConvertFrom-Json
        # Merge personal properties if needed (for future authentication use)
    }
}

# Determine configuration values: JSON takes precedence, then command-line parameters
if ($JsonConfigData) {
    # Use JSON configuration
    if (-not [string]::IsNullOrWhiteSpace($JsonConfigData.LASubscriptionName)) {
        $SubscriptionName = $JsonConfigData.LASubscriptionName
    }
    if (-not [string]::IsNullOrWhiteSpace($JsonConfigData.LAWorkspaceName)) {
        $WorkspaceName = $JsonConfigData.LAWorkspaceName
    }
    if (-not [string]::IsNullOrWhiteSpace($JsonConfigData.LAWorkspaceRG)) {
        $WorkspaceRG = $JsonConfigData.LAWorkspaceRG
    }
    if (-not [string]::IsNullOrWhiteSpace($JsonConfigData.LATimespan)) {
        $Timespan = $JsonConfigData.LATimespan
    }
    Write-Log -Message "Using JSON configuration values" -Level Info -Color Green
}
else {
    Write-Log -Message "Using command-line parameter values (legacy mode)" -Level Info -Color Yellow
}

if ([string]::IsNullOrWhiteSpace($SubscriptionName)) {
    Write-Host "Subscription name is empty." -ForegroundColor Red
    return
}

if ([string]::IsNullOrWhiteSpace($WorkspaceName)) {
    Write-Host "Workspace name is empty." -ForegroundColor Red
    return
}

if ([string]::IsNullOrWhiteSpace($WorkspaceRG)) {
    Write-Host "Workspace resource group is empty." -ForegroundColor Red
    return
}


if ([string]::IsNullOrWhiteSpace($ServerName)){
    $ServerCSVList = Import-Csv -Path $ServerList -ErrorAction SilentlyContinue 
}
else {
    $ServerCSVList = @{
        Server = $ServerName}
    
}

if (!$ServerCSVList) {
    Write-Log -Message 'There are no servers within the file.' -Level Error -Color Red
    return
}
else {
    $Length = $($ServerCSVList | Measure-object).count
    Write-Log "Servers listed in CSV: $Length" -Level Info -Color Green
}
Write-Log "CheckType: $CheckType" -Level Info -Color Cyan
Write-Log "Timespan: $Timespan" -Level Info -Color Cyan

# Only authenticate if there is no existing Azure session
$azContext = Get-AzContext
if (-not $azContext -or -not $azContext.Account) {
    Write-Log "No active Azure session found. Prompting for login..." -Level Warning -Color Yellow
    Connect-AzAccount
} else {
    Write-Log "Already authenticated as: $($azContext.Account.Id)" -Level Info -Color Green
}
# If there are multiple subscriptions, we need to set the context to the one that has the workspace we need
Set-AzContext -Subscription $SubscriptionName | Out-Null

# Grab the workspace ID using the information provided, with access validation (mirrors Export-LogAnalyticsData in PortConnectivity-Windows.ps1)
try {
    $workspace = Get-AzOperationalInsightsWorkspace -Name $workspaceName -ResourceGroupName $workspaceRG -ErrorAction Stop
    $WorkspaceID = $workspace.CustomerId
    Write-Log -Message "✅ Successfully connected to Log Analytics workspace: $workspaceName" -Level Info -Color Green
    Write-Log -Message "   Workspace ID: $WorkspaceID" -Level Debug -Color Cyan

    # Test workspace access by attempting a simple query
    Write-Log -Message "🔍 Testing workspace access permissions..." -Level Info -Color Cyan
    $testQuery = "Heartbeat | limit 1"
    $testResult = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkspaceID -Query $testQuery -Timespan (New-TimeSpan -Hours 1) -ErrorAction Stop
    Write-Log -Message "✅ Workspace access confirmed - Log Analytics queries will proceed" -Level Info -Color Green
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Log -Message "❌ Failed to access Log Analytics workspace" -Level Error -Color Red
    Write-Log -Message "   Workspace: $workspaceName in RG: $workspaceRG" -Level Error -Color Red
    Write-Log -Message "   Subscription: $SubscriptionName" -Level Error -Color Red
    Write-Log -Message "   Error: $errorMessage" -Level Error -Color Red

    if ($errorMessage -like "*Forbidden*" -or $errorMessage -like "*403*") {
        Write-Log -Message "" -Level Info -Color White
        Write-Log -Message "🔧 RESOLUTION STEPS:" -Level Warning -Color Yellow
        Write-Log -Message "   1. Verify you have 'Log Analytics Reader' role (minimum) on the workspace" -Level Warning -Color Yellow
        Write-Log -Message "   2. Run 'Connect-AzAccount' again if your session has expired" -Level Warning -Color Yellow
        Write-Log -Message "   3. Confirm the subscription '$SubscriptionName' is correct" -Level Warning -Color Yellow
        Write-Log -Message "   4. Verify workspace name '$workspaceName' and RG '$workspaceRG' are correct" -Level Warning -Color Yellow
    }
    return
}

# Initialize tracking arrays for success/failure
$script:LAExportSuccess = @()
$script:LAExportFailed = @()

foreach ($Item in $ServerCSVList) {
    # Put the servername into a variable to make things slightly more readable.                
    if ($Item.PSObject.Properties['Server']) {
        $Server = $Item.Server.ToUpper()
    } elseif ($Item.PSObject.Properties['ServerName']) {
        $Server = $Item.ServerName.ToUpper()
    } elseif ($Item.PSObject.Properties['Title']) {
        $Server = $Item.Title.ToUpper()
    } else {
        Write-Log "No valid server property found for item: $($Item | Out-String)" -Level Error -Color Red
        continue
    }
    
    Write-Log "Processing server: $Server" -Level Info -Color Cyan
    
    # This query will pull the LogAnalytics file which has all of the connection data in it for a record.        
    $Query = @"
VMConnection
| where Protocol == 'tcp' and Computer contains('$Server') and not(SourceIp == '127.0.0.1') and not(SourceIp == DestinationIp) and not(DestinationIp == '169.254.169.254')
| summarize
    Responses = sum(Responses),
    LinksFailed = sum(LinksFailed),
    MaxLinksLive = max(LinksLive),
    TotalBytesSent = sum(BytesSent),
    TotalBytesReceived = sum(BytesReceived),
    AverageResponseTime = 1.0 * sum(ResponseTimeSum) / sum(Responses)
  by
    Computer,Direction,ProcessName,SourceIp,DestinationIp,DestinationPort,RemoteIp
| order by Direction asc
"@

    Write-Log "Constructed Log Analytics query for $Server" -Level Debug -Color Cyan

    # Download the data from Log Analytics using the integrated DownloadData function.
    $result = DownloadData -Query $Query -Timespan $Timespan -WorkspaceID $WorkspaceID

    # Save the actual data array from the query result into $allData
    $allData = $result.results

    $ResultCount = ($allData | Measure-Object).Count
    if ($ResultCount -gt 0) {
        # First export: Group all data by SourceIp, RemoteIp, DestinationPort
        $OutputPath = [IO.Path]::Combine($OutputDir, $Server, "$Server" + "_$($CheckType)_LogAnalytics_$Timespan.csv")
        CreateDir -NewPath ([IO.Path]::Combine($OutputDir, $Server))
        $GroupedPortScanInputList = $allData | Group-Object -Property SourceIp, RemoteIp, DestinationPort

        $GroupedPortScanData = @()
        foreach ($group in $GroupedPortScanInputList) {
            $SourceIp = $group.Group[0].SourceIp
            $RemoteIp = $group.Group[0].RemoteIp
            $DestinationPort = $group.Group[0].DestinationPort
            $Processes = ($group.Group | Select-Object -ExpandProperty ProcessName) -join " "

            # Aggregate Total Bytes Sent and Received
            $TotalBytesSent = ($group.Group | Measure-Object -Property TotalBytesSent -Sum).Sum
            $TotalBytesReceived = ($group.Group | Measure-Object -Property TotalBytesReceived -Sum).Sum

            # Compute weighted average response time using Responses as weight
            $totalResponses = ($group.Group | Measure-Object -Property Responses -Sum).Sum
            if ($totalResponses -gt 0) {
                $filteredItems = $group.Group | Where-Object {
                    $null -ne $_.Responses -and
                    $null -ne $_.AverageResponseTime -and
                    $_.AverageResponseTime -ne 'NaN' -and
                    $_.AverageResponseTime -ne ''
                }
                $weightedSum = ($filteredItems | ForEach-Object { [double]$_.Responses * [double]$_.AverageResponseTime } | Measure-Object -Sum).Sum
                $AverageResponseTime = $weightedSum / $totalResponses
            }
            else {
                $AverageResponseTime = 0
            }

            $GroupedPortScanData += [PSCustomObject]@{
                Computer            = $group.Group[0].Computer
                Direction           = $group.Group[0].Direction
                ProcessName         = $Processes
                SourceIp            = $SourceIp
                DestinationIp       = $group.Group[0].DestinationIp
                DestinationPort     = $DestinationPort
                RemoteIp            = $RemoteIp
                Responses           = ($group.Group | Measure-Object -Property Responses -Sum).Sum
                LinksFailed         = ($group.Group | Measure-Object -Property LinksFailed -Sum).Sum
                MaxLinksLive        = ($group.Group | Measure-Object -Property MaxLinksLive -Maximum).Maximum
                TotalBytesSent      = $TotalBytesSent
                TotalBytesReceived  = $TotalBytesReceived
                AverageResponseTime = $AverageResponseTime
            }
        }
        $GroupedPortScanData | Export-Csv $OutputPath -Delimiter ',' -NoTypeInformation
        Write-Host "Exported $ResultCount results to output file for the server $Server to $OutputPath" -ForegroundColor Yellow

        # Second export: Filter for outbound connections and select only desired fields.
        # Cast Responses to [double] to handle NaN strings returned by Log Analytics
        $filteredData = $allData |
        Where-Object {
            $_.Direction -eq 'outbound' -and
            $_.Responses -ne 'NaN' -and
            $_.Responses -ne '' -and
            $null -ne $_.Responses -and
            [double]$_.Responses -gt 0
        } |
        Select-Object -Property SourceIp, ProcessName, RemoteIp, DestinationPort -Unique |
        Sort-Object -Property RemoteIp

        $ResultCount = ($filteredData | Measure-Object).Count

        if ($CheckType -eq 'Pre') {
            if ($ResultCount -ne 0) {
                $OutputPath = [IO.Path]::Combine($OutputDir, $Server, "$Server" + '_PortScanInput.csv')
                CreateDir -NewPath ([IO.Path]::Combine($OutputDir, $Server))
                $GroupedPortScanInputList = $filteredData | Group-Object -Property SourceIp, RemoteIp, DestinationPort

                $GroupedPortScanData = @()
                foreach ($group in $GroupedPortScanInputList) {
                    $SourceIp = $group.Group[0].SourceIp
                    $RemoteIp = $group.Group[0].RemoteIp
                    $DestinationPort = $group.Group[0].DestinationPort
                    $Processes = ($group.Group | Select-Object -ExpandProperty ProcessName) -join " "
                    $GroupedPortScanData += [PSCustomObject]@{
                        SourceIp        = $SourceIp
                        ProcessName     = $Processes
                        RemoteIp        = $RemoteIp
                        DestinationPort = $DestinationPort
                    }
                }
                $GroupedPortScanData | Export-Csv $OutputPath -Delimiter ',' -NoTypeInformation
                Write-Host "Exported $ResultCount results to output file for the server $Server to $OutputPath" -ForegroundColor Yellow
            }
            else {
                Write-Host "No outbound results found for server $Server - PortScanInput.csv not generated" -ForegroundColor Yellow
            }
        }
        else {
            # Post / Dashboard / Verify - PortScanInput.csv is not required; main export above is sufficient
            Write-Log -Message "[$Server] $CheckType check: $ResultCount outbound connections found (PortScanInput.csv not generated for $CheckType)" -Level Info -Color Cyan
        }

        # LA Export tracking (success path)
        if (-not ($script:LAExportSuccess -contains $Server)) { 
            $script:LAExportSuccess += $Server 
        }
    }
    else {
        Write-Host "$ResultCount results found for server $Server" -ForegroundColor Red
        # LA Export tracking (failure path)
        if (-not ($script:LAExportFailed -contains $Server)) { 
            $script:LAExportFailed += $Server 
        }
    }
}
# Export summary files with success and failed servers
$serverListDir = Split-Path -Path $ServerList -Parent
if ([string]::IsNullOrWhiteSpace($serverListDir)) {
    $serverListDir = $OutputDir
}
$ts = Get-Date -Format $TimestampFormat
$successPath = Join-Path $serverListDir "LA_Export_Success_$ts.csv"
$failedPath  = Join-Path $serverListDir "LA_Export_Failed_$ts.csv"

$successContent = @()
$successContent += "Log Analytics Export - Success"
$successContent += "Timestamp: $(Get-Date -Format $TimestampFormat)"
$successContent += "Total Success: $($script:LAExportSuccess.Count)"
$successContent += ""
$successContent += $script:LAExportSuccess | Sort-Object
$successContent | Out-File -FilePath $successPath -Encoding UTF8 -Force

$failedContent = @()
$failedContent += "Log Analytics Export - Failed (No LA data returned)"
$failedContent += "Timestamp: $(Get-Date -Format $TimestampFormat)"
$failedContent += "Total Failed: $($script:LAExportFailed.Count)"
$failedContent += ""
if ($script:LAExportFailed.Count -gt 0) {
    $failedContent += $script:LAExportFailed | Sort-Object
}
else {
    $failedContent += "None"
}
$failedContent | Out-File -FilePath $failedPath -Encoding UTF8 -Force

Write-Host "LA export tracking files written:" -ForegroundColor Cyan
Write-Host "  SUCCESS: $successPath" -ForegroundColor Green
Write-Host "  FAILED : $failedPath"  -ForegroundColor Yellow

# Also export legacy ErrorList.csv for backward compatibility
$summaryReport = @()
foreach ($server in $script:LAExportSuccess) {
    $summaryReport += [PSCustomObject]@{
        Server = $server
        Status = "Success"
    }
}
foreach ($server in $script:LAExportFailed) {
    $summaryReport += [PSCustomObject]@{
        Server = $server
        Status = "Failed"
    }
}
Write-Log "Exporting Error Log: $([IO.Path]::Combine($OutputDir, 'ErrorList.csv'))" -Level Info -Color Cyan
$summaryReport | Export-Csv -NoTypeInformation -Path $([IO.Path]::Combine($OutputDir, 'ErrorList.csv'))
