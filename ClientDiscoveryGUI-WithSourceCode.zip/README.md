# Avanade Cloud Impact MOVE - Client Discovery

**Version:** 26.06.66  
**Platform:** Windows, packaged EXE-first; PowerShell 5.1+ for source-script/development runs

## Overview

This portable package collects discovery data from Windows and Linux servers to support Azure migration planning. It generates JSON output files and a client-facing HTML artifact report for reviewing collection status.

> Use **Load Results** in the Server List tab to load the latest HTML artifact report into the grid, or generate one if a report does not already exist.

For a detailed client operator walkthrough (configuration recommendations, action-by-action behavior, scope rules, and screenshot checklist), see **CLIENT_USER_GUIDE.md**.

A browser-ready multi-page instruction site is also included under **Instructions/index.html** (all links are relative for local offline browsing).

---

## Quick Start

1. Extract this folder to any location (no installation required).
2. Double-click **ClientDiscoveryGUI.exe**.
3. Follow the workflow: **Welcome → Configuration → Server List**.

---

## Contents

```
ClientDiscovery/
├── ClientDiscoveryGUI.ps1          ← Main GUI (source)
├── ClientDiscoveryGUI.exe          ← Compiled GUI (if built)
├── Compile-ClientDiscovery.ps1     ← EXE build script
├── Build-ClientPackage.ps1         ← Creates client handoff package (items 2/3/4/8)
├── serverlist-sample.csv           ← Sample server list CSV
├── settings.json                   ← Encrypted credentials (created by GUI)
├── README.md                       ← This file
└── Scripts/
    ├── ServerDataCollector.exe     ← Main compiled entrypoint (if built)
    ├── ServerDataCollector.ps1     ← Main entrypoint source
    ├── AdminAccessAndRDPCheck.exe / .ps1
    ├── Generate-ArtifactReport.exe / .ps1 ← HTML artifact report generator
    ├── ZipOutput.exe / .ps1
    ├── WindowsVM/
    │   ├── MigrationCheck-DataCollector.exe / .ps1
    │   ├── CollectSQLData.exe / .ps1
    │   ├── CollectIISData.exe / .ps1
    │   ├── MigrationCheck-ScanIP.exe / .ps1
    │   └── Tools/
    │       └── SQLPSModule.zip
    └── LinuxVM/
        ├── Linux-DataCollector.exe / .ps1
        └── Linux-DataCollector.sh
```

## Root Folder Packaging Checklist (Keep vs Move vs Compile)

Use this checklist when preparing a client-facing package from the `ClientDiscovery` root:

- [ ] **Compile:** `ClientDiscoveryGUI.ps1` → `ClientDiscoveryGUI.exe`
- [ ] **Compile where possible:** `Scripts/**/*.ps1` → adjacent `*.exe`
- [ ] **Keep in package:** `ClientDiscoveryGUI.exe`
- [ ] **Keep in package:** compiled `Scripts/**/*.exe` collectors
- [ ] **Move out of package (internal/build only):** `ClientDiscoveryGUI.ps1`
- [ ] **Move out of package (internal/build only):** `Compile-ClientDiscovery.ps1`
- [ ] **Move out of package where an EXE exists:** matching `Scripts/**/*.ps1` collector sources
- [ ] **Keep in package:** `Scripts/` (compiled data collectors and dependencies)
- [ ] **Keep in package:** `serverlist-sample.csv` (client template input)
- [ ] **Keep in package:** `README.md` (client run guide)
- [ ] **Do not pre-populate package:** `settings.json` (created per-client/per-user in GUI)

---

## CSV Format

The server list CSV must contain at minimum:

| Column | Required | Values |
|--------|----------|--------|
| `ServerName` or `Server` | Yes | Hostname or IP address |
| `OSType` | Recommended | `Windows` or `Linux` |

Servers without an `OSType` value (or with an unrecognised value) are treated as **Linux**.

**Example:**
```csv
ServerName,OSType
webserver01,Windows
appserver01,Windows
dbserver01,Windows
linuxapp01,Linux
linuxweb01,Linux
```

---

## Running the GUI

### As `.exe`
Double-click `ClientDiscoveryGUI.exe`. No PowerShell window required.

### As `.ps1` for development/internal troubleshooting
```powershell
powershell.exe -ExecutionPolicy Bypass -File .\ClientDiscoveryGUI.ps1
```

The client-facing package is intended to run from the compiled EXE and does not require PowerShell 7 to be installed on the operator VM.

---

## Running from the Command Line

You can also invoke the collector directly without the GUI:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\Scripts\ServerDataCollector.ps1 `
    -CheckType Pre_Migration `
    -ServerList .\serverlist.csv `
    -OutputDir C:\DiscoveryOutput `
    -PersonalJSON .\settings.json
```

### Key Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `-CheckType` | *(required)* | `Pre_Migration`, `Post_Migration`, or `Test_Migration` |
| `-ServerList` | `.\serverlist.csv` | Path to the server list CSV |
| `-OutputDir` | `C:\Avanade\<username>` | Root output directory |
| `-PersonalJSON` | — | Path to encrypted `settings.json` |
| `-UseCredential` | — | Interactive credential prompt |
| `-MaxThreads` | `10` | Concurrent connections per OS type |
| `-ScanIP` | — | Scan C: drive for hardcoded IPs (Windows) |
| `-ScanIPPath` | — | Specific path to scan for IPs |
| `-SkipEventLog` | — | Skip Event Log collection (Windows) |
| `-EventLogMaxEvents` | `1000` | Max events per log (Windows) |
| `-ServerOnlyData` | — | Basic inventory only, skip SQL/IIS/EventLog |

---

## Credentials

### Option A — Interactive Prompt
Select **Interactive prompt** in the Credentials tab.  
The collector will prompt for credentials when it runs. Suitable for single ad-hoc runs.

### Option B — Encrypted Settings File
1. Go to the **Credentials** tab in the GUI.
2. Select **Encrypted settings.json**.
3. Enter your username and password.
4. Click **Save Encrypted Settings**.

The password is encrypted with **Windows DPAPI (CurrentUser scope)**. The `settings.json` file:
- Is only decryptable by the **same Windows user account** that created it.
- Is only decryptable on the **same machine**.
- Does **not** contain plain-text passwords — it is safe to store alongside this package.

The generated `settings.json` format is compatible with the `AlternateUsername`/`AlternatePassword` credential pattern used by the underlying collectors.

---

## Target Server Requirements

### Windows Targets
- **WinRM enabled:** run `winrm quickconfig` on each target.
- **Authentication:** account with local administrator rights (or domain admin).
- **Ports:** 5985 (HTTP/NTLM) or 5986 (HTTPS). The collector tries HTTPS first and falls back to HTTP.
- **PowerShell 5.1+** on the target (no special installation needed on modern Windows).

### Linux Targets
- **SSH access** on port 22 with the configured username/password.
- **Bash** available on the remote host.
- **Posh-SSH** module on the *machine running this GUI*:
  ```powershell
  Install-Module Posh-SSH -Scope CurrentUser
  ```
- The bash collector script (`Linux-DataCollector.sh`) is automatically uploaded to `/tmp/avanade-migration` on the remote host.

---

## Output Directory Structure

```
<OutputDir>/
├── ServerList/                     ← Auto-generated split CSVs (audit trail)
│   ├── sdc_Windows_<timestamp>.csv
│   └── sdc_Linux_<timestamp>.csv
├── webserver01/
│   ├── webserver01_Pre_Migration.json
│   ├── webserver01_Pre_SQL_Config.json   (if SQL detected)
│   └── webserver01_Pre_IIS_Config.json   (if IIS detected)
├── appserver01/
│   └── appserver01_Pre_Migration.json
└── linuxapp01/
    └── linuxapp01_Pre_Migration.json
```

JSON files are named using the pattern:  
`<ServerName>_<CheckType>[_ScanIP].json`

HTML artifact reports are written to:
`<OutputDir>/Reports/ArtifactReport/ArtifactReport-<timestamp>.html`
and refreshed at:
`<OutputDir>/Reports/ArtifactReport/ArtifactReport-latest.html`

---

## Building the EXEs

Requires the `ps2exe` module:
```powershell
Install-Module ps2exe -Scope CurrentUser
```

Then run:
```powershell
.\Compile-ClientDiscovery.ps1
```

To build the full client-shareable folder, including compiled collectors and vendored client modules, run:
```powershell
.\Build-ClientDiscoveryPackage.ps1
```

This writes `Release\ClientDiscovery\` and `Release\ClientDiscovery-<version>.zip` from the repository root. The package excludes `settings.json` by default and removes PowerShell source files when matching compiled EXEs exist; use `-IncludeSources` or `-KeepSettings` only for internal builds.

This produces `ClientDiscoveryGUI.exe` alongside the `.ps1` file. The EXE resolves all sibling paths (Scripts/, settings.json, serverlist-sample.csv) relative to its own location.

By default, the build also compiles package collector entry points under `Scripts/` to adjacent `.exe` files. The GUI and `ServerDataCollector` prefer those compiled EXEs when present and fall back to `.ps1` sources for development. To rebuild only the GUI, run:

```powershell
.\Compile-ClientDiscovery.ps1 -GuiOnly
```

---

## Creating the Client Handoff Package

To create the minimal client handoff package (checklist items **2, 3, 4, 8**), run:

```powershell
.\Build-ClientPackage.ps1
```

This creates `ClientPackage/` with:
- Item 2: `MigrationCheck-DataCollector.ps1`
- Item 3: `CollectSQLData.ps1`
- Item 4: `CollectIISData.ps1`
- Item 8: `SQLPSModule.zip`
- `MANIFEST.txt` (selection + source mapping)

Use `-Force` to overwrite an existing `ClientPackage` folder.

---

## Troubleshooting

**"WinRM access denied"** — Ensure the target has WinRM enabled and the account is a local administrator.

**"Cannot connect to SSH"** — Verify SSH is running on port 22, the credentials are correct, and `Posh-SSH` is installed.

**"Posh-SSH not found"** — Install the `Posh-SSH` module for the Windows user running the client package.

**"Password could not be decrypted"** — The `settings.json` was created by a different Windows user or on a different machine. Re-enter and save credentials on this machine with your user account.

**Empty JSON / "No data collected"** — Check that WinRM is responding. Try running the collector manually with `-Verbose` for detailed output.

---

## Support

Contact the Avanade Migration Team for assistance with this tool.
