# Avanade Cloud Impact MOVE - Client Discovery - Client User Guide

Version: 26.06.55
Audience: Client operators and migration coordinators
Scope: Client package usage with executable tools (.exe) only

## 1. Purpose

This guide explains how to use the Avanade Cloud Impact MOVE - Client Discovery package end-to-end:

1. Configure collection behavior and credentials.
2. Load and review a server list.
3. Run data collection against selected or all servers.
4. Export Log Analytics data.
5. Generate and load artifact results.
6. Build a ZIP package for delivery.

This document is written for client handoff usage where tools are distributed as .exe files.

## 2. Process Overview (Recommended Sequence)

Follow this sequence in order:

1. Access Check
2. Run All Data Collectors
3. Export Log Analytics
4. Generate Artifact Report
5. ZIP Output for Delivery

Why this order works:

- Access Check validates remote connectivity before larger collection runs.
- Full collector captures host/server evidence first.
- Log Analytics export adds time-series and workspace context.
- Artifact report provides a human-readable validation summary.
- ZIP step packages all outputs in one delivery artifact.

## 3. Screenshot Plan (Insert Your Screenshots)

Add screenshots in a folder such as `Screenshots\` in your client package and update paths below.

Suggested screenshot set:

1. Welcome tab overview
2. Configuration tab - full page
3. Output and collection section
4. Log Analytics configuration section
5. Access Check options section
6. Credentials section (interactive mode)
7. Credentials section (encrypted mode)
8. Server List tab - toolbar
9. Server List tab - action sidebar with numbered workflow buttons
10. Grid with selected rows
11. Load Results with Latest checked
12. Load Results with Latest unchecked (file picker)
13. Confirm Command dialog
14. Artifact report loaded into grid
15. ZIP output location example

Use these placeholders while assembling the final client document:

- [Insert Screenshot 1: Welcome tab]
- [Insert Screenshot 2: Configuration tab]
- [Insert Screenshot 3: Server List tab]

## 4. Launching the Client App

1. Open the client package folder.
2. Double-click `ClientDiscoveryGUI.exe`.
3. Start on `1. Welcome`, then move to `2. Configuration`, then `3. Server List`.

If prompted by endpoint security controls, allow local execution from the trusted package folder.

## 5. Configuration Tab - Field-by-Field Guide

## 5.1 Output and Collection

Field: Output Directory

- What it does: Root folder where JSON, reports, logs, and ZIP outputs are written.
- Default: `C:\Avanade\<username>`
- Recommendation: Use a short local path with plenty of free space.

Recommended setting:

- Pilot/small run: `C:\Avanade\Discovery\Pilot`
- Production-scale run: `D:\Discovery\<WaveName>`

Why:

- Short local paths reduce file-path and permission issues.
- Dedicated folders simplify packaging and cleanup.

Field: Max Threads (also shown in Server List sidebar)

- What it does: Concurrency per OS type for collector runs.
- Default: `10`
- Range: `1` to `50`

Recommendations:

- 1-25 servers: `8-10`
- 25-100 servers: `10-16`
- 100+ servers: `16-24` only if network and remote endpoints tolerate concurrency

Why:

- Higher values shorten runtime but increase connection pressure and potential throttling.

## 5.2 Log Analytics Export Options

Fields:

- Subscription
- Workspace RG
- Workspace
- Timespan

Timespan options:

- `30d` (default)
- `14d`
- `7d`
- `24h`
- `1h`

Recommendations:

- Default assessment: `30d`
- Focused troubleshooting: `7d`
- Validation retest: `24h`

Why:

- Longer windows provide better historical behavior context.
- Short windows reduce noise and query volume during validation.

## 5.3 Access Check Options

Fields:

- RDP Port (default `3389`)
- PS Timeout (sec) (default `5`)
- Max Concurrent (default `8`)

Recommendations:

- RDP Port: keep `3389` unless your environment uses a custom port.
- PS Timeout: `5` for LAN; `8-12` for high-latency or restricted networks.
- Max Concurrent: start `8`; raise to `10-16` only after stable pilot results.

Why:

- Lower timeout can produce false failures on slower links.
- Excessive concurrency can produce intermittent access failures.

## 5.4 Credentials

Mode A: Interactive prompt

- Behavior: requests credentials each run.
- Use when: short, ad-hoc operation or highly restricted credential policy.

Mode B: Encrypted settings.json (DPAPI)

- Behavior: stores encrypted credentials tied to current user and machine.
- Use when: repeated runs by same operator on same workstation.

Recommendations:

- Use encrypted mode for repeatable multi-wave operations.
- Use interactive mode for one-time secure sessions.

Tabs in credential panel:

- Windows (WinRM)
- Linux (SSH)
- SQL

Tip:

- `Copy these credentials to Linux and SQL tabs when saving` is useful when one service account is intentionally shared.

## 6. Server List Tab - How to Operate

## 6.1 Load a Server List

1. Click `LoadCSV`.
2. Pick a CSV file.
3. Grid loads immediately.

Minimum practical columns:

- `ServerName` (or `Server`)
- `OSType` (`Windows` or `Linux`)

## 6.2 Toolbar Buttons

- `LoadCSV`: browse and immediately load CSV into grid.
- `Load Results`: load artifact HTML results into grid.
- `Latest` checkbox (default checked):
  - Checked: use latest artifact behavior (and generate if needed).
  - Unchecked: open picker at `OutputDir\Reports\ArtifactReport` to choose an HTML report.
- `Save`: save current grid to CSV.
- `Sample`: load packaged sample CSV.
- `+ Row`: append blank row.
- `- Row`: delete selected rows.
- `Select All`: select all rows.
- `Clear`: clear selection.

## 6.3 Selection Rules (Very Important)

Execution scope is determined by current grid selection:

- No rows selected: action runs against all rows.
- Some rows selected: action runs only against selected rows.
- All rows selected: treated as all rows.

This applies to Access Check, collection actions, Log Analytics export, Artifact Report, and ZIP operations.

## 7. Server List Actions - What Each Button Does

The GUI builds a run CSV from selected/all rows and launches executable tools.

## 7.1 Workflow Buttons (Primary Sequence)

1. Access Check

- Purpose: validate admin/remoting access before full collection.
- Executable: `Scripts\AdminAccessAndRDPCheck.exe`
- Key inputs: run CSV, output directory, RDP/timeout/concurrency, credential mode.

2. Run All Data Collectors

- Purpose: full baseline collection.
- Executable: `Scripts\ServerDataCollector.exe`
- Key inputs: run CSV, output directory, check type, max threads, credential mode.

3. Export Log Analytics

- Purpose: workspace-based operational data export.
- Executable target in client package: `Scripts\Avanade-ExportLogAnalyticsData.exe`
- Key inputs: run CSV, output directory, LA subscription/workspace/timespan.

4. Generate Artifact Report

- Purpose: generate HTML summary report from collected evidence.
- Executable: `Scripts\Generate-ArtifactReport.exe`
- Output: HTML report under `OutputDir\Reports\ArtifactReport`.

5. ZIP Output for Delivery

- Purpose: package deliverables for handoff.
- Executable: `Scripts\ZipOutput.exe`
- Output: ZIP files under `OutputDir\ZIPFiles`.

## 7.2 Individual Data Collectors

Server Data Only

- Executable: `Scripts\ServerDataCollector.exe` with server-only mode.
- Purpose: quick inventory without extra SQL/IIS/EventLog deep collection.

Collect SQL

- Executable: `Scripts\WindowsVM\CollectSQLData.exe`
- Purpose: SQL-specific discovery details.

Collect IIS

- Executable: `Scripts\WindowsVM\CollectIISData.exe`
- Purpose: IIS/web app discovery details.

Event Log

- Executable: `Scripts\WindowsVM\MigrationCheck-DataCollector.exe`
- Purpose: targeted event log extraction.

IP Scan

- Executable: `Scripts\WindowsVM\MigrationCheck-ScanIP.exe`
- Purpose: scan for hardcoded IP references.

## 8. Load Results - Operational Modes

Mode A: Latest checked

- Typical behavior:
  - Load latest artifact report if present.
  - If missing, generate then load.

Mode B: Latest unchecked

- Behavior:
  - Opens file picker at `OutputDir\Reports\ArtifactReport`.
  - Operator selects any HTML report to load into grid.

Use Mode B when reviewing historical runs, not just the latest.

## 9. Recommended Baseline Settings (Client Default Profile)

For first production wave:

- Output Directory: dedicated local path (non-Desktop, non-OneDrive sync path)
- Max Threads: `10`
- Access Check:
  - RDP Port `3389`
  - PS Timeout `8`
  - Max Concurrent `8`
- Log Analytics Timespan: `30d`
- Credentials: Encrypted settings mode for repeatability

Why this baseline:

- Balanced performance and stability.
- Reduced chance of transient failures on mixed network quality.
- Reproducible reruns across multiple waves.

## 10. Typical End-to-End Runbook (Operator Checklist)

1. Open `ClientDiscoveryGUI.exe`.
2. Configuration tab:
   - Set Output Directory.
   - Set LA fields (subscription/RG/workspace/timespan).
   - Confirm Access Check settings.
   - Configure credential mode and save if encrypted.
3. Server List tab:
   - `LoadCSV` and validate grid.
   - Select rows for scope, or leave none selected for all.
4. Run in order:
   - Access Check
   - Run All Data Collectors
   - Export Log Analytics
   - Generate Artifact Report
   - Load Results (Latest checked)
   - ZIP Output for Delivery
5. Deliver ZIP from `OutputDir\ZIPFiles`.

## 11. Troubleshooting

Issue: No grid data loaded

- Fix: use `LoadCSV` or `Load Results` before running actions.

Issue: Output directory missing

- Fix: set valid Output Directory in Configuration.

Issue: Credentials fail in encrypted mode

- Fix: re-save credentials under same Windows user and machine.

Issue: Log Analytics export validation errors

- Fix: ensure subscription, workspace RG, workspace name, and timespan are populated.

Issue: Action ran on wrong server scope

- Fix: verify row selection before execution; no selection means all rows.

## 12. Appendix - Suggested Screenshot Captions

- Figure 1: Welcome tab with recommended workflow panel
- Figure 2: Configuration tab overview
- Figure 3: Log Analytics export settings
- Figure 4: Credentials mode selection
- Figure 5: Server List toolbar and selection controls
- Figure 6: Numbered workflow actions in sidebar
- Figure 7: Confirm Command dialog before run
- Figure 8: Loaded artifact results grid
- Figure 9: ZIP output folder contents
