# Screenshot Placement

Place client-approved screenshots in this folder using the suggested names below:

1. 01-welcome-overview.png
2. 02-configuration-overview.png
3. 03-output-and-collection.png
4. 04-log-analytics-settings.png
5. 05-access-check-options.png
6. 06-credentials-interactive.png
7. 07-credentials-encrypted.png
8. 08-serverlist-toolbar.png
9. 09-serverlist-workflow-buttons.png
10. 10-grid-selection-example.png
11. 11-load-results-latest.png
12. 12-load-results-picker.png
13. 13-confirm-command-dialog.png
14. 14-artifact-results-grid.png
15. 15-zip-output-example.png

Use this folder as the source when assembling a client-facing PDF or Word guide.
