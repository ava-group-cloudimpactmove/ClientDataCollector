#!/bin/bash
# =============================================================================
# MigrationCheck-DataCollector.sh
# Avanade Migration Check - Linux Data Collector
# 
# SYNOPSIS:
#   Performs pre/post-migration data collection on a Linux server and generates
#   a structured JSON file for processing by MigrationCheck-HtmlGenerator.ps1.
#   Mirrors the field names and JSON structure used by the Windows
#   MigrationCheck-DataCollector.ps1 where applicable.
#
# USAGE:
#   bash MigrationCheck-DataCollector.sh <CheckType>
#   CheckType: Pre_Migration | Post_Migration | Test_Migration
#
# AUTHOR: Avanade Migration Team
# VERSION: 26.05.12
#
# CHANGELOG:
#   26.05.12: Refactored from MigrationCheckJSON.sh. Aligned JSON field names
#             with Windows MigrationCheck-DataCollector.ps1. Added: CPU count,
#             memory detail, RAID/mdadm, NFS shares, cron scheduled tasks,
#             journald event logs, process details, patch/update details,
#             migration validation checks. Fixed subshell variable scoping by
#             using process substitution (< <()) instead of piped while loops.
#             Removed strict mode - data collectors continue on individual
#             command failures.
# =============================================================================

# Data collection scripts must continue even when individual commands fail.
# Do NOT use 'set -e' or 'set -o pipefail' here.

# --- Argument handling ---
CHECKTYPE="${1:-}"
if [ -z "$CHECKTYPE" ]; then
  read -rp "CheckType (Pre_Migration / Post_Migration / Test_Migration): " CHECKTYPE
fi

case "$CHECKTYPE" in
  Pre_Migration|Post_Migration|Test_Migration) ;;
  *)
    echo "ERROR: CheckType must be Pre_Migration, Post_Migration, or Test_Migration" >&2
    exit 1
    ;;
esac

SCRIPT_VERSION="26.05.12"
TIMESTAMP=$(date -u +"%Y-%m-%d %H:%M:%S UTC")
echo "[$(date '+%Y-%m-%d %H:%M:%S')] MigrationCheck-DataCollector.sh v${SCRIPT_VERSION} starting. CheckType=${CHECKTYPE}"

# --- JSON escape helper (no jq required) ---
esc() {
  printf '%s' "$1" \
    | sed 's/\\/\\\\/g; s/"/\\"/g; s/	/\\t/g' \
    | tr -d '\r' \
    | awk '{printf "%s\\n", $0}' \
    | sed '$ s/\\n$//'
}

jline() { printf '%s\n' "$1" >> "$JSON_FILE"; }

get_nfs_mounts() {
  if command -v findmnt &>/dev/null; then
    findmnt -rn -t nfs,nfs4 -o SOURCE,TARGET,FSTYPE,OPTIONS 2>/dev/null | awk 'NF{
      src=$1; target=$2; fstype=$3; $1=$2=$3=""; sub(/^ +/,"");
      printf "%s|%s|%s|%s\n", src, target, fstype, $0
    }'
  elif [ -r /proc/mounts ]; then
    awk '$3=="nfs" || $3=="nfs4" {printf "%s|%s|%s|%s\n",$1,$2,$3,$4}' /proc/mounts 2>/dev/null
  fi
}

# --- Detect OS ---
if [ -f /etc/os-release ]; then
  . /etc/os-release
  OS_PRETTY="${PRETTY_NAME:-Unknown}"
  OS_ID="${ID:-unknown}"
  OS_FAMILY="${ID_LIKE:-$OS_ID}"
else
  OS_PRETTY="$(uname -s)"
  OS_ID="unknown"
  OS_FAMILY="unknown"
fi

HOSTNAME=$(hostname)
HOSTNAME_SHORT=$(hostname | cut -d'.' -f1)
DOMAIN=$(hostname -d 2>/dev/null || echo "")
ARCH=$(uname -m)
KERNEL=$(uname -r)
TIMEZONE=$(timedatectl show --property=Timezone --value 2>/dev/null \
           || timedatectl 2>/dev/null | awk '/Time zone/{print $3}' \
           || cat /etc/timezone 2>/dev/null \
           || echo "Unknown")
IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "Unknown")
CPU_MODEL=$(lscpu 2>/dev/null | awk -F': +' '/^Model name/{print $2; exit}' || echo "Unknown")
CPU_COUNT=$(nproc 2>/dev/null || echo "0")
CPU_SOCKETS=$(lscpu 2>/dev/null | awk -F': +' '/^Socket\(s\)/{print $2; exit}' || echo "")
CPU_CORES_PER=$(lscpu 2>/dev/null | awk -F': +' '/^Core\(s\) per socket/{print $2; exit}' || echo "")
CPU_THREADS_PER=$(lscpu 2>/dev/null | awk -F': +' '/^Thread\(s\) per core/{print $2; exit}' || echo "")
RAM_TOTAL=$(free -h 2>/dev/null | awk '/^Mem/{print $2}' || echo "Unknown")
RAM_TOTAL_BYTES=$(awk '/MemTotal/{print $2}' /proc/meminfo 2>/dev/null || echo "0")
RAM_AVAILABLE=$(free -h 2>/dev/null | awk '/^Mem/{print $4}' || echo "Unknown")
LAST_BOOT=$(who -b 2>/dev/null | awk '{print $3, $4}' || uptime -s 2>/dev/null || echo "Unknown")
UPTIME=$(uptime -p 2>/dev/null || echo "Unknown")
UPTIME_SECONDS=$(awk '{printf "%d", $1}' /proc/uptime 2>/dev/null || echo "0")

case "$OS_ID" in
  ubuntu|debian)      FIREWALL=$(systemctl is-active ufw 2>/dev/null || echo "inactive") ;;
  rhel|centos|ol|rocky|almalinux|fedora) FIREWALL=$(systemctl is-active firewalld 2>/dev/null || echo "inactive") ;;
  *) FIREWALL=$(systemctl is-active firewalld 2>/dev/null || systemctl is-active ufw 2>/dev/null || echo "unknown") ;;
esac

SELINUX_STATUS="Not installed"
APPARMOR_STATUS="Not installed"
if command -v getenforce &>/dev/null; then
  SELINUX_STATUS=$(getenforce 2>/dev/null || echo "Unknown")
elif [ -f /etc/selinux/config ]; then
  SELINUX_STATUS=$(awk -F= '/^SELINUX=/{print $2}' /etc/selinux/config 2>/dev/null | tr -d ' ') || true
fi
if command -v aa-status &>/dev/null; then
  aa-status --enabled 2>/dev/null && APPARMOR_STATUS="enabled" || APPARMOR_STATUS="disabled"
fi

NIC_COUNT=$(ip link show 2>/dev/null | grep -c '^[0-9]') || NIC_COUNT=0

REBOOT_REQUIRED="No"
if [ -f /var/run/reboot-required ]; then
  REBOOT_REQUIRED="Yes"
elif command -v needs-restarting &>/dev/null; then
  needs-restarting -r &>/dev/null || REBOOT_REQUIRED="Yes"
fi

PRODUCT_ID=$(sudo cat /sys/class/dmi/id/product_uuid 2>/dev/null || cat /sys/class/dmi/id/product_uuid 2>/dev/null || echo "Unknown")
PRODUCT_NAME=$(cat /sys/class/dmi/id/product_name 2>/dev/null || echo "Unknown")
MANUFACTURER=$(cat /sys/class/dmi/id/sys_vendor 2>/dev/null || echo "Unknown")

# ── Windows-aligned derived values ─────────────────────────────────────────
RAM_TOTAL_GB=$(awk "BEGIN {printf \"%.1f\", ${RAM_TOTAL_BYTES:-0} / 1048576}")
UPTIME_DAYS=$(awk "BEGIN {printf \"%.1f\", ${UPTIME_SECONDS:-0} / 86400}")
RAM_USED_BYTES=$(awk '/MemAvailable/{a=$2} /MemTotal/{t=$2} END{print t-a}' /proc/meminfo 2>/dev/null || echo "0")
CURRENT_MEMORY_PCT=$(awk "BEGIN {printf \"%.2f%%\", (${RAM_USED_BYTES:-0} / ${RAM_TOTAL_BYTES:-1}) * 100}")
CURRENT_CPU_PCT=$(top -bn1 2>/dev/null | awk '/[Cc]pu\(s\)|^%Cpu/{for(i=1;i<=NF;i++) if($i~/id/) {id=$(i-1); gsub(/%/,"",id); printf "%.2f%%", 100-id; exit}}' 2>/dev/null || echo "Unknown")
TOTAL_DISK_GB=$(lsblk -bdno SIZE,TYPE 2>/dev/null | awk '$2=="disk"{s+=$1} END{printf "%.0f", s/1073741824}' || echo "0")
DOMAIN_JOINED="false"
[ -n "$DOMAIN" ] && DOMAIN_JOINED="true"
RAN_ON=$(date '+%Y-%m-%d %H:%M:%S')
PENDING_UPDATES_COUNT=0
case "$OS_ID" in
  ubuntu|debian)
    PENDING_UPDATES_COUNT=$(apt list --upgradable 2>/dev/null | grep -vc '^Listing' || echo "0") ;;
  rhel|centos|ol|rocky|almalinux|fedora)
    PENDING_UPDATES_COUNT=$(yum check-update --quiet 2>/dev/null | awk 'NF==3 && !/^$/ && !/^Loading/{c++} END{print c+0}') ;;
esac
EVENT_LOG_ERRORS_LAST_WEEK=$(journalctl --since "7 days ago" -p 3 --no-pager -q 2>/dev/null | wc -l | tr -d ' ' || echo "0")

ORACLE_INSTALLED="No"
ORACLE_RUNNING="No"
ORACLE_DETAILS=""
if command -v sqlplus &>/dev/null || command -v lsnrctl &>/dev/null || id oracle &>/dev/null || [ -d /u01/app/oracle ] || [ -d /opt/oracle ]; then
  ORACLE_INSTALLED="Yes"
fi
case "$OS_ID" in
  ubuntu|debian)
    if dpkg-query -W -f='${Package}\n' 2>/dev/null | grep -Eiq '^(oracle|oracle-|.*oracle.*(database|client|instantclient|listener))'; then
      ORACLE_INSTALLED="Yes"
    fi
    ;;
  rhel|centos|ol|rocky|almalinux|fedora|sles|opensuse*)
    if rpm -qa 2>/dev/null | grep -Eiq '^(oracle|oracle-|.*oracle.*(database|client|instantclient|listener))'; then
      ORACLE_INSTALLED="Yes"
    fi
    ;;
esac
ORACLE_PROCESSES=$(ps -eo pid=,comm= 2>/dev/null | awk '$2 ~ /^ora_/ || $2 == "tnslsnr" || $2 == "oracle" {print $1 ":" $2}' | head -10 | tr '\n' ';' | sed 's/;$//')
if [ -n "$ORACLE_PROCESSES" ]; then
  ORACLE_RUNNING="Yes"
  ORACLE_INSTALLED="Yes"
  ORACLE_DETAILS="$ORACLE_PROCESSES"
elif systemctl list-units --type=service --all --no-legend --no-pager 2>/dev/null | grep -Eiq '(oracle|dbora|tnslsnr|listener)'; then
  ORACLE_INSTALLED="Yes"
  ORACLE_DETAILS="Oracle-related service detected"
fi

OUTPUT_DIR="${OUTPUT_DIR:-$(pwd)}"
mkdir -p "$OUTPUT_DIR"
JSON_FILE="${OUTPUT_DIR}/${HOSTNAME_SHORT^^}_${CHECKTYPE}.json"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Writing JSON to: $JSON_FILE"
> "$JSON_FILE"

# ============================================================
jline '{'
jline '    "SystemOverview": {'
jline "      \"ServerName\": \"$(esc "$HOSTNAME")\","
jline "      \"OperatingSystem\": \"$(esc "$OS_PRETTY")\","
jline "      \"OSFamily\": \"$(esc "$OS_FAMILY")\","
jline "      \"KernelVersion\": \"$(esc "$KERNEL")\","
jline "      \"Architecture\": \"$(esc "$ARCH")\","
jline "      \"IPAddress\": \"$(esc "$IP")\","
jline "      \"NumberOfCores\": $CPU_COUNT,"
jline "      \"RAM(GB)\": $RAM_TOTAL_GB,"
jline "      \"TotalDiskSpaceGB\": $TOTAL_DISK_GB,"
jline "      \"Environment\": \"$(esc "$PRODUCT_NAME")\","
jline "      \"Manufacturer\": \"$(esc "$MANUFACTURER")\","
jline "      \"ProductID\": \"$(esc "$PRODUCT_ID")\","
jline "      \"LastRebootTime\": \"$(esc "$LAST_BOOT")\","
jline "      \"Uptime(Days)\": $UPTIME_DAYS,"
jline "      \"PendingReboot\": \"$(esc "$REBOOT_REQUIRED")\","
jline "      \"PendingUpdates\": $PENDING_UPDATES_COUNT,"
jline "      \"EventLogErrorsLastWeek\": $EVENT_LOG_ERRORS_LAST_WEEK,"
jline "      \"NICCount\": $NIC_COUNT,"
jline "      \"CPUModel\": \"$(esc "$CPU_MODEL")\","
jline "      \"CPUSockets\": \"$(esc "$CPU_SOCKETS")\","
jline "      \"CPUCoresPerSocket\": \"$(esc "$CPU_CORES_PER")\","
jline "      \"CPUThreadsPerCore\": \"$(esc "$CPU_THREADS_PER")\","
jline "      \"RAMAvailable\": \"$(esc "$RAM_AVAILABLE")\","
jline "      \"CurrentCPU%\": \"$(esc "$CURRENT_CPU_PCT")\","
jline "      \"CurrentMemory%\": \"$(esc "$CURRENT_MEMORY_PCT")\","
jline "      \"FirewallStatus\": \"$(esc "$FIREWALL")\","
jline "      \"SELinuxStatus\": \"$(esc "$SELINUX_STATUS")\","
jline "      \"AppArmorStatus\": \"$(esc "$APPARMOR_STATUS")\","
jline "      \"TimeZone\": \"$(esc "$TIMEZONE")\","
jline "      \"OracleInstalled\": \"$(esc "$ORACLE_INSTALLED")\","
jline "      \"OracleRunning\": \"$(esc "$ORACLE_RUNNING")\","
jline "      \"OracleDetails\": \"$(esc "$ORACLE_DETAILS")\","
jline "      \"DomainJoined\": $DOMAIN_JOINED,"
jline "      \"DomainName\": \"$(esc "$DOMAIN")\","
jline "      \"ScriptVersion\": \"$(esc "$SCRIPT_VERSION")\","
jline "      \"ReportGeneratedAt\": \"$(esc "$TIMESTAMP")\","
jline "      \"RanOn\": \"$(esc "$RAN_ON")\","
jline "      \"CheckType\": \"$(esc "$CHECKTYPE")\""
jline '    },'

# ============================================================
# PatchDetails
# ============================================================
jline '    "PatchDetails": ['
FIRST=1
case "$OS_ID" in
  ubuntu|debian)
    while IFS='|' read -r name ver arch; do
      [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
      jline "      {\"Name\":\"$(esc "$name")\",\"Version\":\"$(esc "$ver")\",\"Architecture\":\"$(esc "$arch")\"}"
      FIRST=0
    done < <(apt-get -q --simulate upgrade 2>/dev/null | awk '/^Inst /{
      name=$2; ver=""; arch="";
      for(i=3;i<=NF;i++){
        if($i ~ /^\[/){ v=$i; gsub(/[\[\]()]/,"",v); arch=v }
        if($i ~ /^\(/ && ver==""){ v=$i; gsub(/[()]/,"",v); split(v,a,","); ver=a[1] }
      }
      printf "%s|%s|%s\n", name, ver, arch
    }')
    ;;
  rhel|centos|ol|rocky|almalinux|fedora)
    while IFS='|' read -r name ver arch; do
      [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
      jline "      {\"Name\":\"$(esc "$name")\",\"Version\":\"$(esc "$ver")\",\"Architecture\":\"$(esc "$arch")\"}"
      FIRST=0
    done < <(yum check-update --quiet 2>/dev/null | awk 'NF==3 && !/^$/ && !/^Loading/ && !/^Last/{printf "%s|%s|%s\n",$1,$2,$3}')
    ;;
esac
[ $FIRST -eq 1 ] && jline '      {"Name":"Up to date","Version":"","Architecture":""}'
jline '    ],'

# ============================================================
# DiskDetails
# ============================================================
jline '    "DiskDetails": ['
FIRST=1
while read -r fs type size used avail usepct mnt; do
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"Filesystem\":\"$(esc "$fs")\",\"Type\":\"$(esc "$type")\",\"Size\":\"$(esc "$size")\",\"Used\":\"$(esc "$used")\",\"Available\":\"$(esc "$avail")\",\"UsedPercent\":\"$(esc "$usepct")\",\"MountPoint\":\"$(esc "$mnt")\"}"
  FIRST=0
done < <(df -hPT 2>/dev/null | awk 'NR>1{print $1,$2,$3,$4,$5,$6,$7}')
[ $FIRST -eq 1 ] && jline '      {"Filesystem":"","Type":"","Size":"","Used":"","Available":"","UsedPercent":"","MountPoint":"No disk data"}'
jline '    ],'

# ============================================================
# VolumeDetails (lsblk via python3 inline heredoc)
# ============================================================
jline '    "VolumeDetails": ['
FIRST=1
_py_vol=$(python3 - << 'PYEOF' 2>/dev/null
import json, sys, subprocess
try:
    result = subprocess.run(['lsblk','-o','NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,UUID,LABEL','-J'],
                            capture_output=True, text=True, timeout=30)
    d = json.loads(result.stdout)
    def flatten(node):
        rows=[node]
        for c in node.get('children',[]):
            rows+=flatten(c)
        return rows
    devs=d.get('blockdevices',[])
    all_devs=[dev for n in devs for dev in flatten(n)]
    lines=[]
    for item in all_devs:
        lines.append(json.dumps({'Name':item.get('name') or '','Size':item.get('size') or '',
            'Type':item.get('type') or '','FileSystem':item.get('fstype') or '',
            'MountPoint':item.get('mountpoint') or '','UUID':item.get('uuid') or '',
            'Label':item.get('label') or ''}))
    print('\n'.join(lines))
except:
    pass
PYEOF
)
while IFS= read -r vol_line; do
  [ -z "$vol_line" ] && continue
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      $vol_line"
  FIRST=0
done <<< "$_py_vol"
[ $FIRST -eq 1 ] && jline '      {"Name":"","Size":"","Type":"","FileSystem":"","MountPoint":"No volume data","UUID":"","Label":""}'
jline '    ],'

# ============================================================
# FSTAB
# ============================================================
jline '    "FSTAB": ['
FIRST=1
while read -r dev mnt typ opt; do
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"Device\":\"$(esc "$dev")\",\"MountPoint\":\"$(esc "$mnt")\",\"Type\":\"$(esc "$typ")\",\"Options\":\"$(esc "$opt")\"}"
  FIRST=0
done < <(awk '($1 !~ /^#/ && NF >= 4){print $1,$2,$3,$4}' /etc/fstab 2>/dev/null)
[ $FIRST -eq 1 ] && jline '      {"Device":"","MountPoint":"","Type":"","Options":"No FSTAB entries"}'
jline '    ],'

# ============================================================
# NFSMountDetails
# ============================================================
jline '    "NFSMountDetails": ['
FIRST=1
while IFS='|' read -r nfs_source nfs_target nfs_type nfs_options; do
  [ -z "$nfs_source" ] && continue
  if [[ "$nfs_source" == \[*\]:* ]]; then
    NFS_SERVER="${nfs_source%%]:*}"
    NFS_SERVER="${NFS_SERVER#[}"
    NFS_REMOTE_PATH="${nfs_source#*]:}"
  elif [[ "$nfs_source" == *:* ]]; then
    NFS_SERVER="${nfs_source%%:*}"
    NFS_REMOTE_PATH="${nfs_source#*:}"
  else
    NFS_SERVER="$nfs_source"
    NFS_REMOTE_PATH=""
  fi
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"Source\":\"$(esc "$nfs_source")\",\"Server\":\"$(esc "$NFS_SERVER")\",\"RemotePath\":\"$(esc "$NFS_REMOTE_PATH")\",\"MountPoint\":\"$(esc "$nfs_target")\",\"Type\":\"$(esc "$nfs_type")\",\"Options\":\"$(esc "$nfs_options")\"}"
  FIRST=0
done < <(get_nfs_mounts)
[ $FIRST -eq 1 ] && jline '      {"Source":"None","Server":"","RemotePath":"","MountPoint":"","Type":"","Options":"No NFS mounts found"}'
jline '    ],'

# ============================================================
# RAIDDetails
# ============================================================
jline '    "RAIDDetails": ['
FIRST=1
if command -v mdadm &>/dev/null && [ -f /proc/mdstat ]; then
  while IFS= read -r line; do
    echo "$line" | grep -qE '^md[0-9]+' || continue
    ARRAY=$(echo "$line" | awk '{print $1}')
    RAID_STATUS=$(echo "$line" | awk '{print $3}')
    RAID_LEVEL=$(echo "$line" | grep -oE 'raid[0-9]+' || echo "unknown")
    MEMBERS=$(echo "$line" | grep -oE '[a-z]+[0-9]+\[[0-9]+\]' | tr '\n' ' ' || echo "")
    [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
    jline "      {\"Array\":\"$(esc "$ARRAY")\",\"Status\":\"$(esc "$RAID_STATUS")\",\"Level\":\"$(esc "$RAID_LEVEL")\",\"Members\":\"$(esc "$MEMBERS")\"}"
    FIRST=0
  done < /proc/mdstat
fi
[ $FIRST -eq 1 ] && jline '      {"Array":"None","Status":"No RAID arrays","Level":"","Members":""}'
jline '    ],'

# ============================================================
# ShareDetails (NFS + Samba)
# ============================================================
jline '    "ShareDetails": ['
FIRST=1
if [ -f /etc/exports ]; then
  while IFS= read -r share_line; do
    PATH_PART=$(echo "$share_line" | awk '{print $1}')
    OPTS_PART=$(echo "$share_line" | cut -d' ' -f2-)
    [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
    jline "      {\"ShareName\":\"$(esc "$PATH_PART")\",\"Type\":\"NFS\",\"Path\":\"$(esc "$PATH_PART")\",\"Options\":\"$(esc "$OPTS_PART")\"}"
    FIRST=0
  done < <(awk '!/^#/ && NF' /etc/exports 2>/dev/null)
fi
if command -v testparm &>/dev/null; then
  while IFS='|' read -r sname spath scomment; do
    [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
    jline "      {\"ShareName\":\"$(esc "$sname")\",\"Type\":\"Samba\",\"Path\":\"$(esc "$spath")\",\"Options\":\"$(esc "$scomment")\"}"
    FIRST=0
  done < <(testparm -s 2>/dev/null | awk '
    /^\[/ && !/^\[global\]/ && !/^\[printers\]/ && !/^\[print\$\]/ {
      share=substr($0,2,length($0)-2); path=""; comment=""
    }
    /path =/ {path=$3}
    /comment =/ {$1=$2=""; comment=substr($0,3)}
    /^\[/ && path!="" {print share "|" path "|" comment; path=""}
  ')
fi
[ $FIRST -eq 1 ] && jline '      {"ShareName":"None","Type":"","Path":"","Options":"No shares found"}'
jline '    ],'

# ============================================================
# NetworkInterfaces
# ============================================================
jline '    "NetworkInterfaces": ['
FIRST=1
while read -r ifnum ifname fam addr rest; do
  MAC=$(cat "/sys/class/net/${ifname}/address" 2>/dev/null || echo "")
  MTU=$(cat "/sys/class/net/${ifname}/mtu" 2>/dev/null || echo "")
  STATE=$(cat "/sys/class/net/${ifname}/operstate" 2>/dev/null || echo "")
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"IfIndex\":\"$(esc "$ifnum")\",\"Interface\":\"$(esc "$ifname")\",\"Family\":\"$(esc "$fam")\",\"Address\":\"$(esc "$addr")\",\"MAC\":\"$(esc "$MAC")\",\"MTU\":\"$(esc "$MTU")\",\"State\":\"$(esc "$STATE")\",\"Details\":\"$(esc "$rest")\"}"
  FIRST=0
done < <(ip -o addr show 2>/dev/null)
[ $FIRST -eq 1 ] && jline '      {"IfIndex":"","Interface":"","Family":"","Address":"No NICs found","MAC":"","MTU":"","State":"","Details":""}'
jline '    ],'

# ============================================================
# HostsFile
# ============================================================
jline '    "HostsFile": ['
FIRST=1
while IFS= read -r line; do
  IP_H=$(echo "$line" | awk '{print $1}')
  HOST_H=$(echo "$line" | awk '{print $2}')
  ALIASES_H=$(echo "$line" | awk '{$1=$2=""; sub(/^  */,""); print}')
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"IP\":\"$(esc "$IP_H")\",\"HostName\":\"$(esc "$HOST_H")\",\"Aliases\":\"$(esc "$ALIASES_H")\"}"
  FIRST=0
done < <(awk '!/^#/ && NF' /etc/hosts 2>/dev/null)
[ $FIRST -eq 1 ] && jline '      {"IP":"","HostName":"","Aliases":"Hosts file empty"}'
jline '    ],'

# ============================================================
# RouteTable
# ============================================================
jline '    "RouteTable": ['
FIRST=1
while IFS= read -r route_line; do
  DEST=$(echo "$route_line" | awk '{print $1}')
  GW=$(echo "$route_line" | grep -oP '(?<=via )[^ ]+' 2>/dev/null || echo "")
  DEV=$(echo "$route_line" | grep -oP '(?<=dev )[^ ]+' 2>/dev/null || echo "")
  PROTO=$(echo "$route_line" | grep -oP '(?<=proto )[^ ]+' 2>/dev/null || echo "")
  SCOPE=$(echo "$route_line" | grep -oP '(?<=scope )[^ ]+' 2>/dev/null || echo "")
  SRC=$(echo "$route_line" | grep -oP '(?<=src )[^ ]+' 2>/dev/null || echo "")
  METRIC=$(echo "$route_line" | grep -oP '(?<=metric )[^ ]+' 2>/dev/null || echo "0")
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"Destination\":\"$(esc "$DEST")\",\"Gateway\":\"$(esc "$GW")\",\"Interface\":\"$(esc "$DEV")\",\"Protocol\":\"$(esc "$PROTO")\",\"Scope\":\"$(esc "$SCOPE")\",\"PreferredSource\":\"$(esc "$SRC")\",\"Metric\":\"$(esc "$METRIC")\"}"
  FIRST=0
done < <(ip route show 2>/dev/null)
[ $FIRST -eq 1 ] && jline '      {"Destination":"","Gateway":"","Interface":"","Protocol":"","Scope":"","PreferredSource":"","Metric":"No routes"}'
jline '    ],'

# ============================================================
# PersistentRouteDetails
# ============================================================
jline '    "PersistentRouteDetails": ['
FIRST=1
for routefile in /etc/sysconfig/network-scripts/route-* /etc/network/interfaces /etc/netplan/*.yaml; do
  [ -f "$routefile" ] || continue
  ROUTE_CONTENT=$(cat "$routefile" 2>/dev/null | tr '\n' ' ' || echo "(unreadable)")
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"File\":\"$(esc "$routefile")\",\"Content\":\"$(esc "$ROUTE_CONTENT")\"}"
  FIRST=0
done
[ $FIRST -eq 1 ] && jline '      {"File":"None","Content":"No persistent route files found"}'
jline '    ],'

# ============================================================
# DNS
# ============================================================
jline '    "DomainNameServers": ['
FIRST=1
while read -r ns; do
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      \"$(esc "$ns")\""
  FIRST=0
done < <(awk '/^nameserver/{print $2}' /etc/resolv.conf 2>/dev/null)
[ $FIRST -eq 1 ] && jline '      ""'
jline '    ],'

DNS_OPTIONS=$(awk '/^options/{$1=""; print substr($0,2)}' /etc/resolv.conf 2>/dev/null || echo "")
DNS_SEARCH=$(awk '/^search/{$1=""; print substr($0,2)}' /etc/resolv.conf 2>/dev/null || echo "")
DNS_DOMAIN=$(awk '/^domain/{print $2; exit}' /etc/resolv.conf 2>/dev/null || echo "")
DNS_SORTLIST=$(awk '/^sortlist/{$1=""; print substr($0,2)}' /etc/resolv.conf 2>/dev/null || echo "")
DNS_NAMESERVERS=$(awk '/^nameserver/{print $2}' /etc/resolv.conf 2>/dev/null | paste -sd ',' -)
RESOLV_CONF_RAW=$(awk 'NF && $1 !~ /^#/{print}' /etc/resolv.conf 2>/dev/null | paste -sd ';' -)
jline '    "ResolvConf": {'
jline "      \"Nameservers\": \"$(esc "$DNS_NAMESERVERS")\","
jline "      \"SearchDomains\": \"$(esc "$DNS_SEARCH")\","
jline "      \"Domain\": \"$(esc "$DNS_DOMAIN")\","
jline "      \"Options\": \"$(esc "$DNS_OPTIONS")\","
jline "      \"SortList\": \"$(esc "$DNS_SORTLIST")\","
jline "      \"RawContent\": \"$(esc "$RESOLV_CONF_RAW")\""
jline '    },'

# ============================================================
# IPTables
# ============================================================
jline '    "IPTables": ['
FIRST=1
if command -v iptables &>/dev/null; then
  while IFS= read -r line; do
    [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
    jline "      {\"Rule\":\"$(esc "$line")\"}"
    FIRST=0
  done < <(sudo iptables -L -n -v --line-numbers 2>/dev/null)
fi
[ $FIRST -eq 1 ] && jline '      {"Rule":"iptables not available or no rules"}'
jline '    ],'

# ============================================================
# ListeningPorts
# ============================================================
jline '    "ListeningPorts": ['
FIRST=1
while read -r proto state recvq sendq localaddr foreignaddr rest; do
  PIDPROG=""
  for tok in $rest; do
    case "$tok" in users:*) PIDPROG="$tok" ;; esac
  done
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"Protocol\":\"$(esc "$proto")\",\"State\":\"$(esc "$state")\",\"RecvQ\":\"$(esc "$recvq")\",\"SendQ\":\"$(esc "$sendq")\",\"LocalAddress\":\"$(esc "$localaddr")\",\"ForeignAddress\":\"$(esc "$foreignaddr")\",\"PIDProgram\":\"$(esc "$PIDPROG")\"}"
  FIRST=0
done < <(ss -tunlp 2>/dev/null | tail -n +2)
[ $FIRST -eq 1 ] && jline '      {"Protocol":"","State":"","RecvQ":"","SendQ":"","LocalAddress":"","ForeignAddress":"","PIDProgram":"No listening ports"}'
jline '    ],'

# ============================================================
# InstalledSoftware
# ============================================================
jline '    "InstalledSoftware": ['
FIRST=1
case "$OS_ID" in
  ubuntu|debian)
    while IFS=$'\t' read -r name version arch desc; do
      [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
      jline "      {\"Name\":\"$(esc "$name")\",\"Version\":\"$(esc "$version")\",\"Architecture\":\"$(esc "$arch")\",\"Description\":\"$(esc "$desc")\"}"
      FIRST=0
    done < <(dpkg-query -W --showformat='${Package}\t${Version}\t${Architecture}\t${binary:Summary}\n' 2>/dev/null)
    ;;
  rhel|centos|ol|rocky|almalinux|fedora|sles|opensuse*)
    while IFS=$'\t' read -r name version arch desc; do
      [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
      jline "      {\"Name\":\"$(esc "$name")\",\"Version\":\"$(esc "$version")\",\"Architecture\":\"$(esc "$arch")\",\"Description\":\"$(esc "$desc")\"}"
      FIRST=0
    done < <(rpm -qa --qf '%{NAME}\t%{VERSION}-%{RELEASE}\t%{ARCH}\t%{SUMMARY}\n' 2>/dev/null)
    ;;
  *)
    jline '      {"Name":"Unsupported OS","Version":"N/A","Architecture":"N/A","Description":"Package query not supported"}'
    FIRST=0
    ;;
esac
[ $FIRST -eq 1 ] && jline '      {"Name":"No packages found","Version":"","Architecture":"","Description":""}'
jline '    ],'

# ============================================================
# ServiceDetails
# ============================================================
jline '    "ServiceDetails": ['
FIRST=1
# systemctl output columns:
#   Normal:    UNIT        LOAD    ACTIVE  SUB   DESCRIPTION...
#   Not-found: ●  UNIT     LOAD    ACTIVE  SUB   DESCRIPTION...
# Use IFS=$'\t' with awk producing tab-separated fields so that
# multi-word descriptions are preserved as a single field.
while IFS=$'\t' read -r name load active sub desc; do
  STARTTYPE=$(systemctl is-enabled "$name" 2>/dev/null || echo "unknown")
  DISPNAME="${desc:-$name}"
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"Name\":\"$(esc "$name")\",\"DisplayName\":\"$(esc "$DISPNAME")\",\"Load\":\"$(esc "$load")\",\"Status\":\"$(esc "$active")\",\"SubStatus\":\"$(esc "$sub")\",\"StartType\":\"$(esc "$STARTTYPE")\"}"
  FIRST=0
done < <(systemctl list-units --type=service --all --no-legend --no-pager 2>/dev/null | awk '
  NF >= 4 {
    if ($1 == "●") { n=$2; l=$3; a=$4; s=$5; d=""; for(i=6;i<=NF;i++) d=d (i>6?" ":"") $i }
    else           { n=$1; l=$2; a=$3; s=$4; d=""; for(i=5;i<=NF;i++) d=d (i>5?" ":"") $i }
    printf "%s\t%s\t%s\t%s\t%s\n", n, l, a, s, d
  }')
[ $FIRST -eq 1 ] && jline '      {"Name":"","DisplayName":"","Load":"","Status":"","SubStatus":"","StartType":"No services found"}'
jline '    ],'

# ============================================================
# ProcessDetails (top 50 by CPU)
# ============================================================
jline '    "ProcessDetails": ['
FIRST=1
while read -r user pid cpu mem cmd; do
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"User\":\"$(esc "$user")\",\"PID\":\"$(esc "$pid")\",\"CPU\":\"$(esc "$cpu")\",\"Memory\":\"$(esc "$mem")\",\"Command\":\"$(esc "$cmd")\"}"
  FIRST=0
done < <(ps aux --sort=-%cpu 2>/dev/null | awk 'NR>1 && NR<=51{print $1,$2,$3,$4,$11}')
[ $FIRST -eq 1 ] && jline '      {"User":"","PID":"","CPU":"","Memory":"","Command":"No processes found"}'
jline '    ],'

# ============================================================
# ScheduledTasks
# ============================================================
jline '    "ScheduledTasks": ['
FIRST=1
if [ -f /etc/crontab ]; then
  while IFS= read -r cron_line; do
    [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
    jline "      {\"Source\":\"/etc/crontab\",\"Entry\":\"$(esc "$cron_line")\"}"
    FIRST=0
  done < <(awk '!/^#/ && NF' /etc/crontab 2>/dev/null)
fi
if [ -d /etc/cron.d ]; then
  for cf in /etc/cron.d/*; do
    [ -f "$cf" ] || continue
    while IFS= read -r cron_line; do
      [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
      jline "      {\"Source\":\"$(esc "$cf")\",\"Entry\":\"$(esc "$cron_line")\"}"
      FIRST=0
    done < <(awk '!/^#/ && NF' "$cf" 2>/dev/null)
  done
fi
while IFS= read -r cron_line; do
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"Source\":\"root crontab\",\"Entry\":\"$(esc "$cron_line")\"}"
  FIRST=0
done < <(crontab -l 2>/dev/null | awk '!/^#/ && NF')
while IFS= read -r timer_line; do
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"Source\":\"systemd timer\",\"Entry\":\"$(esc "$timer_line")\"}"
  FIRST=0
done < <(systemctl list-timers --all --no-legend --no-pager 2>/dev/null | awk 'NF')
[ $FIRST -eq 1 ] && jline '      {"Source":"None","Entry":"No scheduled tasks found"}'
jline '    ],'

# ============================================================
# EventLogs (last 500 journald entries)
# ============================================================
jline '    "EventLogs": ['
FIRST=1
while IFS= read -r jentry; do
  TS=$(echo "$jentry" | awk '{print $1}')
  PROC=$(echo "$jentry" | awk '{print $3}' | sed 's/\[.*\]//; s/://')
  MSG=$(echo "$jentry" | cut -d' ' -f4- | sed 's/\\/\\\\/g; s/"/\\"/g')
  LEVEL="Information"
  echo "$MSG" | grep -qiE '^\s*(err|error|crit|alert|emerg)' && LEVEL="Error" || true
  echo "$MSG" | grep -qiE '^\s*(warn|warning)' && LEVEL="Warning" || true
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"TimeCreated\":\"$(esc "$TS")\",\"EntryType\":\"$(esc "$LEVEL")\",\"ProviderName\":\"$(esc "$PROC")\",\"Message\":\"$(esc "$MSG")\",\"LogName\":\"journal\"}"
  FIRST=0
done < <(journalctl -n 500 --no-pager --output=short-iso 2>/dev/null | tail -n +3)
[ $FIRST -eq 1 ] && jline '      {"TimeCreated":"","EntryType":"Information","ProviderName":"","Message":"No journal entries","LogName":"journal"}'
jline '    ],'

# ============================================================
# MigrationValidationChecks
# ============================================================
jline '    "MigrationChecks": ['
FIRST=1
add_check() {
  local check_name="$1" status="$2" result="$3" details="${4:-}"
  [ $FIRST -eq 0 ] && printf ',' >> "$JSON_FILE"
  jline "      {\"CheckName\":\"$(esc "$check_name")\",\"Status\":\"$(esc "$status")\",\"Result\":\"$(esc "$result")\",\"Details\":\"$(esc "$details")\"}"
  FIRST=0
}

case "$OS_ID" in
  ubuntu|debian|rhel|centos|ol|rocky|almalinux|fedora|sles|opensuse*)
    add_check "Operating System" "PASS" "$OS_PRETTY" "Supported OS family" ;;
  *) add_check "Operating System" "WARNING" "$OS_PRETTY" "OS family may require additional validation" ;;
esac

KERNEL_MAJOR=$(echo "$KERNEL" | cut -d. -f1)
if [ "$KERNEL_MAJOR" -ge 4 ] 2>/dev/null; then
  add_check "Kernel Version" "PASS" "$KERNEL" "Kernel 4.x or higher recommended for Azure"
else
  add_check "Kernel Version" "WARNING" "$KERNEL" "Kernel version may be too old for Azure VM extensions"
fi

DNS_CHECK=$(getent hosts microsoft.com 2>/dev/null | head -1 | awk '{print $1}' || echo "")
if [ -n "$DNS_CHECK" ]; then
  add_check "DNS Resolution" "PASS" "DNS resolved microsoft.com to $DNS_CHECK" ""
else
  add_check "DNS Resolution" "FAIL" "Unable to resolve microsoft.com" "Check /etc/resolv.conf"
fi

if [ -n "$DNS_NAMESERVERS" ] || [ -n "$DNS_SEARCH" ]; then
  add_check "resolv.conf Configuration" "WARNING" "Nameservers: ${DNS_NAMESERVERS:-none}; Search: ${DNS_SEARCH:-none}; Domain: ${DNS_DOMAIN:-none}; Options: ${DNS_OPTIONS:-none}; SortList: ${DNS_SORTLIST:-none}" "Review DNS servers and DNS suffix search order for the target network"
else
  add_check "resolv.conf Configuration" "INFO" "No resolv.conf DNS directives detected" ""
fi

NFS_MOUNT_COUNT=$(get_nfs_mounts | awk 'NF' | wc -l | tr -d ' ')
if [ "$NFS_MOUNT_COUNT" -gt 0 ] 2>/dev/null; then
  NFS_MOUNT_SUMMARY=$(get_nfs_mounts | awk -F'|' '{print $1 " mounted on " $2}' | paste -sd ';' -)
  add_check "External NFS Mounts" "WARNING" "$NFS_MOUNT_COUNT NFS mount(s) detected: $NFS_MOUNT_SUMMARY" "Validate external NFS server reachability, firewall rules, DNS, and mount dependencies after migration"
else
  add_check "External NFS Mounts" "PASS" "No NFS mounts detected" ""
fi

if [ "$ORACLE_RUNNING" = "Yes" ]; then
  add_check "Oracle Database" "WARNING" "Oracle installed and running" "Validate Oracle application/database migration dependencies"
elif [ "$ORACLE_INSTALLED" = "Yes" ]; then
  add_check "Oracle Database" "WARNING" "Oracle installed but no running process detected" "Validate Oracle application/database migration dependencies"
else
  add_check "Oracle Database" "INFO" "Oracle not detected" ""
fi

HTTPS_CHECK=$(curl -s --connect-timeout 5 -o /dev/null -w "%{http_code}" https://management.azure.com 2>/dev/null || echo "000")
if [ "$HTTPS_CHECK" != "000" ]; then
  add_check "Azure HTTPS Connectivity" "PASS" "HTTP $HTTPS_CHECK to management.azure.com" ""
else
  add_check "Azure HTTPS Connectivity" "WARNING" "Could not reach management.azure.com" "Outbound HTTPS (443) may be blocked"
fi

if [ "$FIREWALL" = "active" ] || [ "$FIREWALL" = "running" ]; then
  add_check "Firewall Status" "WARNING" "Firewall is active ($FIREWALL)" "Review rules before migration - Azure NSGs will control traffic"
else
  add_check "Firewall Status" "INFO" "Firewall is $FIREWALL" ""
fi

if [ "$SELINUX_STATUS" = "Enforcing" ]; then
  add_check "SELinux Status" "WARNING" "SELinux is Enforcing" "Review policies - may affect waagent installation"
else
  add_check "SELinux Status" "INFO" "SELinux: $SELINUX_STATUS" ""
fi

if command -v waagent &>/dev/null; then
  WAAGENT_VER=$(waagent --version 2>/dev/null | head -1 || echo "installed")
  add_check "Azure VM Agent (waagent)" "PASS" "Installed: $WAAGENT_VER" ""
else
  add_check "Azure VM Agent (waagent)" "FAIL" "Not installed" "Install walinuxagent before or after migration"
fi

if command -v vmware-toolsd &>/dev/null || systemctl is-active open-vm-tools &>/dev/null; then
  add_check "VMware Tools" "INFO" "VMware tools detected" "Will be superseded by Azure VM agent"
else
  add_check "VMware Tools" "INFO" "VMware tools not detected" ""
fi

if [ "$REBOOT_REQUIRED" = "Yes" ]; then
  add_check "Reboot Required" "WARNING" "A system reboot is pending" "Complete reboot before migration if possible"
else
  add_check "Reboot Required" "PASS" "No reboot required" ""
fi

ROOT_USE=$(df / 2>/dev/null | awk 'NR==2{print $5}' | tr -d '%') || ROOT_USE=0
if [ "$ROOT_USE" -lt 80 ] 2>/dev/null; then
  add_check "Root Disk Usage" "PASS" "Root filesystem ${ROOT_USE}% used" ""
elif [ "$ROOT_USE" -lt 90 ] 2>/dev/null; then
  add_check "Root Disk Usage" "WARNING" "Root filesystem ${ROOT_USE}% used" "High disk usage - cleanup recommended"
else
  add_check "Root Disk Usage" "FAIL" "Root filesystem ${ROOT_USE}% used" "Critically full - migration may fail"
fi

if systemctl is-active sshd &>/dev/null || systemctl is-active ssh &>/dev/null; then
  add_check "SSH Service" "PASS" "SSH service is running" ""
else
  add_check "SSH Service" "FAIL" "SSH service not running" "SSH required for remote access post-migration"
fi

SWAP_TOTAL=$(free 2>/dev/null | awk '/^Swap/{print $2}') || SWAP_TOTAL=0
if [ "$SWAP_TOTAL" -gt 0 ] 2>/dev/null; then
  SWAP_H=$(free -h 2>/dev/null | awk '/^Swap/{print $2}' || echo "?")
  add_check "Swap Space" "INFO" "Swap configured: $SWAP_H" "Azure VMs use waagent resource disk for swap"
else
  add_check "Swap Space" "INFO" "No swap configured" ""
fi

if systemctl is-active chronyd &>/dev/null || \
   systemctl is-active ntpd &>/dev/null || \
   systemctl is-active systemd-timesyncd &>/dev/null; then
  add_check "Time Synchronization" "PASS" "Time sync service running" ""
else
  add_check "Time Synchronization" "WARNING" "No time sync service detected" "Configure NTP/chrony post-migration"
fi

jline '    ]'
jline '}'

echo "[$(date '+%Y-%m-%d %H:%M:%S')] JSON generation complete: $JSON_FILE"

# JSON validation via python3 heredoc (avoids shell quoting issues)
python3 - << PYEOF 2>/dev/null && echo "[$(date '+%Y-%m-%d %H:%M:%S')] JSON syntax validated OK" || echo "[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: JSON validation failed - check for generation errors" >&2
import json
with open("$JSON_FILE") as f:
    data = json.load(f)
print("JSON OK: SystemOverview.ServerName=" + str(data.get("SystemOverview",{}).get("ServerName","?")))
PYEOF

echo "[$(date '+%Y-%m-%d %H:%M:%S')] MigrationCheck-DataCollector.sh completed successfully."
exit 0
