#Requires -Version 5.1
<#
.SYNOPSIS
    Avanade Migration Check - Linux Data Collector (PowerShell Remote Runner)

.DESCRIPTION
    Remotely executes MigrationCheck-DataCollector.sh on one or more Linux servers
    via SSH (Posh-SSH), downloads the resulting JSON, and invokes
    MigrationCheck-HtmlGenerator.ps1 to produce Avanade-branded HTML reports.

    Mirrors the parameter names and operational patterns of the Windows
    MigrationCheck-DataCollector.ps1 where applicable.

.PARAMETER CheckType
    Migration phase label: Pre_Migration | Post_Migration | Test_Migration

.PARAMETER ServerList
    Path to a CSV file with a 'Server' or 'HostName' column listing target Linux hosts.
    Ignored when -ServerName is provided.

.PARAMETER ServerName
    Single server hostname or IP to target. Overrides -ServerList.
    Accepts comma-separated values for multiple servers.

.PARAMETER OutputDir
    Local directory where downloaded JSON and generated HTML files are saved.
    Defaults to C:\Avanade\<username>.

.PARAMETER LocalScriptPath
    Path to the local copy of MigrationCheck-DataCollector.sh.
    Defaults to the LinuxVM subfolder beside this script.

.PARAMETER RemoteScriptDir
    Directory on the remote Linux server where the bash script will be uploaded.
    Defaults to /tmp/avanade-migration.

.PARAMETER HtmlGeneratorPath
    Path to MigrationCheck-HtmlGenerator.ps1. When omitted the script looks in
    the same directory as this script, then the parent.

.PARAMETER Username
    SSH username for remote connections.

.PARAMETER Password
    Plain-text SSH password. Used together with -Username.

.PARAMETER PersonalJSON
    Path to a personal JSON file with encrypted or plain-text credentials.
    Same format as the Windows data collector PersonalJSON parameter.

.PARAMETER UseCredential
    Prompt for SSH credentials interactively via Get-Credential.

.PARAMETER SkipHtmlGeneration
    Download JSON only; do not invoke the HTML generator.

.PARAMETER MaxThreads
    Maximum concurrent SSH sessions (background jobs). Defaults to 10.

.PARAMETER GenerateSampleCSV
    Write a sample CSV file to -ServerList path demonstrating required format.

.EXAMPLE
    .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -ServerName tm-lnx01 -Username root -Password secret

.EXAMPLE
    .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -ServerList .\Serverlist.csv -UseCredential

.NOTES
    Author : Avanade Migration Team
    Version: 26.05.16
    Requires: Posh-SSH module (Install-Module Posh-SSH)
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("Pre_Migration", "Post_Migration", "Test_Migration")]
    [string]$CheckType,

    [string]$ServerList = ".\Serverlist.csv",
    [string]$ServerName,
    [string]$OutputDir = "C:\Avanade\$env:USERNAME",

    [string]$LocalScriptPath,
    [string]$RemoteScriptDir = "~/avanade-migration",
    [string]$HtmlGeneratorPath,

    [string]$Username,
    [string]$Password,
    [string]$PersonalJSON,
    [switch]$UseCredential,
    [switch]$SkipHtmlGeneration,
    [int]$MaxThreads = 10,
    [switch]$GenerateSampleCSV
)

$ScriptVersion = "26.05.16"
function Get-CurrentScriptDirectory {
    $candidatePaths = @(
        $PSScriptRoot,
        $PSCommandPath,
        $MyInvocation.MyCommand.Path
    )

    foreach ($candidatePath in $candidatePaths) {
        if (-not [string]::IsNullOrWhiteSpace([string]$candidatePath) -and (Test-Path -LiteralPath $candidatePath)) {
            if (Test-Path -LiteralPath $candidatePath -PathType Container) {
                return $candidatePath
            }
            return (Split-Path -Parent $candidatePath)
        }
    }

    try {
        $processPath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        if (-not [string]::IsNullOrWhiteSpace([string]$processPath) -and (Test-Path -LiteralPath $processPath)) {
            $processName = [System.IO.Path]::GetFileNameWithoutExtension($processPath)
            if ($processName -notmatch '^(?i)(pwsh|powershell|powershell_ise)$') {
                return (Split-Path -Parent $processPath)
            }
        }
    }
    catch {
    }

    return (Get-Location).Path
}

$scriptDir = Get-CurrentScriptDirectory
$scriptsDir = Split-Path $scriptDir -Parent
$clientRoot = Split-Path $scriptsDir -Parent

$localModuleRoots = @(
    (Join-Path $clientRoot 'Modules'),
    (Join-Path $scriptsDir 'Modules'),
    (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'PowerShell\Modules'),
    (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'WindowsPowerShell\Modules'),
    (Join-Path $HOME 'Documents\PowerShell\Modules'),
    (Join-Path $HOME 'Documents\WindowsPowerShell\Modules')
) | Where-Object { Test-Path -LiteralPath $_ -PathType Container }
foreach ($moduleRoot in $localModuleRoots) {
    if (($env:PSModulePath -split [System.IO.Path]::PathSeparator) -notcontains $moduleRoot) {
        $env:PSModulePath = "$moduleRoot$([System.IO.Path]::PathSeparator)$env:PSModulePath"
    }
}

Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] MigrationCheck-DataCollector.ps1 (Linux) v$ScriptVersion"

try {
    Add-Type -AssemblyName System.Security -ErrorAction Stop
}
catch {
    Write-Warning "Could not load System.Security for DPAPI credential decrypt: $($_.Exception.Message)"
}

# ─── Generate sample CSV and exit ───────────────────────────────────────────
if ($GenerateSampleCSV) {
    "Server" | Out-File -FilePath $ServerList -Encoding UTF8
    "tm-lnx01" | Out-File -FilePath $ServerList -Append -Encoding UTF8
    Write-Host "Sample CSV written to: $ServerList" -ForegroundColor Green
    return
}

# ─── Ensure Posh-SSH is available ───────────────────────────────────────────
$poshSshModule = Get-Module -ListAvailable -Name Posh-SSH | Sort-Object Version -Descending | Select-Object -First 1
if (-not $poshSshModule) {
    Write-Host "Posh-SSH module not found. Attempting to install..." -ForegroundColor Yellow
    try {
        Install-Module -Name Posh-SSH -Scope CurrentUser -Force -ErrorAction Stop
        $poshSshModule = Get-Module -ListAvailable -Name Posh-SSH | Sort-Object Version -Descending | Select-Object -First 1
    }
    catch {
        Write-Error "Failed to install Posh-SSH: $_`nInstall manually: Install-Module -Name Posh-SSH"
        exit 1
    }
}
Import-Module $poshSshModule.Path -Force -ErrorAction Stop
Write-Host "Using Posh-SSH $($poshSshModule.Version) from $($poshSshModule.Path)" -ForegroundColor DarkGray

# ─── Resolve local bash script path ─────────────────────────────────────────
if (-not $LocalScriptPath) {
    $LocalScriptPath = Join-Path $scriptDir "Linux-DataCollector.sh"
}
if (-not (Test-Path $LocalScriptPath)) {
    Write-Error "Bash data collector script not found at: $LocalScriptPath"
    exit 1
}

# ─── Resolve HTML generator path ────────────────────────────────────────────
if (-not $HtmlGeneratorPath) {
    $candidates = @(
        # Prefer the unified Windows/Linux generator
        (Join-Path (Split-Path $scriptDir -Parent) "WindowsVM\MigrationCheck-HtmlGenerator.ps1"),
        (Join-Path $scriptDir "MigrationCheck-HtmlGenerator.ps1"),
        (Join-Path (Split-Path $scriptDir -Parent) "LinuxVM\MigrationCheck-HtmlGenerator.ps1")
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { $HtmlGeneratorPath = $c; break }
    }
}
if (-not $SkipHtmlGeneration -and -not (Test-Path $HtmlGeneratorPath)) {
    Write-Warning "HTML generator not found. HTML reports will be skipped. Use -HtmlGeneratorPath to specify location."
    $SkipHtmlGeneration = $true
}

# ─── Credential resolution (mirrors Windows data collector logic) ────────────
$credential = $null
$credSource  = "current user context"
$preferCurrentFirst = (-not $UseCredential)

# Function to decrypt PersonalJSON encrypted password (DPAPI UserScope)
function Decrypt-PersonalJsonPassword {
    param([string]$EncryptedValue)
    try {
        $bytes     = [Convert]::FromBase64String($EncryptedValue)
        $decrypted = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        return [System.Text.Encoding]::Unicode.GetString($decrypted)
    }
    catch {
        Write-Verbose "DPAPI decrypt failed: $_"
        return $null
    }
}

if (-not [string]::IsNullOrEmpty($Username) -and -not [string]::IsNullOrEmpty($Password)) {
    $secPw     = ConvertTo-SecureString $Password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($Username, $secPw)
    $credSource = "supplied parameters ($Username)"
    Write-Host "Using credentials from parameters: $Username" -ForegroundColor Green
}
elseif (-not [string]::IsNullOrEmpty($PersonalJSON) -and (Test-Path $PersonalJSON)) {
    try {
        $pj = Get-Content -Raw $PersonalJSON | ConvertFrom-Json

        # Priority 1: AlternateLinuxUsername / AlternateLinuxPassword (dedicated Linux creds, encrypted)
        $resolvedUser = $null
        $resolvedPass = $null
        if (-not [string]::IsNullOrEmpty($Username)) {
            $resolvedUser = $Username
        }
        elseif ($pj.AlternateLinuxUsername) {
            $resolvedUser = $pj.AlternateLinuxUsername
        }

        if ($pj.AlternateLinuxPassword) {
            $resolvedPass = Decrypt-PersonalJsonPassword -EncryptedValue $pj.AlternateLinuxPassword
        }

        # Priority 2: AlternateUsername / AlternatePassword (general alternate creds, encrypted)
        if (-not $resolvedUser -and $pj.AlternateUsername) { $resolvedUser = $pj.AlternateUsername }
        if (-not $resolvedPass -and $pj.AlternatePassword) {
            $resolvedPass = Decrypt-PersonalJsonPassword -EncryptedValue $pj.AlternatePassword
        }

        # Priority 3: TestUsername / TestPassword (plain text)
        if (-not $resolvedUser -and $pj.TestUsername) { $resolvedUser = $pj.TestUsername }
        if (-not $resolvedPass -and $pj.TestPassword)  { $resolvedPass = $pj.TestPassword }

        if ($resolvedUser -and $resolvedPass) {
            $secPw     = ConvertTo-SecureString $resolvedPass -AsPlainText -Force
            $credential = New-Object System.Management.Automation.PSCredential($resolvedUser, $secPw)
            $credSource = "PersonalJSON ($resolvedUser)"
            Write-Host "Using credentials from PersonalJSON: $resolvedUser" -ForegroundColor Green
        }
        else {
            Write-Warning "PersonalJSON found but no valid credentials could be extracted."
        }
    }
    catch {
        Write-Warning "Failed to read PersonalJSON: $_"
    }
}
elseif ($UseCredential) {
    $credential = Get-Credential -Message "Enter SSH credentials for Linux server(s)"
    $credSource = "interactive prompt ($($credential.UserName))"
    Write-Host "Using interactively supplied credentials: $($credential.UserName)" -ForegroundColor Green
}

if (-not $credential) {
    Write-Error "No credentials provided. Use -Username/-Password, -PersonalJSON, or -UseCredential."
    exit 1
}

# ─── Resolve target servers ──────────────────────────────────────────────────
$targetServers = @()
if ($ServerName) {
    $targetServers = $ServerName -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
}
else {
    if (Test-Path $ServerList) {
        $csv = Import-Csv -Path $ServerList
        # Support flexible column headers matching Windows convention
        foreach ($row in $csv) {
            $svrName = $null
            foreach ($prop in @("Server","ServerName","HostName","Hostname","Title","Name")) {
                if ($row.PSObject.Properties[$prop]) { $svrName = $row.$prop; break }
            }
            if ($svrName) { $targetServers += $svrName.Trim() }
        }
    }
    else {
        Write-Error "Server list CSV not found: $ServerList"
        exit 1
    }
}
$targetServers = $targetServers | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
Write-Host "Target servers: $($targetServers -join ', ')" -ForegroundColor Cyan

# ─── Ensure output directory ─────────────────────────────────────────────────
$ResolvedOutputDir = $OutputDir
if (-not (Test-Path $ResolvedOutputDir)) {
    New-Item -Path $ResolvedOutputDir -ItemType Directory -Force | Out-Null
}

# ─── Transcript logging ──────────────────────────────────────────────────────
$transcriptDir = Join-Path (Split-Path $ResolvedOutputDir -Parent) "Transcripts"
if (-not (Test-Path $transcriptDir)) { New-Item -Path $transcriptDir -ItemType Directory -Force | Out-Null }
$transcriptPath = Join-Path $transcriptDir ("MigrationCheck-DataCollector-Linux-transcript-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt")
Start-Transcript -Path $transcriptPath -ErrorAction SilentlyContinue

Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] CheckType=$CheckType | OutputDir=$ResolvedOutputDir | Servers=$($targetServers.Count)" -ForegroundColor Cyan

# ─── Per-server processing function ─────────────────────────────────────────
$Success = [System.Collections.Generic.List[string]]::new()
$Failure = [System.Collections.Generic.List[string]]::new()
$FailureErrors = @{}

$RemoteScriptName = "Linux-DataCollector.sh"
$BashScript = $LocalScriptPath

foreach ($srv in $targetServers) {
    Write-Host ""
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ─── Processing: $srv ───" -ForegroundColor Cyan
    # For IPs keep the full address as the folder name; for hostnames use the short name
    $srvShort = if ($srv -match '^\d+\.\d+\.\d+\.\d+$') { $srv -replace '\.','_' } else { ($srv -split '\.')[0] }
    $srvDir   = Join-Path $ResolvedOutputDir $srvShort

    $session = $null
    try {
        # Create local output folder
        if (-not (Test-Path $srvDir)) {
            New-Item -Path $srvDir -ItemType Directory -Force | Out-Null
        }

        # Open SSH session
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Connecting to $srv..." -ForegroundColor Gray
        $session = New-SSHSession -ComputerName $srv -Credential $credential -AcceptKey -ConnectionTimeout 30 -ErrorAction Stop
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Connected (SessionId=$($session.SessionId))" -ForegroundColor Green

        # Resolve remote working directory - expand ~ to absolute path
        $resolvedRemoteDir = $RemoteScriptDir
        if ($RemoteScriptDir -match '^~') {
            $homeDir = ((Invoke-SSHCommand -SessionId $session.SessionId -Command 'echo $HOME').Output -join "").Trim()
            $resolvedRemoteDir = $RemoteScriptDir -replace '^~', $homeDir
        }

        # Ensure remote working directory exists (owned by the connecting user, no sudo)
        Invoke-SSHCommand -SessionId $session.SessionId -Command "mkdir -p '$resolvedRemoteDir'" | Out-Null

        # Upload bash script
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Uploading $RemoteScriptName..." -ForegroundColor Gray
        $uploadTempDir = Join-Path ([System.IO.Path]::GetTempPath()) ("LinuxCollectorUpload_" + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $uploadTempDir -Force | Out-Null
        $uploadScriptPath = Join-Path $uploadTempDir $RemoteScriptName
        $bashContent = [System.IO.File]::ReadAllText($BashScript)
        $bashContent = $bashContent -replace "`r`n", "`n" -replace "`r", "`n"
        [System.IO.File]::WriteAllText($uploadScriptPath, $bashContent, (New-Object System.Text.UTF8Encoding($false)))
        try {
            Set-SCPItem -ComputerName $srv -Credential $credential -Path $uploadScriptPath `
                -Destination $resolvedRemoteDir -AcceptKey -ErrorAction Stop
        }
        finally {
            Remove-Item -LiteralPath $uploadTempDir -Recurse -Force -ErrorAction SilentlyContinue
        }

        # Set execute permission
        Invoke-SSHCommand -SessionId $session.SessionId `
            -Command "chmod +x '${resolvedRemoteDir}/${RemoteScriptName}'" | Out-Null

        # Execute the data collector (use sudo if available for privileged commands)
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Executing data collector on $srv..." -ForegroundColor Yellow
        $execResult = Invoke-SSHCommand -SessionId $session.SessionId `
            -Command "cd '$resolvedRemoteDir' && OUTPUT_DIR='$resolvedRemoteDir' bash '${resolvedRemoteDir}/${RemoteScriptName}' '$CheckType' 2>&1" `
            -TimeOut 300

        if ($execResult.Output) {
            $execResult.Output | ForEach-Object { Write-Host "  [remote] $_" -ForegroundColor DarkGray }
        }
        if ($execResult.ExitStatus -ne 0) {
            throw "Remote script exited with code $($execResult.ExitStatus)"
        }

        # Determine expected JSON file name on remote
        $remoteHostShort = (Invoke-SSHCommand -SessionId $session.SessionId -Command "hostname | cut -d'.' -f1 | tr a-z A-Z").Output -join ""
        $remoteHostShort = $remoteHostShort.Trim()
        $remoteJsonName  = "${remoteHostShort}_${CheckType}.json"
        $remoteJsonPath  = "${resolvedRemoteDir}/${remoteJsonName}"

        # Wait for file (with timeout)
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Waiting for JSON output..." -ForegroundColor Gray
        $waited  = 0
        $timeout = 120
        do {
            Start-Sleep -Seconds 3
            $waited += 3
            $exists = (Invoke-SSHCommand -SessionId $session.SessionId -Command "test -f '$remoteJsonPath' && echo exists").Output -join ""
        } while ($exists -notmatch "exists" -and $waited -lt $timeout)

        if ($exists -notmatch "exists") {
            throw "JSON file was not generated at $remoteJsonPath within ${timeout}s"
        }

        # Download JSON
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Downloading $remoteJsonName..." -ForegroundColor Gray
        Get-SCPItem -ComputerName $srv -Credential $credential `
            -Path $remoteJsonPath -Destination $srvDir -PathType File -AcceptKey -Force -ErrorAction Stop

        $localJsonPath = Join-Path $srvDir $remoteJsonName
        if (-not (Test-Path $localJsonPath)) {
            throw "JSON download failed - file not found at $localJsonPath"
        }
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] JSON saved: $localJsonPath" -ForegroundColor Green

        # Generate HTML report
        if (-not $SkipHtmlGeneration -and (Test-Path $HtmlGeneratorPath)) {
            Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Generating HTML report..." -ForegroundColor Gray
            try {
                & $HtmlGeneratorPath -JSONInput $localJsonPath -ErrorAction Stop
                Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] HTML report generated." -ForegroundColor Green
            }
            catch {
                Write-Warning "HTML generation failed for ${srv}: $_"
            }
        }

        # Cleanup remote temp files
        Invoke-SSHCommand -SessionId $session.SessionId `
            -Command "rm -f '${resolvedRemoteDir}/${RemoteScriptName}' '$remoteJsonPath'" | Out-Null

        $Success.Add($srvShort)
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $srv completed successfully." -ForegroundColor Green
    }
    catch {
        $errMsg = $_.Exception.Message
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ERROR processing ${srv}: $errMsg" -ForegroundColor Red
        $Failure.Add($srvShort)
        $FailureErrors[$srvShort] = $errMsg
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Check connectivity and credentials for $srv" -ForegroundColor DarkYellow
    }
    finally {
        if ($session) {
            Remove-SSHSession -SessionId $session.SessionId -ErrorAction SilentlyContinue | Out-Null
        }
    }
}

# ─── Write success/failure CSVs ──────────────────────────────────────────────
$serverListDir = Join-Path $ResolvedOutputDir "..\ServerList"
if (-not (Test-Path $serverListDir)) {
    New-Item -Path $serverListDir -ItemType Directory -Force | Out-Null
}
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

if ($Success.Count -gt 0) {
    $successCsv = Join-Path $serverListDir "Successful_${stamp}.csv"
    $Success | ForEach-Object { [PSCustomObject]@{ ServerName = $_ } } | Export-Csv -Path $successCsv -NoTypeInformation -Encoding UTF8
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $($Success.Count) succeeded. CSV: $successCsv" -ForegroundColor Green
}
if ($Failure.Count -gt 0) {
    $failedCsv = Join-Path $serverListDir "Failed_${stamp}.csv"
    $Failure | ForEach-Object { [PSCustomObject]@{ ServerName = $_; Error = $FailureErrors[$_] } } | Export-Csv -Path $failedCsv -NoTypeInformation -Encoding UTF8
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $($Failure.Count) failed. CSV: $failedCsv" -ForegroundColor Red
    $Failure | ForEach-Object { Write-Host "  FAILED: $_ - $($FailureErrors[$_])" -ForegroundColor Red }
}

# ─── Summary ─────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ╔══════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ║   LINUX MIGRATION CHECK - SUMMARY               ║" -ForegroundColor Cyan
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ╚══════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Servers: $($Success.Count) succeeded, $($Failure.Count) failed out of $($targetServers.Count) total" `
    -ForegroundColor $(if ($Failure.Count -gt 0) { 'Yellow' } else { 'Green' })
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Output directory: $ResolvedOutputDir" -ForegroundColor Cyan
Write-Host ""

try { Stop-Transcript -ErrorAction SilentlyContinue } catch { }
