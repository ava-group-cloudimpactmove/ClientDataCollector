<#
.SYNOPSIS
    Collect-IISData.ps1 - gather IIS configuration useful for migrations (sites, bindings, paths, certs, app pools, NICs).

.DESCRIPTION
    Designed to be PowerShell 5.1 compatible. Can run locally or remotely via -ComputerName (uses Invoke-Command / remoting).
    Produces a JSON file per server and a ZIP containing JSON + applicationHost.config backup + small artifacts.

    Can also process multiple servers from a CSV file containing a ServerName column.

.PARAMETER ComputerName
    One or more computer names to collect from. If omitted, runs against localhost.

.PARAMETER OutputPath
    Directory to write outputs. Defaults to .\IISReports\<ComputerName>.

.PARAMETER ServerList
    Path to CSV file containing ServerName column for batch processing of multiple servers.
    When used, each server gets its own subdirectory under OutputPath.

.PARAMETER CheckType
    Specifies migration phase (Pre_Migration, Post_Migration, Pre, Post). Defaults to Pre_Migration.
    Affects output filename: {ServerName}_{Pre|Post}_IIS_Config.json

.PARAMETER IncludeWebConfigScan
    Switch. When present, the script will enumerate web.config files under site root up to a depth (can be large). Default: Off.

.PARAMETER MaxFilesPerSite
    When IncludeWebConfigScan is used, limits number of files enumerated per site (default 200).

.PARAMETER UseCredential
    Switch to enable interactive credential prompting for remote connections. Use this only if you want to be prompted for credentials interactively.

    Note: If you provide PersonalJSON or Username/Password parameters, credentials will be used automatically without needing this switch.

.PARAMETER Username
    Username for remote connections (used with Password parameter). When provided along with Password, credentials will be used automatically without requiring the UseCredential switch.

.PARAMETER Password
    Plain text password for remote connections (used with Username parameter). When provided along with Username, credentials will be used automatically without requiring the UseCredential switch.

.PARAMETER PersonalJSON
    Path to personal JSON file containing credentials for remote connections. When provided, credentials will be used automatically without requiring the UseCredential switch.

    Priority order for credentials in personal JSON:
    1. AlternateUsername/AlternatePassword (encrypted)
    2. TestUsername/TestPassword (plain text)

    Example personal JSON format:
    {
        "AlternateUsername": "domain\\user",
        "AlternatePassword": "encrypted_password_string",
        "TestUsername": "domain\\user",
        "TestPassword": "password123"
    }

    Usage examples:
    .\CollectIISData.ps1 -CheckType Pre_Migration -PersonalJSON "C:\personal.json"
    .\CollectIISData.ps1 -CheckType Pre_Migration -Username "domain\user" -Password "password"
    .\CollectIISData.ps1 -CheckType Pre_Migration -UseCredential  # Only prompts if no PersonalJSON or Username/Password provided

.PARAMETER Verbose
    Standard verbose output.

.EXAMPLE
    .\CollectIISData.ps1 -ComputerName localhost -OutputPath C:\Reports\IIS -IncludeWebConfigScan -MaxFilesPerSite 500

.EXAMPLE
    .\CollectIISData.ps1 -ServerList C:\ServerList.csv -CheckType Pre_Migration -OutputPath C:\Reports\IIS

.EXAMPLE
    .\CollectIISData.ps1 -ComputerName server1,server2 -Username "domain\user" -Password "password"

.EXAMPLE
    .\CollectIISData.ps1 -ServerList C:\ServerList.csv -PersonalJson "C:\personal.json"

.EXAMPLE
    .\CollectIISData.ps1 -ComputerName server1 -UseCredential  # Interactive credential prompt

#>

param(
    [Parameter(Mandatory = $false)]
    [switch]$RunLocally = $false,

    [Parameter(Mandatory = $false)]
    [string]$ServerName,

    [Parameter(Mandatory = $false)]
    [Alias('ServerListCSV')]
    [string]$ServerList = ".\serverlist.csv",

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = (Join-Path -Path (Get-Location) -ChildPath "IISReports"),

    [Parameter(Mandatory = $false)]
    [ValidateSet("Pre_Migration", "Post_Migration", "Pre", "Post")]
    [string]$CheckType = "Pre_Migration",

    [switch]$IncludeWebConfigScan,

    [int]$MaxFilesPerSite = 200,

    [switch]$UseCredential = $false,

    [string]$Username ,

    [string]$Password ,

    [string]$PersonalJson
)
$ScriptVersion = "26.06.12"
# CHANGELOG
# 2026-06-18: Stopped auto-installing Web-Scripting-Tools; now logs missing IIS
# management tooling in the report and console and continues with fallbacks.
# 2026-06-17: Hardened WinRM fallback handling so TrustedHosts wildcard entries are preserved
# and Basic authentication is only attempted when explicit credentials are available.
# 2026-04-23: Hardened PersonalJson handling by adding PersonalJSON/JsonPersonal aliases and
# normalizing provider-prefixed or quoted paths before credential loading.
# 2026-04-23: Switched credential JSON discovery to literal-path checks/reads for more reliable
# behavior from GUI and CLI launch contexts.

# Normalize personal JSON path once and reuse it.
if (-not [string]::IsNullOrWhiteSpace($PersonalJson)) {
    $PersonalJson = $PersonalJson.Trim().Trim("'").Trim('"')
    if ($PersonalJson -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
        $PersonalJson = $PersonalJson -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
    }
}

# Normalize CheckType parameter
switch ($CheckType) {
    "Pre" { $CheckType = "Pre_Migration" }
    "Post" { $CheckType = "Post_Migration" }
    Default {
        # Keep as-is for "Pre_Migration" and "Post_Migration"
        if ($CheckType -notin @("Pre_Migration", "Post_Migration")) {
            Write-Warning "Invalid CheckType '$CheckType'. Using 'Pre_Migration'."
            $CheckType = "Pre_Migration"
        }
    }
}
function PAT-Decrypt {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$EncryptedPAT
    )

    try {
        if (-not $EncryptedPAT) {
            throw "Encrypted value is null or empty."
        }
        # Convert the Base64-encoded string back to an array of bytes.
        $encryptedBytes = [Convert]::FromBase64String($EncryptedPAT)

        # Decrypt the bytes using DPAPI with the current user scope.
        $decryptedBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($encryptedBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)

        # Convert the decrypted bytes back into a string.
        $decryptedPAT = [System.Text.Encoding]::Unicode.GetString($decryptedBytes)
    }
    catch {
        $msg = if ($_.Exception -and $_.Exception.Message) { $_.Exception.Message } else { "Unknown error" }
        Write-Error "Failed to decrypt encrypted value from Personal JSON (DPAPI CurrentUser): $msg"
        $decryptedPAT = $null
    }

    return $decryptedPAT
}
# Handle credentials for remote connections
$credential = $null

# Check if username and password parameters were provided (automatically use credentials)
if (![string]::IsNullOrEmpty($Username) -and ![string]::IsNullOrEmpty($Password)) {
    Write-Host "Using credentials provided via parameters..." -ForegroundColor Green
    $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($Username, $securePassword)
}
# Check if personal JSON file was provided (automatically use credentials)
elseif (![string]::IsNullOrWhiteSpace($PersonalJson) -and (Test-Path -LiteralPath $PersonalJson)) {
    Write-Host "Loading credentials from personal JSON: $PersonalJson" -ForegroundColor Green
    try {
        $personalData = Get-Content -LiteralPath $PersonalJson -ErrorAction Stop | ConvertFrom-Json

        # Extract credentials from personal JSON with priority order
        $username = $null
        $password = $null
        $credentialIssue = $null

        # Priority 1: AlternateUsername/AlternatePassword (encrypted)
        $hasAlternateCreds = ($personalData.PSObject.Properties.Name -contains 'AlternateUsername' -and
            $personalData.PSObject.Properties.Name -contains 'AlternatePassword' -and
            -not [string]::IsNullOrWhiteSpace($personalData.AlternateUsername) -and
            -not [string]::IsNullOrWhiteSpace($personalData.AlternatePassword))

        if ($hasAlternateCreds) {

            $username = $personalData.AlternateUsername
            $password = PAT-Decrypt -EncryptedPAT $personalData.AlternatePassword
            if (-not [string]::IsNullOrWhiteSpace($password)) {
                Write-Host "Successfully loaded and decrypted AlternateUsername/AlternatePassword." -ForegroundColor Green
            }
            else {
                $password = $null
                $credentialIssue = "Personal JSON contains AlternateUsername/AlternatePassword, but AlternatePassword could not be decrypted (DPAPI CurrentUser). This usually means it was encrypted under a different Windows user profile or on a different machine."
            }
        }

        # Priority 2: TestUsername/TestPassword (plain text) - only if alternate not available
        $hasTestCreds = ($personalData.PSObject.Properties.Name -contains 'TestUsername' -and
            $personalData.PSObject.Properties.Name -contains 'TestPassword' -and
            -not [string]::IsNullOrWhiteSpace($personalData.TestUsername) -and
            -not [string]::IsNullOrWhiteSpace($personalData.TestPassword))

        if (-not $password -and $hasTestCreds) {

            $username = $personalData.TestUsername
            $password = $personalData.TestPassword
            $credentialIssue = $null
            Write-Host "Successfully loaded TestUsername/TestPassword." -ForegroundColor Green
        }

        if ($username -and $password) {
            $securePassword = ConvertTo-SecureString $password -AsPlainText -Force
            $credential = New-Object System.Management.Automation.PSCredential($username, $securePassword)
            Write-Host "Credentials loaded successfully from personal JSON." -ForegroundColor Green
        }
        else {
            if ($credentialIssue) {
                Write-Warning $credentialIssue
            }
            else {
                Write-Warning "Personal JSON file does not contain valid credentials. Expected AlternateUsername/AlternatePassword or TestUsername/TestPassword."
            }
        }
    }
    catch {
        Write-Warning "Failed to load credentials from personal JSON: $($_.Exception.Message)"
    }
}
# If UseCredential is specified but no JSON or user/pass provided, prompt for credentials
elseif ($UseCredential) {
    Write-Host "Prompting for credentials to connect to remote servers..." -ForegroundColor Yellow
    try {
        # Check if we're in an interactive session
        if ([Environment]::UserInteractive -and $Host.Name -ne "ServerRemoteHost") {
            $credential = Get-Credential -Message "Enter credentials for connecting to remote servers"
            if ($null -ne $credential) {
                Write-Host "Credentials captured successfully. Will use these for all remote connections." -ForegroundColor Green
            }
            else {
                Write-Warning "No credentials provided. Will attempt to use current user context."
            }
        }
        else {
            Write-Error "UseCredential switch requires either:"
            Write-Error "  1. An interactive PowerShell session (PowerShell Console, ISE, or Windows Terminal)"
            Write-Error "  2. Username and Password parameters provided"
            Write-Error "  3. PersonalJSON parameter with path to personal JSON file containing credentials"
            Write-Error ""
            Write-Error "Current host: $($Host.Name)"
            Write-Error ""
            Write-Error "Example with parameters:"
            Write-Error "  .\CollectIISData.ps1 -CheckType Pre_Migration -Username 'domain\user' -Password 'password'"
            Write-Error ""
            Write-Error "Example with personal JSON:"
            Write-Error "  .\CollectIISData.ps1 -CheckType Pre_Migration -PersonalJSON 'C:\personal.json'"
            exit 1
        }
    }
    catch {
        Write-Error "Failed to capture credentials: $_"
        Write-Error "This may be due to running in a non-interactive environment."
        Write-Error "Consider using the PersonalJSON or Username/Password parameters instead."
        exit 1
    }
}

# Define Write-Log function first
function Write-Log {
    param($Message, $Level = 'INFO')
    $ts = (Get-Date).ToString("s")
    Write-Host "[$ts] [$Level] $Message"
}

# Extract short form for filename (Pre or Post)
$CheckTypeShort = if ($CheckType -eq "Pre_Migration") { "Pre" } else { "Post" }

Write-Log "CheckType set to: $CheckType (filename will use: $CheckTypeShort)"

function Collect-LocalIISData {
    param(
        [string]$TargetName,
        [string]$BaseOutputPath,
        [switch]$ScanWebConfigs,
        [int]$MaxFiles,
        [string]$CheckTypeShort = "Pre"
    )

    $report = [ordered]@{
        CollectedAt                 = (Get-Date).ToString("o")
        ComputerName                = $TargetName
        CheckType                   = $CheckTypeShort
        OSInfo                      = @{}
        SystemInfo                  = @{}
        IISInstalled                = $false
        Sites                       = @()
        AppPools                    = @()
        SSLBindings                 = @()
        IISFeatures                 = @()
        Services                    = @()
        NetIP                       = @()
        NetworkConfig               = @()
        NetshSsl                    = @()
        ApplicationHostConfigBackup = $null
        MigrationAlerts             = @()
        Notes                       = @()
    }

    try {
        # 0) Collect OS and System Information
        try {
            Write-Log "Collecting OS and system information..."

            # OS Information
            $osInfo = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction SilentlyContinue
            if ($osInfo) {
                $report.OSInfo = [ordered]@{
                    Caption       = $osInfo.Caption
                    Version       = $osInfo.Version
                    BuildNumber   = $osInfo.BuildNumber
                    Architecture  = $osInfo.OSArchitecture
                    ServicePack   = $osInfo.CSDVersion
                    InstallDate   = $osInfo.InstallDate
                    TotalMemoryGB = [math]::Round($osInfo.TotalVisibleMemorySize / 1MB, 2)
                    FreeMemoryGB  = [math]::Round($osInfo.FreePhysicalMemory / 1MB, 2)
                }
            }

            # CPU Information
            $cpuInfo = Get-CimInstance -ClassName Win32_Processor -ErrorAction SilentlyContinue
            if ($cpuInfo) {
                if ($cpuInfo -is [array]) {
                    $cpuInfo = $cpuInfo[0]  # Take first CPU for summary
                }
                $report.SystemInfo = [ordered]@{
                    ProcessorName             = $cpuInfo.Name
                    Manufacturer              = $cpuInfo.Manufacturer
                    MaxClockSpeed             = "$($cpuInfo.MaxClockSpeed) MHz"
                    NumberOfCores             = $cpuInfo.NumberOfCores
                    NumberOfLogicalProcessors = $cpuInfo.NumberOfLogicalProcessors
                    Architecture              = $cpuInfo.Architecture
                }
            }

            # Memory Configuration Details
            $memoryModules = Get-CimInstance -ClassName Win32_PhysicalMemory -ErrorAction SilentlyContinue
            if ($memoryModules) {
                $totalMemoryGB = ($memoryModules | Measure-Object -Property Capacity -Sum).Sum / 1GB
                $memoryDetails = $memoryModules | ForEach-Object {
                    [ordered]@{
                        Capacity      = "$([math]::Round($_.Capacity / 1GB, 2)) GB"
                        Speed         = "$($_.Speed) MHz"
                        Manufacturer  = $_.Manufacturer
                        PartNumber    = $_.PartNumber
                        DeviceLocator = $_.DeviceLocator
                    }
                }
                $report.SystemInfo.TotalPhysicalMemoryGB = [math]::Round($totalMemoryGB, 2)
                $report.SystemInfo.MemoryModules = $memoryDetails
            }
        }
        catch {
            $report.Notes += "Failed to collect OS/System info: $_"
        }

        # 1) Enhanced network configuration collection
        # 1) Enhanced network configuration collection
        try {
            Write-Log "Collecting network configuration..."
            $report.NetIP = @()
            $report.NetworkConfig = @()

            if (Get-Command -Name Get-NetIPAddress -ErrorAction SilentlyContinue) {
                $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -and $_.IPAddress -ne "127.0.0.1" -and $_.IPAddress -notlike "169.254.*" }

                # Get additional network info
                $netAdapters = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Up" }
                $routes = Get-NetRoute -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.DestinationPrefix -eq "0.0.0.0/0" }

                foreach ($ip in $ips) {
                    # Basic IP info for backward compatibility
                    $report.NetIP += [ordered]@{
                        InterfaceAlias = $ip.InterfaceAlias
                        IPAddress      = $ip.IPAddress
                        PrefixLength   = $ip.PrefixLength
                        AddressState   = $ip.AddressState
                        InterfaceIndex = $ip.InterfaceIndex
                    }

                    # Enhanced network config
                    $adapter = $netAdapters | Where-Object { $_.InterfaceIndex -eq $ip.InterfaceIndex }
                    $defaultGateway = ($routes | Where-Object { $_.InterfaceIndex -eq $ip.InterfaceIndex }).NextHop | Select-Object -First 1

                    # Calculate subnet mask from prefix length
                    $subnetMask = ""
                    if ($ip.PrefixLength) {
                        $maskBits = "1" * $ip.PrefixLength + "0" * (32 - $ip.PrefixLength)
                        $octets = @()
                        for ($i = 0; $i -lt 32; $i += 8) {
                            $octet = [Convert]::ToInt32($maskBits.Substring($i, 8), 2)
                            $octets += $octet
                        }
                        $subnetMask = $octets -join "."
                    }

                    # Count IIS sites using this IP
                    $siteCount = 0
                    if ($report.Sites) {
                        foreach ($site in $report.Sites) {
                            if ($site.Bindings) {
                                foreach ($binding in $site.Bindings) {
                                    if ($binding.Binding -like "*$($ip.IPAddress):*") {
                                        $siteCount++
                                        break
                                    }
                                }
                            }
                        }
                    }

                    $networkConfigEntry = [ordered]@{
                        NICName        = $ip.InterfaceAlias
                        IPAddress      = $ip.IPAddress
                        SubnetMask     = $subnetMask
                        PrefixLength   = $ip.PrefixLength
                        DefaultGateway = $defaultGateway
                        AddressState   = $ip.AddressState
                        InterfaceIndex = $ip.InterfaceIndex
                        IISSiteCount   = $siteCount
                    }

                    if ($adapter) {
                        $networkConfigEntry.MACAddress = $adapter.MacAddress
                        $networkConfigEntry.LinkSpeed = $adapter.LinkSpeed
                        $networkConfigEntry.FullDuplex = $adapter.FullDuplex
                        $networkConfigEntry.MediaType = $adapter.MediaType
                    }

                    $report.NetworkConfig += $networkConfigEntry
                }
            }
            else {
                # fallback to ipconfig parsing
                $ipOut = ipconfig | Out-String
                $report.NetIPRaw = $ipOut
            }
        }
        catch {
            $report.Notes += "Failed to collect network info: $_"
        }

        # 2) Check for IIS (WebAdministration / IIS)
        $iisAvailable = $false

        # Try direct import first
        try {
            Import-Module WebAdministration -SkipEditionCheck -ErrorAction Stop
            $iisAvailable = $true
        }
        catch {
            # On newer PowerShell hosts, the Windows PowerShell module path is often missing from
            # $env:PSModulePath. Add it and retry so WebAdministration can be found.
            $winPSModPath = "$env:SystemRoot\system32\WindowsPowerShell\v1.0\Modules"
            if ((Test-Path $winPSModPath) -and ($env:PSModulePath -notlike "*$winPSModPath*")) {
                $env:PSModulePath = "$env:PSModulePath;$winPSModPath"
            }
            try {
                Import-Module WebAdministration -SkipEditionCheck -ErrorAction Stop
                $iisAvailable = $true
            }
            catch {}
        }

        # Fall back to IISAdministration (Get-IISSite) if WebAdministration not available
        if (-not $iisAvailable) {
            try {
                Import-Module IISAdministration -ErrorAction Stop
                $iisAvailable = $true
            }
            catch {}
        }

        # If still unavailable, do not attempt to install Web-Scripting-Tools automatically.
        # Log the issue and continue with appcmd/applicationHost fallbacks where possible.
        if (-not $iisAvailable) {
            try {
                $featureStatus = $null
                if (Get-Command -Name Get-WindowsFeature -ErrorAction SilentlyContinue) {
                    $feature = Get-WindowsFeature -Name Web-Scripting-Tools -ErrorAction SilentlyContinue
                    if ($feature) {
                        $featureStatus = if ($feature.Installed) { "installed" } else { "not installed" }
                    }
                }

                $featureMessage = if ($featureStatus) {
                    "WebAdministration module not available and Web-Scripting-Tools is $featureStatus. Automatic feature enablement is disabled; continuing with IIS fallback collection only."
                }
                else {
                    "WebAdministration module not available. Automatic Web-Scripting-Tools installation is disabled; continuing with IIS fallback collection only."
                }

                Write-Host $featureMessage -ForegroundColor Yellow
                $report.Notes += $featureMessage
            }
            catch {
                $featureMessage = "WebAdministration module not available and feature status could not be confirmed. Automatic Web-Scripting-Tools installation is disabled; continuing with IIS fallback collection only. Detail: $($_.Exception.Message)"
                Write-Host $featureMessage -ForegroundColor Yellow
                $report.Notes += $featureMessage
            }
        }

        if (-not $iisAvailable) {
            # quick role check (populates IISFeatures even without the module)
            try {
                $roles = Get-WindowsFeature *web* -ErrorAction SilentlyContinue
                if ($roles) {
                    $report.IISInstalled = $true
                    $report.IISFeatures = $roles | Where-Object { $_.Installed -eq $true } | Select-Object -Property DisplayName, Name
                }
            }
            catch {
                # ignore
            }
        }

        if (-not $iisAvailable) {
            # still try to detect by existence of applicationHost.config
            $appHostPath = Join-Path -Path $env:windir -ChildPath "System32\inetsrv\config\applicationHost.config"
            if (Test-Path $appHostPath) { $iisAvailable = $true }
        }

        if (-not $iisAvailable) {
            $report.Notes += "IIS modules not detected and applicationHost.config not found. Skipping IIS-specific collection."
            return $report
        }
        else {
            $report.IISInstalled = $true
        }

        # 3) Backup applicationHost.config
        $appHost = Join-Path $env:windir "System32\inetsrv\config\applicationHost.config"
        if (Test-Path $appHost) {
            # Save backup directly in output directory with server prefix
            $copyPath = Join-Path $BaseOutputPath ("$($TargetName)_applicationHost.config.{0}.bak" -f (Get-Date).ToString("yyyyMMdd_HHmmss"))
            $prevProgress = $ProgressPreference
            $ProgressPreference = 'SilentlyContinue'
            Copy-Item -LiteralPath $appHost -Destination $copyPath -Force -ErrorAction SilentlyContinue
            $ProgressPreference = $prevProgress
            if (Test-Path $copyPath) {
                $report.ApplicationHostConfigBackup = $copyPath
            }
            else {
                $report.Notes += "Failed to copy applicationHost.config to $copyPath"
            }
        }
        else {
            $report.Notes += "applicationHost.config not found at expected path: $appHost"
        }

        # 4) Get sites & bindings & physical paths & virtual directories
        try {
            # Prefer WebAdministration / wmi providers
            if (Get-Command -Name Get-Website -ErrorAction SilentlyContinue) {
                $sites = Get-Website
            }
            else {
                # fallback: use appcmd.exe list site /xml to enumerate sites
                # (needed on newer PowerShell hosts when WebAdministration module is unavailable)
                $appcmd = Join-Path $env:windir "System32\inetsrv\appcmd.exe"
                $sites = @()
                if (Test-Path $appcmd) {
                    try {
                        $xmlOut = & $appcmd list site /xml 2>$null
                        if ($xmlOut) {
                            [xml]$siteXml = ($xmlOut -join "`n")
                            foreach ($siteNode in $siteXml.appcmd.SITE) {
                                # Each binding string is "protocol/ip:port:hostname"
                                $bindObjs = @()
                                $rawBindStr = $siteNode.bindings
                                if ($rawBindStr) {
                                    foreach ($rb in ($rawBindStr -split ',')) {
                                        $rb = $rb.Trim()
                                        if ($rb -match '^(.+?)/(.+)$') {
                                            $bindObjs += [PSCustomObject]@{
                                                protocol           = $Matches[1]
                                                bindingInformation = $Matches[2]
                                            }
                                        }
                                    }
                                }
                                # Resolve physical path via appcmd list vdir
                                $physPath = $null
                                try {
                                    $sn = $siteNode.'SITE.NAME'
                                    $vdirOut = & $appcmd list vdir "/app.name:$sn/" /xml 2>$null
                                    if ($vdirOut) {
                                        [xml]$vx = ($vdirOut -join "`n")
                                        $physPath = $vx.appcmd.VDIR.physicalPath
                                    }
                                }
                                catch {}
                                $sites += [PSCustomObject]@{
                                    Name         = $siteNode.'SITE.NAME'
                                    id           = $siteNode.'SITE.ID'
                                    state        = $siteNode.state
                                    physicalPath = $physPath
                                    bindings     = [PSCustomObject]@{ Collection = $bindObjs }
                                }
                            }
                            $report.Notes += "WebAdministration module unavailable; sites discovered via appcmd.exe /xml"
                        }
                    }
                    catch {
                        $report.Notes += "appcmd site enumeration failed: $_"
                    }
                }
                else {
                    $report.Notes += "Get-Website unavailable and appcmd.exe not found - cannot enumerate sites."
                }
            }

            foreach ($s in $sites) {
                # Build binding objects
                $bindings = @()
                if ($s.bindings) {
                    foreach ($b in $s.bindings.Collection) {
                        # binding has fields protocol, bindingInformation (ip:port:host)
                        $bindInfo = $b.bindingInformation
                        $ip, $port, $bindingHost = $bindInfo -split (':', 3)
                        # capture certificate info if present
                        $certThumb = $null
                        $certStore = $null
                        # for https, WebAdministration stores sslFlags/certHash
                        try {
                            $bh = $b.CertificateHash 2>$null
                            if ($bh) { $certThumb = ($bh | ForEach-Object { $_.ToString('X2') }) -join '' }
                        }
                        catch {}
                        if (-not $certThumb) {
                            # try appcmd query for this site:binding
                            # skip for now
                        }
                        $bindings += [ordered]@{
                            Protocol              = $b.protocol
                            BindingInformation    = $bindInfo
                            IP                    = $ip
                            Port                  = $port
                            Host                  = $bindingHost
                            CertificateThumbprint = $certThumb
                            CertificateStore      = $certStore
                        }
                    }
                }

                # get physical path and virtual directories via IIS:\ drive
                $physicalPath = $null
                $vdirs = @()
                try {
                    $sitePath = "IIS:\Sites\$($s.Name)"
                    if (Test-Path $sitePath) {
                        $apps = Get-ChildItem $sitePath | Where-Object { $_.PSIsContainer -and $_.Name -ne 'Bindings' } -ErrorAction SilentlyContinue
                        foreach ($app in $apps) {
                            # each application may have virtual directories
                            $apppath = $app.Path
                            $vdirNodes = Get-ChildItem $app.PSPath -ErrorAction SilentlyContinue
                            foreach ($v in $vdirNodes) {
                                if ($v.SchemaClassName -eq "VDir") {
                                    $vdirs += [ordered]@{
                                        Application  = $app.Path
                                        VirtualPath  = $v.Path
                                        PhysicalPath = $v.physicalPath
                                    }
                                }
                            }
                        }
                        # Get physical path for root application
                        $rootApp = Get-Item "$sitePath/root" -ErrorAction SilentlyContinue
                        if ($rootApp) {
                            $physicalPath = $rootApp.physicalPath
                        }
                    }
                }
                catch {
                    $report.Notes += "Failed to enumerate vdirs for site $($s.Name): $_"
                }

                # If IIS: PSDrive was unavailable (WebAdministration not loaded), fall back to
                # physicalPath already resolved via appcmd in the site object
                if (-not $physicalPath -and $s.PSObject.Properties['physicalPath'] -and $s.physicalPath) {
                    $physicalPath = $s.physicalPath
                }

                $report.Sites += [ordered]@{
                    Name               = $s.Name
                    ID                 = $s.id
                    State              = $s.state
                    PhysicalPath       = $physicalPath
                    Bindings           = $bindings
                    VirtualDirectories = $vdirs
                }
            }
        }
        catch {
            $report.Notes += "Error enumerating sites: $_"
        }

        # 5) Get AppPools
        try {
            if (Get-Command -Name Get-WebAppPoolState -ErrorAction SilentlyContinue) {
                # Try IIS: PSDrive first; fall back to Get-WebConfiguration if unavailable (PS7 WinPSCompat)
                $appPools = $null
                try {
                    $appPools = Get-ChildItem IIS:\AppPools -ErrorAction Stop
                }
                catch {
                    # IIS: PSDrive not registered in PS7 WinPSCompat session
                    $appPools = Get-WebConfiguration /system.applicationHost/applicationPools/add -ErrorAction SilentlyContinue
                }
                foreach ($ap in $appPools) {
                    $poolState = $null
                    try { $poolState = (Get-WebAppPoolState -Name $ap.Name -ErrorAction SilentlyContinue).Value } catch {}
                    $poolObj = [ordered]@{
                        Name                     = $ap.Name
                        State                    = $poolState
                        PipelineMode             = $ap.managedPipelineMode
                        ManagedRuntimeVersion    = $ap.managedRuntimeVersion
                        ProcessModelIdentityType = $ap.processModel.identityType
                        ProcessModelUserName     = $ap.processModel.userName
                        Recycle                  = $ap.recycling.periodicRestart
                        MaxProcesses             = $ap.processModel.maxProcesses
                    }
                    $report.AppPools += $poolObj
                }
            }
            else {
                # fallback to appcmd list apppool
                $appcmd = Join-Path $env:windir "System32\inetsrv\appcmd.exe"
                if (Test-Path $appcmd) {
                    $raw = & $appcmd list apppool /text:* 2>$null
                    $report.AppCmdAppPools = $raw
                }
            }
        }
        catch {
            $report.Notes += "Failed to enumerate AppPools: $_"
        }

        # 6) Map sites -> app pool
        try {
            foreach ($site in $report.Sites) {
                # use IIS drive (or Get-WebConfiguration fallback) to get application pool mapping for root
                $siteName = $site.Name
                try {
                    $rootPool = $null
                    # Try IIS: PSDrive first
                    if (Test-Path "IIS:") {
                        $appPath = "IIS:\Sites\$siteName\"
                        $rootApp = Get-Item -Path ($appPath + "root") -ErrorAction SilentlyContinue
                        if ($rootApp -and $null -ne $rootApp.applicationPool) {
                            $rootPool = $rootApp.applicationPool
                        }
                        else {
                            # check applications
                            $apps = Get-ChildItem "IIS:\Sites\$siteName" -ErrorAction SilentlyContinue
                            foreach ($a in $apps) {
                                if ($a.ItemType -eq "Application") {
                                    $site.Applications += [ordered]@{
                                        Path            = $a.Path
                                        ApplicationPool = $a.applicationPool
                                    }
                                }
                            }
                        }
                    }
                    else {
                        # IIS: PSDrive unavailable (PS7 WinPSCompat) - use Get-WebConfiguration
                        $filter = "/system.applicationHost/sites/site[@name='$siteName']/application[@path='/']"
                        $rootApp = Get-WebConfiguration $filter -ErrorAction SilentlyContinue
                        if ($rootApp) { $rootPool = $rootApp.applicationPool }
                    }
                    if ($rootPool) { $site.AppPool = $rootPool }
                }
                catch { }
            }
        }
        catch {}

        # 6.5) Migration binding checks
        # IP Binding  (Warning): site is bound to a specific IP instead of *, which will break if the IP changes after migration.
        # Invalid Binding (Error): the bound IP does not exist on any local NIC right now.
        try {
            $nicIPs = @($report.NetworkConfig | ForEach-Object { $_.IPAddress } | Where-Object { $_ -and $_ -ne '' })

            foreach ($site in $report.Sites) {
                foreach ($binding in $site.Bindings) {
                    $bindInfo = $binding.BindingInformation
                    if (-not $bindInfo) { continue }

                    # Extract IP from binding string "IP:Port:HostHeader"
                    $bindIP = $null
                    if ($bindInfo -match '^(\d+\.\d+\.\d+\.\d+):') {
                        $bindIP = $Matches[1]
                    }

                    if ($bindIP) {
                        $ipOnServer = ($nicIPs.Count -gt 0 -and $nicIPs -contains $bindIP)

                        if ($ipOnServer) {
                            # IP Binding: the IP exists on this server but is hardcoded.
                            # Only relevant in Pre-migration — if the IP changes post-migration
                            # these bindings will break and must be updated.
                            if ($CheckTypeShort -eq 'Pre') {
                                $report.MigrationAlerts += [ordered]@{
                                    Type     = 'IP_Binding'
                                    Severity = 'Warning'
                                    Site     = $site.Name
                                    Binding  = "$($binding.Protocol) $bindInfo"
                                    Message  = "Site '$($site.Name)' binding '$($binding.Protocol) $bindInfo' uses a specific IP address ($bindIP) that is currently assigned to this server. If the server IP changes after migration, this binding must be updated manually."
                                }
                            }
                        }
                        else {
                            # Invalid Binding: the IP is not on any local NIC — already broken.
                            # No need to also warn about IP changes; fix the binding first.
                            if ($nicIPs.Count -gt 0) {
                                $report.MigrationAlerts += [ordered]@{
                                    Type     = 'Invalid_Binding'
                                    Severity = 'Error'
                                    Site     = $site.Name
                                    Binding  = "$($binding.Protocol) $bindInfo"
                                    Message  = "Site '$($site.Name)' binding '$($binding.Protocol) $bindInfo' references IP $bindIP which is not assigned to any network interface on this server (NIC IPs: $($nicIPs -join ', '))."
                                }
                            }
                        }
                    }
                }
            }
        }
        catch {
            $report.Notes += "Migration binding checks failed: $_"
        }

        # 7) SSL certificate info (thumbprint -> cert details)
        try {
            $certs = @()
            # Get thumbprints found in bindings
            $thumbs = ($report.Sites | ForEach-Object { $_.Bindings } | ForEach-Object { $_ } | Where-Object { $_.CertificateThumbprint } | Select-Object -ExpandProperty CertificateThumbprint -Unique) -ne $null
            # Also collect netsh sslcert entries
            $netshOut = & netsh http show sslcert 2>$null
            $report.NetshSsl = $netshOut
            # Also pull local machine My certs
            try {
                $store = New-Object System.Security.Cryptography.X509Certificates.X509Store("My", "LocalMachine")
                $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)
                $store.Certificates | ForEach-Object {
                    $certs += [ordered]@{
                        Thumbprint   = $_.Thumbprint
                        Subject      = $_.Subject
                        Issuer       = $_.Issuer
                        NotBefore    = $_.NotBefore
                        NotAfter     = $_.NotAfter
                        FriendlyName = $_.FriendlyName
                        SerialNumber = $_.SerialNumber
                    }
                }
                $store.Close()
                $report.SSLCertificates = $certs
            }
            catch {
                $report.Notes += "Failed to read LocalMachine\\My cert store: $_"
            }
        }
        catch {
            $report.Notes += "Failed gathering cert info: $_"
        }

        # 8) netsh http show sslcert raw (already above)
        # included in report.NetshSsl

        # 9) Get relevant Windows services
        try {
            $svcNames = "W3SVC", "WAS", "IISADMIN"
            $svcs = Get-Service -Name $svcNames -ErrorAction SilentlyContinue | Select-Object Name, DisplayName, Status
            $report.Services = $svcs
        }
        catch {
            $report.Notes += "Failed to collect IIS services: $_"
        }

        # 10) Installed IIS features (if possible)
        try {
            if (Get-Command -Name Get-WindowsFeature -ErrorAction SilentlyContinue) {
                $roles = Get-WindowsFeature *web* -ErrorAction SilentlyContinue
                $report.IISFeatures = $roles | Where-Object { $_.Installed -eq $true } | Select-Object -Property DisplayName, Name
            }
        }
        catch {}

        # 11) Optionally scan for web.config files & simple file list per site root (limited)
        if ($ScanWebConfigs) {
            $report.WebConfigFiles = @()
            foreach ($site in $report.Sites) {
                if ($site.PhysicalPath) {
                    try {
                        $path = $site.PhysicalPath
                        if (Test-Path $path) {
                            $found = Get-ChildItem -Path $path -Filter web.config -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First $MaxFiles
                            $report.WebConfigFiles += [ordered]@{
                                Site       = $site.Name
                                Root       = $path
                                WebConfigs = $found | Select-Object FullName, LastWriteTime
                            }
                        }
                        else {
                            $report.Notes += "Physical path for site $($site.Name) not found: $path"
                        }
                    }
                    catch {
                        $report.Notes += "Error scanning web.configs under $path : $_"
                    }
                }
            }
        }

        # 12) File ACLs for site root(s) (owner + basic permissions)
        try {
            $report.SiteFileAcl = @()
            foreach ($site in $report.Sites) {
                $p = $site.PhysicalPath
                if ($p -and (Test-Path $p)) {
                    try {
                        $acl = Get-Acl -LiteralPath $p
                        $report.SiteFileAcl += [ordered]@{
                            Site   = $site.Name
                            Path   = $p
                            Owner  = $acl.Owner
                            Access = $acl.Access | Select-Object IdentityReference, FileSystemRights, AccessControlType
                        }
                    }
                    catch {
                        $report.Notes += "Failed to Get-Acl on $p : $_"
                    }
                }
            }
        }
        catch {}

        # 13) Save results: JSON + small text summary
        try {
            # Save files directly in base output directory
            $jsonPath = Join-Path $BaseOutputPath ("$($TargetName)_$($CheckTypeShort)_IIS_Config.json")
            $report | ConvertTo-Json -Depth 6 | Out-File -FilePath $jsonPath -Encoding UTF8
            $report.JsonPath = $jsonPath
            write-host "Saved IIS report JSON to: $jsonPath" -ForegroundColor Green

            # small human-readable summary
            $summary = @()
            $summary += "IIS report for $TargetName collected at $($report.CollectedAt)"
            $summary += "IIS Installed: $($report.IISInstalled)"
            $summary += "Sites found: $($report.Sites.Count)"
            foreach ($st in $report.Sites) {
                $summary += (" - {0} (ID:{1}) State:{2} PhysicalPath:{3} Bindings:{4}" -f $st.Name, $st.ID, $st.State, $st.PhysicalPath, (@($st.Bindings | ForEach-Object { $_.BindingInformation }) -join '; '))
            }
            $summaryPath = Join-Path $BaseOutputPath "$($TargetName)_IISReport_Summary.txt"
            $summary | Out-File -FilePath $summaryPath -Encoding UTF8
            $report.SummaryPath = $summaryPath

            # Clean up loose .bak config backup (no longer zipped)
            if ($report.ApplicationHostConfigBackup -and (Test-Path $report.ApplicationHostConfigBackup)) {
                Remove-Item -LiteralPath $report.ApplicationHostConfigBackup -Force -ErrorAction SilentlyContinue
            }
        }
        catch {
            $report.Notes += "Failed to save output artifacts: $_"
        }

    }
    catch {
        $report.Notes += "Top-level error collecting IIS data: $_"
    }

    return $report
}

# Determine target servers using standardized logic
$targetServers = @()
$MyHostName = (Get-CimInstance -ClassName Win32_ComputerSystem).DNSHostName
if ($RunLocally -or $ServerName -eq "localhost") {
    $targetServers = @($MyHostName)
}
elseif ($ServerName) {
    # Handle comma-separated server names
    if ($ServerName -match ',') {
        $targetServers = $ServerName -split ',' | ForEach-Object { $_.Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    }
    else {
        $targetServers = @($ServerName.Trim())
    }
}
else {
    if (Test-Path $ServerList) {
        try {
            $csv = Import-Csv -Path $ServerList
            foreach ($entry in $csv) {
                # Only include rows that provide an actual host name (Server or ServerName).
                $hostPart = $null
                if ($entry.Server) { $hostPart = $entry.Server }
                elseif ($entry.ServerName) { $hostPart = $entry.ServerName }

                if ($hostPart) {
                    $NewServerNameFQDN = $hostPart
                    if ($entry.DomainName) {
                        $NewServerNameFQDN += "." + $entry.DomainName
                    }
                    $targetServers += $NewServerNameFQDN
                }
                else {
                    # Skip rows that do not contain a host; avoid creating entries like ".domain.com" which yield empty hostnames later
                    continue
                }
            }
        }
        catch {
            Write-Warning "Failed to import CSV. Defaulting to localhost."
            $targetServers = @($MyHostName)
        }
    }
    else {
        Write-Warning "Server list file not found. Defaulting to localhost."
        $targetServers = @($MyHostName)
    }
}
# Normalize the target servers list: trim whitespace, remove empty entries, and deduplicate
$targetServers = $targetServers | ForEach-Object { $_.ToString().Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
Write-Host "Target servers: $($targetServers -join ', ')"

# Determine base output directory (matches CollectSQLData.ps1 pattern)
$baseOutputDir = if ($OutputPath) {
    # If OutputPath is provided, use it as base directory
    if (Test-Path $OutputPath -PathType Container) {
        $OutputPath
    }
    else {
        # If OutputPath doesn't exist, use it directly (will be created)
        $OutputPath
    }
}
else {
    # Default to current directory + "IISReports"
    Join-Path (Get-Location) "IISReports"
}

Write-Log "Base output directory: $baseOutputDir"

# Ensure base output directory exists
if (-not (Test-Path $baseOutputDir)) {
    try {
        New-Item -Path $baseOutputDir -ItemType Directory -Force | Out-Null
        Write-Log "Created base output directory: $baseOutputDir"
    }
    catch {
        Write-Log "Failed to create base output directory: $baseOutputDir - $($_.Exception.Message)" "ERROR"
        throw
    }
}

# Process each server
$successCount = 0
$failCount = 0
$totalServers = $targetServers.Count
$allReports = @()

foreach ($serverFQDN in $targetServers) {
    Write-Log "Processing server $($successCount + $failCount + 1) of $totalServers`: $serverFQDN"

    # Extract hostname from FQDN for directory/file naming
    $serverNameToProcess = if ($serverFQDN -match '\.') {
        $serverFQDN.Split('.')[0]
    } else {
        $serverFQDN
    }

    Write-Log "Using hostname '$serverNameToProcess' for output directory"

    # Resolve connect target: try FQDN first, fall back to short hostname if DNS fails
    $connectTarget = $serverFQDN
    if ($serverFQDN -ne $serverNameToProcess) {
        try {
            $dnsCheck = Resolve-DnsName -Name $serverFQDN -Type A -ErrorAction Stop | Where-Object { $_.IPAddress -match '^[0-9]+\.' } | Select-Object -First 1
            if (-not $dnsCheck) {
                $shortCheck = Resolve-DnsName -Name $serverNameToProcess -Type A -ErrorAction Stop | Where-Object { $_.IPAddress -match '^[0-9]+\.' } | Select-Object -First 1
                if ($shortCheck) {
                    Write-Log "FQDN '$serverFQDN' did not resolve; using short hostname '$serverNameToProcess' for connection"
                    $connectTarget = $serverNameToProcess
                }
            }
        }
        catch {
            try {
                $null = Resolve-DnsName -Name $serverNameToProcess -Type A -ErrorAction Stop
                Write-Log "FQDN '$serverFQDN' did not resolve; using short hostname '$serverNameToProcess' for connection"
                $connectTarget = $serverNameToProcess
            }
            catch {
                Write-Log "Neither FQDN '$serverFQDN' nor short hostname '$serverNameToProcess' resolved via DNS; attempting connection anyway" "WARN"
            }
        }
    }

    try {
        # Create server-specific directory structure (matches CollectSQLData.ps1)
        # Use OutputPath directly as base + append server name (no extra Artifacts\ nesting),
        # so callers that already resolved the per-server dir can pass their parent directory.
        $serverOutputDir = Join-Path $baseOutputDir $serverNameToProcess
        $outputFileName = "$($serverNameToProcess)_$($CheckTypeShort)_IIS_Config.json"
        $serverOutputPath = Join-Path $serverOutputDir $outputFileName

        # Ensure server-specific output directory exists
        if (-not (Test-Path $serverOutputDir)) {
            try {
                New-Item -Path $serverOutputDir -ItemType Directory -Force | Out-Null
                Write-Log "Created server output directory: $serverOutputDir"
            }
            catch {
                Write-Log "Failed to create server output directory: $serverOutputDir - $($_.Exception.Message)" "ERROR"
                throw
            }
        }

        Write-Log "Collecting IIS data from $serverFQDN -> $serverOutputPath"

        # Determine if this is local or remote execution
        # Compare $serverFQDN against local hostname (both short and FQDN forms)
        $isLocalExecution = ($serverFQDN -ieq $env:COMPUTERNAME) -or
                           ($serverFQDN -ieq $MyHostName) -or
                           ($serverFQDN -ieq "$MyHostName.$env:USERDNSDOMAIN") -or
                           ($serverFQDN -eq 'localhost') -or
                           ($serverNameToProcess -ieq $env:COMPUTERNAME) -or
                           ($serverNameToProcess -ieq $MyHostName)

        # Collect IIS data from the server
        if ($isLocalExecution) {
            Write-Log "Detected local execution for $serverFQDN"
            $report = Collect-LocalIISData -TargetName $serverNameToProcess -BaseOutputPath $serverOutputDir -ScanWebConfigs:$IncludeWebConfigScan -MaxFiles $MaxFilesPerSite -CheckTypeShort $CheckTypeShort
        }
        else {
            Write-Log "Detected remote execution for $serverFQDN"
            $report = $null
            $connectionSucceeded = $false
            $attemptErrors = [System.Collections.Generic.List[string]]::new()

            # IIS remote scriptblock (runs on the target server)
            $iisRemoteScript = {
                param($ScanWebConfigs, $MaxFiles)
                $out = [ordered]@{
                    ComputerName = $env:COMPUTERNAME
                    CollectedAt  = (Get-Date).ToString("o")
                    IISInstalled = $false
                    Sites        = @()
                    AppPools     = @()
                    Notes        = @()
                }
                try {
                    if (Get-Command -Name Get-Website -ErrorAction SilentlyContinue) {
                        Import-Module WebAdministration -ErrorAction SilentlyContinue
                        $out.IISInstalled = $true
                        $sites = Get-Website -ErrorAction SilentlyContinue
                        if ($sites) {
                            $out.Sites = $sites | Select-Object name, id, state, physicalPath, @{Name = 'Bindings'; Expression = { $_.bindings.Collection | ForEach-Object { [ordered]@{Protocol = $_.protocol; BindingInformation = $_.bindingInformation } } } }
                        }
                        $appPools = Get-IISAppPool -ErrorAction SilentlyContinue
                        if ($appPools) {
                            $out.AppPools = $appPools | Select-Object Name, State, ProcessModel, Recycling
                        }
                    }
                    else {
                        $out.Notes += "IIS WebAdministration module not available"
                    }
                }
                catch {
                    $out.Notes += "Error collecting IIS data: $($_.Exception.Message)"
                }
                return $out
            }

            function Add-WinRmTrustedHostIfNeeded {
                param([string]$RemoteServer)

                try {
                    $currentTrustedHosts = (Get-Item WSMan:\localhost\Client\TrustedHosts -ErrorAction SilentlyContinue).Value
                    $trustedHostPatterns = @($currentTrustedHosts -split ',' | ForEach-Object { ([string]$_).Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

                    # '*' must stand alone. If a previous run left '*,server', normalize it back to '*'.
                    if ($trustedHostPatterns -contains '*') {
                        if ($trustedHostPatterns.Count -gt 1) {
                            Set-Item WSMan:\localhost\Client\TrustedHosts -Value '*' -Force -ErrorAction Stop
                            Write-Log "Normalized WSMan TrustedHosts wildcard entry back to '*'"
                        }
                        return
                    }

                    if ($trustedHostPatterns -contains $RemoteServer) {
                        return
                    }

                    $newTrustedHosts = @($trustedHostPatterns + $RemoteServer) -join ','
                    Set-Item WSMan:\localhost\Client\TrustedHosts -Value $newTrustedHosts -Force -ErrorAction Stop
                    Write-Log "Added $RemoteServer to WSMan TrustedHosts for explicit-auth fallback"
                }
                catch {
                    Write-Log "Could not update TrustedHosts (non-fatal): $($_.Exception.Message)" "WARN"
                }
            }

            # Helper: single Invoke-Command attempt — mirrors MigrationCheck-DataCollector logic
            function Invoke-IISRemoteScanAttempt {
                param(
                    [string]$AttemptLabel,
                    [string]$AttemptComputerName,
                    [bool]$UseSSL,
                    [System.Management.Automation.PSCredential]$AttemptCredential,
                    [bool]$IncludePortInSPN = $false,
                    [string]$Authentication = ''
                )
                try {
                    $attemptUser = if ($AttemptCredential) { $AttemptCredential.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
                    if ($Authentication -eq 'Basic' -and -not $AttemptCredential) {
                        Write-Log "Skipping $AttemptLabel for $AttemptComputerName because Basic authentication requires explicit credentials." "WARN"
                        return [PSCustomObject]@{ Succeeded = $false; Data = $null; LastError = 'Basic authentication requires explicit credentials.'; UserName = $attemptUser }
                    }
                    if (-not [string]::IsNullOrWhiteSpace($Authentication)) {
                        Add-WinRmTrustedHostIfNeeded -RemoteServer $AttemptComputerName
                    }
                    Write-Log "Attempting IIS connection to $AttemptComputerName using $AttemptLabel as $attemptUser..."
                    $p = @{
                        ComputerName  = $AttemptComputerName
                        ScriptBlock   = $iisRemoteScript
                        ArgumentList  = $IncludeWebConfigScan, $MaxFilesPerSite
                        ErrorAction   = 'Stop'
                    }
                    if ($UseSSL -or $IncludePortInSPN) {
                        try {
                            $soParams = @{}
                            if ($UseSSL)            { $soParams.SkipCACheck = $true; $soParams.SkipCNCheck = $true; $soParams.SkipRevocationCheck = $true }
                            if ($IncludePortInSPN)  { $soParams.IncludePortInSPN = $true }
                            $p.SessionOption = New-PSSessionOption @soParams
                        } catch { }
                    }
                    if ($UseSSL)     { $p.UseSSL = $true; $p.Port = 5986 }
                    if ($AttemptCredential) { $p.Credential = $AttemptCredential }
                    if (-not [string]::IsNullOrWhiteSpace($Authentication)) { $p.Authentication = $Authentication }

                    $result = Invoke-Command @p
                    Write-Log "Successfully connected to $AttemptComputerName using $AttemptLabel as $attemptUser"
                    return [PSCustomObject]@{ Succeeded = $true; Data = $result; LastError = $null; UserName = $attemptUser }
                }
                catch {
                    $msg = $_.Exception.Message
                    $attemptUser = if ($AttemptCredential) { $AttemptCredential.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
                    $attemptErrors.Add("$AttemptLabel as $attemptUser failed: $msg") | Out-Null
                    Write-Log "Failed to connect to $AttemptComputerName using ${AttemptLabel} as ${attemptUser}: $msg" "WARN"
                    return [PSCustomObject]@{ Succeeded = $false; Data = $null; LastError = $msg; UserName = $attemptUser }
                }
            }

            # Build connection targets: FQDN first, then short hostname, then DNS-resolved name
            $connectionTargets = [System.Collections.Generic.List[string]]::new()
            if (-not [string]::IsNullOrWhiteSpace($connectTarget))        { $connectionTargets.Add($connectTarget) | Out-Null }
            if (-not [string]::IsNullOrWhiteSpace($serverNameToProcess) -and -not ($connectionTargets -contains $serverNameToProcess)) {
                $connectionTargets.Add($serverNameToProcess) | Out-Null
            }
            try {
                $resolvedHostName = ([System.Net.Dns]::GetHostEntry($connectTarget)).HostName
                if (-not [string]::IsNullOrWhiteSpace($resolvedHostName) -and -not ($connectionTargets -contains $resolvedHostName)) {
                    $connectionTargets.Add($resolvedHostName) | Out-Null
                }
            } catch { }

            $preferCurrentUserFirst = (-not $UseCredential)
            if ($credential -and $preferCurrentUserFirst) {
                try {
                    $computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
                    if (-not [bool]$computerSystem.PartOfDomain) {
                        $preferCurrentUserFirst = $false
                        Write-Log "Local computer is not domain-joined; explicit credentials will be attempted before current user context." "WARN"
                    }
                } catch {
                    Write-Log "Could not determine local domain membership: $($_.Exception.Message)" "WARN"
                }
            }
            $attemptResult = $null

            foreach ($connectionTarget in $connectionTargets) {
                if ($connectionSucceeded) { break }

                if ($preferCurrentUserFirst) {
                    $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null
                    $connectionSucceeded = [bool]$attemptResult.Succeeded
                    $cuHttpLastError = $attemptResult.LastError
                    if (-not $connectionSucceeded) {
                        $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $null
                        $connectionSucceeded = [bool]$attemptResult.Succeeded
                    }
                    $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
                    if (-not $connectionSucceeded -and (($cuHttpLastError -match $crossDomainPattern) -or ($attemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                        $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null -Authentication 'Negotiate'
                        $connectionSucceeded = [bool]$attemptResult.Succeeded
                    }
                }

                if (-not $connectionSucceeded -and $credential) {
                    $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $credential
                    $connectionSucceeded = [bool]$attemptResult.Succeeded
                    $httpLastError = $attemptResult.LastError
                    if (-not $connectionSucceeded -and $httpLastError -match '0x80090322|An unknown security error') {
                        $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 +IncludePortInSPN)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $credential -IncludePortInSPN $true
                        $connectionSucceeded = [bool]$attemptResult.Succeeded
                    }
                    if (-not $connectionSucceeded) {
                        $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $credential
                        $connectionSucceeded = [bool]$attemptResult.Succeeded
                    }
                    $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
                    if (-not $connectionSucceeded -and (($httpLastError -match $crossDomainPattern) -or ($attemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                        $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $credential -Authentication 'Negotiate'
                        $connectionSucceeded = [bool]$attemptResult.Succeeded
                        if (-not $connectionSucceeded) {
                            $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTPS/5986 Basic)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $credential -Authentication 'Basic'
                            $connectionSucceeded = [bool]$attemptResult.Succeeded
                        }
                    }
                }

                if (-not $preferCurrentUserFirst -and -not $connectionSucceeded) {
                    $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null
                    $connectionSucceeded = [bool]$attemptResult.Succeeded
                    $cuHttpLastError = $attemptResult.LastError
                    if (-not $connectionSucceeded) {
                        $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $null
                        $connectionSucceeded = [bool]$attemptResult.Succeeded
                    }
                    $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
                    if (-not $connectionSucceeded -and (($cuHttpLastError -match $crossDomainPattern) -or ($attemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                        $attemptResult = Invoke-IISRemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null -Authentication 'Negotiate'
                        $connectionSucceeded = [bool]$attemptResult.Succeeded
                    }
                }
            }

            if ($connectionSucceeded -and $attemptResult.Data) {
                $report = $attemptResult.Data
            }

            # If all attempts failed, create error report
            if (-not $connectionSucceeded) {
                $errorMessage = "Failed to connect to $connectTarget with all available methods. Attempts: $($attemptErrors -join ' | ')"
                Write-Log $errorMessage "ERROR"

                # Create error report if remote connection fails
                $report = [ordered]@{
                    ComputerName = $serverNameToProcess
                    CollectedAt  = (Get-Date).ToString("o")
                    IISInstalled = $false
                    Sites        = @()
                    AppPools     = @()
                    Notes        = @($errorMessage)
                    Error        = $errorMessage
                    ConnectionFailed = $true
                }

                # Save error report but don't generate HTML or count as success
                try {
                    $report | ConvertTo-Json -Depth 6 | Out-File -FilePath $serverOutputPath -Encoding UTF8
                    Write-Log "Saved connection error report for $serverNameToProcess to $serverOutputPath" "WARN"
                }
                catch {
                    Write-Log "Failed to save error report for $serverNameToProcess`: $($_.Exception.Message)" "ERROR"
                }

                $allReports += $report
                $failCount++
                continue  # Skip HTML generation for failed connections
            }
        }

        # Save individual server report (only reached for successful connections)
        if ($report -and -not $report.ConnectionFailed) {
            try {
                $report | ConvertTo-Json -Depth 6 | Out-File -FilePath $serverOutputPath -Encoding UTF8

                # Determine if this was a successful IIS data collection vs non-IIS server
                if ($report.IISInstalled -or ($report.Sites -and $report.Sites.Count -gt 0)) {
                    Write-Log "Successfully collected IIS data for $serverNameToProcess (IIS installed: $($report.IISInstalled), Sites found: $($report.Sites.Count))"

                    # Generate HTML report only for servers with IIS
                    try {
                        Write-Log "Generating HTML report for $serverNameToProcess from JSON: $serverOutputPath"

                        # Try multiple possible locations for the HTML converter
                        $htmlConverterPaths = @(
                            (Join-Path $PSScriptRoot "Convert-IISConfigToHTML.ps1"),
                            (Join-Path (Split-Path $PSScriptRoot -Parent) "Reports\IIS\Convert-IISConfigToHTML.ps1"),
                            (Join-Path (Split-Path $PSScriptRoot -Parent) "Scripts\Convert-IISConfigToHTML.ps1")
                        )

                        $htmlConverterPath = $null
                        foreach ($path in $htmlConverterPaths) {
                            if (Test-Path $path) {
                                $htmlConverterPath = $path
                                break
                            }
                        }

                        if ($htmlConverterPath) {
                            Write-Log "Found HTML converter at: $htmlConverterPath"
                            & $htmlConverterPath -JSONFile $serverOutputPath
                            $htmlPath = $serverOutputPath -replace '\.json$', '.html'
                            if (Test-Path $htmlPath) {
                                Write-Log "HTML report generated for $serverNameToProcess`: $htmlPath"

                                # Regenerate the SPA Server Report so the IIS Config tab
                                # appears immediately without a separate "Regen Reports" step.
                                $htmlGenPaths = @(
                                    (Join-Path $PSScriptRoot "MigrationCheck-HtmlGenerator.ps1"),
                                    (Join-Path $PSScriptRoot "..\MigrationCheck-HtmlGenerator.ps1")
                                )
                                $htmlGenPath = $htmlGenPaths | Where-Object { Test-Path $_ } | Select-Object -First 1
                                if ($htmlGenPath) {
                                    Write-Log "Regenerating SPA Server Report to include IIS tab for $serverNameToProcess"
                                    try {
                                        & $htmlGenPath -JsonDirectory $serverOutputDir -ErrorAction Stop 2>&1 |
                                            Where-Object { $_ -match 'OK|WARN|Error|SPA|generated' } |
                                            ForEach-Object { Write-Log "  [HtmlGen] $_" }
                                    }
                                    catch {
                                        Write-Log "SPA Server Report regeneration failed (non-fatal): $($_.Exception.Message)" "WARN"
                                    }
                                }
                                else {
                                    Write-Log "MigrationCheck-HtmlGenerator.ps1 not found — skipping SPA regeneration" "WARN"
                                }
                            }
                        }
                        else {
                            Write-Log "HTML converter not found - skipping HTML generation for $serverNameToProcess" "WARN"
                        }
                    }
                    catch {
                        Write-Log "Failed to generate HTML report for $serverNameToProcess`: $_" "WARN"
                    }
                }
                else {
                    Write-Log "Successfully connected to $serverNameToProcess but IIS is not installed or no sites found" "INFO"
                }

                $allReports += $report
                $successCount++
            }
            catch {
                Write-Log "Failed to save IIS data for $serverNameToProcess`: $($_.Exception.Message)" "WARN"
                $allReports += $report  # Still add to collection for troubleshooting
                $failCount++
            }
        }
    }
    catch {
        Write-Log "Failed to process server $serverNameToProcess`: $($_.Exception.Message)" "WARN"
        $failCount++
    }
}



# Write final summary with detailed breakdown
Write-Log "IIS data collection completed:"
Write-Log "  Total servers: $totalServers"
Write-Log "  Successful connections: $successCount"
Write-Log "  Failed connections: $failCount"

if ($failCount -gt 0) {
    Write-Log "Connection failures indicate PowerShell remoting issues - check WinRM configuration, credentials, and network connectivity" "WARN"
}

# Analyze successful connections for IIS vs non-IIS servers
$iisServers = @($allReports | Where-Object { $_.IISInstalled -eq $true -or ($_.Sites -and $_.Sites.Count -gt 0) })
$nonIisServers = @($allReports | Where-Object { -not $_.ConnectionFailed -and -not $_.IISInstalled -and (-not $_.Sites -or $_.Sites.Count -eq 0) })

if ($iisServers.Count -gt 0) {
    Write-Log "IIS servers found: $($iisServers.Count)" "INFO"
    foreach ($iisServer in $iisServers) {
        Write-Log "  - $($iisServer.ComputerName): $($iisServer.Sites.Count) sites" "INFO"
    }
}

if ($nonIisServers.Count -gt 0) {
    Write-Log "Non-IIS servers (successful connection, no IIS): $($nonIisServers.Count)" "INFO"
    foreach ($nonIisServer in $nonIisServers) {
        Write-Log "  - $($nonIisServer.ComputerName): Connected but IIS not installed" "INFO"
    }
}
