#Requires -Version 5.1
<#
.SYNOPSIS
    Generates a client-facing HTML artifact collection status report for the Avanade Cloud Impact MOVE - Client Discovery package.

.DESCRIPTION
    Scans the output directory, or its Artifacts subdirectory when present, for collected JSON artifact files
    per server and cross-references with the latest access check CSV to explain why servers may have no
    artifacts. Produces a professional, Avanade-branded HTML report suitable for client delivery.

    For each server the report shows:
      - Whether the main migration JSON was collected
    - Whether SQL Config JSON was collected when SQL evidence exists in the main artifact
    - Whether IIS Config JSON was collected when IIS evidence exists in the main artifact
    - Whether Log Analytics CSV output was exported for the server
      - The access check result (OK / Failed / Not Checked)
      - Any error messages from the access check
      - An overall status (Complete / Partial / No Data / Access Failed)

    Folder layout expected under OutputDir:
      {OutputDir}\{ServerName}\{ServerName}_Pre_Migration.json   (main artifact)
    {OutputDir}\{ServerName}\{ServerName}_Pre_SQL_Config.json   (expected only when SQL evidence exists)
    {OutputDir}\{ServerName}\{ServerName}_Pre_IIS_Config.json   (expected only when IIS evidence exists)
    {OutputDir}\{ServerName}\{ServerName}_Pre_LogAnalytics_*.csv   (optional Log Analytics export)
    {OutputDir}\Reports\Access\*.csv   (access check results - latest used)

        If {OutputDir}\Artifacts exists, the script uses that folder as the artifact source instead:
            {OutputDir}\Artifacts\{ServerName}\{ServerName}_Pre_Migration.json
            {OutputDir}\Artifacts\Reports\Access\*.csv

        Access check CSVs are searched in both {OutputDir}\Reports\Access and the artifact source Reports\Access
        folder. The newest CSV found in either location is used.

.PARAMETER OutputDir
    Base output directory used during data collection. Server sub-folders are expected directly under this path.
    Defaults to the current directory.

.PARAMETER ServerList
    Optional path to the original server list CSV. Used to populate OS type for servers that have no artifact folder.
    The CSV must contain at minimum a 'Server' column. An 'OSType' column is optional.

.PARAMETER CheckType
    Collection check type label. Accepted values: Pre_Migration, Post_Migration. Defaults to Pre_Migration.

.PARAMETER ReportPath
    Full path for the output HTML report. If not specified the report is saved to:
    {OutputDir}\Reports\ArtifactReport\ArtifactReport-{timestamp}.html

.NOTES
    Author  : Avanade Migration Team
    Version : 26.06.21
    Requires: PowerShell 5.1+
#>
param(
    [string]$OutputDir  = ".",
    [string]$ServerList = "",
    [string]$CheckType  = "Pre_Migration",
    [string]$ReportPath = "",
    [switch]$NoOpen
)

$ScriptVersion = "26.06.21"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

function Resolve-Dir {
    param([string]$Path)
    return [System.IO.Path]::GetFullPath($Path)
}

function Get-JsonPropertyValue {
    param(
        [object]$InputObject,
        [string]$Name
    )

    if ($null -eq $InputObject -or [string]::IsNullOrWhiteSpace($Name)) { return $null }

    if ($InputObject -is [System.Collections.IDictionary]) {
        if ($InputObject -is [System.Collections.Generic.IDictionary[string, object]]) {
            if ($InputObject.ContainsKey($Name)) { return $InputObject[$Name] }
        }
        elseif ($InputObject -is [System.Collections.Generic.IDictionary[string, string]]) {
            if ($InputObject.ContainsKey($Name)) { return $InputObject[$Name] }
        }
        elseif ($InputObject.Contains($Name)) {
            return $InputObject[$Name]
        }
        foreach ($key in $InputObject.Keys) {
            if ([string]$key -eq $Name) { return $InputObject[$key] }
        }
        return $null
    }

    $prop = $InputObject.PSObject.Properties[$Name]
    if ($prop) { return $prop.Value }
    return $null
}

function Get-JsonNestedPropertyValue {
    param(
        [object]$InputObject,
        [string[]]$Path
    )

    $current = $InputObject
    foreach ($part in $Path) {
        $current = Get-JsonPropertyValue -InputObject $current -Name $part
        if ($null -eq $current) { return $null }
    }
    return $current
}

function ConvertFrom-JsonCompat {
    param([string]$JsonText)

    if ([string]::IsNullOrWhiteSpace($JsonText)) { return $null }

    $convertFromJsonCmd = Get-Command ConvertFrom-Json -ErrorAction Stop
    $supportsAsHashtable = $convertFromJsonCmd.Parameters.ContainsKey('AsHashtable')

    if ($supportsAsHashtable) {
        return ($JsonText | ConvertFrom-Json -AsHashtable -ErrorAction Stop)
    }

    try {
        return ($JsonText | ConvertFrom-Json -ErrorAction Stop)
    }
    catch {
        # PowerShell 5.1 can fail when JSON contains keys that differ only by case.
        # Fall back to JavaScriptSerializer, which treats keys case-sensitively.
        Add-Type -AssemblyName System.Web.Extensions -ErrorAction SilentlyContinue
        $serializer = New-Object System.Web.Script.Serialization.JavaScriptSerializer
        $serializer.MaxJsonLength = [int]::MaxValue
        return $serializer.DeserializeObject($JsonText)
    }
}

function Resolve-ArtifactOsType {
    param(
        [object]$JsonObject,
        [string]$Fallback
    )

    $osCandidates = @(
        (Get-JsonNestedPropertyValue -InputObject $JsonObject -Path @('SystemOverview', 'OperatingSystem')),
        (Get-JsonNestedPropertyValue -InputObject $JsonObject -Path @('SystemOverview', 'OSFamily')),
        (Get-JsonPropertyValue -InputObject $JsonObject -Name 'OperatingSystem'),
        (Get-JsonPropertyValue -InputObject $JsonObject -Name 'OSType'),
        (Get-JsonPropertyValue -InputObject $JsonObject -Name 'OS')
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }

    foreach ($candidate in $osCandidates) {
        $text = [string]$candidate
        if ($text -imatch 'linux|ubuntu|debian|red hat|rhel|centos|suse|oracle linux') { return 'Linux' }
        if ($text -imatch 'windows|microsoft') { return 'Windows' }
    }

    if ($Fallback -imatch 'linux') { return 'Linux' }
    if ($Fallback -imatch 'windows') { return 'Windows' }
    return $Fallback
}

function Resolve-ArtifactOsTypeFromText {
    param(
        [string]$JsonText,
        [string]$Fallback
    )

    if (-not [string]::IsNullOrWhiteSpace($JsonText)) {
        $fieldMatches = [regex]::Matches($JsonText, '(?is)"(?:OperatingSystem|OSFamily|OSType|OS)"\s*:\s*"([^"]+)"')
        foreach ($fieldMatch in $fieldMatches) {
            $fieldText = $fieldMatch.Groups[1].Value
            if ($fieldText -imatch 'windows|microsoft') { return 'Windows' }
            if ($fieldText -imatch 'linux|ubuntu|debian|red hat|rhel|centos|suse|oracle linux') { return 'Linux' }
        }
    }

    if ($Fallback -imatch 'linux') { return 'Linux' }
    if ($Fallback -imatch 'windows') { return 'Windows' }
    return $Fallback
}

function Test-JsonEvidence {
    param(
        [string]$JsonText,
        [string[]]$Patterns
    )

    if ([string]::IsNullOrWhiteSpace($JsonText)) { return $false }
    foreach ($pattern in $Patterns) {
        if ($JsonText -imatch $pattern) { return $true }
    }
    return $false
}

function Test-SqlInPlay {
    param([string]$JsonText)
    return Test-JsonEvidence -JsonText $JsonText -Patterns @(
        '"Name"\s*:\s*"[^"]*SQL Server',
        '"DisplayName"\s*:\s*"[^"]*SQL Server',
        '"ProcessName"\s*:\s*"sqlservr"',
        '"Name"\s*:\s*"MSSQL[^""]*"',
        '"LocalPort"\s*:\s*(1433|1434|5022)'
    )
}

function Test-IisInPlay {
    param([string]$JsonText)
    return Test-JsonEvidence -JsonText $JsonText -Patterns @(
        '"Name"\s*:\s*"Web-Server"',
        '"Name"\s*:\s*"IIS-[^""]+"',
        '"DisplayName"\s*:\s*"[^"]*(IIS|Internet Information Services|World Wide Web)',
        '"Name"\s*:\s*"W3SVC"',
        '"Name"\s*:\s*"WAS"',
        '"ProcessName"\s*:\s*"w3wp"',
        'inetpub'
    )
}

$OutputDir = Resolve-Dir $OutputDir

# ---------------------------------------------------------------------------
# Validate OutputDir
# ---------------------------------------------------------------------------
if (-not (Test-Path -LiteralPath $OutputDir -PathType Container)) {
    Write-Host "ERROR: OutputDir not found: $OutputDir" -ForegroundColor Red
    exit 1
}

$ArtifactRoot = $OutputDir
$artifactsCandidate = Join-Path $OutputDir 'Artifacts'
if (Test-Path -LiteralPath $artifactsCandidate -PathType Container) {
    $ArtifactRoot = Resolve-Dir $artifactsCandidate
}

# -- Transcript / diagnostic log ------------------------------------------------
$_logDir = Join-Path $OutputDir 'Logs'
if (-not (Test-Path $_logDir)) { New-Item -ItemType Directory -Path $_logDir -Force | Out-Null }
$_logFile = Join-Path $_logDir ("ArtifactReport-{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
Start-Transcript -Path $_logFile -Append -NoClobber -ErrorAction SilentlyContinue
Write-Host "=== Transcript started: $_logFile ===" -ForegroundColor DarkGray

Write-Host "INFO: Output directory: $OutputDir" -ForegroundColor Cyan
if ($ArtifactRoot -ne $OutputDir) {
    Write-Host "INFO: Using artifact source directory: $ArtifactRoot" -ForegroundColor Cyan
} else {
    Write-Host "INFO: Using artifact source directory: $OutputDir" -ForegroundColor Cyan
}

# ---------------------------------------------------------------------------
# Folders to skip (not server directories)
# ---------------------------------------------------------------------------
$SkipFolders = @('Artifacts', 'ServerList', 'Reports', 'Transcripts', 'Temp', 'Logs')

# ---------------------------------------------------------------------------
# Load optional server list CSV
# ---------------------------------------------------------------------------
$ServerListMap = @{}  # lowercase name -> OSType
$ServerListNames = [System.Collections.Generic.HashSet[string]]([System.StringComparer]::OrdinalIgnoreCase)

if ($ServerList -ne "" -and (Test-Path -LiteralPath $ServerList)) {
    Write-Host "INFO: Loading server list: $ServerList" -ForegroundColor Cyan
    try {
        $slRows = Import-Csv -Path $ServerList
        foreach ($row in $slRows) {
            $sName = ($row.PSObject.Properties | Where-Object { $_.Name -imatch '^(server|servername|hostname|name)$' } | Select-Object -First 1).Value
            if (-not $sName) { continue }
            [void]$ServerListNames.Add($sName)
            $osType = if ($row.PSObject.Properties['OSType']) { $row.OSType } elseif ($row.PSObject.Properties['OS']) { $row.OS } else { '' }
            $ServerListMap[$sName.ToLower()] = $osType
        }
        Write-Host "   Loaded $($ServerListMap.Count) server entries from CSV." -ForegroundColor Gray
    } catch {
        Write-Host "WARN: Could not parse server list CSV: $_" -ForegroundColor Yellow
    }
}

# ---------------------------------------------------------------------------
# Find and load latest access check CSV
# ---------------------------------------------------------------------------
$AccessMap = @{}  # lowercase server name -> row object
$AccessCsvPath = $null
$AccessServerNames = [System.Collections.Generic.HashSet[string]]([System.StringComparer]::OrdinalIgnoreCase)

$accessDirs = [System.Collections.Generic.List[string]]::new()
$rootAccessDir = Join-Path $OutputDir "Reports\Access"
$artifactAccessDir = Join-Path $ArtifactRoot "Reports\Access"
[void]$accessDirs.Add($rootAccessDir)
if ($artifactAccessDir -ne $rootAccessDir) { [void]$accessDirs.Add($artifactAccessDir) }

$csvFiles = @()
foreach ($accessDir in $accessDirs) {
    if (Test-Path -LiteralPath $accessDir) {
        $csvFiles += Get-ChildItem -LiteralPath $accessDir -Filter "*.csv" -File -ErrorAction SilentlyContinue
    } else {
        Write-Host "WARN: Access check directory not found: $accessDir" -ForegroundColor Yellow
    }
}

$csvFiles = @($csvFiles | Sort-Object LastWriteTime -Descending)
if ($csvFiles.Count -gt 0) {
    $AccessCsvPath = $csvFiles[0].FullName
    Write-Host "INFO: Loading access check CSV: $AccessCsvPath" -ForegroundColor Cyan
    try {
        $accessRows = Import-Csv -Path $AccessCsvPath
        foreach ($row in $accessRows) {
            $sName = ($row.PSObject.Properties | Where-Object { $_.Name -imatch '^(server|servername|hostname|name)$' } | Select-Object -First 1).Value
            if (-not $sName) { continue }
            [void]$AccessServerNames.Add($sName)
            $serverKey = $sName.ToLower()
            $AccessMap[$serverKey] = $row

            $shortName = ($sName -split '\.')[0]
            if ($shortName -and -not $AccessMap.ContainsKey($shortName.ToLower())) {
                $AccessMap[$shortName.ToLower()] = $row
            }
        }
        Write-Host "   Loaded $($AccessServerNames.Count) access check row(s)." -ForegroundColor Gray
    } catch {
        Write-Host "WARN: Could not parse access check CSV: $_" -ForegroundColor Yellow
    }
} else {
    Write-Host "WARN: No access check CSV found in: $($accessDirs -join '; ')" -ForegroundColor Yellow
}

# ---------------------------------------------------------------------------
# Discover server sub-directories
# ---------------------------------------------------------------------------
$serverDirs = Get-ChildItem -LiteralPath $ArtifactRoot -Directory -ErrorAction SilentlyContinue |
    Where-Object { $SkipFolders -notcontains $_.Name }

$serverNames = [System.Collections.Generic.HashSet[string]]([System.StringComparer]::OrdinalIgnoreCase)
if ($ServerListNames.Count -gt 0) {
    foreach ($sName in $ServerListNames) { [void]$serverNames.Add($sName) }
    Write-Host "INFO: Restricting report to $($ServerListNames.Count) server(s) from ServerList." -ForegroundColor Cyan
} else {
    foreach ($d in $serverDirs) { [void]$serverNames.Add($d.Name) }
}

# Add servers from access CSV that have no artifact folder when the report is not filtered by ServerList.
if ($ServerListNames.Count -eq 0) {
    foreach ($sName in $AccessServerNames) {
        $shortName = ($sName -split '\.')[0]
        if ($serverNames.Contains($sName) -or ($shortName -and $serverNames.Contains($shortName))) { continue }
        [void]$serverNames.Add($sName)
    }
}

Write-Host "INFO: Total servers to report: $($serverNames.Count)" -ForegroundColor Cyan

# ---------------------------------------------------------------------------
# Build report rows
# ---------------------------------------------------------------------------
$rows = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($srv in ($serverNames | Sort-Object)) {
    $srvLower   = $srv.ToLower()
    $srvFolder  = Join-Path $ArtifactRoot $srv

    # --- OS Type ---
    $osType = ''
    if ($ServerListMap.ContainsKey($srvLower)) { $osType = $ServerListMap[$srvLower] }

    # --- Artifact file paths ---
    $migFile = $null
    $sqlFile = $null
    $iisFile = $null
    $migPath = Join-Path $srvFolder "${srv}_${CheckType}.json"
    $sqlPath = Join-Path $srvFolder "${srv}_Pre_SQL_Config.json"
    $iisPath = Join-Path $srvFolder "${srv}_Pre_IIS_Config.json"
    $laExpectedPath = Join-Path $srvFolder "${srv}_*_LogAnalytics_*.csv"
    $laFile = $null
    $laPath = Join-Path $srvFolder "${srv}_Pre_LogAnalytics_*.csv"

    if (Test-Path -LiteralPath $srvFolder -PathType Container) {
        if (Test-Path -LiteralPath $migPath) { $migFile = Split-Path -Leaf $migPath }
        if (Test-Path -LiteralPath $sqlPath) { $sqlFile = $sqlPath }
        if (Test-Path -LiteralPath $iisPath) { $iisFile = $iisPath }
        $laMatch = Get-ChildItem -LiteralPath $srvFolder -Filter "${srv}_*_LogAnalytics_*.csv" -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending |
            Select-Object -First 1
        if ($laMatch) {
            $laFile = $laMatch.Name
            $laPath = $laMatch.FullName
        }
    }

    # --- Main JSON to inspect for embedded data ---
    $mainJsonPath = if ($migFile) { $migPath } else { $null }

    $jsonParsed        = $null
    $jsonText          = ''

    if ($mainJsonPath -and (Test-Path -LiteralPath $mainJsonPath)) {
        try {
            $jsonText = Get-Content -LiteralPath $mainJsonPath -Raw
            $jsonParsed = ConvertFrom-JsonCompat -JsonText $jsonText
        } catch {
            Write-Host "   WARN: Could not parse JSON for $srv : $_" -ForegroundColor Yellow
        }
    }

    $osType = Resolve-ArtifactOsType -JsonObject $jsonParsed -Fallback $osType
    if ([string]::IsNullOrWhiteSpace($osType)) {
        $osType = Resolve-ArtifactOsTypeFromText -JsonText $jsonText -Fallback $osType
    }

    # --- Booleans ---
    $hasMigJSON = $null -ne $migFile
    $displayFile = if ($migFile) { $migFile } else { '' }
    $hasSQLJSON = $null -ne $sqlFile
    $hasIISJSON = $null -ne $iisFile
    $hasLogAnalyticsCsv = $null -ne $laFile
    $sqlExpected = $hasSQLJSON -or (Test-SqlInPlay -JsonText $jsonText)
    $iisExpected = $hasIISJSON -or (Test-IisInPlay -JsonText $jsonText)

    # --- Access check ---
    $accessStatus = 'Not Checked'
    $accessErrors = ''
    if ($AccessMap.ContainsKey($srvLower)) {
        $aRow = $AccessMap[$srvLower]
        $accessOsType = if ($aRow.PSObject.Properties['OSType']) { [string]$aRow.OSType } else { '' }
        if ($accessOsType -imatch 'windows|linux') {
            $osType = Resolve-ArtifactOsTypeFromText -JsonText '' -Fallback $accessOsType
        }
        elseif ([string]::IsNullOrWhiteSpace($osType)) {
            $osType = Resolve-ArtifactOsTypeFromText -JsonText $jsonText -Fallback $accessOsType
        }
        $isLinuxAccessRow = $accessOsType -imatch 'linux'

        # Try common column names for success indicator
        $statusVal = if ($isLinuxAccessRow -and $aRow.PSObject.Properties['LinuxSshAccess'] -and $aRow.LinuxSshAccess -notmatch '^(N/A|Not Tested)?$') { $aRow.LinuxSshAccess }
                     elseif ($aRow.PSObject.Properties['Access'])        { $aRow.Access }
                     elseif ($aRow.PSObject.Properties['Status'])        { $aRow.Status }
                     elseif ($aRow.PSObject.Properties['PSRemoting'])    { $aRow.PSRemoting }
                     else { '' }

        if ($statusVal -imatch '^(true|success|ok|pass|yes|1)$') {
            $accessStatus = 'OK'
        } else {
            $accessStatus = 'Failed'
        }

        # Access error column is intentionally limited to PS/SSH connectivity errors only.
        $msgVal = if ($isLinuxAccessRow) {
            if ($aRow.PSObject.Properties['LinuxSshError'] -and -not [string]::IsNullOrWhiteSpace([string]$aRow.LinuxSshError)) {
                $aRow.LinuxSshError
            } elseif ($aRow.PSObject.Properties['Messages'] -and -not [string]::IsNullOrWhiteSpace([string]$aRow.Messages)) {
                $linuxMessages = @(([string]$aRow.Messages -split '\s*\|\s*') | Where-Object { $_ -match '^(?i)(SSH|Linux SSH):' })
                $linuxMessages -join ' | '
            } else { '' }
        } else {
            if ($aRow.PSObject.Properties['PSError'] -and -not [string]::IsNullOrWhiteSpace([string]$aRow.PSError)) {
                $aRow.PSError
            } elseif ($aRow.PSObject.Properties['Messages'] -and -not [string]::IsNullOrWhiteSpace([string]$aRow.Messages)) {
                $psMessages = @(([string]$aRow.Messages -split '\s*\|\s*') | Where-Object { $_ -match '^(?i)PowerShell:' })
                $psMessages -join ' | '
            } else { '' }
        }
        $accessErrors = if ($msgVal) { $msgVal } else { '' }
    }

    # --- Overall status ---
    $anyArtifact = $hasMigJSON -or $hasSQLJSON -or $hasIISJSON -or $hasLogAnalyticsCsv
    $missingExpectedArtifact = (-not $hasMigJSON) -or ($sqlExpected -and -not $hasSQLJSON) -or ($iisExpected -and -not $hasIISJSON)

    $overallStatus = if ($hasMigJSON -and -not $missingExpectedArtifact) {
        'Complete'
    } elseif ($anyArtifact -or ($sqlExpected -and -not $hasSQLJSON) -or ($iisExpected -and -not $hasIISJSON)) {
        'Partial'
    } elseif ($accessStatus -eq 'Failed') {
        'Access Failed'
    } else {
        'No Data'
    }

    $rows.Add([PSCustomObject]@{
        Server             = $srv
        OSType             = $osType
        MigJSON            = $hasMigJSON
        MigFile            = $displayFile
        MigPath            = $migPath
        SQLJSON            = $hasSQLJSON
        SQLExpected        = $sqlExpected
        SQLPath            = $sqlPath
        IISJSON            = $hasIISJSON
        IISExpected        = $iisExpected
        IISPath            = $iisPath
        LogAnalyticsCsv    = $hasLogAnalyticsCsv
        LogAnalyticsFile   = if ($laFile) { $laFile } else { '' }
        LogAnalyticsPath   = $laPath
        LogAnalyticsExpectedPath = $laExpectedPath
        AccessStatus       = $accessStatus
        AccessErrors       = $accessErrors
        OverallStatus      = $overallStatus
    })

    Write-Host "   $srv  ->  $overallStatus  (Access: $accessStatus)" -ForegroundColor $(
        switch ($overallStatus) {
            'Complete'      { 'Green' }
            'Partial'       { 'Yellow' }
            'Access Failed' { 'Red' }
            default         { 'Gray' }
        }
    )
}

# ---------------------------------------------------------------------------
# Summary counts
# ---------------------------------------------------------------------------
function Get-PercentText {
    param(
        [int]$Count,
        [int]$Total
    )

    if ($Total -le 0) { return 'N/A' }
    return ('{0}%' -f ([Math]::Round(($Count / $Total) * 100, 1)))
}

$totalCount        = @($rows).Count
$windowsTotalCount = @($rows | Where-Object { $_.OSType -imatch 'windows' }).Count
$linuxTotalCount   = @($rows | Where-Object { $_.OSType -imatch 'linux' }).Count
$completedWindowsCount = @($rows | Where-Object { $_.OverallStatus -eq 'Complete' -and $_.OSType -imatch 'windows' }).Count
$completedLinuxCount   = @($rows | Where-Object { $_.OverallStatus -eq 'Complete' -and $_.OSType -imatch 'linux' }).Count
$totalCollectedCount   = @($rows | Where-Object { $_.MigJSON -eq $true }).Count
$sqlCollectedCount     = @($rows | Where-Object { $_.SQLJSON -eq $true }).Count
$sqlExpectedCount      = @($rows | Where-Object { $_.SQLExpected -eq $true }).Count
$iisCollectedCount     = @($rows | Where-Object { $_.IISJSON -eq $true }).Count
$iisExpectedCount      = @($rows | Where-Object { $_.IISExpected -eq $true }).Count
$logAnalyticsCount     = @($rows | Where-Object { $_.LogAnalyticsCsv -eq $true }).Count
$noDataCount           = @($rows | Where-Object { $_.OverallStatus -eq 'No Data' }).Count
$accessFailedCount     = @($rows | Where-Object { $_.OverallStatus -eq 'Access Failed' }).Count

$totalCollectedPercent = Get-PercentText -Count $totalCollectedCount -Total $totalCount
$windowsPercent        = Get-PercentText -Count $completedWindowsCount -Total $windowsTotalCount
$linuxPercent          = Get-PercentText -Count $completedLinuxCount -Total $linuxTotalCount
$sqlPercent            = Get-PercentText -Count $sqlCollectedCount -Total $sqlExpectedCount
$iisPercent            = Get-PercentText -Count $iisCollectedCount -Total $iisExpectedCount
$logAnalyticsPercent   = Get-PercentText -Count $logAnalyticsCount -Total $totalCount
$noDataPercent         = Get-PercentText -Count $noDataCount -Total $totalCount
$accessFailedPercent   = Get-PercentText -Count $accessFailedCount -Total $totalCount

# ---------------------------------------------------------------------------
# Handle empty scenario
# ---------------------------------------------------------------------------
if ($totalCount -eq 0 -and -not $AccessCsvPath) {
    Write-Host "INFO: No data found - generating empty report." -ForegroundColor Yellow
}

# ---------------------------------------------------------------------------
# Report output path
# ---------------------------------------------------------------------------
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

if (-not $ReportPath) {
    $reportDir = Join-Path $OutputDir "Reports\ArtifactReport"
    if (-not (Test-Path -LiteralPath $reportDir)) {
        New-Item -ItemType Directory -Path $reportDir -Force | Out-Null
    }
    $ReportPath = Join-Path $reportDir "ArtifactReport-$timestamp.html"
}

$reportParent = Split-Path -Parent $ReportPath
if ($reportParent -and -not (Test-Path -LiteralPath $reportParent)) {
    New-Item -ItemType Directory -Path $reportParent -Force | Out-Null
}

function ConvertTo-LatestReportPath {
    param([string]$Path)

    $parent = Split-Path -Parent $Path
    $leaf = Split-Path -Leaf $Path
    $latestLeaf = $leaf -replace '[-_]\d{8}[-_]\d{6}\.html$', '-latest.html'
    if ($latestLeaf -eq $leaf) {
        $latestLeaf = [System.IO.Path]::GetFileNameWithoutExtension($leaf) + '-latest.html'
    }
    if ($parent) { return Join-Path $parent $latestLeaf }
    return $latestLeaf
}

$latestReportPath = ConvertTo-LatestReportPath -Path $ReportPath

# ---------------------------------------------------------------------------
# Build HTML table rows
# ---------------------------------------------------------------------------
function Get-OsBadge {
    param([string]$OS)
    $lower = $OS.ToLower()
    if ($lower -match 'linux')   { return '<span class="badge badge-linux">Linux</span>' }
    if ($lower -match 'windows') { return '<span class="badge badge-windows">Windows</span>' }
    return '<span class="badge badge-unknown">Unknown</span>'
}

function Get-AccessBadge {
    param([string]$Status)
    switch ($Status) {
        'OK'          { return '<span class="badge badge-ok">OK</span>' }
        'Failed'      { return '<span class="badge badge-failed">FAILED</span>' }
        default       { return '<span class="badge badge-notchecked">Not Checked</span>' }
    }
}

function ConvertTo-HtmlEncoded {
    param([string]$Text)
    return $Text -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;' -replace '"','&quot;'
}

function ConvertTo-RelativeHref {
    param(
        [string]$TargetPath,
        [string]$FromDirectory
    )

    if ([string]::IsNullOrWhiteSpace($TargetPath) -or -not (Test-Path -LiteralPath $TargetPath -PathType Leaf)) {
        return ''
    }

    try {
        $baseDirectory = if ([string]::IsNullOrWhiteSpace($FromDirectory)) { (Get-Location).Path } else { $FromDirectory }
        $fromUri = [System.Uri]::new(([System.IO.Path]::GetFullPath($baseDirectory).TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar))
        $targetUri = [System.Uri]::new([System.IO.Path]::GetFullPath($TargetPath))
        return $fromUri.MakeRelativeUri($targetUri).ToString()
    } catch {
        return ''
    }
}

function New-ArtifactCell {
    param(
        [bool]$Collected,
        [string]$CollectedText,
        [string]$ExpectedPath,
        [string]$MissingText = 'Not Collected',
        [string]$AdditionalDetail = '',
        [string]$LinkPath = ''
    )

    $statusClass = if ($Collected) { 'artifact-found' } else { 'artifact-missing' }
    $statusText = if ($Collected) { 'Collected' } else { $MissingText }
    $displayText = if ($CollectedText) { $CollectedText } else { $statusText }
    $tooltipParts = @()
    if ($ExpectedPath) { $tooltipParts += "Looking for: $ExpectedPath" }
    if ($AdditionalDetail) { $tooltipParts += $AdditionalDetail }
    $tooltip = ConvertTo-HtmlEncoded ($tooltipParts -join "`n")
    $icon = if ($Collected) { 'OK' } else { 'Missing' }
    $displayHtml = ConvertTo-HtmlEncoded $displayText

    if ($Collected -and $LinkPath) {
        $href = ConvertTo-RelativeHref -TargetPath $LinkPath -FromDirectory $reportParent
        if ($href) {
            $displayHtml = '<a class="artifact-link" href="{0}" title="Open artifact: {1}">{2}</a>' -f (ConvertTo-HtmlEncoded $href), (ConvertTo-HtmlEncoded $LinkPath), $displayHtml
        }
    }

    $template = '<span class="artifact-state {0}" title="{1}"><span class="state-dot"></span><span class="state-text">{2}</span><span class="tooltip-indicator">?</span><span class="sr-only">{3}</span></span>'
    return $template -f $statusClass, $tooltip, $displayHtml, $icon
}

function New-NotApplicableCell {
    param([string]$Reason)
    $template = '<span class="artifact-state artifact-na" title="{0}"><span class="state-dot"></span><span class="state-text">N/A</span><span class="tooltip-indicator">?</span></span>'
    return $template -f (ConvertTo-HtmlEncoded $Reason)
}

$htmlRows = [System.Text.StringBuilder]::new()

foreach ($row in $rows) {
    $rowClass = switch ($row.OverallStatus) {
        'Complete'      { 'row-complete' }
        'Partial'       { 'row-partial' }
        'Access Failed' { 'row-noaccess' }
        default         { 'row-nodata' }
    }

    # OS badge
    $osBadge = Get-OsBadge -OS $row.OSType

    $migCell = New-ArtifactCell -Collected $row.MigJSON -CollectedText $row.MigFile -ExpectedPath $row.MigPath -LinkPath $row.MigPath

    # SQL - only expected when the main artifact shows SQL is in play.
    $sqlCell = if (-not $row.SQLExpected) {
        New-NotApplicableCell -Reason "SQL was not detected in the main server artifact, so SQL config is not expected. Checked location: $($row.SQLPath)"
    } elseif ($row.SQLJSON) {
        New-ArtifactCell -Collected $true -CollectedText (Split-Path -Leaf $row.SQLPath) -ExpectedPath $row.SQLPath -LinkPath $row.SQLPath
    } else {
        New-ArtifactCell -Collected $false -ExpectedPath $row.SQLPath
    }

    # IIS - only expected when the main artifact shows IIS is in play.
    $iisCell = if (-not $row.IISExpected) {
        New-NotApplicableCell -Reason "IIS was not detected in the main server artifact, so IIS config is not expected. Checked location: $($row.IISPath)"
    } elseif ($row.IISJSON) {
        New-ArtifactCell -Collected $true -CollectedText (Split-Path -Leaf $row.IISPath) -ExpectedPath $row.IISPath -LinkPath $row.IISPath
    } else {
        New-ArtifactCell -Collected $false -ExpectedPath $row.IISPath
    }

    # Log Analytics export
    $laCell = if ($row.LogAnalyticsCsv) {
        New-ArtifactCell -Collected $true -CollectedText $row.LogAnalyticsFile -ExpectedPath $row.LogAnalyticsExpectedPath -AdditionalDetail 'Generated by Avanade-ExportLogAnalyticsData.ps1' -LinkPath $row.LogAnalyticsPath
    } else {
        New-ArtifactCell -Collected $false -ExpectedPath $row.LogAnalyticsExpectedPath -MissingText 'Not exported' -AdditionalDetail 'Run Export Log Analytics from the Avanade Cloud Impact MOVE - Client Discovery GUI to collect this optional CSV artifact.'
    }

    # Access
    $accessCell = Get-AccessBadge -Status $row.AccessStatus

    # Access Error - truncate at 80 chars, full in tooltip
    $notesRaw    = $row.AccessErrors
    $notesEsc    = ConvertTo-HtmlEncoded $notesRaw
    $notesTrunc  = if ($notesRaw.Length -gt 80) { (ConvertTo-HtmlEncoded $notesRaw.Substring(0, 80)) + "..." } else { $notesEsc }
    $notesCell   = if ($notesRaw) {
        "<span class='notes-truncated' title='$notesEsc'>$notesTrunc</span>"
    } else { '' }

    # Overall status badge
    $overallBadge = switch ($row.OverallStatus) {
        'Complete'      { '<span class="status-badge status-complete">Complete</span>' }
        'Partial'       { '<span class="status-badge status-partial">Partial</span>' }
        'Access Failed' { '<span class="status-badge status-accessfail">Access Failed</span>' }
        default         { '<span class="status-badge status-nodata">No Data</span>' }
    }

    [void]$htmlRows.AppendLine(@"
        <tr class="$rowClass">
            <td class="server-name">$(ConvertTo-HtmlEncoded $row.Server)</td>
            <td>$osBadge</td>
            <td>$overallBadge</td>
            <td>$migCell</td>
            <td>$sqlCell</td>
            <td>$iisCell</td>
            <td>$laCell</td>
            <td>$accessCell</td>
            <td class="notes-cell">$notesCell</td>
        </tr>
"@)
}

# If no rows, show empty state
$tableBodyHtml = if ($rows.Count -eq 0) {
    @"
        <tr>
            <td colspan="9" class="empty-state">
                <div class="empty-icon">No Data</div>
                <div>No artifact data found. Ensure collection has run and OutputDir is correct.</div>
            </td>
        </tr>
"@
} else {
    $htmlRows.ToString()
}

# ---------------------------------------------------------------------------
# No-data page short-circuit message (injected into summary bar)
# ---------------------------------------------------------------------------
$noDataBanner = if ($totalCount -eq 0 -and -not $AccessCsvPath) {
    '<div class="no-data-banner">Warning: No server artifact folders or access check CSV were found in the specified output directory. Verify the <strong>OutputDir</strong> parameter and that collection has completed.</div>'
} else { '' }

# ---------------------------------------------------------------------------
# Generate full HTML
# ---------------------------------------------------------------------------
$generatedAt  = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$outputDirEsc = ConvertTo-HtmlEncoded $OutputDir
$artifactRootEsc = ConvertTo-HtmlEncoded $ArtifactRoot
$checkTypeEsc = ConvertTo-HtmlEncoded $CheckType
$accessCsvEsc = if ($AccessCsvPath) { ConvertTo-HtmlEncoded $AccessCsvPath } else { '<em>None found</em>' }

$html = @"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avanade Cloud Impact MOVE - Client Discovery - Artifact Collection Report</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 24px;
            background: #f4f2f4;
            color: #2b2430;
            font-size: 14px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background-color: #fff;
            border: 1px solid #e7e0ea;
            border-radius: 6px;
            box-shadow: 0 18px 44px rgba(43,36,48,0.12);
            overflow: hidden;
        }

        /* ---- Header ---- */
        .header {
            background: linear-gradient(90deg, #FF6600 0%, #FF5800 22%, #E83B6B 52%, #B8357A 74%, #890078 100%);
            color: white;
            padding: 16px 24px;
            border-bottom: 4px solid #FF6600;
        }
        .header-inner {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 24px;
            flex-wrap: wrap;
        }
        .brand-block {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 230px;
        }
        .header-logo {
            font-size: 0.92em;
            font-weight: 800;
            letter-spacing: 1.6px;
            text-transform: uppercase;
            white-space: nowrap;
        }
        .report-name {
            border-left: 1px solid rgba(255,255,255,0.45);
            padding-left: 14px;
            font-size: 0.95em;
            font-weight: 650;
            white-space: nowrap;
        }
        .header-text h1 {
            margin: 0 0 6px 0;
            font-size: 1.45em;
            font-weight: 650;
        }
        .header-text .subtitle {
            font-size: 0.88em;
            line-height: 1.45;
        }
        .metadata {
            display: grid;
            grid-template-columns: repeat(2, minmax(190px, 1fr));
            gap: 8px 18px;
            max-width: 820px;
        }
        .metadata-item { min-width: 0; }
        .metadata-label {
            display: block;
            font-size: 0.68em;
            letter-spacing: 0.8px;
            opacity: 0.8;
            text-transform: uppercase;
            font-weight: 700;
        }
        .metadata-value {
            display: block;
            overflow-wrap: anywhere;
            font-weight: 500;
        }

        /* ---- No-data banner ---- */
        .no-data-banner {
            background-color: #fff3cd;
            color: #7a5800;
            border-left: 4px solid #FF8C00;
            padding: 14px 24px;
            font-size: 0.95em;
        }

        /* ---- Summary cards ---- */
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 0;
            background-color: #fff;
            border-bottom: 1px solid #e8e2eb;
        }
        .summary-card {
            background: #fff;
            padding: 18px 16px;
            text-align: center;
            border-right: 1px solid #e8e2eb;
            border-bottom: 1px solid #e8e2eb;
        }
        .summary-card:last-child { border-right: none; }
        .summary-card h3 {
            margin: 0 0 8px 0;
            color: #777;
            font-size: 0.78em;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }
        .summary-card .number {
            font-size: 2.1em;
            font-weight: 700;
            line-height: 1;
            margin: 6px 0 4px;
        }
        .summary-card .label {
            font-size: 0.8em;
            color: #888;
        }
        .summary-card .percent {
            font-size: 0.88em;
            color: #6b6170;
            font-weight: 700;
            margin-top: 2px;
        }
        .color-total    { color: #A100FF; }
        .color-windows  { color: #0078D4; }
        .color-linux    { color: #107C10; }
        .color-sql      { color: #5C2D91; }
        .color-iis      { color: #008272; }
        .color-la       { color: #FF6600; }
        .color-nodata   { color: #E31837; }
        .color-access   { color: #B00020; }

        /* ---- Search/filter bar ---- */
        .filter-bar {
            padding: 16px 24px;
            background: #fbfafc;
            border-bottom: 1px solid #e8e2eb;
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-bar input[type=text] {
            padding: 7px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 0.9em;
            min-width: 220px;
        }
        .filter-bar select {
            padding: 7px 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 0.9em;
            background: white;
        }
        .filter-bar label { font-size: 0.85em; color: #555; }

        /* ---- Content ---- */
        .content { padding: 24px; }

        /* ---- Table ---- */
        .table-wrapper {
            overflow-x: auto;
            border: 1px solid #e8e2eb;
            border-radius: 6px;
            box-shadow: 0 8px 22px rgba(43,36,48,0.08);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            font-size: 0.88em;
        }
        thead th {
            background-color: #2b2430;
            color: white;
            padding: 12px 14px;
            text-align: left;
            font-weight: 600;
            white-space: nowrap;
            cursor: pointer;
            user-select: none;
        }
        thead th:hover { background-color: #4b235d; }
        thead th.sort-asc::after  { content: ' ^'; font-size: 0.75em; }
        thead th.sort-desc::after { content: ' v'; font-size: 0.75em; }

        td {
            padding: 10px 14px;
            border-bottom: 1px solid #eee8f0;
            vertical-align: middle;
        }
        tr:last-child td { border-bottom: none; }

        /* Row tinting */
        tr.row-complete  { background-color: #ffffff; }
        tr.row-partial   { background-color: #FFF8F0; }
        tr.row-nodata    { background-color: #FFF0F0; }
        tr.row-noaccess  { background-color: #FFF0F0; }

        tr:hover td { background-color: rgba(255,102,0,0.04); }

        .server-name { font-weight: 600; color: #333; }

        /* ---- Badges ---- */
        .badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.78em;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }
        .badge-windows     { background-color: #dce8ff; color: #1a4a9e; }
        .badge-linux       { background-color: #efe3ff; color: #5f2d91; }
        .badge-unknown     { background-color: #eee; color: #777; }
        .badge-ok          { background-color: #d4f5ef; color: #00705c; }
        .badge-failed      { background-color: #fde0e4; color: #991025; }
        .badge-notchecked  { background-color: #eee; color: #777; }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.78em;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }
        .status-complete   { background-color: #d4f5ef; color: #00705c; }
        .status-partial    { background-color: #fff0dc; color: #a05000; }
        .status-nodata     { background-color: #fde0e4; color: #991025; }
        .status-accessfail { background-color: #fde0e4; color: #991025; }

        /* ---- Misc cell helpers ---- */
        .filename { font-family: 'Cascadia Code', Consolas, monospace; font-size: 0.85em; color: #555; }
        .na       { color: #aaa; font-size: 0.85em; }
        .not-collected { color: #999; font-size: 0.85em; }

        .artifact-state {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            max-width: 250px;
            cursor: help;
            vertical-align: middle;
        }
        .artifact-state .state-text {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            min-width: 0;
        }
        .artifact-found .state-text { color: #2e5f52; font-weight: 650; }
        .artifact-missing .state-text { color: #8a3341; }
        .artifact-na .state-text { color: #8b8490; }
        .artifact-link {
            color: inherit;
            text-decoration: underline;
            text-underline-offset: 2px;
        }
        .artifact-link:hover { color: #6b005f; }
        .state-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            flex: 0 0 auto;
            background: #E31837;
        }
        .artifact-found .state-dot { background: #00C3A0; }
        .artifact-na .state-dot { background: #b8afb8; }
        .tooltip-indicator {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex: 0 0 auto;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            border: 1px solid #cfc6d4;
            color: #6b6170;
            background: #fff;
            font-size: 10px;
            font-weight: 800;
            line-height: 1;
        }
        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }

        .notes-cell { max-width: 220px; }
        .notes-truncated {
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 200px;
            color: #c0392b;
            font-size: 0.83em;
            cursor: help;
        }

        /* ---- Empty state ---- */
        .empty-state {
            text-align: center;
            padding: 48px 24px;
            color: #888;
        }
        .empty-icon { font-size: 2.5em; margin-bottom: 12px; }

        /* ---- Footer ---- */
        .footer {
            text-align: center;
            padding: 18px 24px;
            color: #888;
            font-size: 0.82em;
            border-top: 1px solid #eee;
            background: #fafafa;
            line-height: 1.8;
        }
        .footer strong { color: #555; }

        @media (max-width: 900px) {
            .summary { grid-template-columns: repeat(2, 1fr); }
            .metadata { grid-template-columns: 1fr; }
        }
        @media (max-width: 560px) {
            .summary { grid-template-columns: 1fr; }
            .header-inner { flex-direction: column; align-items: flex-start; }
        }
    </style>
</head>
<body>
<div class="container">

    <!-- Header -->
    <div class="header">
        <div class="header-inner">
            <div class="brand-block">
                <div class="header-logo">AVANADE</div>
                <div class="report-name">Cloud Impact MOVE - Client Discovery</div>
            </div>
            <div class="header-text">
                <h1>Artifact Collection Report</h1>
                <div class="metadata">
                    <div class="metadata-item">
                        <span class="metadata-label">Output Directory</span>
                        <span class="metadata-value">$outputDirEsc</span>
                    </div>
                    <div class="metadata-item">
                        <span class="metadata-label">Artifact Source</span>
                        <span class="metadata-value">$artifactRootEsc</span>
                    </div>
                    <div class="metadata-item">
                        <span class="metadata-label">Check Type</span>
                        <span class="metadata-value">$checkTypeEsc</span>
                    </div>
                    <div class="metadata-item">
                        <span class="metadata-label">Access CSV</span>
                        <span class="metadata-value">$accessCsvEsc</span>
                    </div>
                    <div class="metadata-item">
                        <span class="metadata-label">Generated</span>
                        <span class="metadata-value">$generatedAt</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    $noDataBanner

    <!-- Summary Cards -->
    <div class="summary">
        <div class="summary-card">
            <h3>Total Collected</h3>
            <div class="number color-total">$totalCollectedCount / $totalCount</div>
            <div class="percent">$totalCollectedPercent</div>
            <div class="label">Windows + Linux complete</div>
        </div>
        <div class="summary-card">
            <h3>Completed Windows</h3>
            <div class="number color-windows">$completedWindowsCount / $windowsTotalCount</div>
            <div class="percent">$windowsPercent</div>
            <div class="label">complete / Windows</div>
        </div>
        <div class="summary-card">
            <h3>Completed Linux</h3>
            <div class="number color-linux">$completedLinuxCount / $linuxTotalCount</div>
            <div class="percent">$linuxPercent</div>
            <div class="label">complete / Linux</div>
        </div>
        <div class="summary-card">
            <h3>SQL</h3>
            <div class="number color-sql">$sqlCollectedCount / $sqlExpectedCount</div>
            <div class="percent">$sqlPercent</div>
            <div class="label">collected / detected</div>
        </div>
        <div class="summary-card">
            <h3>IIS</h3>
            <div class="number color-iis">$iisCollectedCount / $iisExpectedCount</div>
            <div class="percent">$iisPercent</div>
            <div class="label">collected / detected</div>
        </div>
        <div class="summary-card">
            <h3>Log Analytics</h3>
            <div class="number color-la">$logAnalyticsCount / $totalCount</div>
            <div class="percent">$logAnalyticsPercent</div>
            <div class="label">exports / total</div>
        </div>
        <div class="summary-card">
            <h3>No Data</h3>
            <div class="number color-nodata">$noDataCount / $totalCount</div>
            <div class="percent">$noDataPercent</div>
            <div class="label">no artifacts / total</div>
        </div>
        <div class="summary-card">
            <h3>Access Failed</h3>
            <div class="number color-access">$accessFailedCount / $totalCount</div>
            <div class="percent">$accessFailedPercent</div>
            <div class="label">blocked / total</div>
        </div>
    </div>

    <!-- Filter bar -->
    <div class="filter-bar">
        <label>Filter:</label>
        <input type="text" id="filterText" placeholder="Search server name..." oninput="applyFilters()">
        <label>Status:</label>
        <select id="filterStatus" onchange="applyFilters()">
            <option value="">All</option>
            <option value="Complete">Complete</option>
            <option value="Partial">Partial</option>
            <option value="Access Failed">Access Failed</option>
            <option value="No Data">No Data</option>
        </select>
        <label>Access:</label>
        <select id="filterAccess" onchange="applyFilters()">
            <option value="">All</option>
            <option value="OK">OK</option>
            <option value="Failed">Failed</option>
            <option value="Not Checked">Not Checked</option>
        </select>
        <label>OS:</label>
        <select id="filterOS" onchange="applyFilters()">
            <option value="">All</option>
            <option value="windows">Windows</option>
            <option value="linux">Linux</option>
            <option value="unknown">Unknown</option>
        </select>
    </div>

    <!-- Main Table -->
    <div class="content">
        <div class="table-wrapper">
            <table id="artifactTable">
                <thead>
                    <tr>
                        <th onclick="sortTable(0)">Server Name</th>
                        <th onclick="sortTable(1)">OS Type</th>
                        <th onclick="sortTable(2)">Overall Status</th>
                        <th onclick="sortTable(3)">Data Collection</th>
                        <th onclick="sortTable(4)">SQL Config</th>
                        <th onclick="sortTable(5)">IIS Config</th>
                        <th onclick="sortTable(6)">Log Analytics</th>
                        <th onclick="sortTable(7)">Access Check</th>
                        <th>Access Error</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
$tableBodyHtml
                </tbody>
            </table>
        </div>
        <div id="filterInfo" style="margin-top:10px; font-size:0.82em; color:#888;"></div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <strong>Avanade Cloud Impact MOVE - Client Discovery</strong> &nbsp;|&nbsp;
        Script Version: <strong>$ScriptVersion</strong> &nbsp;|&nbsp;
        Report Generated: <strong>$generatedAt</strong><br>
        Output Directory: <strong>$outputDirEsc</strong>
    </div>

</div>

<script>
    // ---- Sorting ----
    let sortColIdx = -1;
    let sortAsc = true;

    function sortTable(colIdx) {
        const table = document.getElementById('artifactTable');
        const tbody = table.querySelector('tbody');
        const rows  = Array.from(tbody.querySelectorAll('tr'));

        if (sortColIdx === colIdx) { sortAsc = !sortAsc; }
        else { sortColIdx = colIdx; sortAsc = true; }

        rows.sort((a, b) => {
            const aText = (a.cells[colIdx] ? a.cells[colIdx].innerText : '').trim().toLowerCase();
            const bText = (b.cells[colIdx] ? b.cells[colIdx].innerText : '').trim().toLowerCase();
            return sortAsc ? aText.localeCompare(bText) : bText.localeCompare(aText);
        });

        rows.forEach(r => tbody.appendChild(r));

        // Update header indicators
        document.querySelectorAll('thead th').forEach((th, i) => {
            th.classList.remove('sort-asc', 'sort-desc');
            if (i === colIdx) th.classList.add(sortAsc ? 'sort-asc' : 'sort-desc');
        });
    }

    // ---- Filtering ----
    function applyFilters() {
        const text       = document.getElementById('filterText').value.toLowerCase();
        const status     = document.getElementById('filterStatus').value.toLowerCase();
        const access     = document.getElementById('filterAccess').value.toLowerCase();
        const os         = document.getElementById('filterOS').value.toLowerCase();
        const tbody      = document.getElementById('tableBody');
        const rows       = Array.from(tbody.querySelectorAll('tr'));

        let visible = 0;
        rows.forEach(row => {
            const rowText = row.innerText.toLowerCase();
            const serverCell  = row.cells[0] ? row.cells[0].innerText.toLowerCase() : '';
            const osCell      = row.cells[1] ? row.cells[1].innerText.toLowerCase() : '';
            const statusCell  = row.cells[8] ? row.cells[8].innerText.toLowerCase() : '';
            const accessCell  = row.cells[6] ? row.cells[6].innerText.toLowerCase() : '';

            const matchText   = !text   || serverCell.includes(text);
            const matchStatus = !status || statusCell.includes(status);
            const matchAccess = !access || accessCell.includes(access);
            const matchOS     = !os     || osCell.includes(os);

            const show = matchText && matchStatus && matchAccess && matchOS;
            row.style.display = show ? '' : 'none';
            if (show) visible++;
        });

        const info = document.getElementById('filterInfo');
        if (text || status || access || os) {
            info.textContent = 'Showing ' + visible + ' of ' + rows.length + ' servers.';
        } else {
            info.textContent = '';
        }
    }
</script>

</body>
</html>
"@

# ---------------------------------------------------------------------------
# Write report
# ---------------------------------------------------------------------------
Write-Host "INFO: Writing report to: $ReportPath" -ForegroundColor Cyan
$html | Out-File -FilePath $ReportPath -Encoding UTF8 -Force
if ($latestReportPath -and ($latestReportPath -ne $ReportPath)) {
    $html | Out-File -FilePath $latestReportPath -Encoding UTF8 -Force
    Write-Host "INFO: Updating latest report: $latestReportPath" -ForegroundColor Cyan
}

Write-Host "Report generated successfully." -ForegroundColor Green
Write-Host "   $ReportPath" -ForegroundColor White
if ($latestReportPath -and ($latestReportPath -ne $ReportPath)) {
    Write-Host "   $latestReportPath" -ForegroundColor White
}

if (-not $NoOpen) {
    # ---------------------------------------------------------------------------
    # Open in default browser
    # ---------------------------------------------------------------------------
    try {
        Start-Process $ReportPath
    } catch {
        Write-Host "WARN: Could not open report in browser: $_" -ForegroundColor Yellow
    }
}

Write-Host "=== Transcript saved: $_logFile ===" -ForegroundColor DarkGray
Stop-Transcript -ErrorAction SilentlyContinue
