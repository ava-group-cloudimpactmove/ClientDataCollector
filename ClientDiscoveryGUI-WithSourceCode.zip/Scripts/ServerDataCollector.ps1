#Requires -Version 5.1
<#
.SYNOPSIS
    Avanade Cloud Impact MOVE - Client Discovery - Universal Server Data Collector

.DESCRIPTION
    Reads the OSType column from the provided server list CSV and routes each
    server to the correct data collector:

        Linux   → LinuxVM\Linux-DataCollector.ps1       (SSH via Posh-SSH)
        Windows → WindowsVM\MigrationCheck-DataCollector.ps1  (WinRM)

    Both collectors are invoked sequentially so their output streams remain
    readable in the same terminal window.  All shared parameters (CheckType,
    OutputDir, credentials, etc.) are forwarded transparently.

    JSON outputs only — no HTML report generation.

.PARAMETER CheckType
    Migration phase label: Pre_Migration | Post_Migration | Test_Migration

.PARAMETER ServerList
    Path to a CSV file that contains at minimum a server name column
    ('ServerName' or 'Server') and an 'OSType' column.
    Use -GenerateSampleCSV to produce a starter file.

.PARAMETER OutputDir
    Root directory for downloaded JSON files.
    If an existing Artifacts directory is supplied, it is used directly.
    Defaults to C:\Avanade\<current username>.

.PARAMETER Username
    Username for remote connections.
    SSH user for Linux; WinRM user for Windows.

.PARAMETER Password
    Plain-text password for remote connections.

.PARAMETER PersonalJSON
    Path to a personal JSON file with encrypted / plain-text credentials.
    Accepted by both sub-collectors using the same format.

.PARAMETER UseCredential
    Prompt for credentials interactively (applies to both collectors).

.PARAMETER ProjectJson
    Windows collector only: path to project JSON configuration file.

.PARAMETER ScanIP
    Windows collector only: scan C: drive for hard-coded IP addresses.

.PARAMETER ScanIPPath
    Windows collector only: specific path to scan for hard-coded IP addresses.
    Only used when ScanIP is set.

.PARAMETER SkipEventLog
    Windows collector only: skip Windows Event Log collection.

.PARAMETER EventLogMaxEvents
    Windows collector only: maximum number of events per log (default 1000).

.PARAMETER JobTimeoutSeconds
    Windows collector only: maximum seconds to wait for each remote per-server background job. Defaults to 600 (10 minutes).

.PARAMETER ServerOnlyData
    Windows collector only: collect basic server inventory only.

.PARAMETER MaxThreads
    Maximum concurrent connections per collector. Defaults to 10.

.PARAMETER ProgressStatusPath
    Optional path where a small JSON progress file is written for GUI polling.

.PARAMETER VerboseDiagnostics
    Show detailed sub-collector output in the console instead of writing it only to diagnostics logs.

.PARAMETER GenerateSampleCSV
    Write a sample CSV file to the -ServerList path and exit.

.EXAMPLE
    # Mixed server list – runs Windows and Linux collectors automatically
    .\ServerDataCollector.ps1 -CheckType Pre_Migration -ServerList .\serverlist.csv -PersonalJSON .\settings.json

.EXAMPLE
    # Interactive credentials
    .\ServerDataCollector.ps1 -CheckType Post_Migration -ServerList .\serverlist.csv -UseCredential

.NOTES
    Author  : Avanade Migration Team
    Version : 26.07.06
    Path    : ClientDiscovery\Scripts\ServerDataCollector.ps1

    JSON-only variant — HTML report generators are not included in this package.
    The CSV ServerName/Server column is forwarded as-is to each sub-collector.
    Temporary single-column CSVs are created per OS group under OutputDir\ServerList.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Pre_Migration', 'Post_Migration', 'Test_Migration')]
    [string]$CheckType,

    [string]$ServerList = '.\serverlist.csv',
    [string]$OutputDir = "C:\Avanade\$env:USERNAME",

    # Credentials (shared)
    [string]$Username,
    [string]$Password,
    [string]$PersonalJSON,
    [switch]$UseCredential,

    # Windows-collector-only options
    [string]$ProjectJson,
    [switch]$ScanIP,
    [string]$ScanIPPath,
    [switch]$SkipEventLog,
    [int]   $EventLogMaxEvents = 1000,
    [int]   $JobTimeoutSeconds = 600,
    [switch]$ServerOnlyData,

    # Shared
    [int]   $MaxThreads = 10,
    [string]$ProgressStatusPath,
    [switch]$VerboseDiagnostics,
    [switch]$GenerateSampleCSV
)

$ScriptVersion = '26.07.08'

# Enforce Windows PowerShell 5.1 for client execution consistency.
if ($PSVersionTable.PSEdition -eq 'Core') {
    $windowsPowerShell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $windowsPowerShell -PathType Leaf)) {
        throw 'Windows PowerShell 5.1 (powershell.exe) is required but was not found on this machine.'
    }

    $relaunchArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath)
    foreach ($key in $PSBoundParameters.Keys) {
        $value = $PSBoundParameters[$key]
        if ($value -is [System.Management.Automation.SwitchParameter]) {
            if ($value.IsPresent) { $relaunchArgs += "-$key" }
            continue
        }

        if ($value -is [bool]) {
            if ($value) { $relaunchArgs += "-$key" }
            continue
        }

        if ($null -ne $value) {
            $relaunchArgs += "-$key"
            $relaunchArgs += [string]$value
        }
    }

    & $windowsPowerShell @relaunchArgs
    exit $LASTEXITCODE
}

function Get-CurrentScriptDirectory {
    $candidatePaths = @(
        $PSCommandPath,
        $MyInvocation.MyCommand.Path
    )

    foreach ($candidatePath in $candidatePaths) {
        if (-not [string]::IsNullOrWhiteSpace([string]$candidatePath) -and (Test-Path -LiteralPath $candidatePath)) {
            return (Split-Path -Parent $candidatePath)
        }
    }

    try {
        $processPath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        if (-not [string]::IsNullOrWhiteSpace([string]$processPath) -and (Test-Path -LiteralPath $processPath)) {
            $processName = [System.IO.Path]::GetFileNameWithoutExtension($processPath)
            if ($processName -notmatch '^(?i)(pwsh|powershell|powershell_ise)$') {
                return (Split-Path -Parent $processPath)
            }
        }
    }
    catch {
    }

    return (Get-Location).Path
}

$ScriptDir = Get-CurrentScriptDirectory

function Resolve-ServerDataCollectorOutputPaths {
    param([string]$Path)

    $trimmedPath = $Path.TrimEnd([char[]]'\/')
    # Case-insensitive for Windows path compatibility.
    if ((Split-Path -Leaf $trimmedPath) -ieq 'Artifacts') {
        $parentPath = Split-Path -Parent $trimmedPath
        if ([string]::IsNullOrWhiteSpace($parentPath)) {
            $parentPath = (Get-Location).Path
        }

        return [pscustomobject]@{
            RootOutputDir      = $parentPath
            ArtifactsOutputDir = $trimmedPath
        }
    }

    return [pscustomobject]@{
        RootOutputDir      = $Path
        ArtifactsOutputDir = Join-Path $Path 'Artifacts'
    }
}

$outputPaths = Resolve-ServerDataCollectorOutputPaths -Path $OutputDir
$rootOutputDir = $outputPaths.RootOutputDir
$artifactsOutputDir = $outputPaths.ArtifactsOutputDir

# ── Transcript / diagnostic log ─────────────────────────────────────────────────
$_logDir = Join-Path $rootOutputDir 'Logs'
if (-not (Test-Path $_logDir)) { New-Item -ItemType Directory -Path $_logDir -Force | Out-Null }
$_logFile = Join-Path $_logDir ("ServerDataCollector-{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$_diagnosticLogFile = Join-Path $_logDir ("ServerDataCollector-Diagnostics-{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
if ([string]::IsNullOrWhiteSpace([string]$ProgressStatusPath)) {
    $ProgressStatusPath = Join-Path $_logDir ("ClientDiscovery-Progress-{0}.json" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
}
Start-Transcript -Path $_logFile -Append -NoClobber -ErrorAction SilentlyContinue

# ── Logging ───────────────────────────────────────────────────────────────────
function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $colour = switch ($Level) {
        'ERROR' { 'Red' }
        'WARN' { 'Yellow' }
        'RETRY' { 'Yellow' }
        'ACTION' { 'Blue' }
        'SUCCESS' { 'Green' }
        default { 'White' }
    }
    Write-Host "[$ts] [$Level] $Message" -ForegroundColor $colour
}

function Write-DiagnosticLog {
    param([string]$Message)
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $_diagnosticLogFile -Value "[$ts] $Message" -ErrorAction SilentlyContinue
}

function Write-DiscoveryProgressStatus {
    param(
        [string]$State = 'Running',
        [string]$Phase = '',
        [string]$CurrentServer = '',
        [int]$Total = 0,
        [int]$Completed = 0,
        [int]$Failed = 0,
        [string]$Message = ''
    )

    if ($Total -gt 0) {
        $percent = [Math]::Min(100, [Math]::Max(0, [int](($Completed / $Total) * 100)))
    }
    else {
        $percent = 0
    }

    if ($Total -gt $Completed) {
        $remaining = $Total - $Completed
    }
    else {
        $remaining = 0
    }
    $payload = [ordered]@{
        State         = $State
        Phase         = $Phase
        CurrentServer = $CurrentServer
        Total         = $Total
        Completed     = $Completed
        Failed        = $Failed
        Remaining     = $remaining
        Percent       = $percent
        Message       = $Message
        LogFile       = $_diagnosticLogFile
        Transcript    = $_logFile
        Updated       = (Get-Date).ToString('o')
    }

    try {
        $statusDir = Split-Path -Parent $ProgressStatusPath
        if ($statusDir -and -not (Test-Path -LiteralPath $statusDir)) {
            New-Item -ItemType Directory -Path $statusDir -Force | Out-Null
        }
        $tmpPath = "$ProgressStatusPath.tmp"
        $payload | ConvertTo-Json -Depth 4 | Set-Content -Path $tmpPath -Encoding UTF8
        Move-Item -Path $tmpPath -Destination $ProgressStatusPath -Force
    }
    catch {
        Write-DiagnosticLog "Failed to update progress status: $($_.Exception.Message)"
    }

    if ($State -eq 'Running') {
        if ($CurrentServer) {
            $statusText = "$Phase $CurrentServer ($Completed/$Total complete, $Failed failed)"
        }
        else {
            $statusText = "$Phase ($Completed/$Total complete, $Failed failed)"
        }
        Write-Progress -Activity 'Client Discovery' -Status $statusText -PercentComplete $percent
    }
    elseif ($State -eq 'Complete') {
        Write-Progress -Activity 'Client Discovery' -Completed
    }
}

Write-Log "ServerDataCollector.ps1 v$ScriptVersion  |  CheckType=$CheckType" 'INFO'
Write-Log "Diagnostics log: $_diagnosticLogFile" 'INFO'
Write-Log "Progress status: $ProgressStatusPath" 'INFO'
Write-DiagnosticLog "Transcript started: $_logFile"
Write-DiagnosticLog "JSON-only mode - HTML generation is not included in this package."

if ($JobTimeoutSeconds -lt 60) {
    Write-Log "JobTimeoutSeconds value '$JobTimeoutSeconds' is too low. Using minimum supported value of 60 seconds." 'WARN'
    $JobTimeoutSeconds = 60
}

# Run-scoped summary cutoff to prevent stale files from previous runs reporting as current.
$runStartTime = Get-Date

# ── Generate sample CSV and exit ──────────────────────────────────────────────
if ($GenerateSampleCSV) {
    $sample = @(
        'ServerName,OSType',
        'server01,Windows',
        'server02,Linux'
    ) -join [Environment]::NewLine
    Set-Content -Path $ServerList -Value $sample -Encoding UTF8
    Write-Log "Sample CSV written to: $ServerList"
    return
}

# ── Validate input CSV ────────────────────────────────────────────────────────
$resolvedList = Resolve-Path -LiteralPath $ServerList -ErrorAction SilentlyContinue
if (-not $resolvedList) {
    Write-Log "Server list not found: $ServerList" 'ERROR'
    exit 1
}

$csvRows = @()
$importedRows = Import-Csv -Path $resolvedList.Path -ErrorAction Stop
foreach ($importedRow in @($importedRows)) {
    if ($null -ne $importedRow) {
        $csvRows += $importedRow
    }
}

$csvRowCount = @($csvRows).Count
if ($csvRowCount -eq 0) {
    Write-Log "Server list is empty: $ServerList" 'ERROR'
    exit 1
}

Write-Log "Loaded server list: $($resolvedList.Path) (rows=$csvRowCount)" 'INFO'
Write-DiagnosticLog ("Loaded server list: " + [string]$resolvedList.Path)
Write-DiagnosticLog ("Loaded row count: " + [string]$csvRowCount)

# Determine which column holds the server name
$headers = $csvRows[0].PSObject.Properties.Name
$nameCol = $null
if ($headers -contains 'ServerName') { 
    $nameCol = 'ServerName' 
}
elseif ($headers -contains 'Server') { 
    $nameCol = 'Server' 
}
else {
    Write-Log "CSV must contain a 'ServerName' or 'Server' column. Found: $($headers -join ', ')" 'ERROR'
    exit 1
}

if ($headers -notcontains 'OSType') {
    Write-Log "CSV is missing an 'OSType' column - everything will be treated as Linux unless 'Windows' appears in the value." 'WARN'
}

# ── Partition by OSType ───────────────────────────────────────────────────────
$windowsRows = @()
$linuxRows = @()
foreach ($row in $csvRows) {
    $osTypeValue = [string]$row.OSType
    if ((-not [string]::IsNullOrWhiteSpace($osTypeValue)) -and ($osTypeValue.Trim() -imatch 'windows')) {
        $windowsRows += $row
    }
    else {
        $linuxRows += $row
    }
}

Write-Log "Servers - Total: $csvRowCount   Windows: $($windowsRows.Count)   Linux: $($linuxRows.Count)" 'INFO'

# ── Ensure ServerList dir exists under the root output dir ──────────────────────
$serverListDir = Join-Path $rootOutputDir 'ServerList'
if (-not (Test-Path -LiteralPath $serverListDir)) {
    New-Item -ItemType Directory -Path $serverListDir -Force | Out-Null
    Write-Log "Created server list directory: $serverListDir" 'ACTION'
}

# Artifacts dir — sub-collectors put per-server JSON here
if (-not (Test-Path -LiteralPath $artifactsOutputDir)) {
    New-Item -ItemType Directory -Path $artifactsOutputDir -Force | Out-Null
    Write-Log "Created artifacts directory: $artifactsOutputDir" 'ACTION'
}

# ── Helper: write a split CSV to OutputDir\ServerList\ ───────────────────────
function New-TempServerCsv {
    param([object[]]$Rows, [string]$NameCol, [string]$Label)
    if (-not $Rows -or $Rows.Count -eq 0) { return $null }
    $fileName = "sdc_${Label}_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
    $csvPath = Join-Path $script:serverListDir $fileName
    $Rows |
    Select-Object @{ Name = 'Server'; Expression = { $_.$NameCol } } |
    Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    Write-DiagnosticLog "Split server list written: $csvPath"
    return $csvPath
}

function Resolve-CollectorCommandPath {
    param([string]$ScriptPath)

    $exePath = [System.IO.Path]::ChangeExtension($ScriptPath, '.exe')
    if (Test-Path -LiteralPath $exePath -PathType Leaf) {
        return $exePath
    }

    if (Test-Path -LiteralPath $ScriptPath -PathType Leaf) {
        return $ScriptPath
    }

    return $ScriptPath
}

function Invoke-CollectorCommand {
    param(
        [string]$CommandPath,
        [hashtable]$Parameters,
        [string]$DiagnosticLogFile
    )

    $commandExtension = [System.IO.Path]::GetExtension($CommandPath).ToLowerInvariant()
    $argumentList = @()
    foreach ($key in $Parameters.Keys) {
        $value = $Parameters[$key]
        if ($value -is [System.Management.Automation.SwitchParameter]) {
            if ($value.IsPresent) { $argumentList += "-$key" }
        }
        elseif ($value -is [bool]) {
            if ($value) { $argumentList += "-$key" }
        }
        elseif ($null -ne $value) {
            $argumentList += "-$key"
            $argumentList += [string]$value
        }
    }

    if ($VerboseDiagnostics -or [string]::IsNullOrWhiteSpace([string]$DiagnosticLogFile)) {
        if ($commandExtension -eq '.exe') {
            & $CommandPath @argumentList
            return
        }

        & $CommandPath @Parameters
        return
    }

    Write-DiagnosticLog "Launching collector: $CommandPath $($argumentList -join ' ')"
    if ($commandExtension -eq '.exe') {
        & $CommandPath @argumentList *>> $DiagnosticLogFile
        return
    }

    & $CommandPath @Parameters *>> $DiagnosticLogFile
}

function Test-ArtifactGeneratedThisRun {
    param(
        [string]$Path,
        [datetime]$RunStart
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $false
    }

    try {
        $item = Get-Item -LiteralPath $Path -ErrorAction Stop
        return ($item.LastWriteTime -ge $RunStart)
    }
    catch {
        return $false
    }
}

function Get-ServerArtifactStatus {
    param([string]$Target)

    $targetShort = ($Target -split '\.')[0]
    $candidateNames = @($Target, $targetShort) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

    $resolvedSrv = $targetShort
    foreach ($candidate in $candidateNames) {
        if (Test-Path -LiteralPath (Join-Path $artifactsOutputDir $candidate) -PathType Container) {
            $resolvedSrv = $candidate
            break
        }
    }

    $srvFolder = Join-Path $artifactsOutputDir $resolvedSrv
    $migJson = Join-Path $srvFolder "${resolvedSrv}_${suffix}.json"
    $sqlJson = Join-Path $srvFolder "${resolvedSrv}_${checkShort}_SQL_Config.json"
    $iisJson = Join-Path $srvFolder "${resolvedSrv}_${checkShort}_IIS_Config.json"

    $migOk = Test-ArtifactGeneratedThisRun -Path $migJson -RunStart $runStartTime
    $sqlOk = Test-ArtifactGeneratedThisRun -Path $sqlJson -RunStart $runStartTime
    $iisOk = Test-ArtifactGeneratedThisRun -Path $iisJson -RunStart $runStartTime

    return [PSCustomObject]@{
        Server        = $resolvedSrv
        MigrationJSON = $migOk
        SQLJSON       = $sqlOk
        IISJSON       = $iisOk
        Succeeded     = ($migOk -or $sqlOk -or $iisOk)
    }
}

# ── Per-group collection with operator progress ───────────────────────────────
$checkShort = ($CheckType -split '_')[0]   # Pre, Post, Test
$suffix = $CheckType + ($(if ($ScanIP) { '_ScanIP' } else { '' }))

$linuxRunRows = @($linuxRows | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.$nameCol) })
$windowsRunRows = @($windowsRows | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.$nameCol) })

function Invoke-DiscoveryGroupRun {
    param(
        [object[]]$Rows,
        [string]$OsLabel,
        [ref]$Completed,
        [ref]$Failed,
        [int]$Total
    )

    if (-not $Rows -or $Rows.Count -eq 0) { return }

    $collectorScript = $null
    $params = @{}
    if ($OsLabel -eq 'Linux') {
        $collectorScript = Resolve-CollectorCommandPath -ScriptPath (Join-Path $ScriptDir 'LinuxVM\Linux-DataCollector.ps1')
        if (-not (Test-Path -LiteralPath $collectorScript)) {
            Write-Log "Linux collector not found at: $collectorScript" 'ERROR'
            foreach ($row in $Rows) {
                $serverName = ([string]$row.$nameCol).Trim()
                if (-not [string]::IsNullOrWhiteSpace($serverName)) {
                    $Completed.Value++
                    $Failed.Value++
                }
            }
            return
        }

        $tmpCsv = New-TempServerCsv -Rows $Rows -NameCol $nameCol -Label "Linux_Batch"
        $params = @{
            CheckType          = $CheckType
            ServerList         = $tmpCsv
            OutputDir          = $artifactsOutputDir
            MaxThreads         = $MaxThreads
            SkipHtmlGeneration = $true
        }
        if ($Username) { $params['Username'] = $Username }
        if ($Password) { $params['Password'] = $Password }
        if ($PersonalJSON) { $params['PersonalJSON'] = $PersonalJSON }
        if ($UseCredential) { $params['UseCredential'] = $true }
    }
    else {
        $collectorScript = Resolve-CollectorCommandPath -ScriptPath (Join-Path $ScriptDir 'WindowsVM\MigrationCheck-DataCollector.ps1')
        if (-not (Test-Path -LiteralPath $collectorScript)) {
            Write-Log "Windows collector not found at: $collectorScript" 'ERROR'
            foreach ($row in $Rows) {
                $serverName = ([string]$row.$nameCol).Trim()
                if (-not [string]::IsNullOrWhiteSpace($serverName)) {
                    $Completed.Value++
                    $Failed.Value++
                }
            }
            return
        }

        $tmpCsv = New-TempServerCsv -Rows $Rows -NameCol $nameCol -Label "Windows_Batch"
        $params = @{
            CheckType         = $CheckType
            ServerList        = $tmpCsv
            OutputDir         = $artifactsOutputDir
            MaxThreads        = $MaxThreads
            EventLogMaxEvents = $EventLogMaxEvents
            JobTimeoutSeconds = $JobTimeoutSeconds
        }
        if ($Username) { $params['Username'] = $Username }
        if ($Password) { $params['Password'] = $Password }
        if ($PersonalJSON) { $params['PersonalJSON'] = $PersonalJSON }
        if ($ProjectJson) { $params['ProjectJson'] = $ProjectJson }
        if ($UseCredential) { $params['UseCredential'] = $true }
        if ($ScanIP) { $params['ScanIP'] = $true }
        if ($ScanIPPath) { $params['ScanIPPath'] = $ScanIPPath }
        if ($SkipEventLog) { $params['SkipEventLog'] = $true }
        if ($ServerOnlyData) { $params['ServerOnlyData'] = $true }
    }

    Write-Log "Starting $OsLabel batch collection for $($Rows.Count) server(s)." 'ACTION'
    Write-DiscoveryProgressStatus -State 'Running' -Phase $OsLabel -CurrentServer '' -Total $Total -Completed $Completed.Value -Failed $Failed.Value -Message "Starting $OsLabel batch"

    try {
        Invoke-CollectorCommand -CommandPath $collectorScript -Parameters $params -DiagnosticLogFile $_diagnosticLogFile
    }
    catch {
        Write-DiagnosticLog "$OsLabel collector exception: $($_.Exception.Message)"
    }

    foreach ($row in $Rows) {
        $serverName = ([string]$row.$nameCol).Trim()
        if ([string]::IsNullOrWhiteSpace($serverName)) { continue }

        $status = Get-ServerArtifactStatus -Target $serverName
        $Completed.Value++
        if ($status.Succeeded) {
            Write-Log "Completed ${serverName}" 'SUCCESS'
        }
        else {
            $Failed.Value++
            Write-Log "Failed or incomplete ${serverName}. See diagnostics log." 'ERROR'
        }

        Write-DiscoveryProgressStatus -State 'Running' -Phase $OsLabel -CurrentServer $serverName -Total $Total -Completed $Completed.Value -Failed $Failed.Value -Message "Finished $serverName"
    }
}

$completedCount = 0
$failedCount = 0
$totalCount = $linuxRunRows.Count + $windowsRunRows.Count
Write-DiscoveryProgressStatus -State 'Running' -Phase 'Starting' -Total $totalCount -Completed 0 -Failed 0 -Message 'Starting Client Discovery collection'

Invoke-DiscoveryGroupRun -Rows $linuxRunRows -OsLabel 'Linux' -Completed ([ref]$completedCount) -Failed ([ref]$failedCount) -Total $totalCount
Invoke-DiscoveryGroupRun -Rows $windowsRunRows -OsLabel 'Windows' -Completed ([ref]$completedCount) -Failed ([ref]$failedCount) -Total $totalCount

Write-DiscoveryProgressStatus -State 'Complete' -Phase 'Complete' -Total $totalCount -Completed $completedCount -Failed $failedCount -Message 'Collection complete'
Write-Log "ServerDataCollector complete. Servers: $completedCount processed, $failedCount failed." 'INFO'

# ── Consolidated output summary (JSON-only) ───────────────────────────────────

$summaryTargets = @(
    $csvRows |
    ForEach-Object { [string]$_.$nameCol } |
    Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
    ForEach-Object { $_.Trim() } |
    Select-Object -Unique
)

if ($summaryTargets.Count -gt 0 -and (Test-Path -LiteralPath $artifactsOutputDir)) {
    $summaryRows = @()
    $totals = [ordered]@{ MigrationJSON = 0; SQLJSON = 0; IISJSON = 0 }

    foreach ($target in $summaryTargets) {
        $targetShort = ($target -split '\.')[0]
        $candidateNames = @($target, $targetShort) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

        $resolvedSrv = $targetShort
        foreach ($candidate in $candidateNames) {
            if (Test-Path -LiteralPath (Join-Path $artifactsOutputDir $candidate) -PathType Container) {
                $resolvedSrv = $candidate
                break
            }
        }

        $srvFolder = Join-Path $artifactsOutputDir $resolvedSrv
        $migJson = Join-Path $srvFolder "${resolvedSrv}_${suffix}.json"
        $sqlJson = Join-Path $srvFolder "${resolvedSrv}_${checkShort}_SQL_Config.json"
        $iisJson = Join-Path $srvFolder "${resolvedSrv}_${checkShort}_IIS_Config.json"

        $migOk = Test-ArtifactGeneratedThisRun -Path $migJson -RunStart $runStartTime
        $sqlOk = Test-ArtifactGeneratedThisRun -Path $sqlJson -RunStart $runStartTime
        $iisOk = Test-ArtifactGeneratedThisRun -Path $iisJson -RunStart $runStartTime

        if ($migOk) { $totals.MigrationJSON++ }
        if ($sqlOk) { $totals.SQLJSON++ }
        if ($iisOk) { $totals.IISJSON++ }

        if ($migOk) { $migStatus = 'YES' } else { $migStatus = '-' }
        if ($sqlOk) { $sqlStatus = 'YES' } else { $sqlStatus = '-' }
        if ($iisOk) { $iisStatus = 'YES' } else { $iisStatus = '-' }

        $summaryRows += [PSCustomObject]@{
            Server           = $resolvedSrv
            'Migration JSON' = $migStatus
            'SQL JSON'       = $sqlStatus
            'IIS JSON'       = $iisStatus
        }
    }

    if ($summaryRows.Count -gt 0) {
        Write-Log ''
        Write-Log '=========================================='
        Write-Log '      CONSOLIDATED OUTPUT SUMMARY'
        Write-Log '=========================================='

        $colServer = [Math]::Max(8, ($summaryRows | ForEach-Object { $_.Server.Length } | Measure-Object -Maximum).Maximum + 2)
        $colFile = 16
        $fmt = "{0,-$colServer} {1,-$colFile} {2,-$colFile} {3,-$colFile}"
        $header = $fmt -f 'Server', 'Migration JSON', 'SQL JSON', 'IIS JSON'
        $divider = '-' * $header.Length

        Write-Host ''
        Write-Host $header -ForegroundColor White
        Write-Host $divider -ForegroundColor DarkGray
        foreach ($row in $summaryRows) {
            Write-Host ($fmt -f $row.Server, $row.'Migration JSON', $row.'SQL JSON', $row.'IIS JSON') -ForegroundColor Green
        }
        Write-Host $divider -ForegroundColor DarkGray
        Write-Host ($fmt -f 'TOTAL', "$($totals.MigrationJSON)/$($summaryRows.Count)", "$($totals.SQLJSON)/$($summaryRows.Count)", "$($totals.IISJSON)/$($summaryRows.Count)") -ForegroundColor Yellow
        Write-Host ''
        Write-Log "Artifacts directory: $artifactsOutputDir"
    }
}

Write-Log "Diagnostics saved: $_diagnosticLogFile" 'INFO'
Write-Log "Transcript saved: $_logFile" 'INFO'
Stop-Transcript -ErrorAction SilentlyContinue
