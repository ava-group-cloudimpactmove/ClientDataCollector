<#
.SYNOPSIS
    Compresses files from an output directory into ZIP archives.

.DESCRIPTION
    This script creates ZIP archives from all files in the specified output directory.
    Files are batched into multiple ZIP files if the total count exceeds the maximum objects per ZIP.

.PARAMETER OutputDir
    The directory containing files to be zipped (typically the Artifacts directory).

.PARAMETER DestinationDirectory  
    The directory where ZIP files will be created.

.EXAMPLE
    .\ZipOutput.ps1 -OutputDir "C:\Output\Artifacts" -DestinationDirectory "C:\Output\ZIPFiles"
    Creates ZIP files containing all files from the Artifacts directory.

.NOTES
    Author: Avanade Migration Team
    - Files are batched into groups of 95 objects per ZIP file
    - ZIP files are named with timestamps and part numbers for identification
#>

param (
    [Parameter(Mandatory = $true)]
    [Alias('OutputDirectory')]
    [string]$OutputDir,

    [Parameter(Mandatory = $true)]
    [string]$DestinationDirectory,

    [Parameter(Mandatory = $false)]
    [string]$ServerList
)
$ScriptVersion = "26.06.20"
Write-Host "ZipOutput.ps1 v$ScriptVersion"
# Validate
if (-Not (Test-Path $OutputDir -PathType Container)) {
    Write-Error "OutputDir '$OutputDir' does not exist."
    exit 1
}
if (-Not (Test-Path $DestinationDirectory -PathType Container)) {
    Write-Host "Creating destination directory: $DestinationDirectory"
    New-Item -ItemType Directory -Path $DestinationDirectory | Out-Null
}

if ($ServerList) {
    Write-Host "ServerList parameter is ignored. Zipping full output directory: $OutputDir" -ForegroundColor Yellow
}

Write-Host "Processing all files in output directory..."
$allFiles = Get-ChildItem -Path $OutputDir -Recurse -File

# Check if any files were found
if ($allFiles.Count -eq 0) {
    Write-Host "No files found to zip!" -ForegroundColor Red
    Write-Host "The output directory appears to be empty or contains no files." -ForegroundColor Yellow
    exit 0
}

$maxObjectsPerZip = 95
$totalObjects = $allFiles.Count
$zipCount = [math]::Ceiling($totalObjects / $maxObjectsPerZip)

Write-Host "`nTotal files to zip: $totalObjects"
Write-Host "Filtering mode: All files in output directory"
Write-Host "Creating $zipCount zip file(s)...`n"

for ($i = 0; $i -lt $zipCount; $i++) {
    $start = $i * $maxObjectsPerZip
    $end = [Math]::Min($start + $maxObjectsPerZip - 1, $totalObjects - 1)
    $batch = $allFiles[$start..$end]

    # Set up staging area
    $stagingRoot = Join-Path -Path ([System.IO.Path]::GetTempPath()) -ChildPath ([System.Guid]::NewGuid().ToString())
    $stagingContent = Join-Path $stagingRoot 'content'
    New-Item -ItemType Directory -Path $stagingContent | Out-Null

    # Copy files using robocopy in a single call
    foreach ($file in $batch) {
        $relativePath = $file.FullName.Substring($OutputDir.Length).TrimStart('\')
        $sourceDir = Split-Path $file.FullName -Parent
        $targetDir = Join-Path $stagingContent (Split-Path $relativePath -Parent)

        if (-not (Test-Path $targetDir)) {
            New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        }

        robocopy $sourceDir $targetDir $file.Name /NFL /NDL /NJH /NJS /NC /NS /NP /R:1 /W:1 > $null
    }

    # Build zip file
    $dateStamp = Get-Date -Format "yyyyMMddHHmmss"
    $zipPrefix = "Output"
    $zipFileName = Join-Path -Path $DestinationDirectory -ChildPath ("{0}_{1}_Part{2}.zip" -f $zipPrefix, $dateStamp, ($i + 1))

    try {
        Compress-Archive -Path "$stagingContent\*" -DestinationPath $zipFileName -Force
        Write-Host "✅ Created zip: $zipFileName"
    } catch {
        Write-Error "❌ Failed to create zip: $zipFileName. Error: $_"
    }

    # Cleanup
    Remove-Item -Path $stagingRoot -Recurse -Force -ErrorAction SilentlyContinue
}

# Summary
Write-Host "`n" + "="*60 -ForegroundColor Green
Write-Host "ZIP OPERATION COMPLETED" -ForegroundColor Green  
Write-Host "="*60 -ForegroundColor Green
Write-Host "Total files processed: $totalObjects" -ForegroundColor Cyan
Write-Host "ZIP files created: $zipCount" -ForegroundColor Cyan
Write-Host "Output location: $DestinationDirectory" -ForegroundColor Cyan
Write-Host "Filter: All files (no server selection)" -ForegroundColor Yellow
Write-Host "="*60 -ForegroundColor Green

if (Test-Path $zipFileName) {
    if ($env:AVAMOVE_SUPPRESS_OUTPUT -ne '1') {
        Start-Process -FilePath explorer.exe -ArgumentList "/select, $zipFileName"
    }
}
