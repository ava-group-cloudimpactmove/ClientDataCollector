<#
.SYNOPSIS
    Scans target servers for hardcoded IP addresses in text files and produces a JSON output per server.

.DESCRIPTION
    Connects to each server in the ServerList (or a single ServerName) and runs a recursive scan of the
    C:\ drive looking for hardcoded private/RFC-1918 IPv4 addresses embedded in text-based files.

    Results are written as:
        <OutputDir>\<ServerName>\<ServerName>_<Phase>_HardcodedIP.json
    where <Phase> is Pre, Post, or Test (derived from -CheckType).

.PARAMETER ServerList
    Path to a CSV file with a ServerName (and optional DomainName) column.

.PARAMETER ServerName
    Single server to target. Overrides ServerList. Use "localhost" to scan the local machine.

.PARAMETER OutputDir
    Root directory where per-server output folders and JSON files will be written.
    Defaults to C:\Avanade\<Username>.

.PARAMETER RunLocally
    Run the scan on the local machine without opening a WinRM remote session.

.PARAMETER PersonalJSON
    Path to a personal JSON file containing credentials (AlternateUsername/AlternatePassword or
    TestUsername/TestPassword).

.PARAMETER Username
    Username for remote WinRM connections.

.PARAMETER Password
    Plain-text password for remote WinRM connections.

.PARAMETER UseCredential
    Prompt for credentials interactively (only works in interactive sessions).

.PARAMETER MaxThreads
    Maximum number of parallel background jobs to run simultaneously. Defaults to 10.

.EXAMPLE
    .\MigrationCheck-ScanIP.ps1 -ServerList ".\serverlist.csv" -PersonalJSON "C:\personal.json" -OutputDir "C:\Output"

.EXAMPLE
    .\MigrationCheck-ScanIP.ps1 -ServerName localhost -RunLocally -OutputDir "C:\Output"

.NOTES
    Author: Ryan Ferguson
#>
[CmdletBinding()]
Param(
    [string]$ServerList   = '.\serverlist.csv',
    [string]$ServerName,
    [string]$OutputDir    = "C:\Avanade\$env:USERNAME",
    [switch]$RunLocally   = $false,
    [string]$PersonalJSON,
    [string]$Username,
    [string]$Password,
    [System.Management.Automation.PSCredential]$RemoteCredential = $null,
    [switch]$UseCredential = $false,
    [int]$MaxThreads       = 10,

    [ValidateSet('Pre_Migration', 'Post_Migration', 'Test_Migration')]
    [string]$CheckType = 'Pre_Migration'
)

$ScriptVersion = '26.06.11'
Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] MigrationCheck-ScanIP v$ScriptVersion started."
# 2026-06-17: Hardened WinRM TrustedHosts fallback handling and skipped Basic authentication when no explicit credential is available.

#region ── Credential helpers ───────────────────────────────────────────────

function PAT-Decrypt {
    param([string]$EncryptedPAT)
    try {
        Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
        if ([string]::IsNullOrWhiteSpace($EncryptedPAT)) { throw 'Encrypted value is null or empty.' }
        $encryptedBytes = [Convert]::FromBase64String($EncryptedPAT)
        $decryptedBytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $encryptedBytes, $null,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        return [System.Text.Encoding]::Unicode.GetString($decryptedBytes)
    }
    catch {
        Write-Verbose "Could not decrypt Personal JSON value with DPAPI CurrentUser: $($_.Exception.Message)"
        return $null
    }
}

$credential = $null

if ($RemoteCredential) {
    # Pre-built credential passed in by the caller (e.g. MigrationCheck-DataCollector)
    Write-Host 'Using RemoteCredential supplied by caller...' -ForegroundColor Green
    $credential = $RemoteCredential
}
elseif (![string]::IsNullOrEmpty($Username) -and ![string]::IsNullOrEmpty($Password)) {
    Write-Host 'Using credentials provided via parameters...' -ForegroundColor Green
    $secPw    = ConvertTo-SecureString $Password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($Username, $secPw)
}
elseif (![string]::IsNullOrEmpty($PersonalJSON) -and (Test-Path $PersonalJSON)) {
    $normalizedPersonalJSON = $PersonalJSON -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
    $normalizedPersonalJSON = $normalizedPersonalJSON.Trim().Trim("'`"")
    Write-Host "Loading credentials from personal JSON: $normalizedPersonalJSON" -ForegroundColor Green
    try {
        $personalData = Get-Content $normalizedPersonalJSON -Raw | ConvertFrom-Json

        $credUser = $null
        $credPass = $null

        $hasAlt = ($personalData.PSObject.Properties.Name -contains 'AlternateUsername' -and
                   $personalData.PSObject.Properties.Name -contains 'AlternatePassword' -and
                   -not [string]::IsNullOrWhiteSpace($personalData.AlternateUsername) -and
                   -not [string]::IsNullOrWhiteSpace($personalData.AlternatePassword))
        if ($hasAlt) {
            $credUser = $personalData.AlternateUsername
            $credPass = PAT-Decrypt -EncryptedPAT $personalData.AlternatePassword
            if ($credPass) { Write-Host "✔ Using encrypted AlternateUsername/AlternatePassword from personal JSON" -ForegroundColor Green }
            else           { Write-Warning 'AlternatePassword DPAPI decryption failed; falling through to TestUsername/TestPassword.' }
        }

        $hasTest = ($personalData.PSObject.Properties.Name -contains 'TestUsername' -and
                    $personalData.PSObject.Properties.Name -contains 'TestPassword' -and
                    -not [string]::IsNullOrWhiteSpace($personalData.TestUsername) -and
                    -not [string]::IsNullOrWhiteSpace($personalData.TestPassword))
        if (-not $credPass -and $hasTest) {
            $credUser = $personalData.TestUsername
            $credPass = $personalData.TestPassword
            Write-Host "✔ Using TestUsername/TestPassword from personal JSON" -ForegroundColor Green
        }

        if ($credUser -and $credPass) {
            $secPw      = ConvertTo-SecureString $credPass -AsPlainText -Force
            $credential = New-Object System.Management.Automation.PSCredential($credUser, $secPw)
        }
        else {
            Write-Warning 'Personal JSON did not yield usable credentials. Will use current user context.'
        }
    }
    catch {
        Write-Warning "Failed to load credentials from personal JSON: $($_.Exception.Message)"
    }
}
elseif ($UseCredential) {
    if ([Environment]::UserInteractive -and $Host.Name -ne 'ServerRemoteHost') {
        $credential = Get-Credential -Message 'Enter credentials for remote connections'
    }
    else {
        Write-Warning '-UseCredential requires an interactive session. Continuing with current user context.'
    }
}

#endregion

#region ── Output directory ─────────────────────────────────────────────────

$OutputDir = ($OutputDir -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', '').Trim().Trim("'`"")
if (-not (Test-Path $OutputDir)) { New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null }

#endregion

#region ── Server list ───────────────────────────────────────────────────────

$MyHostName   = (Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue).DNSHostName
if (-not $MyHostName) { $MyHostName = $env:COMPUTERNAME }

$targetServers = @()
if ($RunLocally -or $ServerName -eq 'localhost') {
    $targetServers = @($MyHostName)
}
elseif ($ServerName) {
    $targetServers = @($ServerName.Trim() -split '\s*,\s*' | Where-Object { $_ })
}
elseif (Test-Path $ServerList) {
    try {
        $csv = Import-Csv -Path $ServerList
        foreach ($row in $csv) {
            $host_ = if ($row.ServerName) { $row.ServerName } elseif ($row.Server) { $row.Server } else { $null }
            if ([string]::IsNullOrWhiteSpace($host_)) { continue }
            $fqdn = if ($row.DomainName) { "$host_.$($row.DomainName)" } else { $host_ }
            $targetServers += $fqdn
        }
    }
    catch {
        Write-Warning "Failed to import ServerList CSV. Defaulting to localhost."
        $targetServers = @($MyHostName)
    }
}
else {
    Write-Warning "Server list not found: $ServerList. Defaulting to localhost."
    $targetServers = @($MyHostName)
}

$targetServers = $targetServers |
    ForEach-Object { $_.ToString().Trim() } |
    Where-Object   { -not [string]::IsNullOrWhiteSpace($_) } |
    Select-Object -Unique

Write-Host "Target servers: $($targetServers -join ', ')" -ForegroundColor Cyan

#endregion

#region ── Remote scan scriptblock ──────────────────────────────────────────

# This scriptblock runs ON the target server (via Invoke-Command or directly).
# It returns an array of [PSCustomObject] with FilePath/IPAddress/LineText/LineNumber/IsLocal.
$scanScriptBlock = {
    $startTime  = Get-Date
    $serverName = (Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue).DNSHostName
    if (-not $serverName) { $serverName = $env:COMPUTERNAME }

    function Write-ScanLog {
        param([string]$Msg)
        Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [$serverName] $Msg"
    }

    Write-ScanLog "Starting IP scan for hardcoded IP addresses..."

    $localIPs = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                    Select-Object -ExpandProperty IPAddress

    # ── Scan scope ──────────────────────────────────────────────────────────
    $Includes  = @('C:\Windows\System32\drivers\etc\hosts')
    $RootPath  = 'C:\'

    $Excludes  = @(
        'C:\Program Files\WindowsPowerShell\',
        'C:\Windows\',
        'C:\Users\',
        'C:\Avanade\',
        '\Microsoft',
        '\Tmp\',
        'PowerShell\Modules',
        'ShellExtensions\Platform',
        'Reference Assemblies\Microsoft\Framework',
        'Program Files\nodejs\',
        '\lib\',
        'README',
        '\log\',
        'agent\plugin\',
        'sf3\',
        'WinPcap\',
        'C:\Scripts\',
        '\Temp\'
    )
    $ExcludesNorm = $Excludes | ForEach-Object { $_.Trim().TrimEnd('\').ToLower() }

    $ExcludeFiles = @(
        '*.dll','*.ex*','*.gif','*.png','*.bmp','*.ico','*.mui','*.sys','*.chm',
        '*.pfx','*.cer','*.evtx','*.tlb','*.zip','*.htm*','*.msi','*.csv','*.doc*',
        '*.xls*','*.ppt*','*.rtf','*.cat','*.manifest','*.svc','*.svg',
        '*.dat','*.pyc','*.hpp','*.lib*','*.rst','*.avi','*.mp*','*.pdf','*.wmf',
        '*.jp*','*.ttf','*.wav','*.vs*','*.pak','*.bundle','*.nls','*.deploy',
        '*.jar','*.sav','*.xml','*.adt','*.tim','*.dvd','*.cfs','*.pos',
        '*.bin','*.cab','*.msp','*.etl','*.dmp','*.mdmp','*.pdb','*.ilk',
        '*.cache','*.tmp','*.temp','*.bak','*.old','*.orig','*.swp','*.swo',
        '*.iso','*.img','*.vhd*','*.vmdk','*.ova','*.ovf','*.wim','*.esd',
        '*.mof','*.p7*','*.crl','*.sst','*.stl','*.crt','*.key','*.pem',
        '*.font','*.fon','*.eot','*.woff*','*.otf','*.cur','*.ani',
        '*.db','*.mdb','*.ldb','*.sqlite*','*.log','*.trace','*.out',
        '*.o','*.obj','*.a','*.so','*.dylib','*.class','*.pyc','*.pyo',
        '*.bsc','*.sbr','*.pch','*.idb','*.suo','*.user','*.sdf',
        '*.resx','*.resources','*.designer.*','*.generated.*','*.g.cs',
        '*.min.*','*.compressed.*','*.obfuscated.*','*.merged.*'
    )
    # ────────────────────────────────────────────────────────────────────────

    $ipRegex         = '\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b'
    $ipRegexCompiled = [regex]::new($ipRegex, [System.Text.RegularExpressions.RegexOptions]::Compiled)

    function Test-IsBinaryFile {
        param([string]$FilePath)
        try {
            $stream    = [System.IO.File]::OpenRead($FilePath)
            $buffer    = New-Object byte[] 4096
            $bytesRead = $stream.Read($buffer, 0, 4096)
            $stream.Close()
            if ($bytesRead -eq 0) { return $false }
            $printable = ($buffer[0..($bytesRead - 1)] |
                Where-Object { ($_ -eq 9) -or ($_ -eq 10) -or ($_ -eq 13) -or ($_ -ge 32 -and $_ -le 126) }).Count
            return (($printable / $bytesRead) -lt 0.80)
        }
        catch { return $true }
    }

    function Invoke-FileScan {
        param([string]$FilePath)
        $hits = @()
        try {
            if (Test-IsBinaryFile -FilePath $FilePath) { return $hits }
            $matches_ = Select-String -Path $FilePath -Pattern $ipRegex -AllMatches -ErrorAction SilentlyContinue
            foreach ($m in $matches_) {
                $line   = $m.Line
                $ipList = foreach ($rm in $ipRegexCompiled.Matches($line)) {
                    $ip = $rm.Value
                    if (($ip -match '^192\.168\.' -or $ip -match '^10\.' -or $ip -match '^172\.(1[6-9]|2[0-9]|3[01])\.') -and
                        ($line -notmatch 'Ver')) { $ip }
                }
                if ($ipList.Count -gt 0) {
                    $cleanLine = $line -replace "[^\p{L}\p{Nd}/ .]", ''
                    foreach ($ip in $ipList) {
                        $hits += [PSCustomObject]@{
                            FilePath   = $FilePath
                            IPAddress  = $ip
                            LineText   = $cleanLine
                            LineNumber = $m.LineNumber
                            IsLocal    = ($localIPs -contains $ip)
                        }
                    }
                }
            }
        }
        catch { }
        return $hits
    }

    $IPMatches = @()

    # Scan specifically-included files (e.g. hosts file)
    foreach ($fp in $Includes) {
        if (Test-Path $fp -PathType Leaf) {
            $IPMatches += Invoke-FileScan -FilePath $fp
        }
    }

    # Scan top-level directories on C:\
    $topDirs = Get-ChildItem -Path $RootPath -Directory -ErrorAction SilentlyContinue
    foreach ($dir in $topDirs) {
        $dirLower = $dir.FullName.TrimEnd('\').ToLower()
        if ($ExcludesNorm | Where-Object { $dirLower -like "*$_*" }) { continue }

        Get-ChildItem -Path $dir.FullName -Recurse -File -Exclude $ExcludeFiles -ErrorAction SilentlyContinue |
        Where-Object { $_.Length -lt 5MB } |
        ForEach-Object {
            $fp_ = $_.FullName.ToLower()
            $excluded = $false
            foreach ($exc in $ExcludesNorm) { if ($fp_ -like "*$exc*") { $excluded = $true; break } }
            if (-not $excluded) { $IPMatches += Invoke-FileScan -FilePath $_.FullName }
        }
    }

    $elapsed = [math]::Round(((Get-Date) - $startTime).TotalSeconds, 1)
    Write-ScanLog "IP scan complete. Found $($IPMatches.Count) hit(s) in ${elapsed}s."

    return [PSCustomObject]@{
        ServerName   = $serverName
        ScanComplete = $true
        HitCount     = $IPMatches.Count
        Results      = @($IPMatches)
    }
}

#endregion

#region ── Per-server execution ──────────────────────────────────────────────

$localHostName = $MyHostName.ToLower()

function Invoke-RemoteScan {
    param(
        [string]$Target,
        [System.Management.Automation.PSCredential]$Cred
    )

    $scanAttemptErrors = [System.Collections.Generic.List[string]]::new()

    function Add-WinRmTrustedHostIfNeeded {
        param([string]$RemoteServer)

        try {
            $currentTrustedHosts = (Get-Item WSMan:\localhost\Client\TrustedHosts -ErrorAction SilentlyContinue).Value
            $trustedHostPatterns = @($currentTrustedHosts -split ',' | ForEach-Object { ([string]$_).Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

            # '*' must stand alone. If a previous run left '*,server', normalize it back to '*'.
            if ($trustedHostPatterns -contains '*') {
                if ($trustedHostPatterns.Count -gt 1) {
                    Set-Item WSMan:\localhost\Client\TrustedHosts -Value '*' -Force -ErrorAction Stop
                    Write-Host "  Normalized WSMan TrustedHosts wildcard entry back to '*'" -ForegroundColor DarkGray
                }
                return
            }

            if ($trustedHostPatterns -contains $RemoteServer) {
                return
            }

            $newTrustedHosts = @($trustedHostPatterns + $RemoteServer) -join ','
            Set-Item WSMan:\localhost\Client\TrustedHosts -Value $newTrustedHosts -Force -ErrorAction Stop
            Write-Host "  Added $RemoteServer to WSMan TrustedHosts for explicit-auth fallback" -ForegroundColor DarkGray
        }
        catch {
            Write-Warning "  Could not update TrustedHosts (non-fatal): $($_.Exception.Message)"
        }
    }

    function Invoke-SingleScanAttempt {
        param(
            [string]$AttemptLabel,
            [string]$AttemptComputerName,
            [bool]$UseSSL,
            [System.Management.Automation.PSCredential]$AttemptCredential,
            [bool]$IncludePortInSPN = $false,
            [string]$Authentication = ''
        )
        try {
            $attemptUser = if ($AttemptCredential) { $AttemptCredential.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
            if ($Authentication -eq 'Basic' -and -not $AttemptCredential) {
                Write-Host "  Skipping $AttemptLabel on $AttemptComputerName because Basic authentication requires explicit credentials." -ForegroundColor DarkGray
                return [PSCustomObject]@{ Succeeded = $false; Data = $null; LastError = 'Basic authentication requires explicit credentials.'; UserName = $attemptUser }
            }
            if (-not [string]::IsNullOrWhiteSpace($Authentication)) {
                Add-WinRmTrustedHostIfNeeded -RemoteServer $AttemptComputerName
            }
            Write-Host "  Attempting $AttemptLabel on $AttemptComputerName as $attemptUser..." -ForegroundColor DarkGray
            $p = @{ ComputerName = $AttemptComputerName; ScriptBlock = $scanScriptBlock; ErrorAction = 'Stop' }
            if ($UseSSL -or $IncludePortInSPN) {
                try {
                    $soParams = @{}
                    if ($UseSSL)           { $soParams.SkipCACheck = $true; $soParams.SkipCNCheck = $true; $soParams.SkipRevocationCheck = $true }
                    if ($IncludePortInSPN) { $soParams.IncludePortInSPN = $true }
                    $p.SessionOption = New-PSSessionOption @soParams
                } catch { }
            }
            if ($UseSSL)     { $p.UseSSL = $true; $p.Port = 5986 }
            if ($AttemptCredential) { $p.Credential = $AttemptCredential }
            if (-not [string]::IsNullOrWhiteSpace($Authentication)) { $p.Authentication = $Authentication }
            $result = Invoke-Command @p
            Write-Host "  ✔ Connected to $AttemptComputerName using $AttemptLabel as $attemptUser" -ForegroundColor Green
            return [PSCustomObject]@{ Succeeded = $true; Data = $result; LastError = $null; UserName = $attemptUser }
        }
        catch {
            $msg = $_.Exception.Message
            $attemptUser = if ($AttemptCredential) { $AttemptCredential.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
            $scanAttemptErrors.Add("$AttemptLabel as $attemptUser failed: $msg") | Out-Null
            Write-Warning "  Connection attempt failed [$AttemptLabel as $attemptUser] for ${AttemptComputerName}: $msg"
            return [PSCustomObject]@{ Succeeded = $false; Data = $null; LastError = $msg; UserName = $attemptUser }
        }
    }

    # Build connection targets: original (FQDN) first, then short name, then DNS-resolved name
    $shortName = if ($Target -match '\.') { $Target.Split('.')[0] } else { $Target }
    $connectionTargets = [System.Collections.Generic.List[string]]::new()
    $connectionTargets.Add($Target) | Out-Null
    if ($shortName -ne $Target -and -not ($connectionTargets -contains $shortName)) {
        $connectionTargets.Add($shortName) | Out-Null
    }
    try {
        $resolvedHostName = ([System.Net.Dns]::GetHostEntry($Target)).HostName
        if (-not [string]::IsNullOrWhiteSpace($resolvedHostName) -and -not ($connectionTargets -contains $resolvedHostName)) {
            $connectionTargets.Add($resolvedHostName) | Out-Null
        }
    } catch { }

    $preferCurrentUserFirst = (-not $UseCredential)
    if ($Cred -and $preferCurrentUserFirst) {
        try {
            $computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
            if (-not [bool]$computerSystem.PartOfDomain) {
                $preferCurrentUserFirst = $false
                Write-Host "  Local computer is not domain-joined; explicit credentials will be attempted before current user context." -ForegroundColor Yellow
            }
        } catch {
            Write-Warning "  Could not determine local domain membership: $($_.Exception.Message)"
        }
    }
    $succeeded = $false
    $attemptResult = $null

    foreach ($connectionTarget in $connectionTargets) {
        if ($succeeded) { break }

        if ($preferCurrentUserFirst) {
            $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null
            $succeeded = [bool]$attemptResult.Succeeded
            $cuHttpLastError = $attemptResult.LastError
            if (-not $succeeded) {
                $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'current user context (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $null
                $succeeded = [bool]$attemptResult.Succeeded
            }
            $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
            if (-not $succeeded -and (($cuHttpLastError -match $crossDomainPattern) -or ($scanAttemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null -Authentication 'Negotiate'
                $succeeded = [bool]$attemptResult.Succeeded
            }
        }

        if (-not $succeeded -and $Cred) {
            $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $Cred
            $succeeded = [bool]$attemptResult.Succeeded
            $httpLastError = $attemptResult.LastError
            if (-not $succeeded -and $httpLastError -match '0x80090322|An unknown security error') {
                $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 +IncludePortInSPN)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $Cred -IncludePortInSPN $true
                $succeeded = [bool]$attemptResult.Succeeded
            }
            if (-not $succeeded) {
                $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $Cred
                $succeeded = [bool]$attemptResult.Succeeded
            }
            $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
            if (-not $succeeded -and (($httpLastError -match $crossDomainPattern) -or ($scanAttemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                Add-WinRmTrustedHostIfNeeded -RemoteServer $connectionTarget
                $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $Cred -Authentication 'Negotiate'
                $succeeded = [bool]$attemptResult.Succeeded
                if (-not $succeeded) {
                    $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTPS/5986 Basic)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $Cred -Authentication 'Basic'
                    $succeeded = [bool]$attemptResult.Succeeded
                }
            }
        }

        if (-not $preferCurrentUserFirst -and -not $succeeded) {
            $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null
            $succeeded = [bool]$attemptResult.Succeeded
            $cuHttpLastError = $attemptResult.LastError
            if (-not $succeeded) {
                $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'current user context (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $null
                $succeeded = [bool]$attemptResult.Succeeded
            }
            $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
            if (-not $succeeded -and (($cuHttpLastError -match $crossDomainPattern) -or ($scanAttemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                $attemptResult = Invoke-SingleScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null -Authentication 'Negotiate'
                $succeeded = [bool]$attemptResult.Succeeded
            }
        }
    }

    if ($succeeded) { return $attemptResult.Data }
    Write-Warning "  All connection attempts failed for $Target. Attempts: $($scanAttemptErrors -join ' | ')"
    return $null
}

$allResults = @()

foreach ($target in $targetServers) {
    $ts = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')]"
    Write-Host "$ts Processing: $target" -ForegroundColor Yellow

    $shortName = if ($target -match '\.') { $target.Split('.')[0] } else { $target }
    $targetLower = $target.ToLower()
    $shortLower  = $shortName.ToLower()

    $isLocal = ($targetLower -in 'localhost', $localHostName, $env:COMPUTERNAME.ToLower()) -or
               ($shortLower  -in 'localhost', $localHostName, $env:COMPUTERNAME.ToLower()) -or
               $RunLocally

    # ── Run scan ────────────────────────────────────────────────────────────
    $scanResult = $null
    if ($isLocal) {
        Write-Host "  Running scan locally on $target..." -ForegroundColor DarkCyan
        $scanResult = & $scanScriptBlock | ForEach-Object {
            if ($_ -is [PSCustomObject] -and $_.PSObject.Properties['ScanComplete']) {
                $_
            }
            else {
                Write-Host "  [local] $_" -ForegroundColor DarkGray
            }
        }
    }
    else {
        $scanResult = Invoke-RemoteScan -Target $target -Cred $credential
    }

    # ── Write JSON ──────────────────────────────────────────────────────────
    $serverOutputDir = Join-Path $OutputDir $shortName
    if (-not (Test-Path $serverOutputDir)) {
        New-Item -Path $serverOutputDir -ItemType Directory -Force | Out-Null
    }

    $checkShort = ($CheckType -split '_')[0]   # Pre, Post, Test
    $jsonPath = Join-Path $serverOutputDir "${shortName}_${checkShort}_HardcodedIP.json"

    if ($null -eq $scanResult) {
        Write-Warning "No scan result returned for $target. Skipping JSON output."
        $allResults += [PSCustomObject]@{
            ServerName = $shortName
            Succeeded  = $false
            HitCount   = 0
            JsonPath   = $null
            Error      = 'No result returned (connection or scan failure)'
        }
        continue
    }

    # Ensure Results is always a proper array before serialising
    $normalised = [PSCustomObject]@{
        ServerName   = $scanResult.ServerName
        ScanComplete = [bool]$scanResult.ScanComplete
        HitCount     = [int]$scanResult.HitCount
        Results      = @($scanResult.Results | ForEach-Object {
            [PSCustomObject]@{
                FilePath   = [string]$_.FilePath
                IPAddress  = [string]$_.IPAddress
                LineText   = [string]$_.LineText
                LineNumber = [int]$_.LineNumber
                IsLocal    = [bool]$_.IsLocal
            }
        })
    }

    $jsonContent = ConvertTo-Json -InputObject $normalised -Depth 6 -Compress:($PSVersionTable.PSVersion.Major -ge 7)
    [System.IO.File]::WriteAllText($jsonPath, $jsonContent, [System.Text.Encoding]::UTF8)

    Write-Host "  ✔ JSON written: $jsonPath ($($normalised.HitCount) hits)" -ForegroundColor Green

    $allResults += [PSCustomObject]@{
        ServerName = $shortName
        Succeeded  = $true
        HitCount   = $normalised.HitCount
        JsonPath   = $jsonPath
        Error      = ''
    }
}

#endregion

#region ── Summary ───────────────────────────────────────────────────────────

Write-Host ''
Write-Host '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━' -ForegroundColor Cyan
Write-Host " MigrationCheck-ScanIP complete" -ForegroundColor Cyan
Write-Host '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━' -ForegroundColor Cyan

$allResults | ForEach-Object {
    $icon    = if ($_.Succeeded) { '✔' } else { '✘' }
    $color   = if ($_.Succeeded) { 'Green' } else { 'Red' }
    $detail  = if ($_.Succeeded) { "Hits: $($_.HitCount)  →  $($_.JsonPath)" } else { "Error: $($_.Error)" }
    Write-Host "  $icon $($_.ServerName)  $detail" -ForegroundColor $color
}

Write-Host ''
$allResults

#endregion
