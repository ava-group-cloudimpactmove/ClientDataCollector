<# =====================================================================
Export-SqlClusterConfig.ps1
WSFC + (optional) SQL AG export to JSON (PowerShell 5.1 compatible)



Requires:
- Windows PowerShell 5.1
- FailoverClusters module (RSAT/installed on a cluster node)
- (Optional) SqlServer module for Invoke-Sqlcmd

Parameters:
- CheckType: Specifies migration phase (Pre_Migration, Post_Migration, Pre, Post). Defaults to Pre_Migration.
  Affects output filename: {ServerName}_{Pre|Post}_SQL_Config.json
- RunLocally: Run the script on the local machine
- ServerName: Single server name or comma-separated server names to process
- ServerList: Path to CSV file containing Server/ServerName column (default: .\serverlist.csv)
- OutputPath: Custom output path for JSON file (single server) or base directory (batch mode)
- ClusterName: Target Windows Server Failover Cluster name
- SqlInstance: SQL Server instance(s) to query for AG information
- SqlCredential: Credentials for SQL Server connections
- RemoteCredential: Credentials for remote server connections
- IncludeVerboseResourceProps: Include detailed cluster resource properties

Examples:
  Local Mode:
  .\CollectSQLData.ps1 -CheckType Pre_Migration -RunLocally

  Single Server Mode:
  .\CollectSQLData.ps1 -CheckType Pre_Migration -ServerName SERVER01
  .\CollectSQLData.ps1 -CheckType Post -ServerName SERVER01 -OutputPath C:\Reports\

  Multiple Servers:
  .\CollectSQLData.ps1 -CheckType Pre -ServerName "SERVER01,SERVER02,SERVER03"

  CSV Batch Mode:
  .\CollectSQLData.ps1 -CheckType Pre_Migration -ServerList C:\ServerList.csv -OutputPath C:\Reports\
  # Processes each server in CSV and outputs to C:\Reports\Artifacts\{ServerName}\{ServerName}_Pre_SQL_Config.json

Author: Ryan Ferguson - With a lot of help from AI!  Guess I have to give credit where credit is due.
===================================================================== #>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidateSet("Pre_Migration", "Post_Migration", "Pre", "Post")]
    [string]$CheckType = "Pre_Migration",

    [Parameter(Mandatory = $false)]
    [switch]$RunLocally = $false,

    [Parameter(Mandatory = $false)]
    [string]$ServerName,

    [Parameter(Mandatory = $false)]
    [Alias('ServerListCSV')]
    [string]$ServerList = ".\serverlist.csv",

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$OutputPath,

    [Parameter(Mandatory = $false)]
    [string]$ClusterName,

    [Parameter(Mandatory = $false)]
    [string[]]$SqlInstance,

    [Parameter(Mandatory = $false)]
    [PSCredential]$SqlCredential,

    [Parameter(Mandatory = $false)]
    [PSCredential]$RemoteCredential,

    [Parameter(Mandatory = $false)]
    [string]$Username,

    [Parameter(Mandatory = $false)]
    [string]$Password,

    [Parameter(Mandatory = $false)]
    [string]$PersonalJson = "",

    [switch]$IncludeVerboseResourceProps,

    [Parameter(Mandatory = $false)]
    [switch]$ForceInstall
)
$ScriptVersion = "26.06.12"
# 2026-06-17: Hardened WinRM fallback handling so TrustedHosts wildcard entries are preserved
# and Basic authentication is only attempted when explicit credentials are available.
# 2026-04-23: Hardened PersonalJson parameter handling for GUI/CLI runs.
# Accepts PersonalJSON/JsonPersonal aliases and normalizes provider-prefixed/quoted paths
# before credential loading so fallback credentials are reliably recognized.
# 2026-03-18: Fixed DBNull serialisation bug: DataTable row values that are System.DBNull are now
# stored as $null in rowData so ConvertTo-Json emits JSON null instead of {} (empty object).
# This prevents the 'System.Management.Automation.OrderedHashtable' rendering in HTML reports.

# Normalize personal JSON path once and reuse it throughout the script.
if (-not [string]::IsNullOrWhiteSpace($PersonalJson)) {
    $PersonalJson = $PersonalJson.Trim().Trim("'").Trim('"')
    if ($PersonalJson -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
        $PersonalJson = $PersonalJson -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
    }
}

function Write-Info($msg) { Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Warn($msg) { Write-Warning $msg }
function Write-Err ($msg) { Write-Host "[ERROR] $msg" -ForegroundColor Red }

function Resolve-SqlModuleZipPath {
    param(
        [string]$ZipFilePath
    )

    $candidatePaths = @()

    if (-not [string]::IsNullOrWhiteSpace($ZipFilePath)) {
        $candidatePaths += $ZipFilePath
    }

    $candidatePaths += @(
        (Join-Path $PSScriptRoot "Tools\SQLPSModule.zip"),
        (Join-Path $PSScriptRoot "SQLPSModule.zip"),
        (Join-Path (Split-Path -Parent $PSScriptRoot) "Tools\SQLPSModule.zip")
    )

    foreach ($candidate in $candidatePaths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) {
        if (Test-Path -LiteralPath $candidate) {
            return $candidate
        }
    }

    return $null
}

function Import-AvailableSqlModule {
    param(
        [switch]$TryInstall,
        [string]$ZipFilePath
    )

    $moduleNames = @('SqlServer', 'SQLPS')

    foreach ($moduleName in $moduleNames) {
        try {
            Import-Module -Name $moduleName -Force -ErrorAction Stop
            Write-Info "Loaded SQL module: $moduleName"
            return $true
        }
        catch { }
    }

    try {
        $availableModule = Get-Module -ListAvailable -Name SqlServer, SQLPS |
        Sort-Object Version -Descending |
        Select-Object -First 1

        if ($availableModule) {
            Import-Module -Name $availableModule.Path -Force -ErrorAction Stop
            Write-Info "Loaded SQL module from discovered path: $($availableModule.Path)"
            return $true
        }
    }
    catch { }

    if ($TryInstall) {
        if (Install-SqlPSModuleLocal -ZipFilePath $ZipFilePath) {
            foreach ($moduleName in $moduleNames) {
                try {
                    Import-Module -Name $moduleName -Force -ErrorAction Stop
                    Write-Info "Loaded SQL module after install: $moduleName"
                    return $true
                }
                catch { }
            }

            try {
                $availableModule = Get-Module -ListAvailable -Name SqlServer, SQLPS |
                Sort-Object Version -Descending |
                Select-Object -First 1

                if ($availableModule) {
                    Import-Module -Name $availableModule.Path -Force -ErrorAction Stop
                    Write-Info "Loaded SQL module from discovered path after install: $($availableModule.Path)"
                    return $true
                }
            }
            catch { }
        }
    }

    return $false
}

# =====================================================================
# CREDENTIAL HANDLING LOGIC (from MigrationCheck-DataCollector.ps1)
# =====================================================================

# Function to decrypt encrypted credentials from PersonalJSON file
function PAT-Decrypt {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$EncryptedPAT
    )

    try {
        if (-not $EncryptedPAT) {
            throw "Encrypted value is null or empty."
        }
        # Convert the Base64-encoded string back to an array of bytes.
        $encryptedBytes = [Convert]::FromBase64String($EncryptedPAT)

        # Decrypt the bytes using DPAPI with the current user scope.
        $decryptedBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($encryptedBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)

        # Convert the decrypted bytes back into a string.
        $decryptedPAT = [System.Text.Encoding]::Unicode.GetString($decryptedBytes)
    }
    catch {
        $msg = if ($_.Exception -and $_.Exception.Message) { $_.Exception.Message } else { "Unknown error" }
        Write-Error "Failed to decrypt encrypted value from Personal JSON (DPAPI CurrentUser): $msg"
        $decryptedPAT = $null
    }

    return $decryptedPAT
}

# Handle credentials for remote and SQL connections
$credential = $null
$personalSqlCredential = $null
$personalRemoteCredential = $null

# Check if username and password parameters were provided (automatically use credentials)
if (![string]::IsNullOrEmpty($Username) -and ![string]::IsNullOrEmpty($Password)) {
    Write-Host "Using credentials provided via parameters..." -ForegroundColor Green
    $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($Username, $securePassword)
    if (-not $RemoteCredential) { $RemoteCredential = $credential }
}
# Check if personal JSON file was provided (automatically use credentials)
elseif (![string]::IsNullOrWhiteSpace($PersonalJson) -and (Test-Path -LiteralPath $PersonalJson)) {
    Write-Host "Loading credentials from personal JSON: $PersonalJson" -ForegroundColor Green
    try {
        $personalData = Get-Content -LiteralPath $PersonalJson -ErrorAction Stop | ConvertFrom-Json

        $credentialIssues = [System.Collections.Generic.List[string]]::new()

        # SQL credentials are used inside the remote SQL collection only.
        $hasAlternateSqlCreds = ($personalData.PSObject.Properties.Name -contains 'AlternateSqlUsername' -and
            $personalData.PSObject.Properties.Name -contains 'AlternateSqlPassword' -and
            -not [string]::IsNullOrWhiteSpace($personalData.AlternateSqlUsername) -and
            -not [string]::IsNullOrWhiteSpace($personalData.AlternateSqlPassword))

        if ($hasAlternateSqlCreds) {
            $sqlPassword = PAT-Decrypt -EncryptedPAT $personalData.AlternateSqlPassword
            if (-not [string]::IsNullOrWhiteSpace($sqlPassword)) {
                $secureSqlPassword = ConvertTo-SecureString $sqlPassword -AsPlainText -Force
                $personalSqlCredential = New-Object System.Management.Automation.PSCredential($personalData.AlternateSqlUsername, $secureSqlPassword)
                Write-Host "Successfully loaded and decrypted AlternateSqlUsername/AlternateSqlPassword." -ForegroundColor Green
            }
            else {
                $credentialIssues.Add("Personal JSON contains AlternateSqlUsername/AlternateSqlPassword, but AlternateSqlPassword could not be decrypted (DPAPI CurrentUser). This usually means it was encrypted under a different Windows user profile or on a different machine.") | Out-Null
            }
        }

        # Windows alternate credentials are used for WinRM remoting.
        $hasAlternateCreds = ($personalData.PSObject.Properties.Name -contains 'AlternateUsername' -and
            $personalData.PSObject.Properties.Name -contains 'AlternatePassword' -and
            -not [string]::IsNullOrWhiteSpace($personalData.AlternateUsername) -and
            -not [string]::IsNullOrWhiteSpace($personalData.AlternatePassword))

        if ($hasAlternateCreds) {
            $remotePassword = PAT-Decrypt -EncryptedPAT $personalData.AlternatePassword
            if (-not [string]::IsNullOrWhiteSpace($remotePassword)) {
                $secureRemotePassword = ConvertTo-SecureString $remotePassword -AsPlainText -Force
                $personalRemoteCredential = New-Object System.Management.Automation.PSCredential($personalData.AlternateUsername, $secureRemotePassword)
                Write-Host "Successfully loaded and decrypted AlternateUsername/AlternatePassword." -ForegroundColor Green
            }
            else {
                $credentialIssues.Add("Personal JSON contains AlternateUsername/AlternatePassword, but AlternatePassword could not be decrypted (DPAPI CurrentUser). This usually means it was encrypted under a different Windows user profile or on a different machine.") | Out-Null
            }
        }

        if (-not $personalRemoteCredential -and $personalSqlCredential) {
            $personalRemoteCredential = $personalSqlCredential
            Write-Warn "Personal JSON did not provide AlternateUsername/AlternatePassword; falling back to AlternateSqlUsername/AlternateSqlPassword for WinRM remoting."
        }

        if ($personalRemoteCredential -or $personalSqlCredential) {
            $credential = $personalRemoteCredential
            Write-Host "Credentials loaded successfully from personal JSON." -ForegroundColor Green
        }
        else {
            if ($credentialIssues.Count -gt 0) {
                foreach ($issue in $credentialIssues) { Write-Warning $issue }
            }
            else {
                Write-Warning "Personal JSON file does not contain valid credentials. Expected AlternateSqlUsername/AlternateSqlPassword, AlternateUsername/AlternatePassword, or TestUsername/TestPassword."
            }
        }
    }
    catch {
        Write-Warning "Failed to load credentials from personal JSON: $($_.Exception.Message)"
    }
}

# Set SQL and remoting credentials independently. The remoting path should use
# the Windows alternate credential, while SQL can use dedicated SQL credentials.
if ($personalSqlCredential -and -not $SqlCredential) {
    $SqlCredential = $personalSqlCredential
    Write-Info "SqlCredential set from PersonalJSON SQL credentials - Username: $($personalSqlCredential.UserName)"
}
elseif ($credential -and -not $SqlCredential) {
    $SqlCredential = $credential
    Write-Info "SqlCredential set from PersonalJSON Windows credentials - Username: $($credential.UserName)"
}

if ($personalRemoteCredential -and -not $RemoteCredential) {
    $RemoteCredential = $personalRemoteCredential
    Write-Info "RemoteCredential set from PersonalJSON Windows credentials - Username: $($personalRemoteCredential.UserName)"
}

if ($RemoteCredential) {
    $credential = $RemoteCredential
}

# Function to install SQL PowerShell module locally from zip file
function Install-SqlPSModuleLocal {
    param(
        [string]$ZipFilePath = ""
    )
    try {
        Write-Info "Attempting to install SQL PowerShell module locally from zip file..."

        $ZipFilePath = Resolve-SqlModuleZipPath -ZipFilePath $ZipFilePath
        if (-not $ZipFilePath) {
            Write-Warn "SQLPSModule.zip not found in expected relative locations near the script."
            return $false
        }

        Write-Info "Using SQL module zip file: $ZipFilePath"

        # Install into the first writable module path from PSModulePath
        $moduleDirectory = ($env:PSModulePath -split ';' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -First 1)
        if ([string]::IsNullOrWhiteSpace($moduleDirectory)) {
            $moduleDirectory = Join-Path $HOME "Documents\WindowsPowerShell\Modules"
        }
        if (-not (Test-Path $moduleDirectory)) {
            New-Item -Path $moduleDirectory -ItemType Directory -Force | Out-Null
        }

        # Extract the zip file
        Write-Info "Extracting SQL PowerShell module to $moduleDirectory..."
        if ($PSVersionTable.PSVersion.Major -ge 5) {
            Expand-Archive -Path $ZipFilePath -DestinationPath $moduleDirectory -Force
        }
        else {
            # Fallback for older PowerShell versions
            $shell = New-Object -ComObject Shell.Application
            $zip = $shell.NameSpace($ZipFilePath)
            $dest = $shell.NameSpace($moduleDirectory)
            $dest.CopyHere($zip.Items(), 4)
        }

        Write-Info "SQL PowerShell module installation completed locally"
        return $true
    }
    catch {
        Write-Err "Failed to install SQL PowerShell module locally: $($_.Exception.Message)"
        return $false
    }
}

# Function to install SQL PowerShell modules on remote server
function Install-SqlPSModulesRemote {
    param(
        [string]$ServerName
    )
    try {
        Write-Info "Attempting to install SQL PowerShell modules on $ServerName..."

        # Look for InstallSQLPSModules-Remote.ps1 script
        $installScriptPath = Join-Path $PSScriptRoot "Tools\InstallSQLPSModules-Remote.ps1"
        if (-not (Test-Path $installScriptPath)) {
            # Try alternative locations
            $installScriptPath = Join-Path $PSScriptRoot "InstallSQLPSModules-Remote.ps1"
        }

        if (-not (Test-Path $installScriptPath)) {
            Write-Warn "InstallSQLPSModules-Remote.ps1 not found. Expected location: $installScriptPath"
            return $false
        }

        # Look for SQLPSModule.zip using script-relative paths
        $moduleZipPath = Resolve-SqlModuleZipPath

        if (-not (Test-Path $moduleZipPath)) {
            Write-Warn "SQLPSModule.zip not found. Expected location: $moduleZipPath"
            return $false
        }

        Write-Info "Running: $installScriptPath -ModuleZipPath $moduleZipPath -ServerName $ServerName"

        # Build parameters hashtable for proper splatting
        $installParams = @{
            ModuleZipPath = $moduleZipPath
            ServerName    = $ServerName
        }

        # Add credential parameters if available
        if ($RemoteCredential) {
            Write-Info "Adding credentials to installation script for user: $($RemoteCredential.UserName)"
            $installParams.Username = $RemoteCredential.UserName
            $installParams.Password = $RemoteCredential.GetNetworkCredential().Password
        }
        elseif (![string]::IsNullOrWhiteSpace($PersonalJson) -and (Test-Path -LiteralPath $PersonalJson)) {
            Write-Info "Adding PersonalJSON to installation script: $PersonalJson"
            $installParams.PersonalJSON = $PersonalJson
        }

        # Execute the installation script with proper splatting
        Write-Info "Installing SQL modules with parameters: $(($installParams.Keys | ForEach-Object { "$_=$($installParams[$_])" }) -join ', ')"
        $null = & $installScriptPath @installParams

        Write-Info "SQL PowerShell module installation completed on $ServerName"
        return $true
    }
    catch {
        Write-Err "Failed to install SQL PowerShell modules on $ServerName`: $($_.Exception.Message)"
        return $false
    }
}

# Wrapper function that handles SQL data collection with retry logic
function Export-SqlClusterConfigWithRetry {
    param(
        [string]$OutputPath,
        [string]$SqlInstance,
        [string]$RemoteServer
    )
    $maxRetries = 1
    $retryCount = 0

    while ($retryCount -le $maxRetries) {
        try {
            if ($retryCount -gt 0) {
                Write-Info "Retrying SQL data collection (attempt $($retryCount + 1) of $($maxRetries + 1))..."
            }

            # Call the main collection function
            Export-SqlClusterConfig -OutputPath $OutputPath -SqlInstance $SqlInstance -RemoteServer $RemoteServer

            # If we get here, the collection succeeded
            return
        }
        catch {
            Write-Err "SQL data collection failed: $($_.Exception.Message)"

            # Check if this is an SQL module related error and we haven't retried yet
            if ($retryCount -eq 0 -and $RemoteServer -and
                ($_.Exception.Message -like "*SQL*module*" -or
                $_.Exception.Message -like "*SqlServer*" -or
                $_.Exception.Message -like "*SQLPS*" -or
                $_.Exception.Message -like "*Invoke-Sqlcmd*")) {

                if ($ForceInstall) {
                    Write-Info "SQL module error detected. ForceInstall enabled; attempting module installation..."

                    if (Install-SqlPSModulesRemote -ServerName $RemoteServer) {
                        Write-Info "SQL modules installed successfully. Retrying data collection..."
                        $retryCount++
                        continue
                    }
                    else {
                        Write-Err "Failed to install SQL modules. Cannot retry."
                        throw
                    }
                }
                else {
                    Write-Warn "SQL module error detected, but ForceInstall is not set. Skipping module installation."
                    throw
                }
            }
            else {
                # Either not a retry-able error, no remote server, or already retried
                Write-Err "Cannot retry SQL data collection: not a module error or maximum retries reached"
                throw
            }
        }
    }
}

# Normalize CheckType parameter
switch ($CheckType) {
    "Pre" { $CheckType = "Pre_Migration" }
    "Post" { $CheckType = "Post_Migration" }
    Default {
        # Keep as-is for "Pre_Migration" and "Post_Migration"
        if ($CheckType -notin @("Pre_Migration", "Post_Migration")) {
            Write-Warn "Invalid CheckType '$CheckType', defaulting to 'Pre_Migration'"
            $CheckType = "Pre_Migration"
        }
    }
}

# Extract short form for filename (Pre or Post)
$CheckTypeShort = if ($CheckType -eq "Pre_Migration") { "Pre" } else { "Post" }

Write-Info "CheckType set to: $CheckType (filename will use: $CheckTypeShort)"
if (-not [string]::IsNullOrWhiteSpace($PersonalJson)) {
    Write-Info "PersonalJSON credential file provided: $PersonalJson"
}

# Function to execute SQL queries using sqlcmd as fallback
function Invoke-SqlcmdFallback {
    param(
        [string]$ServerInstance,
        [string]$Query,
        [switch]$TrustServerCertificate
    )
    try {
        Write-Info "Using sqlcmd fallback for SQL Server queries on instance: $ServerInstance"

        # Prepare sqlcmd arguments
        $sqlcmdArgs = @(
            '-S', $ServerInstance
            '-E'  # Use Windows Authentication
            '-Q', $Query
            '-s', "`t"  # Tab delimiter
            '-h', '1'  # Include headers for object parsing
            '-W'  # Remove trailing spaces
        )

        if ($TrustServerCertificate) {
            $sqlcmdArgs += '-C'  # Trust server certificate
        }

        # Execute sqlcmd
        $result = & sqlcmd @sqlcmdArgs 2>&1

        if ($LASTEXITCODE -ne 0) {
            throw "sqlcmd failed with exit code $LASTEXITCODE. Output: $($result -join "`n")"
        }

        # Parse tab-delimited output into objects
        $lines = $result | ForEach-Object { $_.ToString() } | Where-Object {
            $_ -and $_.Trim() -ne '' -and
            $_ -notmatch '^\(\d+\s+rows?\s+affected\)$' -and
            $_ -notmatch '^Changed database context to'
        }
        if ($lines.Count -eq 0) {
            return @()
        }

        # First line contains column headers
        $rawHeaders = $lines[0] -split "`t"
        $headerCounts = @{}
        $headers = for ($h = 0; $h -lt $rawHeaders.Count; $h++) {
            $name = [string]$rawHeaders[$h]
            if ([string]::IsNullOrWhiteSpace($name)) {
                $name = "Column$($h + 1)"
            }
            $name = $name.Trim()
            if ($headerCounts.ContainsKey($name)) {
                $headerCounts[$name]++
                $name = "${name}_$($headerCounts[$name])"
            }
            else {
                $headerCounts[$name] = 1
            }
            $name
        }
        $objects = @()

        for ($i = 1; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -match '^\s*-+\s*(\t\s*-+\s*)*$') {
                continue
            }
            $values = $lines[$i] -split "`t"
            $obj = [ordered]@{}

            for ($j = 0; $j -lt $headers.Count; $j++) {
                $obj[$headers[$j]] = if ($j -lt $values.Count) { $values[$j] } else { $null }
            }

            $objects += [pscustomobject]$obj
        }

        return $objects

    }
    catch {
        throw "sqlcmd fallback failed: $($_.Exception.Message)"
    }
}

# Function to try multiple connection approaches for remote SQL Server
function Test-SqlConnection {
    param(
        [string]$ServerInstance
    )
    $connectionStrings = @(
        "Server=$ServerInstance;Integrated Security=true;Connection Timeout=30;TrustServerCertificate=true;Encrypt=false;MultipleActiveResultSets=true;",
        "Server=$ServerInstance,1433;Integrated Security=true;Connection Timeout=30;TrustServerCertificate=true;Encrypt=false;",
        "Server=tcp:$ServerInstance,1433;Integrated Security=true;Connection Timeout=30;TrustServerCertificate=true;Encrypt=false;",
        "Data Source=$ServerInstance;Integrated Security=true;Connection Timeout=30;TrustServerCertificate=true;Encrypt=false;",
        "Server=\\$ServerInstance\pipe\sql\query;Integrated Security=true;Connection Timeout=30;"
    )

    foreach ($connStr in $connectionStrings) {
        try {
            $shortConn = $connStr.Substring(0, [Math]::Min(50, $connStr.Length))
            Write-Host "Trying connection: $shortConn..."
            $testConn = New-Object System.Data.SqlClient.SqlConnection($connStr)

            # Add timeout wrapper for connection.Open()
            $connectionTask = $testConn.OpenAsync()
            $connectionCompleted = $connectionTask.Wait(30000)  # 30 second timeout

            if (-not $connectionCompleted) {
                Write-Host "Connection timeout after 30 seconds"
                $testConn.Dispose()
                continue
            }

            $testConn.Close()
            Write-Host "Success with: $shortConn"
            return $connStr
        }
        catch {
            $errorMsg = $_.Exception.Message.Substring(0, [Math]::Min(80, $_.Exception.Message.Length))
            Write-Host "Failed: $errorMsg"
        }
    }

    throw "All connection methods failed for server: $ServerInstance"
}

# Function to execute SQL queries using .NET SqlConnection as final fallback
function Invoke-DotNetSqlFallback {
    param(
        [string]$ServerInstance,
        [string]$Query,
        [switch]$TrustServerCertificate
    )
    try {
        Write-Info "Using .NET SqlConnection fallback for SQL Server queries on instance: $ServerInstance"

        # Try multiple connection approaches to find one that works
        try {
            $connectionString = Test-SqlConnection -ServerInstance $ServerInstance
            Write-Info "Using tested connection string for $ServerInstance"
        }
        catch {
            Write-Warn "Connection test failed, using default connection string: $($_.Exception.Message)"
            $connectionString = "Server=$ServerInstance;Integrated Security=true;Connection Timeout=30;TrustServerCertificate=true;Encrypt=false;MultipleActiveResultSets=true;"
        }

        $results = @()
        $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)

        try {
            # Add async timeout wrapper for connection.Open()
            $openTask = $connection.OpenAsync()
            $connectionSucceeded = $openTask.Wait(30000)  # 30 second timeout

            if (-not $connectionSucceeded) {
                throw "Connection timeout: Could not establish SQL connection within 30 seconds"
            }

            $command = New-Object System.Data.SqlClient.SqlCommand($Query, $connection)
            $command.CommandTimeout = 300  # 5 minutes

            $reader = $command.ExecuteReader()

            # Get column names
            $columns = @()
            for ($i = 0; $i -lt $reader.FieldCount; $i++) {
                $columns += $reader.GetName($i)
            }

            # Read data
            while ($reader.Read()) {
                $row = [ordered]@{}
                for ($i = 0; $i -lt $columns.Count; $i++) {
                    $value = if ($reader.IsDBNull($i)) { $null } else { $reader.GetValue($i) }
                    $row[$columns[$i]] = $value
                }
                $results += [pscustomobject]$row
            }

            $reader.Close()
        }
        finally {
            if ($connection.State -eq 'Open') {
                $connection.Close()
            }
            $connection.Dispose()
        }

        return $results

    }
    catch {
        $errorMessage = $_.Exception.Message
        throw "DotNet SqlConnection fallback failed: $errorMessage"
    }
}

# Helper function to execute individual SQL queries with error handling
function Invoke-SqlQueriesWithErrorHandling {
    param(
        [string]$ServerInstance,
        [hashtable]$SqlQueries,
        [bool]$UseDotNetMethod,
        [bool]$HaveSqlCmd,
        [bool]$UseSqlcmdFallback,
        [hashtable]$SqlParams
    )
    $allResults = @()
    $successCount = 0
    $totalCount = $SqlQueries.Count

    Write-Info "Executing $totalCount SQL queries individually with error handling..."

    foreach ($queryName in $SqlQueries.Keys) {
        try {
            Write-Info "Executing query: $queryName"
            $query = $SqlQueries[$queryName]

            if ($UseDotNetMethod) {
                # Use .NET SqlConnection (primary method)
                $results = Invoke-DotNetSqlFallback -ServerInstance $ServerInstance -Query $query -TrustServerCertificate
                if ($results) {
                    $allResults += $results
                    $successCount++
                    $rowCount = $results.Count
                    Write-Info "Query '$queryName' completed successfully ($rowCount rows)"
                }
                else {
                    Write-Info "Query '$queryName' completed with no results"
                    $successCount++
                }
            }
            elseif ($HaveSqlCmd) {
                $params = $SqlParams.Clone()
                $params.Query = $query
                $results = Invoke-Sqlcmd @params -As DataTable
                if ($results) {
                    # Convert DataTable to custom objects with Category column
                    foreach ($row in $results) {
                        $obj = [ordered]@{}
                        foreach ($column in $results.Columns) {
                            $obj[$column.ColumnName] = $row[$column.ColumnName]
                        }
                        $allResults += [pscustomobject]$obj
                    }
                    $successCount++
                    Write-Info "Query '$queryName' completed successfully ($($results.Rows.Count) rows)"
                }
                else {
                    Write-Info "Query '$queryName' completed with no results"
                    $successCount++
                }
            }
            elseif ($UseSqlcmdFallback) {
                # Use sqlcmd fallback
                $results = Invoke-SqlcmdFallback -ServerInstance $ServerInstance -Query $query -TrustServerCertificate
                if ($results) {
                    $allResults += $results
                    $successCount++
                    $rowCount = $results.Count
                    Write-Info "Query '$queryName' completed successfully ($rowCount rows)"
                }
                else {
                    Write-Info "Query '$queryName' completed with no results"
                    $successCount++
                }
            }

        }
        catch {
            Write-Warn "Query '$queryName' failed: $($_.Exception.Message)"
            # Continue with next query instead of failing entirely
        }
    }

    Write-Info "Completed SQL queries: $successCount/$totalCount successful"
    return $allResults
}

# Function to collect OS information directly from the operating system
function Get-OSInformation {
    param(
        [string]$ComputerName = $env:COMPUTERNAME
    )
    try {
        Write-Info "Collecting OS information from $ComputerName"

        # Get OS information
        $osInfo = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $ComputerName -ErrorAction Stop
        $computerInfo = Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName -ErrorAction Stop
        $processorInfo = Get-CimInstance -ClassName Win32_Processor -ComputerName $ComputerName -ErrorAction Stop | Select-Object -First 1

        # Calculate memory in GB
        $physicalMemoryGB = [math]::Round($computerInfo.TotalPhysicalMemory / 1GB, 2)
        $physicalMemoryKB = [math]::Round($computerInfo.TotalPhysicalMemory / 1KB, 0)

        # Get logical processor count
        $logicalProcessors = (Get-CimInstance -ClassName Win32_Processor -ComputerName $ComputerName | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum

        # Create standardized OS info object
        $osData = [PSCustomObject]@{
            ComputerName        = $computerInfo.Name
            PhysicalServerName  = $computerInfo.Name
            WindowsRelease      = $osInfo.Caption
            WindowsVersion      = $osInfo.Version
            WindowsServicePack  = $osInfo.ServicePackMajorVersion
            WindowsSKU          = $osInfo.OperatingSystemSKU
            OSLanguageVersion   = $osInfo.Locale
            LogicalCPUCount     = $logicalProcessors
            HyperthreadRatio    = if ($processorInfo.NumberOfCores -gt 0) { $processorInfo.NumberOfLogicalProcessors / $processorInfo.NumberOfCores } else { 1 }
            PhysicalMemoryKB    = $physicalMemoryKB
            PhysicalMemoryGB    = $physicalMemoryGB
            VirtualMemoryKB     = [math]::Round($osInfo.TotalVirtualMemorySize, 0)
            OSArchitecture      = $osInfo.OSArchitecture
            LastBootUpTime      = $osInfo.LastBootUpTime
            InstallDate         = $osInfo.InstallDate
            Manufacturer        = $computerInfo.Manufacturer
            Model               = $computerInfo.Model
            Domain              = $computerInfo.Domain
            TotalPhysicalMemory = $computerInfo.TotalPhysicalMemory
        }

        Write-Info "Successfully collected OS information from $ComputerName"
        return $osData

    }
    catch {
        Write-Warn "Failed to collect OS information from ${ComputerName}: $($_.Exception.Message)"
        return $null
    }
}

function Get-AGPrimaryServer {
    param(
        [string]$CurrentServer = $env:COMPUTERNAME,
        [string[]]$SqlInstances = @("$env:COMPUTERNAME", "localhost")
    )

    try {
        Write-Info "Checking if $CurrentServer is an AG secondary replica..."

        foreach ($instance in $SqlInstances) {
            try {
                # Try to query AG information to see if we're in a secondary role
                $agQuery = @"
SELECT
    ar.replica_server_name,
    ar.role_desc,
    ag.name AS ag_name,
    CASE WHEN ar.replica_server_name = @@SERVERNAME THEN 1 ELSE 0 END AS is_local
FROM sys.availability_groups ag
INNER JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
INNER JOIN sys.dm_hadr_availability_replica_states ars ON ar.replica_id = ars.replica_id
WHERE ars.is_local = 1;
"@

                $agInfo = Invoke-SqlcmdFallback -ServerInstance $instance -Query $agQuery

                if ($agInfo -and $agInfo.Count -gt 0) {
                    $localReplica = $agInfo[0]
                    Write-Info "Found local AG replica: $($localReplica.replica_server_name) with role: $($localReplica.role_desc)"

                    if ($localReplica.role_desc -eq "SECONDARY") {
                        Write-Info "Current server is AG SECONDARY. Looking for PRIMARY replica..."

                        # Query to find the primary replica
                        $primaryQuery = @"
SELECT
    ar.replica_server_name,
    ar.role_desc,
    ag.name AS ag_name
FROM sys.availability_groups ag
INNER JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
INNER JOIN sys.dm_hadr_availability_replica_states ars ON ar.replica_id = ars.replica_id
WHERE ars.role_desc = 'PRIMARY' AND ag.name = '$($localReplica.ag_name)';
"@

                        $primaryInfo = Invoke-SqlcmdFallback -ServerInstance $instance -Query $primaryQuery

                        if ($primaryInfo -and $primaryInfo.Count -gt 0) {
                            $primaryServer = $primaryInfo[0].replica_server_name
                            Write-Info "Found PRIMARY replica: $primaryServer for AG: $($localReplica.ag_name)"
                            return @{
                                IsPrimary     = $false
                                IsSecondary   = $true
                                PrimaryServer = $primaryServer
                                LocalServer   = $localReplica.replica_server_name
                                AGName        = $localReplica.ag_name
                                LocalRole     = "SECONDARY"
                            }
                        }
                    }
                    else {
                        Write-Info "Current server is AG PRIMARY."
                        return @{
                            IsPrimary     = $true
                            IsSecondary   = $false
                            PrimaryServer = $localReplica.replica_server_name
                            LocalServer   = $localReplica.replica_server_name
                            AGName        = $localReplica.ag_name
                            LocalRole     = "PRIMARY"
                        }
                    }
                }

            }
            catch {
                Write-Info "Could not query AG information from instance $instance - may not be in an AG or SQL connection failed"
                continue
            }
        }

        Write-Info "No AG configuration detected or not accessible - assuming standalone SQL instance"
        return @{
            IsPrimary     = $true
            IsSecondary   = $false
            PrimaryServer = $CurrentServer
            LocalServer   = $CurrentServer
            AGName        = $null
            LocalRole     = "STANDALONE"
        }

    }
    catch {
        Write-Warn "Failed to detect AG configuration: $($_.Exception.Message)"
        return @{
            IsPrimary     = $true
            IsSecondary   = $false
            PrimaryServer = $CurrentServer
            LocalServer   = $CurrentServer
            AGName        = $null
            LocalRole     = "UNKNOWN"
        }
    }
}

function Export-SqlClusterConfig (
    [string]$OutputPath,
    [string]$SqlInstance,
    [string]$RemoteServer
) {

    Write-Info "Starting SQL Server and Cluster configuration export..."
    Write-Info "Target output file: $OutputPath"

    # If RemoteServer is specified, execute the entire script on the remote server
    if ($RemoteServer) {
        Write-Info "Executing data collection remotely on $RemoteServer using PowerShell remoting..."

        $remoteCollectionScriptBlock = {
            param($IncludeVerboseResourceProps, $RemoteServerName, $ForceInstallRemote)
                    # Remote execution context - all code runs on target server
                    function Write-Info($msg) { Write-Host "[REMOTE-INFO] $msg" -ForegroundColor Cyan }
                    function Write-Warn($msg) { Write-Warning "[REMOTE] $msg" }
                    function Write-Err ($msg) { Write-Host "[REMOTE-ERROR] $msg" -ForegroundColor Red }

                    # Function to execute SQL queries using sqlcmd as fallback (remote version)
                    function Invoke-SqlcmdFallback {
                        param(
                            [string]$ServerInstance,
                            [string]$Query,
                            [switch]$TrustServerCertificate
                        )
                        try {
                            Write-Info "Using sqlcmd fallback for SQL Server queries on instance: $ServerInstance"

                            # Prepare sqlcmd arguments
                            $sqlcmdArgs = @(
                                '-S', $ServerInstance
                                '-E'  # Use Windows Authentication
                                '-Q', $Query
                                '-s', "`t"  # Tab delimiter
                                '-h', '1'  # Include headers for object parsing
                                '-W'  # Remove trailing spaces
                            )

                            if ($TrustServerCertificate) {
                                $sqlcmdArgs += '-C'  # Trust server certificate
                            }

                            # Execute sqlcmd
                            $result = & sqlcmd @sqlcmdArgs 2>&1

                            if ($LASTEXITCODE -ne 0) {
                                throw "sqlcmd failed with exit code $LASTEXITCODE. Output: $($result -join "`n")"
                            }

                            # Parse tab-delimited output into objects
                            $lines = $result | ForEach-Object { $_.ToString() } | Where-Object {
                                $_ -and $_.Trim() -ne '' -and
                                $_ -notmatch '^\(\d+\s+rows?\s+affected\)$' -and
                                $_ -notmatch '^Changed database context to'
                            }
                            if ($lines.Count -eq 0) {
                                return @()
                            }

                            # First line contains column headers
                            $rawHeaders = $lines[0] -split "`t"
                            $headerCounts = @{}
                            $headers = for ($h = 0; $h -lt $rawHeaders.Count; $h++) {
                                $name = [string]$rawHeaders[$h]
                                if ([string]::IsNullOrWhiteSpace($name)) {
                                    $name = "Column$($h + 1)"
                                }
                                $name = $name.Trim()
                                if ($headerCounts.ContainsKey($name)) {
                                    $headerCounts[$name]++
                                    $name = "${name}_$($headerCounts[$name])"
                                }
                                else {
                                    $headerCounts[$name] = 1
                                }
                                $name
                            }
                            $objects = @()

                            for ($i = 1; $i -lt $lines.Count; $i++) {
                                if ($lines[$i] -match '^\s*-+\s*(\t\s*-+\s*)*$') {
                                    continue
                                }
                                $values = $lines[$i] -split "`t"
                                $obj = [ordered]@{}

                                for ($j = 0; $j -lt $headers.Count; $j++) {
                                    $obj[$headers[$j]] = if ($j -lt $values.Count) { $values[$j] } else { $null }
                                }

                                $objects += [pscustomobject]$obj
                            }

                            return $objects

                        }
                        catch {
                            throw "sqlcmd fallback failed: $($_.Exception.Message)"
                        }
                    }

                    # Function to execute SQL queries using .NET SqlConnection as final fallback (remote version)
                    function Invoke-DotNetSqlFallback {
                        param(
                            [string]$ServerInstance,
                            [string]$Query,
                            [switch]$TrustServerCertificate
                        )
                        try {
                            Write-Info "Using .NET SqlConnection fallback for SQL Server queries on instance: $ServerInstance"

                            # Build connection string with enhanced remote connectivity options
                            $connectionString = "Server=$ServerInstance;Integrated Security=true;Connection Timeout=30;TrustServerCertificate=true;Encrypt=false;MultipleActiveResultSets=true;"
                            if ($TrustServerCertificate) {
                                # Already included above for remote connectivity
                            }

                            $results = @()
                            $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)

                            try {
                                # Add async timeout wrapper for connection.Open()
                                $openTask = $connection.OpenAsync()
                                $connectionSucceeded = $openTask.Wait(30000)  # 30 second timeout

                                if (-not $connectionSucceeded) {
                                    throw "Connection timeout: Could not establish SQL connection within 30 seconds"
                                }

                                $command = New-Object System.Data.SqlClient.SqlCommand($Query, $connection)
                                $command.CommandTimeout = 300  # 5 minutes

                                $reader = $command.ExecuteReader()

                                # Get column names
                                $columns = @()
                                for ($i = 0; $i -lt $reader.FieldCount; $i++) {
                                    $columns += $reader.GetName($i)
                                }

                                # Read data
                                while ($reader.Read()) {
                                    $row = [ordered]@{}
                                    for ($i = 0; $i -lt $columns.Count; $i++) {
                                        $value = if ($reader.IsDBNull($i)) { $null } else { $reader.GetValue($i) }
                                        $row[$columns[$i]] = $value
                                    }
                                    $results += [pscustomobject]$row
                                }

                                $reader.Close()
                            }
                            finally {
                                if ($connection.State -eq 'Open') {
                                    $connection.Close()
                                }
                                $connection.Dispose()
                            }

                            return $results

                        }
                        catch {
                            throw ".NET SqlConnection fallback failed: $($_.Exception.Message)"
                        }
                    }

                    # Function to collect OS information directly from the operating system (remote version)
                    function Get-OSInformation {
                        param(
                            [string]$ComputerName = $env:COMPUTERNAME
                        )
                        try {
                            Write-Info "Collecting OS information from $ComputerName"

                            # Get OS information
                            $osInfo = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $ComputerName -ErrorAction Stop
                            $computerInfo = Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName -ErrorAction Stop
                            $processorInfo = Get-CimInstance -ClassName Win32_Processor -ComputerName $ComputerName -ErrorAction Stop | Select-Object -First 1

                            # Calculate memory in GB
                            $physicalMemoryGB = [math]::Round($computerInfo.TotalPhysicalMemory / 1GB, 2)
                            $physicalMemoryKB = [math]::Round($computerInfo.TotalPhysicalMemory / 1KB, 0)

                            # Get logical processor count
                            $logicalProcessors = (Get-CimInstance -ClassName Win32_Processor -ComputerName $ComputerName | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum

                            # Create standardized OS info object
                            $osData = [PSCustomObject]@{
                                ComputerName        = $computerInfo.Name
                                PhysicalServerName  = $computerInfo.Name
                                WindowsRelease      = $osInfo.Caption
                                WindowsVersion      = $osInfo.Version
                                WindowsServicePack  = $osInfo.ServicePackMajorVersion
                                WindowsSKU          = $osInfo.OperatingSystemSKU
                                OSLanguageVersion   = $osInfo.Locale
                                LogicalCPUCount     = $logicalProcessors
                                HyperthreadRatio    = if ($processorInfo.NumberOfCores -gt 0) { $processorInfo.NumberOfLogicalProcessors / $processorInfo.NumberOfCores } else { 1 }
                                PhysicalMemoryKB    = $physicalMemoryKB
                                PhysicalMemoryGB    = $physicalMemoryGB
                                VirtualMemoryKB     = [math]::Round($osInfo.TotalVirtualMemorySize, 0)
                                OSArchitecture      = $osInfo.OSArchitecture
                                LastBootUpTime      = $osInfo.LastBootUpTime
                                InstallDate         = $osInfo.InstallDate
                                Manufacturer        = $computerInfo.Manufacturer
                                Model               = $computerInfo.Model
                                Domain              = $computerInfo.Domain
                                TotalPhysicalMemory = $computerInfo.TotalPhysicalMemory
                            }

                            Write-Info "Successfully collected OS information from $ComputerName"
                            return $osData

                        }
                        catch {
                            Write-Warn "Failed to collect OS information from ${ComputerName}: $($_.Exception.Message)"
                            return $null
                        }
                    }

                    # Function to install SQL PowerShell module locally from zip file (remote version)
                    function Install-SqlPSModuleLocal {
                        param(
                            [string]$ZipFilePath = ""
                        )
                        try {
                            Write-Info "Checking for SQL PowerShell module installation files on remote server..."

                            # On remote server, look for module files that may have been copied
                            $modulePaths = @(
                                (Join-Path $env:TEMP "SqlServerModule.zip"),
                                (Join-Path $env:TEMP "SQLPSModule.zip"),
                                (Join-Path (Get-Location).Path "SQLPSModule.zip")
                            )

                            $foundZip = $null
                            foreach ($path in $modulePaths) {
                                if (Test-Path $path) {
                                    $foundZip = $path
                                    break
                                }
                            }

                            if (-not $foundZip) {
                                Write-Warn "No SQL module zip file found on remote server. Remote installation method should be used instead."
                                return $false
                            }

                            Write-Info "Using SQL module zip file: $foundZip"

                            # Define target directory dynamically from module path
                            $moduleDirectory = ($env:PSModulePath -split ';' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -First 1)
                            if ([string]::IsNullOrWhiteSpace($moduleDirectory)) {
                                $moduleDirectory = Join-Path $HOME "Documents\WindowsPowerShell\Modules"
                            }
                            if (-not (Test-Path $moduleDirectory)) {
                                New-Item -Path $moduleDirectory -ItemType Directory -Force | Out-Null
                            }

                            # Extract the zip file
                            Write-Info "Extracting SQL PowerShell module to $moduleDirectory..."
                            if ($PSVersionTable.PSVersion.Major -ge 5) {
                                Expand-Archive -Path $foundZip -DestinationPath $moduleDirectory -Force
                            }
                            else {
                                # Fallback for older PowerShell versions
                                $shell = New-Object -ComObject Shell.Application
                                $zip = $shell.NameSpace($foundZip)
                                $dest = $shell.NameSpace($moduleDirectory)
                                $dest.CopyHere($zip.Items(), 4)
                            }

                            Write-Info "SQL PowerShell module installation completed on remote server"
                            return $true
                        }
                        catch {
                            Write-Err "Failed to install SQL PowerShell module on remote server: $($_.Exception.Message)"
                            return $false
                        }
                    }

                    $Now = Get-Date
                    $Result = [ordered]@{
                        Metadata = [ordered]@{
                            CollectedOnUtc   = ($Now.ToUniversalTime().ToString("o"))
                            CollectedOnLocal = $Now.ToString("o")
                            ComputerName     = $env:COMPUTERNAME
                            ScriptName       = "Export-SqlClusterConfig.ps1"
                            ScriptVersion    = "1.0.1"
                            User             = "$($env:USERDOMAIN)\$($env:USERNAME)"
                            ExecutionMode    = "Remote"
                        }
                        Cluster  = $null
                        Sql      = @()
                        OSInfo   = $null
                        Notes    = @()
                        Warnings = @()
                        Errors   = @()
                    }

                    # Collect OS information directly from the operating system (remote)
                    Write-Info "Collecting OS information independently of SQL Server..."
                    $Result.OSInfo = Get-OSInformation -ComputerName $env:COMPUTERNAME

                    # --- FailoverClusters module (on remote server) ---
                    try {
                        Import-Module FailoverClusters -ErrorAction Stop
                        Write-Info "FailoverClusters module loaded on remote server."
                    }
                    catch {
                        $msg = "FailoverClusters module not found on remote server. Skipping cluster data collection - only SQL data will be collected."
                        Write-Warn $msg
                        $Result.Warnings += $msg
                    }

                    # --- Connect to local cluster on remote server ---
                    $clusterObj = $null
                    if (Get-Module FailoverClusters) {
                        try {
                            $clusterObj = Get-Cluster -ErrorAction Stop
                            Write-Info ("Connected to local cluster: {0}" -f $clusterObj.Name)
                        }
                        catch {
                            $err = "Unable to connect to local cluster: $($_.Exception.Message)"
                            Write-Err $err
                            $Result.Errors += $err
                        }
                    }

                    # --- Auto-detect local SQL instances on remote server ---
                    $SqlInstance = @()
                    Write-Info "Auto-detecting local SQL instances on remote server..."

                    try {
                        # Method 1: Check registry for installed instances
                        $regPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"
                        if (Test-Path $regPath) {
                            $instances = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue
                            if ($instances) {
                                foreach ($prop in $instances.PSObject.Properties) {
                                    if ($prop.Name -notin @("PSPath", "PSParentPath", "PSChildName", "PSDrive", "PSProvider")) {
                                        if ($prop.Name -eq "MSSQLSERVER") {
                                            $SqlInstance += $RemoteServerName
                                        }
                                        else {
                                            $SqlInstance += "$RemoteServerName\$($prop.Name)"
                                        }
                                    }
                                }
                            }
                        }

                        # Method 2: Check for running SQL Server services
                        $sqlServices = Get-Service -Name "MSSQL*" -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Running" }
                        foreach ($service in $sqlServices) {
                            if ($service.Name -eq "MSSQLSERVER") {
                                if ("localhost" -notin $SqlInstance) {
                                    $SqlInstance += "localhost"
                                }
                            }
                            elseif ($service.Name -like "MSSQL`$*") {
                                $instanceName = $service.Name.Replace("MSSQL`$", "")
                                $fullInstanceName = "localhost\$instanceName"
                                if ($fullInstanceName -notin $SqlInstance) {
                                    $SqlInstance += $fullInstanceName
                                }
                            }
                        }

                        if ($SqlInstance.Count -gt 0) {
                            # Remove duplicates - prefer named server over localhost
                            $deduplicatedInstances = @()
                            $hasNamedInstance = $false
                            $namedServer = $env:COMPUTERNAME

                            # Check if we have a named server instance (not localhost)
                            foreach ($inst in $SqlInstance) {
                                if ($inst -ne "localhost" -and $inst -notlike "localhost\*") {
                                    $hasNamedInstance = $true
                                    $deduplicatedInstances += $inst
                                }
                            }

                            # If we don't have named instances, keep localhost entries
                            if (-not $hasNamedInstance) {
                                $deduplicatedInstances = $SqlInstance
                            }
                            else {
                                # Also add named instances of localhost if they don't conflict
                                foreach ($inst in $SqlInstance) {
                                    if ($inst -like "localhost\*") {
                                        $instancePart = $inst.Replace("localhost\", "")
                                        $namedEquivalent = "$namedServer\$instancePart"
                                        if ($namedEquivalent -notin $deduplicatedInstances) {
                                            $deduplicatedInstances += $inst
                                        }
                                    }
                                }
                            }

                            $SqlInstance = $deduplicatedInstances
                            Write-Info "Detected local SQL instances: $($SqlInstance -join ', ')"
                        }
                        else {
                            Write-Info "No local SQL instances detected."
                        }
                    }
                    catch {
                        $warn = "Failed to detect local SQL instances: $($_.Exception.Message)"
                        Write-Warn $warn
                        $Result.Warnings += $warn
                    }

                    # --- WSFC collection on remote server ---
                    if ($clusterObj) {
                        try {
                            # Cluster parameters
                            $clusterParams = @()
                            try {
                                Write-Info "Collecting cluster parameters for cluster: $($clusterObj.Name)"
                                # Use cluster object directly for remote execution
                                try {
                                    $clusterParams = (Get-ClusterParameter -InputObject $clusterObj | Sort-Object Name) | Where-Object { $_.Name -notin @('SharedVolumeSecurityDescriptor', 'SecurityDescriptor') } | ForEach-Object {
                                        [ordered]@{ Name = $_.Name; Value = $_.Value }
                                    }
                                }
                                catch {
                                    Write-Warn "Failed to collect cluster parameters: $($_.Exception.Message)"
                                    $clusterParams = @()
                                }
                                Write-Info "Successfully collected $($clusterParams.Count) cluster parameters"
                            }
                            catch {
                                $warningMsg = "Failed to read cluster parameters: $($_.Exception.Message)"
                                Write-Warn $warningMsg
                                $Result.Warnings += $warningMsg
                            }

                            # Quorum
                            $quorum = [ordered]@{}
                            try {
                                $q = Get-ClusterQuorum
                                $quorum.Type = $q.QuorumType
                                $quorum.Resource = $q.QuorumResource
                                if ($q.PSObject.Properties.Name -contains 'WitnessShare') { $quorum.WitnessShare = $q.WitnessShare }
                            }
                            catch { $Result.Warnings += "Failed to read quorum info: $($_.Exception.Message)" }

                            # Nodes
                            $nodes = @()
                            try {
                                $nodes = Get-ClusterNode | ForEach-Object {
                                    $n = $_
                                    [ordered]@{
                                        Name          = $n.Name
                                        State         = $n.State
                                        ID            = $n.Id
                                        NodeWeight    = $n.NodeWeight
                                        DynamicWeight = $n.DynamicWeight
                                    }
                                }
                            }
                            catch { $Result.Warnings += "Failed to read nodes: $($_.Exception.Message)" }

                            # Networks
                            $networks = @()
                            try {
                                $networks = Get-ClusterNetwork | ForEach-Object {
                                    $nw = $_
                                    [ordered]@{
                                        Name        = $nw.Name
                                        Role        = $nw.Role
                                        State       = $nw.State
                                        Metric      = $nw.Metric
                                        AutoMetric  = $nw.AutoMetric
                                        Address     = $nw.Address
                                        AddressMask = $nw.AddressMask
                                        Description = $nw.Description
                                    }
                                }
                            }
                            catch { $Result.Warnings += "Failed to read networks: $($_.Exception.Message)" }

                            # Groups & Resources
                            $groups = @()
                            try {
                                $groups = Get-ClusterGroup | ForEach-Object {
                                    $g = $_
                                    $resList = @()
                                    try {
                                        $resList = Get-ClusterResource | Where-Object { $_.OwnerGroup -eq $g.Name } | ForEach-Object {
                                            $r = $_
                                            $params = @()
                                            $privProps = @()

                                            if ($IncludeVerboseResourceProps) {
                                                try {
                                                    $params = (Get-ClusterParameter -InputObject $r -ErrorAction Stop) |
                                                    Where-Object { $_.Name -notin @('SharedVolumeSecurityDescriptor', 'SecurityDescriptor') } |
                                                    Sort-Object Name | ForEach-Object {
                                                        [ordered]@{ Name = $_.Name; Value = $_.Value }
                                                    }
                                                }
                                                catch {
                                                    $Result.Warnings += "Failed to read parameters for resource '$($r.Name)': $($_.Exception.Message)"
                                                }
                                            }

                                            # Dependencies
                                            $deps = @()
                                            try {
                                                $depObjs = Get-ClusterResourceDependency -Resource $r -ErrorAction SilentlyContinue
                                                if ($depObjs) {
                                                    $deps = $depObjs | ForEach-Object {
                                                        [string]$_.DependencyExpression
                                                    }
                                                }
                                            }
                                            catch { }

                                            [ordered]@{
                                                Name              = $r.Name
                                                Type              = $r.ResourceType
                                                State             = $r.State
                                                OwnerGroup        = $r.OwnerGroup
                                                OwnerNode         = $r.OwnerNode
                                                IsCore            = $r.CoreResource
                                                PersistentState   = $r.PersistentState
                                                Parameters        = $params
                                                PrivateProperties = $privProps
                                                Dependencies      = $deps
                                            }
                                        }
                                    }
                                    catch {
                                        $Result.Warnings += "Failed to read resources for group '$($g.Name)': $($_.Exception.Message)"
                                    }

                                    [ordered]@{
                                        Name        = $g.Name
                                        Id          = $g.Id
                                        State       = $g.State
                                        OwnerNode   = $g.OwnerNode
                                        IsCoreGroup = $g.CoreGroup
                                        Resources   = $resList
                                    }
                                }
                            }
                            catch {
                                $Result.Warnings += "Failed to read groups/resources: $($_.Exception.Message)"
                            }

                            # Storage
                            $storage = @()
                            try {
                                $storage = Get-ClusterResource |
                                Where-Object { $_.ResourceType -match 'Disk' } |
                                ForEach-Object {
                                    [ordered]@{
                                        Name       = $_.Name
                                        Type       = $_.ResourceType
                                        State      = $_.State
                                        OwnerGroup = $_.OwnerGroup
                                        OwnerNode  = $_.OwnerNode
                                    }
                                }
                            }
                            catch { $Result.Warnings += "Failed to enumerate storage resources: $($_.Exception.Message)" }

                            # AG Listener Configuration (detailed listener port and IP information) - Remote
                            $agListenerConfig = [ordered]@{}
                            try {
                                Write-Info "Collecting AG Listener configuration details..."

                                # 1) Pull resources first (avoid piping Get-ClusterResource directly)
                                $all = Get-ClusterResource -ErrorAction Stop

                                # 2) Find the AG resource robustly
                                $agRes = $all | Where-Object { $_.ResourceType -eq 'SQL Server Availability Group' } | Select-Object -First 1
                                if (-not $agRes) {
                                    # Some builds/locales return a slightly different type string; match loosely
                                    $agRes = $all | Where-Object { ($_.ResourceType -like 'SQL Server Availability Group*') -or ($_.Name -match 'AG|Availability') } | Select-Object -First 1
                                }

                                if ($agRes) {
                                    # 3) Use the AG's owner group to find the listener network name
                                    $agGroup = $agRes.OwnerGroup
                                    $listenerNN = $all | Where-Object { $_.OwnerGroup -eq $agGroup -and $_.ResourceType -eq 'Network Name' } | Select-Object -First 1

                                    if ($listenerNN) {
                                        # 4) Get the dependent IP resource (where ProbePort lives)
                                        $listenerIp = $null
                                        try {
                                            $listenerIp = (Get-ClusterResourceDependency -Resource $listenerNN.Name -ErrorAction SilentlyContinue) |
                                            Where-Object ResourceType -eq 'IP Address' | Select-Object -First 1
                                        }
                                        catch {
                                            # Fallback: find IP in same group
                                            $listenerIp = $all | Where-Object { $_.OwnerGroup -eq $agGroup -and $_.ResourceType -eq 'IP Address' } | Select-Object -First 1
                                        }

                                        if (-not $listenerIp) {
                                            $listenerIp = $all | Where-Object { $_.OwnerGroup -eq $agGroup -and $_.ResourceType -eq 'IP Address' } | Select-Object -First 1
                                        }

                                        if ($listenerIp) {
                                            # 5) Get the key values
                                            $dns = $null
                                            $addr = $null
                                            $probe = $null

                                            try {
                                                $dns = (Get-ClusterParameter -InputObject $listenerNN | Where-Object Name -eq 'DnsName').Value
                                            }
                                            catch { $Result.Warnings += "Failed to get listener DNS name: $($_.Exception.Message)" }

                                            try {
                                                $ipParams = Get-ClusterParameter -InputObject $listenerIp
                                                $addr = ($ipParams | Where-Object Name -eq 'Address').Value
                                                $probe = ($ipParams | Where-Object Name -eq 'ProbePort').Value
                                            }
                                            catch { $Result.Warnings += "Failed to get listener IP parameters: $($_.Exception.Message)" }

                                            $agListenerConfig = [ordered]@{
                                                AGResourceName         = $agRes.Name
                                                AGGroupName            = $agGroup.Name
                                                ListenerResourceName   = $listenerNN.Name
                                                ListenerDNSName        = $dns
                                                ListenerIPResourceName = $listenerIp.Name
                                                ListenerIPAddress      = $addr
                                                ListenerProbePort      = $probe
                                                AGResourceState        = $agRes.State
                                                ListenerResourceState  = $listenerNN.State
                                                IPResourceState        = $listenerIp.State
                                            }

                                            Write-Info "Found AG Listener: $dns at $addr with ProbePort $probe"
                                        }
                                        else {
                                            $Result.Warnings += "No IP Address resource found for AG listener '$($listenerNN.Name)'"
                                        }
                                    }
                                    else {
                                        $Result.Warnings += "No Network Name (listener) found in AG group '$($agGroup.Name)'"
                                    }
                                }
                                else {
                                    Write-Info "No SQL Server Availability Group resource found in cluster"
                                }

                            }
                            catch {
                                $Result.Warnings += "Failed to collect AG Listener configuration: $($_.Exception.Message)"
                            }

                            # --- Enhanced Cluster Listener Detection ---
                            try {
                                Write-Info "Collecting comprehensive cluster listener information..."
                                $clusterListeners = @()

                                # Get all Network Name resources (potential listeners)
                                $networkNameResources = $all | Where-Object ResourceType -eq 'Network Name'

                                foreach ($nnRes in $networkNameResources) {
                                    try {
                                        $listenerInfo = [ordered]@{
                                            ResourceName    = $nnRes.Name
                                            ResourceType    = $nnRes.ResourceType
                                            OwnerGroup      = $nnRes.OwnerGroup
                                            State           = $nnRes.State
                                            DnsName         = $null
                                            IPAddress       = $null
                                            ProbePort       = $null
                                            AssociatedPorts = @()
                                        }

                                        # Get DNS name
                                        try {
                                            $dnsParam = Get-ClusterParameter -InputObject $nnRes | Where-Object Name -eq 'DnsName'
                                            $listenerInfo.DnsName = $dnsParam.Value
                                        }
                                        catch { }

                                        # Find associated IP Address resources
                                        $ipResources = @()
                                        try {
                                            # Get dependencies
                                            $ipResources = (Get-ClusterResourceDependency -Resource $nnRes.Name -ErrorAction SilentlyContinue) |
                                            Where-Object ResourceType -eq 'IP Address'
                                        }
                                        catch { }

                                        # Fallback: find IP resources in the same group
                                        if (-not $ipResources) {
                                            $ipResources = $all | Where-Object { $_.OwnerGroup -eq $nnRes.OwnerGroup -and $_.ResourceType -eq 'IP Address' }
                                        }

                                        foreach ($ipRes in $ipResources) {
                                            try {
                                                $ipParams = Get-ClusterParameter -InputObject $ipRes
                                                $address = ($ipParams | Where-Object Name -eq 'Address').Value
                                                $probePort = ($ipParams | Where-Object Name -eq 'ProbePort').Value

                                                if ($address) {
                                                    $listenerInfo.IPAddress = $address
                                                }
                                                if ($probePort) {
                                                    $listenerInfo.ProbePort = $probePort
                                                    $listenerInfo.AssociatedPorts += "ProbePort: $probePort"
                                                }

                                                # Check for any other port-related parameters
                                                $portParams = $ipParams | Where-Object { $_.Name -like '*Port*' -or $_.Name -like '*port*' }
                                                foreach ($portParam in $portParams) {
                                                    if ($portParam.Name -ne 'ProbePort' -and $portParam.Value) {
                                                        $listenerInfo.AssociatedPorts += "$($portParam.Name): $($portParam.Value)"
                                                    }
                                                }
                                            }
                                            catch {
                                                $Result.Warnings += "Failed to get IP parameters for $($ipRes.Name): $($_.Exception.Message)"
                                            }
                                        }

                                        $clusterListeners += $listenerInfo

                                        if ($listenerInfo.ProbePort) {
                                            Write-Info "Found cluster listener: $($listenerInfo.DnsName) with ProbePort $($listenerInfo.ProbePort)"
                                        }
                                    }
                                    catch {
                                        $Result.Warnings += "Failed to process Network Name resource $($nnRes.Name): $($_.Exception.Message)"
                                    }
                                }

                            }
                            catch {
                                $Result.Warnings += "Failed to collect comprehensive cluster listener information: $($_.Exception.Message)"
                            }

                            $dnsSuffix = $null
                            if ($clusterObj.PSObject.Properties.Name -contains 'DNSDomain') { $dnsSuffix = $clusterObj.DNSDomain }

                            $Result.Cluster = [ordered]@{
                                Name             = $clusterObj.Name
                                Description      = $clusterObj.Description
                                Id               = $clusterObj.Id
                                DnsSuffix        = $dnsSuffix
                                Quorum           = $quorum
                                Parameters       = $clusterParams
                                Nodes            = $nodes
                                Networks         = $networks
                                Groups           = $groups
                                Storage          = $storage
                                AGListenerConfig = $agListenerConfig
                                ClusterListeners = $clusterListeners
                            }

                        }
                        catch {
                            $err = "Unhandled error while collecting WSFC details: $($_.Exception.Message)"
                            Write-Err $err
                            $Result.Errors += $err
                        }
                    }

                    # Include the cluster data collection code here (truncated for space)
                    # ... [Rest of cluster data collection logic] ...
                    $haveSqlCmd = $false
                    $useSqlcmdFallback = $false
                    $useDotNetFallback = $false

                    # Try to import SQL module with error handling
                    try {
                        Import-Module -Name SqlServer -Force -ErrorAction Stop
                        Write-Info "SQL Server module loaded successfully on remote server."
                        $haveSqlCmd = $true
                    }
                    catch {
                        try {
                            Import-Module -Name SQLPS -Force -ErrorAction Stop
                            Write-Info "SQLPS module loaded successfully on remote server."
                            $haveSqlCmd = $true
                        }
                        catch {
                            if (-not $ForceInstallRemote) {
                                $sqlModuleWarn = "Failed to load SQL module by name. ForceInstall is not set, so module installation is skipped."
                                Write-Warn $sqlModuleWarn
                                $Result.Warnings += $sqlModuleWarn
                            }
                            else {
                                Write-Warn "Failed to load SQL module by name, attempting to install from zip file because ForceInstall is set..."
                                if (Install-SqlPSModuleLocal) {
                                    try {
                                        Import-Module -Name SqlServer -Force -ErrorAction Stop
                                        Write-Info "SQL Server module loaded successfully after installation."
                                        $haveSqlCmd = $true
                                    }
                                    catch {
                                        try {
                                            Import-Module -Name SQLPS -Force -ErrorAction Stop
                                            Write-Info "SQLPS module loaded successfully after installation."
                                            $haveSqlCmd = $true
                                        }
                                        catch {
                                            $sqlModuleWarn = "Failed to load SQL module even after installation: $($_.Exception.Message)"
                                            Write-Warn $sqlModuleWarn
                                            $Result.Warnings += $sqlModuleWarn
                                        }
                                    }
                                }
                                else {
                                    $sqlModuleWarn = "Failed to load SQL module and installation failed: $($_.Exception.Message)"
                                    Write-Warn $sqlModuleWarn
                                    $Result.Warnings += $sqlModuleWarn
                                }
                            }
                        }
                    }

                    # If SQL module could not be loaded, fall back to sqlcmd or .NET SqlClient
                    if (-not $haveSqlCmd) {
                        try {
                            $null = Get-Command sqlcmd -ErrorAction Stop
                            $useSqlcmdFallback = $true
                            Write-Info "Using sqlcmd fallback on remote server."
                        }
                        catch {
                            try {
                                [System.Data.SqlClient.SqlConnection] | Out-Null
                                $useDotNetFallback = $true
                                Write-Info "Using .NET SqlConnection fallback on remote server."
                            }
                            catch {
                                $warn = "No SQL query methods available on remote server (SqlServer/SQLPS module, sqlcmd, or .NET SqlClient). SQL queries will be skipped, but non-SQL data has been collected."
                                Write-Warn $warn
                                $Result.Warnings += $warn
                            }
                        }
                    }
                    # --- SQL AG collection on remote server ---
                    <# if ($SqlInstance -and $SqlInstance.Count -gt 0) {
                    $haveSqlCmd = $false
                    $useSqlcmdFallback = $false
                    $useDotNetFallback = $false

                    try {

                        # try the legacy name
                        try {
                            Import-Module -Name SqlServer -Force -ErrorAction Stop
                            write-info "SQLPS module available on remote server."
                        }
                        catch {
                            Write-Warn "Failed to load PowerShell Module, attempting to install from zip file..."
                            if (Install-SqlPSModuleLocal) {
                                try {
                                    Import-Module -Name SqlServer -Force -ErrorAction Stop
                                    write-info "SQLPS module loaded successfully after installation."
                                }
                                catch {
                                    write-host "Failed to load Powershell Module even after installation. Error: $_"
                                    Throw "SQL PowerShell module not available."
                                }
                            } else {
                                write-host "Failed to load Powershell Module and installation failed. Error: $_"
                                Throw "SQL PowerShell module not available."
                            }
                        }

                        $haveSqlCmd = $true
                        Write-Info ".NET SqlConnection not available, using SqlServer module fallback."
                    }
                    catch {
                        # Try sqlcmd fallback
                        try {
                            $null = Get-Command sqlcmd -ErrorAction Stop
                            $useSqlcmdFallback = $true
                            Write-Info "SqlServer module not available on remote server, using sqlcmd fallback."
                        }
                        catch {
                            # Try .NET SqlConnection fallback
                            try {
                                [System.Data.SqlClient.SqlConnection] | Out-Null
                                $useDotNetFallback = $true
                                Write-Info "Neither SqlServer module nor sqlcmd available on remote server, using .NET SqlConnection fallback."
                            }
                            catch {
                                $warn = "No SQL query methods available on remote server (SqlServer module, sqlcmd, or .NET SqlConnection); skipping SQL AG query."
                                Write-Warn $warn
                                $Result.Warnings += $warn
                            }
                        }
                    }
                } #>
                    if ($haveSqlCmd -or $useSqlcmdFallback -or $useDotNetFallback) {
                        # Execute SQL data collection
                        Write-Info "Proceeding with comprehensive SQL migration validation data collection..."
                        try {
                            $tsql = @"
SET NOCOUNT ON;

-- =====================================================================
-- SQL SERVER MIGRATION VALIDATION DATA COLLECTION
-- =====================================================================

-- 1. SERVER INFORMATION
SELECT
    'ServerInfo' AS Category,
    GETDATE() AS CollectionTime,
    @@SERVERNAME AS ServerName,
    SERVERPROPERTY('ServerName') AS ServerName_Property,
    SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS PhysicalServerName,
    SERVERPROPERTY('MachineName') AS MachineName,
    SERVERPROPERTY('InstanceName') AS InstanceName,
    SERVERPROPERTY('ProductVersion') AS ProductVersion,
    SERVERPROPERTY('ProductLevel') AS ProductLevel,
    SERVERPROPERTY('Edition') AS Edition,
    SERVERPROPERTY('EngineEdition') AS EngineEdition,
    SERVERPROPERTY('Collation') AS ServerCollation,
    SERVERPROPERTY('IsClustered') AS IsClustered,
    SERVERPROPERTY('IsHadrEnabled') AS IsHadrEnabled,
    SERVERPROPERTY('HadrManagerStatus') AS HadrManagerStatus,
    -- Add OS and system information
    (SELECT windows_release FROM sys.dm_os_windows_info) AS WindowsRelease,
    (SELECT windows_service_pack_level FROM sys.dm_os_windows_info) AS WindowsServicePack,
    (SELECT windows_sku FROM sys.dm_os_windows_info) AS WindowsSKU,
    (SELECT os_language_version FROM sys.dm_os_windows_info) AS OSLanguageVersion,
    (SELECT cpu_count FROM sys.dm_os_sys_info) AS LogicalCPUCount,
    (SELECT hyperthread_ratio FROM sys.dm_os_sys_info) AS HyperthreadRatio,
    (SELECT physical_memory_kb FROM sys.dm_os_sys_info) AS PhysicalMemoryKB,
    (SELECT virtual_memory_kb FROM sys.dm_os_sys_info) AS VirtualMemoryKB,
    (SELECT sqlserver_start_time FROM sys.dm_os_sys_info) AS SQLServerStartTime;

-- 2. DATABASE INVENTORY
SELECT
    'DatabaseInventory' AS Category,
    d.database_id,
    d.name AS DatabaseName,
    d.collation_name,
    d.state_desc AS DatabaseState,
    d.recovery_model_desc,
    d.compatibility_level,
    d.is_auto_close_on,
    d.is_auto_shrink_on,
    d.is_auto_create_stats_on,
    d.is_auto_update_stats_on,
    d.is_auto_update_stats_async_on,
    d.is_trustworthy_on,
    d.is_db_chaining_on,
    d.is_broker_enabled,
    d.is_encrypted,
    d.is_read_only,
    d.user_access_desc,
    d.create_date,
    d.is_published,
    d.is_subscribed,
    d.is_merge_published,
    d.is_distributor,
    d.snapshot_isolation_state_desc,
    d.is_read_committed_snapshot_on,
    CASE d.page_verify_option
        WHEN 0 THEN 'NONE'
        WHEN 1 THEN 'TORN_PAGE_DETECTION'
        WHEN 2 THEN 'CHECKSUM'
        ELSE 'UNKNOWN'
    END AS page_verify_option_desc
FROM sys.databases d
WHERE d.database_id > 4 OR d.name IN ('master', 'model', 'msdb', 'tempdb');

-- 3. DATABASE FILES
SELECT
    'DatabaseFiles' AS Category,
    DB_NAME(f.database_id) AS DatabaseName,
    f.file_id,
    f.name AS LogicalName,
    f.physical_name AS PhysicalPath,
    f.type_desc AS FileType,
    f.size * 8 / 1024 AS SizeMB,
    CASE WHEN f.max_size = -1 THEN 'Unlimited'
         WHEN f.max_size = 268435456 THEN 'Unlimited'
         ELSE CAST(f.max_size * 8 / 1024 AS VARCHAR(20)) + ' MB'
    END AS MaxSizeMB,
    CASE WHEN f.is_percent_growth = 1
         THEN CAST(f.growth AS VARCHAR(10)) + '%'
         ELSE CAST(f.growth * 8 / 1024 AS VARCHAR(10)) + ' MB'
    END AS GrowthSetting,
    f.state_desc AS FileState,
    fg.name AS FileGroupName
FROM sys.master_files f
LEFT JOIN sys.filegroups fg ON f.data_space_id = fg.data_space_id
ORDER BY f.database_id, f.file_id;

-- 4. DATABASE SIZES
SELECT
    'DatabaseSizes' AS Category,
    DB_NAME(database_id) AS DatabaseName,
    SUM(CASE WHEN type_desc = 'ROWS' THEN size * 8 / 1024 ELSE 0 END) AS DataSizeMB,
    SUM(CASE WHEN type_desc = 'LOG' THEN size * 8 / 1024 ELSE 0 END) AS LogSizeMB,
    SUM(size * 8 / 1024) AS TotalSizeMB
FROM sys.master_files
WHERE database_id > 4 OR database_id IN (1,2,3,4)
GROUP BY database_id
ORDER BY TotalSizeMB DESC;

-- 5. SERVER CONFIGURATION
SELECT
    'ServerConfiguration' AS Category,
    c.name AS ConfigName,
    c.value AS ConfigValue,
    c.value_in_use AS ValueInUse,
    c.description,
    c.is_dynamic,
    c.is_advanced
FROM sys.configurations c
ORDER BY c.name;

-- 6. SQL SERVER AGENT JOBS WITH EXECUTION HISTORY
IF (HAS_PERMS_BY_NAME('msdb.dbo.sysjobs', 'OBJECT', 'SELECT') = 1 AND HAS_PERMS_BY_NAME('msdb.dbo.sysjobservers', 'OBJECT', 'SELECT') = 1)
BEGIN
    SELECT
        'AgentJobs' AS Category,
        j.job_id,
        j.name AS JobName,
        j.enabled,
        j.description,
        j.date_created,
        j.date_modified,
        CASE j.notify_level_eventlog
            WHEN 0 THEN 'Never'
            WHEN 1 THEN 'On Success'
            WHEN 2 THEN 'On Failure'
            WHEN 3 THEN 'Always'
        END AS NotifyLevel,
        j.delete_level,
        -- Last execution information
        jh.last_run_date,
        jh.last_run_time,
        CASE jh.last_run_outcome
            WHEN 0 THEN 'Failed'
            WHEN 1 THEN 'Succeeded'
            WHEN 2 THEN 'Retry'
            WHEN 3 THEN 'Canceled'
            WHEN 5 THEN 'Unknown'
            ELSE 'Never Run'
        END AS LastRunStatus,
        jh.last_run_duration,
        -- Convert run_date/run_time to readable datetime
        CASE
            WHEN jh.last_run_date > 0 AND jh.last_run_time >= 0 THEN
                CONVERT(datetime,
                    CAST(jh.last_run_date AS varchar(8)) + ' ' +
                    CASE
                        WHEN LEN(CAST(jh.last_run_time AS varchar(6))) = 1 THEN '00:00:0' + CAST(jh.last_run_time AS varchar(6))
                        WHEN LEN(CAST(jh.last_run_time AS varchar(6))) = 2 THEN '00:00:' + CAST(jh.last_run_time AS varchar(6))
                        WHEN LEN(CAST(jh.last_run_time AS varchar(6))) = 3 THEN '00:0' + LEFT(CAST(jh.last_run_time AS varchar(6)), 1) + ':' + RIGHT(CAST(jh.last_run_time AS varchar(6)), 2)
                        WHEN LEN(CAST(jh.last_run_time AS varchar(6))) = 4 THEN '00:' + LEFT(CAST(jh.last_run_time AS varchar(6)), 2) + ':' + RIGHT(CAST(jh.last_run_time AS varchar(6)), 2)
                        WHEN LEN(CAST(jh.last_run_time AS varchar(6))) = 5 THEN '0' + LEFT(CAST(jh.last_run_time AS varchar(6)), 1) + ':' + SUBSTRING(CAST(jh.last_run_time AS varchar(6)), 2, 2) + ':' + RIGHT(CAST(jh.last_run_time AS varchar(6)), 2)
                        WHEN LEN(CAST(jh.last_run_time AS varchar(6))) = 6 THEN LEFT(CAST(jh.last_run_time AS varchar(6)), 2) + ':' + SUBSTRING(CAST(jh.last_run_time AS varchar(6)), 3, 2) + ':' + RIGHT(CAST(jh.last_run_time AS varchar(6)), 2)
                    END, 120)
            ELSE NULL
        END AS LastRunDateTime
    FROM msdb.dbo.sysjobs j
    LEFT JOIN (
        SELECT
            job_id,
            last_run_date,
            last_run_time,
            last_run_outcome,
            last_run_duration,
            ROW_NUMBER() OVER (PARTITION BY job_id ORDER BY last_run_date DESC, last_run_time DESC) AS rn
        FROM msdb.dbo.sysjobservers
    ) jh ON j.job_id = jh.job_id AND jh.rn = 1
    ORDER BY j.name;
END
ELSE
BEGIN
    SELECT TOP 0
        'AgentJobs' AS Category,
        CAST(NULL AS uniqueidentifier) AS job_id,
        CAST(NULL AS nvarchar(128)) AS JobName,
        CAST(NULL AS tinyint) AS enabled,
        CAST(NULL AS nvarchar(512)) AS description,
        CAST(NULL AS datetime) AS date_created,
        CAST(NULL AS datetime) AS date_modified,
        CAST(NULL AS nvarchar(20)) AS NotifyLevel,
        CAST(NULL AS tinyint) AS delete_level,
        CAST(NULL AS int) AS last_run_date,
        CAST(NULL AS int) AS last_run_time,
        CAST(NULL AS nvarchar(20)) AS LastRunStatus,
        CAST(NULL AS int) AS last_run_duration,
        CAST(NULL AS datetime) AS LastRunDateTime;
END;

-- 7. BACKUP HISTORY SUMMARY (Last 90 days)
IF (HAS_PERMS_BY_NAME('msdb.dbo.backupset', 'OBJECT', 'SELECT') = 1 AND HAS_PERMS_BY_NAME('msdb.dbo.backupmediafamily', 'OBJECT', 'SELECT') = 1)
BEGIN
    SELECT
        'BackupHistory' AS Category,
        d.name AS DatabaseName,
        bs.type AS BackupType,
        CASE bs.type
            WHEN 'D' THEN 'Full'
            WHEN 'I' THEN 'Differential'
            WHEN 'L' THEN 'Log'
            WHEN 'F' THEN 'File/Filegroup'
            WHEN 'G' THEN 'Differential File'
            WHEN 'P' THEN 'Partial'
            WHEN 'Q' THEN 'Differential Partial'
        END AS BackupTypeDesc,
        bs.backup_start_date,
        bs.backup_finish_date,
        bs.backup_size / 1024 / 1024 AS BackupSizeMB,
        bs.compressed_backup_size / 1024 / 1024 AS CompressedSizeMB,
        bmf.physical_device_name
    FROM msdb.dbo.backupset bs
    INNER JOIN sys.databases d ON bs.database_name = d.name
    INNER JOIN msdb.dbo.backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
    WHERE bs.backup_start_date >= DATEADD(day, -90, GETDATE())
    ORDER BY bs.backup_start_date DESC;
END
ELSE
BEGIN
    SELECT TOP 0
        'BackupHistory' AS Category,
        CAST(NULL AS sysname) AS DatabaseName,
        CAST(NULL AS char(1)) AS BackupType,
        CAST(NULL AS nvarchar(30)) AS BackupTypeDesc,
        CAST(NULL AS datetime) AS backup_start_date,
        CAST(NULL AS datetime) AS backup_finish_date,
        CAST(NULL AS bigint) AS BackupSizeMB,
        CAST(NULL AS bigint) AS CompressedSizeMB,
        CAST(NULL AS nvarchar(260)) AS physical_device_name;
END;

-- 8. SERVER LOGINS AND SECURITY
SELECT
    'ServerLogins' AS Category,
    p.name AS LoginName,
    p.type_desc AS LoginType,
    p.is_disabled,
    p.create_date,
    p.modify_date,
    p.default_database_name,
    p.default_language_name,
    CASE WHEN p.type IN ('S', 'U') THEN 'Password Set'
         ELSE 'N/A'
    END AS PasswordStatus
FROM sys.server_principals p
WHERE p.type IN ('S', 'U', 'G', 'R', 'C', 'K')
AND p.name NOT LIKE '##%'
ORDER BY p.name;

-- 9. AVAILABILITY GROUPS (Enhanced - SQL Server 2016 compatible)
IF (OBJECT_ID('sys.availability_groups') IS NOT NULL AND ISNULL(CONVERT(int, SERVERPROPERTY('IsHadrEnabled')), 0) = 1)
BEGIN
    DECLARE @agSql nvarchar(max) =
        N'SELECT ' +
        N'''AvailabilityGroups'' AS Category, ' +
        N'ag.group_id, ag.name AS AGName, ag.resource_id, ag.failure_condition_level, ag.health_check_timeout, ag.automated_backup_preference_desc, ' +
        CASE WHEN COL_LENGTH('sys.availability_groups', 'basic_features') IS NOT NULL THEN N'CAST(ag.basic_features AS bit) AS basic_features, ' ELSE N'CAST(NULL AS bit) AS basic_features, ' END +
        N'''WSFC'' AS cluster_type_desc, ' +
        CASE WHEN COL_LENGTH('sys.availability_groups', 'db_failover') IS NOT NULL THEN N'CAST(ag.db_failover AS bit) AS db_failover, ' ELSE N'CAST(NULL AS bit) AS db_failover, ' END +
        CASE WHEN COL_LENGTH('sys.availability_groups', 'dtc_support') IS NOT NULL THEN N'CAST(ag.dtc_support AS bit) AS dtc_support, ' ELSE N'CAST(NULL AS bit) AS dtc_support, ' END +
        CASE WHEN COL_LENGTH('sys.availability_groups', 'is_distributed') IS NOT NULL THEN N'CAST(ag.is_distributed AS bit) AS is_distributed ' ELSE N'CAST(NULL AS bit) AS is_distributed ' END +
        N'FROM sys.availability_groups AS ag;';

    EXEC sys.sp_executesql @agSql;
END
ELSE
BEGIN
    SELECT TOP 0
        'AvailabilityGroups' AS Category,
        CAST(NULL AS uniqueidentifier) AS group_id,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS uniqueidentifier) AS resource_id,
        CAST(NULL AS int) AS failure_condition_level,
        CAST(NULL AS int) AS health_check_timeout,
        CAST(NULL AS nvarchar(60)) AS automated_backup_preference_desc,
        CAST(NULL AS bit) AS basic_features,
        CAST(NULL AS nvarchar(20)) AS cluster_type_desc,
        CAST(NULL AS bit) AS db_failover,
        CAST(NULL AS bit) AS dtc_support,
        CAST(NULL AS bit) AS is_distributed;
END;

-- 10. AG REPLICAS WITH STATUS (SQL Server 2016 compatible)
IF (OBJECT_ID('sys.availability_groups') IS NOT NULL AND OBJECT_ID('sys.availability_replicas') IS NOT NULL AND ISNULL(CONVERT(int, SERVERPROPERTY('IsHadrEnabled')), 0) = 1)
BEGIN
    DECLARE @agReplicaSql nvarchar(max) =
        N'SELECT ' +
        N'''AGReplicas'' AS Category, ' +
        N'ag.name AS AGName, ar.replica_server_name, ar.endpoint_url, ar.availability_mode_desc, ar.failover_mode_desc, ' +
        CASE WHEN COL_LENGTH('sys.availability_replicas', 'seeding_mode_desc') IS NOT NULL THEN N'CAST(ar.seeding_mode_desc AS nvarchar(60)) AS seeding_mode_desc, ' ELSE N'CAST(NULL AS nvarchar(60)) AS seeding_mode_desc, ' END +
        N'ar.session_timeout, ar.primary_role_allow_connections_desc, ar.secondary_role_allow_connections_desc, ar.backup_priority, ar.read_only_routing_url, ' +
        N'ars.role_desc, ars.connected_state_desc, ars.operational_state_desc, ars.synchronization_health_desc, ars.recovery_health_desc ' +
        N'FROM sys.availability_groups ag ' +
        N'JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id ' +
        N'LEFT JOIN sys.dm_hadr_availability_replica_states ars ON ar.replica_id = ars.replica_id;';

    EXEC sys.sp_executesql @agReplicaSql;
END
ELSE
BEGIN
    SELECT TOP 0
        'AGReplicas' AS Category,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS nvarchar(128)) AS replica_server_name,
        CAST(NULL AS nvarchar(256)) AS endpoint_url,
        CAST(NULL AS nvarchar(60)) AS availability_mode_desc,
        CAST(NULL AS nvarchar(60)) AS failover_mode_desc,
        CAST(NULL AS nvarchar(60)) AS seeding_mode_desc,
        CAST(NULL AS int) AS session_timeout,
        CAST(NULL AS nvarchar(60)) AS primary_role_allow_connections_desc,
        CAST(NULL AS nvarchar(60)) AS secondary_role_allow_connections_desc,
        CAST(NULL AS tinyint) AS backup_priority,
        CAST(NULL AS nvarchar(256)) AS read_only_routing_url,
        CAST(NULL AS nvarchar(60)) AS role_desc,
        CAST(NULL AS nvarchar(60)) AS connected_state_desc,
        CAST(NULL AS nvarchar(60)) AS operational_state_desc,
        CAST(NULL AS nvarchar(60)) AS synchronization_health_desc,
        CAST(NULL AS nvarchar(60)) AS recovery_health_desc;
END;

-- 11. AG DATABASES WITH SYNC STATUS (Enhanced with server names)
IF (OBJECT_ID('sys.availability_groups') IS NOT NULL AND OBJECT_ID('sys.availability_databases_cluster') IS NOT NULL AND OBJECT_ID('sys.availability_replicas') IS NOT NULL AND ISNULL(CONVERT(int, SERVERPROPERTY('IsHadrEnabled')), 0) = 1)
BEGIN
    SELECT
        'AGDatabases' AS Category,
        ag.name AS AGName,
        ar.replica_server_name,
        adc.database_name,
        CASE
            WHEN adrs.is_primary_replica = 1 THEN 'PRIMARY'
            ELSE 'SECONDARY'
        END AS replica_role,
        adrs.synchronization_state_desc,
        adrs.synchronization_health_desc,
        CASE adrs.is_suspended WHEN 1 THEN 'Yes' ELSE 'No' END AS is_suspended,
        d.state_desc AS database_state_desc,
        (SELECT ar2.replica_server_name
         FROM sys.availability_replicas ar2
         INNER JOIN sys.dm_hadr_availability_replica_states ars2 ON ar2.replica_id = ars2.replica_id
         WHERE ar2.group_id = ag.group_id AND ars2.role_desc = 'PRIMARY') AS primary_server_name
    FROM sys.availability_groups ag
    INNER JOIN sys.availability_databases_cluster adc ON ag.group_id = adc.group_id
    INNER JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
    LEFT JOIN sys.databases d ON adc.database_name = d.name
    LEFT JOIN sys.dm_hadr_database_replica_states adrs ON adc.database_name = DB_NAME(adrs.database_id) AND ar.replica_id = adrs.replica_id;
END
ELSE
BEGIN
    SELECT TOP 0
        'AGDatabases' AS Category,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS nvarchar(128)) AS replica_server_name,
        CAST(NULL AS sysname) AS database_name,
        CAST(NULL AS nvarchar(20)) AS replica_role,
        CAST(NULL AS nvarchar(60)) AS synchronization_state_desc,
        CAST(NULL AS nvarchar(60)) AS synchronization_health_desc,
        CAST(NULL AS nvarchar(3)) AS is_suspended,
        CAST(NULL AS nvarchar(60)) AS database_state_desc,
        CAST(NULL AS nvarchar(128)) AS primary_server_name;
END;

-- 12. DATABASE ENCRYPTION DETAILS
SELECT
    'DatabaseEncryption' AS Category,
    d.name AS DatabaseName,
    d.is_encrypted,
    dek.encryption_state,
    CASE dek.encryption_state
        WHEN 0 THEN 'No database encryption key present'
        WHEN 1 THEN 'Unencrypted'
        WHEN 2 THEN 'Encryption in progress'
        WHEN 3 THEN 'Encrypted'
        WHEN 4 THEN 'Key change in progress'
        WHEN 5 THEN 'Decryption in progress'
        WHEN 6 THEN 'Protection change in progress'
    END AS EncryptionStateDesc,
    dek.create_date AS EncryptionKeyCreateDate,
    dek.regenerate_date AS EncryptionKeyRegenerateDate,
    dek.set_date AS EncryptionKeySetDate,
    dek.opened_date AS EncryptionKeyOpenedDate,
    dek.key_algorithm AS EncryptionAlgorithm,
    dek.key_length AS EncryptionKeyLength,
    c.name AS CertificateName,
    c.certificate_id,
    c.thumbprint AS CertificateThumbprint,
    c.subject AS CertificateSubject,
    c.start_date AS CertificateStartDate,
    c.expiry_date AS CertificateExpiryDate
FROM sys.databases d
LEFT JOIN sys.dm_database_encryption_keys dek ON d.database_id = dek.database_id
LEFT JOIN sys.certificates c ON dek.encryptor_thumbprint = c.thumbprint
WHERE d.database_id > 4 OR d.name IN ('master', 'model', 'msdb', 'tempdb')
ORDER BY d.name;

-- 13. SERVER CERTIFICATES AND KEYS
SELECT
    'ServerCertificates' AS Category,
    c.name AS CertificateName,
    c.certificate_id,
    c.thumbprint,
    c.subject,
    c.start_date,
    c.expiry_date,
    c.issuer_name,
    c.pvt_key_encryption_type_desc
FROM sys.certificates c
ORDER BY c.name;

-- 14. SYMMETRIC KEYS
SELECT
    'SymmetricKeys' AS Category,
    sk.name AS KeyName,
    sk.symmetric_key_id,
    sk.key_length,
    sk.algorithm_desc,
    sk.create_date,
    sk.key_guid
FROM sys.symmetric_keys sk
WHERE sk.name <> '##MS_ServiceMasterKey##'
ORDER BY sk.name;

-- 15. ASYMMETRIC KEYS
SELECT
    'AsymmetricKeys' AS Category,
    ak.name AS KeyName,
    ak.asymmetric_key_id,
    ak.algorithm_desc,
    ak.key_length,
    ak.thumbprint
FROM sys.asymmetric_keys ak
ORDER BY ak.name;

-- 16. SERVICE MASTER KEY INFO
SELECT
    'ServiceMasterKey' AS Category,
    'Service Master Key' AS KeyType,
    create_date
FROM sys.databases
WHERE database_id = 1;

-- 17. DATABASE MASTER KEY INFO
SELECT
    'DatabaseMasterKeys' AS Category,
    DB_NAME() AS DatabaseName,
    'Database Master Key' AS KeyType,
    create_date
FROM sys.symmetric_keys
WHERE name = '##MS_DatabaseMasterKey##';

-- 18. ENCRYPTION HIERARCHY SUMMARY
SELECT
    'EncryptionHierarchy' AS Category,
    d.name AS DatabaseName,
    CASE
        WHEN dek.database_id IS NOT NULL THEN 'TDE Enabled'
        WHEN EXISTS (SELECT 1 FROM sys.symmetric_keys sk WHERE sk.name <> '##MS_ServiceMasterKey##' AND sk.name <> '##MS_DatabaseMasterKey##') THEN 'Column-Level Encryption'
        WHEN EXISTS (SELECT 1 FROM sys.certificates c WHERE c.name NOT LIKE '##%') THEN 'Certificates Present'
        ELSE 'No Encryption'
    END AS EncryptionType,
    CASE WHEN dek.database_id IS NOT NULL THEN c.name ELSE NULL END AS TDECertificate,
    CASE WHEN dek.database_id IS NOT NULL THEN c.expiry_date ELSE NULL END AS CertificateExpiry,
    (SELECT COUNT(*) FROM sys.certificates cert WHERE cert.name NOT LIKE '##%') AS CustomCertificateCount,
    (SELECT COUNT(*) FROM sys.symmetric_keys sk WHERE sk.name <> '##MS_ServiceMasterKey##' AND sk.name <> '##MS_DatabaseMasterKey##') AS CustomSymmetricKeyCount
FROM sys.databases d
LEFT JOIN sys.dm_database_encryption_keys dek ON d.database_id = dek.database_id
LEFT JOIN sys.certificates c ON dek.encryptor_thumbprint = c.thumbprint
WHERE d.database_id > 4 OR d.name IN ('master', 'model', 'msdb', 'tempdb')
ORDER BY d.name;

-- 19. SQL PERFORMANCE HEALTH - Memory Summary
SELECT
    'SQLPerformanceHealth_MemorySummary' AS Category,
    SERVERPROPERTY('MachineName') AS MachineName,
    SERVERPROPERTY('ServerName') AS ServerName,
    SERVERPROPERTY('InstanceName') AS InstanceName,
    SERVERPROPERTY('ProductVersion') AS ProductVersion,
    SERVERPROPERTY('Edition') AS Edition,
    CONVERT(int, (SELECT value_in_use FROM sys.configurations WHERE name = 'max server memory (MB)')) AS MaxServerMemory_MB,
    CONVERT(int, (SELECT value_in_use FROM sys.configurations WHERE name = 'min server memory (MB)')) AS MinServerMemory_MB,
    sm.total_physical_memory_kb / 1024 AS TotalOSMemory_MB,
    sm.available_physical_memory_kb / 1024 AS OSMemoryFree_MB,
    sm.system_memory_state_desc AS OSMemoryState
FROM sys.dm_os_sys_memory AS sm;

-- 20. SQL PERFORMANCE HEALTH - Process Memory
SELECT
    'SQLPerformanceHealth_ProcessMemory' AS Category,
    physical_memory_in_use_kb / 1024.0 AS SQLProcessMemoryUsed_MB,
    large_page_allocations_kb / 1024.0 AS LargePageAllocations_MB,
    locked_page_allocations_kb / 1024.0 AS LockedPages_MB,
    total_virtual_address_space_kb / 1024.0 AS TotalVASpace_MB,
    virtual_address_space_reserved_kb / 1024.0 AS VAS_Reserved_MB,
    virtual_address_space_committed_kb / 1024.0 AS VAS_Committed_MB,
    virtual_address_space_available_kb / 1024.0 AS VAS_Available_MB,
    page_fault_count AS PageFaultCount,
    memory_utilization_percentage AS SQLProcessUtilizationPercent,
    process_physical_memory_low AS IsProcessPhysicalMemoryLow,
    process_virtual_memory_low AS IsProcessVirtualMemoryLow
FROM sys.dm_os_process_memory;

-- 21. SQL PERFORMANCE HEALTH - Committed vs Target Memory
SELECT
    'SQLPerformanceHealth_CommittedMemory' AS Category,
    (committed_kb / 1024.0) AS CommittedMemory_MB,
    (committed_target_kb / 1024.0) AS TargetMemory_MB,
    (committed_kb - committed_target_kb) / 1024.0 AS CommittedMinusTarget_MB
FROM sys.dm_os_sys_info;

-- 22. SQL PERFORMANCE HEALTH - Memory Roll-up
SELECT
    'SQLPerformanceHealth_MemoryRollup' AS Category,
    pm.physical_memory_in_use_kb / 1024.0 AS SQLProcessUsed_MB,
    si.committed_kb / 1024.0 AS Committed_MB,
    si.committed_target_kb / 1024.0 AS Target_MB,
    (SELECT SUM(virtual_memory_committed_kb) / 1024.0 FROM sys.dm_os_memory_clerks WHERE type = 'MEMORYCLERK_SQLBUFFERPOOL') AS BufferPool_MB,
    (SELECT SUM(pages_kb)/1024.0 FROM sys.dm_os_memory_clerks WHERE type LIKE 'CACHESTORE_%') AS PlanCache_MB,
    (SELECT SUM(pages_kb)/1024.0 FROM sys.dm_os_memory_clerks) AS AllClerks_MB
FROM sys.dm_os_process_memory pm
CROSS JOIN sys.dm_os_sys_info si;

-- 23. SQL PERFORMANCE HEALTH - Key Performance Counters
SELECT
    'SQLPerformanceHealth_PerfCounters' AS Category,
    object_name,
    counter_name,
    instance_name,
    cntr_value
FROM sys.dm_os_performance_counters
WHERE
    (object_name LIKE '%Buffer Manager%' AND counter_name IN ('Buffer cache hit ratio','Buffer cache hit ratio base','Lazy writes/sec','Checkpoint pages/sec','Free list stalls/sec'))
    OR (object_name LIKE '%Buffer Node%' AND counter_name IN ('Page life expectancy'))
    OR (object_name LIKE '%Memory Manager%' AND counter_name IN ('Memory Grants Pending','Target Server Memory (KB)','Total Server Memory (KB)'))
    OR (object_name LIKE '%SQL Statistics%' AND counter_name IN ('Batch Requests/sec','SQL Compilations/sec','SQL Re-Compilations/sec'));

-- 24. SQL PERFORMANCE HEALTH - Top Wait Stats (Top 20)
SELECT TOP 20
    'SQLPerformanceHealth_WaitStats' AS Category,
    wait_type,
    waiting_tasks_count,
    wait_time_ms,
    signal_wait_time_ms,
    wait_time_ms - signal_wait_time_ms AS resource_wait_time_ms,
    wait_time_ms * 1.0 / NULLIF(SUM(wait_time_ms) OVER(), 0) AS pct_of_total
FROM sys.dm_os_wait_stats
WHERE wait_type NOT LIKE 'SLEEP%'
  AND wait_type NOT LIKE 'XE_%'
  AND wait_type NOT LIKE 'BROKER_%'
  AND wait_type NOT LIKE 'SQLTRACE_%'
ORDER BY wait_time_ms DESC;

-- 25. SQL PERFORMANCE HEALTH - IO Latency per File (Top 30)
SELECT TOP 30
    'SQLPerformanceHealth_IOLatency' AS Category,
    DB_NAME(vfs.database_id) AS DatabaseName,
    vfs.database_id,
    vfs.file_id,
    mf.type_desc AS FileType,
    mf.physical_name,
    vfs.num_of_reads,
    vfs.io_stall_read_ms,
    CASE WHEN vfs.num_of_reads = 0 THEN NULL ELSE vfs.io_stall_read_ms / vfs.num_of_reads END AS avg_read_latency_ms,
    vfs.num_of_writes,
    vfs.io_stall_write_ms,
    CASE WHEN vfs.num_of_writes = 0 THEN NULL ELSE vfs.io_stall_write_ms / vfs.num_of_writes END AS avg_write_latency_ms,
    vfs.io_stall,
    CASE WHEN (vfs.num_of_reads + vfs.num_of_writes) = 0 THEN NULL ELSE vfs.io_stall / (vfs.num_of_reads + vfs.num_of_writes) END AS avg_io_latency_ms
FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs
LEFT JOIN sys.master_files AS mf ON mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id
ORDER BY vfs.io_stall DESC;

-- 26. SQL PERFORMANCE HEALTH - Scheduler Info
SELECT
    'SQLPerformanceHealth_Schedulers' AS Category,
    scheduler_id,
    cpu_id,
    is_online,
    is_idle,
    current_tasks_count,
    runnable_tasks_count,
    active_workers_count,
    load_factor,
    pending_disk_io_count
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255;

-- 27. SQL PERFORMANCE HEALTH - Tempdb Usage
SELECT
    'SQLPerformanceHealth_TempdbUsage' AS Category,
    SUM(user_object_reserved_page_count)*8 AS user_object_KB,
    SUM(internal_object_reserved_page_count)*8 AS internal_object_KB,
    SUM(version_store_reserved_page_count)*8 AS version_store_KB,
    SUM(unallocated_extent_page_count)*8 AS unallocated_extent_KB,
    SUM(mixed_extent_page_count)*8 AS mixed_extent_KB
FROM tempdb.sys.dm_db_file_space_usage;

-- 28. SQL PERFORMANCE HEALTH - Top 10 Queries by CPU
SELECT TOP 10
    'SQLPerformanceHealth_TopCPUQueries' AS Category,
    qs.total_worker_time / 1000.0 AS total_cpu_ms,
    qs.total_worker_time / NULLIF(qs.execution_count,0) / 1000.0 AS avg_cpu_ms,
    qs.execution_count,
    qs.total_logical_reads,
    qs.total_logical_reads / NULLIF(qs.execution_count,0) AS avg_logical_reads,
    qs.total_elapsed_time / 1000.0 AS total_elapsed_ms,
    qs.total_elapsed_time / NULLIF(qs.execution_count,0) / 1000.0 AS avg_elapsed_ms,
    DB_NAME(st.dbid) AS database_name,
    SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
              CASE WHEN qs.statement_end_offset = -1
                   THEN LEN(CONVERT(nvarchar(max), st.text))
                   ELSE (qs.statement_end_offset - qs.statement_start_offset)/2 + 1
              END) AS query_text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
ORDER BY qs.total_worker_time DESC;

-- 29. SQL PERFORMANCE HEALTH - Top 10 Queries by IO
SELECT TOP 10
    'SQLPerformanceHealth_TopIOQueries' AS Category,
    qs.total_logical_reads,
    qs.total_logical_reads / NULLIF(qs.execution_count,0) AS avg_logical_reads,
    qs.execution_count,
    qs.total_worker_time / 1000.0 AS total_cpu_ms,
    qs.total_elapsed_time / 1000.0 AS total_elapsed_ms,
    DB_NAME(st.dbid) AS database_name,
    SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
              CASE WHEN qs.statement_end_offset = -1
                   THEN LEN(CONVERT(nvarchar(max), st.text))
                   ELSE (qs.statement_end_offset - qs.statement_start_offset)/2 + 1
              END) AS query_text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
ORDER BY qs.total_logical_reads DESC;
"@

                            foreach ($instance in $SqlInstance) {
                                Write-Info "Querying SQL instance: $instance"
                                try {
                                    $sqlParams = @{
                                        ServerInstance = $instance
                                        Query          = $tsql
                                        ErrorAction    = 'Stop'
                                    }

                                    # Add TrustServerCertificate parameter if supported by the SQL Server module
                                    try {
                                        # Test if TrustServerCertificate parameter is supported
                                        $cmdInfo = Get-Command Invoke-Sqlcmd -ErrorAction Stop
                                        if ($cmdInfo.Parameters.ContainsKey('TrustServerCertificate')) {
                                            $sqlParams['TrustServerCertificate'] = $true
                                            Write-Info "Using TrustServerCertificate parameter for enhanced security"
                                        }
                                    }
                                    catch {
                                        Write-Info "TrustServerCertificate parameter not supported by current SQL Server module version"
                                    }

                                    # Execute SQL query using appropriate method
                                    if ($haveSqlCmd) {
                                        $ds = Invoke-Sqlcmd @sqlParams -As DataSet
                                    }
                                    elseif ($useSqlcmdFallback) {
                                        # Use sqlcmd fallback - convert single query results to dataset-like structure
                                        $results = Invoke-SqlcmdFallback -ServerInstance $instance -Query $tsql -TrustServerCertificate

                                        # Simulate dataset structure by grouping results by Category column
                                        $ds = @{
                                            Tables = @()
                                        }

                                        # Group results by Category if available
                                        if ($results) {
                                            $categoryGroups = $results | Group-Object -Property Category -ErrorAction SilentlyContinue
                                            if ($categoryGroups) {
                                                foreach ($group in $categoryGroups) {
                                                    $ds.Tables += , $group.Group
                                                }
                                            }
                                            else {
                                                # If no Category column, treat all as one table
                                                $ds.Tables += , $results
                                            }
                                        }
                                    }
                                    elseif ($useDotNetFallback) {
                                        # Use .NET SqlConnection fallback
                                        $results = Invoke-DotNetSqlFallback -ServerInstance $instance -Query $tsql -TrustServerCertificate

                                        # Simulate dataset structure by grouping results by Category column
                                        $ds = @{
                                            Tables = @()
                                        }

                                        # Group results by Category if available
                                        if ($results) {
                                            $categoryGroups = $results | Group-Object -Property Category -ErrorAction SilentlyContinue
                                            if ($categoryGroups) {
                                                foreach ($group in $categoryGroups) {
                                                    $ds.Tables += , $group.Group
                                                }
                                            }
                                            else {
                                                # If no Category column, treat all as one table
                                                $ds.Tables += , $results
                                            }
                                        }
                                    }

                                    # Process all result sets and organize by category
                                    $instanceData = [ordered]@{
                                        Instance            = $instance
                                        CollectedOnUtc      = (Get-Date).ToUniversalTime().ToString("o")
                                        ServerInfo          = @()
                                        DatabaseInventory   = @()
                                        DatabaseFiles       = @()
                                        DatabaseSizes       = @()
                                        ServerConfiguration = @()
                                        AgentJobs           = @()
                                        BackupHistory       = @()
                                        ServerLogins        = @()
                                        AvailabilityGroups  = @()
                                        AGReplicas          = @()
                                        AGDatabases         = @()
                                        DatabaseEncryption  = @()
                                        ServerCertificates  = @()
                                        SymmetricKeys       = @()
                                        AsymmetricKeys      = @()
                                        ServiceMasterKey    = @()
                                        DatabaseMasterKeys  = @()
                                        EncryptionHierarchy = @()
                                        PerformanceHealth   = @()
                                    }

                                    # Process each result set by category
                                    foreach ($table in $ds.Tables) {
                                        $rows = @()
                                        $category = $null

                                        if ($table -is [System.Data.DataTable]) {
                                            if (-not $table.Rows -or $table.Rows.Count -le 0) {
                                                continue
                                            }
                                            $rows = @($table.Rows)
                                            $category = [string]$table.Rows[0]["Category"]
                                        }
                                        else {
                                            $rows = @($table)
                                            if ($rows.Count -le 0) {
                                                continue
                                            }
                                            $firstRow = $rows | Select-Object -First 1
                                            if (-not $firstRow) {
                                                continue
                                            }
                                            $category = [string]$firstRow.Category
                                        }

                                        if ([string]::IsNullOrWhiteSpace($category)) {
                                            continue
                                        }

                                        foreach ($row in $rows) {
                                            $rowData = [ordered]@{}

                                            if ($table -is [System.Data.DataTable]) {
                                                foreach ($column in $table.Columns) {
                                                    # Keep Category for PerformanceHealth data, remove for others
                                                    if ($column.ColumnName -ne "Category" -or $category -like "SQLPerformanceHealth_*") {
                                                        # Normalize DBNull to $null so ConvertTo-Json emits JSON null
                                                        # instead of {} (empty object), which breaks HTML rendering
                                                        $val = $row[$column.ColumnName]
                                                        $rowData[$column.ColumnName] = if ($val -is [System.DBNull]) { $null } else { $val }
                                                    }
                                                }
                                            }
                                            else {
                                                foreach ($prop in $row.PSObject.Properties) {
                                                    if ($prop.Name -ne "Category" -or $category -like "SQLPerformanceHealth_*") {
                                                        $val = $prop.Value
                                                        $rowData[$prop.Name] = if ($val -is [System.DBNull]) { $null } else { $val }
                                                    }
                                                }
                                            }

                                            switch ($category) {
                                                "ServerInfo" { $instanceData.ServerInfo += $rowData }
                                                "DatabaseInventory" { $instanceData.DatabaseInventory += $rowData }
                                                "DatabaseFiles" { $instanceData.DatabaseFiles += $rowData }
                                                "DatabaseSizes" { $instanceData.DatabaseSizes += $rowData }
                                                "ServerConfiguration" { $instanceData.ServerConfiguration += $rowData }
                                                "AgentJobs" { $instanceData.AgentJobs += $rowData }
                                                "BackupHistory" { $instanceData.BackupHistory += $rowData }
                                                "ServerLogins" { $instanceData.ServerLogins += $rowData }
                                                "AvailabilityGroups" { $instanceData.AvailabilityGroups += $rowData }
                                                "AGReplicas" { $instanceData.AGReplicas += $rowData }
                                                "AGDatabases" { $instanceData.AGDatabases += $rowData }
                                                "DatabaseEncryption" { $instanceData.DatabaseEncryption += $rowData }
                                                "ServerCertificates" { $instanceData.ServerCertificates += $rowData }
                                                "SymmetricKeys" { $instanceData.SymmetricKeys += $rowData }
                                                "AsymmetricKeys" { $instanceData.AsymmetricKeys += $rowData }
                                                "ServiceMasterKey" { $instanceData.ServiceMasterKey += $rowData }
                                                "DatabaseMasterKeys" { $instanceData.DatabaseMasterKeys += $rowData }
                                                "EncryptionHierarchy" { $instanceData.EncryptionHierarchy += $rowData }
                                                default {
                                                    if ($category -like "SQLPerformanceHealth_*") {
                                                        $instanceData.PerformanceHealth += $rowData
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    $Result.Sql += $instanceData

                                    # Summary logging
                                    Write-Info "Successfully collected comprehensive data from SQL instance '$instance':"
                                    Write-Info "  - Server Info: $($instanceData.ServerInfo.Count) items"
                                    Write-Info "  - Databases: $($instanceData.DatabaseInventory.Count) databases"
                                    Write-Info "  - Database Files: $($instanceData.DatabaseFiles.Count) files"
                                    Write-Info "  - Agent Jobs: $($instanceData.AgentJobs.Count) jobs"
                                    Write-Info "  - Backup History: $($instanceData.BackupHistory.Count) backups (90 days)"
                                    Write-Info "  - Server Logins: $($instanceData.ServerLogins.Count) logins"
                                    Write-Info "  - Availability Groups: $($instanceData.AvailabilityGroups.Count) AGs"
                                    Write-Info "  - AG Replicas: $($instanceData.AGReplicas.Count) replicas"
                                    Write-Info "  - AG Databases: $($instanceData.AGDatabases.Count) AG databases"
                                    Write-Info "  - Encrypted Databases: $($instanceData.DatabaseEncryption.Count) encryption records"
                                    Write-Info "  - Server Certificates: $($instanceData.ServerCertificates.Count) certificates"
                                    Write-Info "  - Symmetric Keys: $($instanceData.SymmetricKeys.Count) keys"
                                    Write-Info "  - Asymmetric Keys: $($instanceData.AsymmetricKeys.Count) keys"
                                    Write-Info "  - Encryption Hierarchy: $($instanceData.EncryptionHierarchy.Count) databases analyzed"

                                }
                                catch {
                                    $err = "Failed to query SQL instance '$instance': $($_.Exception.Message)"
                                    Write-Err $err
                                    $Result.Errors += $err
                                }
                            }

                            Write-Info "SQL data collection completed successfully."
                        }
                        catch {
                            $err = "Error during SQL data collection: $($_.Exception.Message)"
                            Write-Err $err
                            $Result.Errors += $err
                        }
                    }
                    else {
                        if (-not $ForceInstallRemote) {
                            $warn = "SqlServer/SQLPS module not available and ForceInstall is not set. Skipping module installation and continuing with non-module collection paths."
                            Write-Warn $warn
                            $Result.Warnings += $warn
                        }
                        else {
                            # Try to install SqlServer module
                            Write-Info "SqlServer module not found, ForceInstall enabled; attempting installation..."
                            try {
                                try {
                                    # Try module by name first
                                    Import-Module -Name SqlServer -Force -ErrorAction Stop
                                    write-info "SqlServer module available."
                                }
                                catch {
                                    # try the legacy name
                                    try {
                                        Import-Module -Name SQLPS -Force -ErrorAction Stop
                                        write-info "SQLPS module available."
                                    }
                                    catch {
                                        Write-Warn "Standard module load failed, attempting to install from zip file..."
                                        if (Install-SqlPSModuleLocal) {
                                            try {
                                                Import-Module -Name SqlServer -Force -ErrorAction Stop
                                                write-info "SqlServer module loaded successfully after installation."
                                            }
                                            catch {
                                                Import-Module -Name SQLPS -Force -ErrorAction Stop
                                                write-info "SQLPS module loaded successfully after installation."
                                            }
                                        }
                                        else {
                                            Throw "SQL PowerShell module not available and installation failed."
                                        }
                                    }
                                }
                                $haveSqlCmd = $true
                                Write-Info ".NET SqlConnection not available, using SqlServer module fallback."
                            }
                            catch {
                                # Fallback: Try to install from Windows Features if available

                                Write-Info "PowerShell Gallery install failed, trying Windows Features..."
                                $sqlFeatures = @(
                                    "RSAT-AD-PowerShell",
                                    "RSAT-ADDS-Tools"
                                )
                                foreach ($feature in $sqlFeatures) {
                                    try {
                                        $feat = Get-WindowsFeature -Name $feature -ErrorAction SilentlyContinue
                                        if ($feat -and $feat.InstallState -ne "Installed") {
                                            Install-WindowsFeature -Name $feature -IncludeManagementTools -ErrorAction SilentlyContinue
                                        }
                                    }
                                    catch { }
                                }

                                # Try importing again

                                try {
                                    Import-Module -Name SqlServer -Force -ErrorAction Stop
                                    $haveSqlCmd = $true
                                    write-info "SqlServer module available on remote server."
                                }
                                catch {
                                    # try the legacy name
                                    try {
                                        Import-Module -Name SQLPS -Force -ErrorAction Stop
                                        $haveSqlCmd = $true
                                        write-info "SQLPS module available on remote server."
                                    }
                                    catch {
                                        $warn = "Failed to install SqlServer module: $($_.Exception.Message). SQL AG data collection will be skipped."
                                        Write-Warn $warn
                                        $Result.Warnings += $warn
                                    }
                                }





                                # If we successfully installed the module, run the SQL collection
                                if ($haveSqlCmd) {
                                    Write-Info "Proceeding with SQL data collection using newly installed module..."
                                    # Add the actual SQL data collection code here
                                    try {
                                        $tsql = @"
SET NOCOUNT ON;

-- Availability Groups basic info (SQL Server 2016 compatible)
IF (OBJECT_ID('sys.availability_groups') IS NOT NULL AND ISNULL(CONVERT(int, SERVERPROPERTY('IsHadrEnabled')), 0) = 1)
BEGIN
    SELECT
        GETDATE() AS SnapshotTime,
        @@SERVERNAME AS ServerName,
        SERVERPROPERTY('ServerName') AS ServerName_Property,
        SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS PhysicalServerName,
        ag.group_id,
        ag.name AS AGName,
        ag.resource_id,
        ag.failure_condition_level,
        ag.health_check_timeout,
        ag.automated_backup_preference_desc,
        CAST(NULL AS bit) AS basic_features,
        'WSFC' AS cluster_type_desc,
        CAST(NULL AS bit) AS db_failover,
        CAST(NULL AS bit) AS dtc_support,
        CAST(NULL AS bit) AS is_distributed
    FROM sys.availability_groups AS ag;
END
ELSE
BEGIN
    SELECT TOP 0
        GETDATE() AS SnapshotTime,
        @@SERVERNAME AS ServerName,
        SERVERPROPERTY('ServerName') AS ServerName_Property,
        SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS PhysicalServerName,
        CAST(NULL AS uniqueidentifier) AS group_id,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS uniqueidentifier) AS resource_id,
        CAST(NULL AS int) AS failure_condition_level,
        CAST(NULL AS int) AS health_check_timeout,
        CAST(NULL AS nvarchar(60)) AS automated_backup_preference_desc,
        CAST(NULL AS bit) AS basic_features,
        CAST(NULL AS nvarchar(20)) AS cluster_type_desc,
        CAST(NULL AS bit) AS db_failover,
        CAST(NULL AS bit) AS dtc_support,
        CAST(NULL AS bit) AS is_distributed;
END;
"@

                                        foreach ($instance in $SqlInstance) {
                                            Write-Info "Querying SQL instance: $instance"
                                            try {
                                                $sqlParams = @{
                                                    ServerInstance = $instance
                                                    Query          = $tsql
                                                    ErrorAction    = 'Stop'
                                                }

                                                # Add TrustServerCertificate parameter if supported by the SQL Server module
                                                try {
                                                    # Test if TrustServerCertificate parameter is supported
                                                    $cmdInfo = Get-Command Invoke-Sqlcmd -ErrorAction Stop
                                                    if ($cmdInfo.Parameters.ContainsKey('TrustServerCertificate')) {
                                                        $sqlParams['TrustServerCertificate'] = $true
                                                    }
                                                }
                                                catch {
                                                    # TrustServerCertificate parameter not supported by current SQL Server module version
                                                }

                                                $ds = Invoke-Sqlcmd @sqlParams -OutputAs DataSet

                                                $agGroups = @()
                                                if ($ds -and $ds.Tables -and $ds.Tables.Count -ge 1) {
                                                    $firstTable = $ds.Tables | Select-Object -First 1
                                                    foreach ($row in @($firstTable)) {
                                                        $agGroups += [ordered]@{
                                                            AGName                    = $row.AGName
                                                            GroupId                   = $row.group_id
                                                            ClusterType               = $row.cluster_type_desc
                                                            ServerName                = $row.ServerName
                                                            PhysicalServerName        = $row.PhysicalServerName
                                                            FailureConditionLevel     = $row.failure_condition_level
                                                            HealthCheckTimeoutMs      = $row.health_check_timeout
                                                            AutomatedBackupPreference = $row.automated_backup_preference_desc
                                                        }
                                                    }
                                                }

                                                $Result.Sql += [ordered]@{
                                                    Instance           = $instance
                                                    CollectedOnUtc     = (Get-Date).ToUniversalTime().ToString("o")
                                                    AvailabilityGroups = $agGroups
                                                }

                                            }
                                            catch {
                                                $err = "Failed to query SQL instance '$instance': $($_.Exception.Message)"
                                                Write-Err $err
                                                $Result.Errors += $err
                                            }
                                        }

                                        Write-Info "SQL data collection completed successfully."
                                    }
                                    catch {
                                        $err = "Error during SQL data collection: $($_.Exception.Message)"
                                        Write-Err $err
                                        $Result.Errors += $err
                                    }
                                }
                            }
                        }
                    }

                    return $Result

                }

        try {
            $sqlAttemptErrors = [System.Collections.Generic.List[string]]::new()

            function Add-WinRmTrustedHostIfNeeded {
                param([string]$RemoteServer)

                try {
                    $currentTrustedHosts = (Get-Item WSMan:\localhost\Client\TrustedHosts -ErrorAction SilentlyContinue).Value
                    $trustedHostPatterns = @($currentTrustedHosts -split ',' | ForEach-Object { ([string]$_).Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

                    # '*' must stand alone. If a previous run left '*,server', normalize it back to '*'.
                    if ($trustedHostPatterns -contains '*') {
                        if ($trustedHostPatterns.Count -gt 1) {
                            Set-Item WSMan:\localhost\Client\TrustedHosts -Value '*' -Force -ErrorAction Stop
                            Write-Info "Normalized WSMan TrustedHosts wildcard entry back to '*'"
                        }
                        return
                    }

                    if ($trustedHostPatterns -contains $RemoteServer) {
                        return
                    }

                    $newTrustedHosts = @($trustedHostPatterns + $RemoteServer) -join ','
                    Set-Item WSMan:\localhost\Client\TrustedHosts -Value $newTrustedHosts -Force -ErrorAction Stop
                    Write-Info "Added $RemoteServer to WSMan TrustedHosts for explicit-auth fallback"
                }
                catch {
                    Write-Warn "Could not update TrustedHosts (non-fatal): $($_.Exception.Message)"
                }
            }

            function Invoke-SqlRemoteAttempt {
                param(
                    [string]$AttemptLabel,
                    [string]$AttemptComputerName,
                    [bool]$UseSSL,
                    [System.Management.Automation.PSCredential]$AttemptCredential,
                    [bool]$IncludePortInSPN = $false,
                    [string]$Authentication = ''
                )
                try {
                    $attemptUser = if ($AttemptCredential) { $AttemptCredential.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
                    if ($Authentication -eq 'Basic' -and -not $AttemptCredential) {
                        Write-Info "Skipping $AttemptLabel for $AttemptComputerName because Basic authentication requires explicit credentials."
                        return [PSCustomObject]@{ Succeeded = $false; Data = $null; LastError = 'Basic authentication requires explicit credentials.'; UserName = $attemptUser }
                    }
                    if (-not [string]::IsNullOrWhiteSpace($Authentication)) {
                        Add-WinRmTrustedHostIfNeeded -RemoteServer $AttemptComputerName
                    }
                    Write-Info "Attempting SQL remote connection to $AttemptComputerName using $AttemptLabel as $attemptUser..."
                    $p = @{ ComputerName = $AttemptComputerName; ErrorAction = 'Stop' }
                    if ($UseSSL -or $IncludePortInSPN) {
                        try {
                            $soParams = @{}
                            if ($UseSSL)           { $soParams.SkipCACheck = $true; $soParams.SkipCNCheck = $true; $soParams.SkipRevocationCheck = $true }
                            if ($IncludePortInSPN) { $soParams.IncludePortInSPN = $true }
                            $p.SessionOption = New-PSSessionOption @soParams
                        } catch { }
                    }
                    if ($UseSSL)     { $p.UseSSL = $true; $p.Port = 5986 }
                    if ($AttemptCredential) { $p.Credential = $AttemptCredential }
                    if (-not [string]::IsNullOrWhiteSpace($Authentication)) { $p.Authentication = $Authentication }
                    $r = Invoke-Command @p -ArgumentList $IncludeVerboseResourceProps, $RemoteServer, $ForceInstall -ScriptBlock $remoteCollectionScriptBlock
                    Write-Info "Successfully connected to $AttemptComputerName using $AttemptLabel as $attemptUser"
                    return [PSCustomObject]@{ Succeeded = $true; Data = $r; LastError = $null; UserName = $attemptUser }
                }
                catch {
                    $msg = $_.Exception.Message
                    $attemptUser = if ($AttemptCredential) { $AttemptCredential.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
                    $sqlAttemptErrors.Add("$AttemptLabel as $attemptUser failed: $msg") | Out-Null
                    Write-Info "Connection attempt failed [$AttemptLabel as $attemptUser] for ${AttemptComputerName}: $msg"
                    return [PSCustomObject]@{ Succeeded = $false; Data = $null; LastError = $msg; UserName = $attemptUser }
                }
            }

            # Build connection targets: RemoteServer first, then short name, then DNS-resolved
            $remoteShortName = if ($RemoteServer -match '\.') { $RemoteServer.Split('.')[0] } else { $RemoteServer }
            $sqlConnectionTargets = [System.Collections.Generic.List[string]]::new()
            $sqlConnectionTargets.Add($RemoteServer) | Out-Null
            if ($remoteShortName -ne $RemoteServer -and -not ($sqlConnectionTargets -contains $remoteShortName)) {
                $sqlConnectionTargets.Add($remoteShortName) | Out-Null
            }
            try {
                $resolvedHostName = ([System.Net.Dns]::GetHostEntry($RemoteServer)).HostName
                if (-not [string]::IsNullOrWhiteSpace($resolvedHostName) -and -not ($sqlConnectionTargets -contains $resolvedHostName)) {
                    $sqlConnectionTargets.Add($resolvedHostName) | Out-Null
                }
            } catch { }

            $preferCurrentUserFirst = $true
            if ($credential -and $preferCurrentUserFirst) {
                try {
                    $computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
                    if (-not [bool]$computerSystem.PartOfDomain) {
                        $preferCurrentUserFirst = $false
                        Write-Info "Local computer is not domain-joined; explicit credentials will be attempted before current user context."
                    }
                } catch {
                    Write-Warn "Could not determine local domain membership: $($_.Exception.Message)"
                }
            }
            $sqlAttemptSucceeded = $false
            $sqlAttemptResult = $null

            foreach ($sqlTarget in $sqlConnectionTargets) {
                if ($sqlAttemptSucceeded) { break }

                if ($preferCurrentUserFirst) {
                    $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'current user context (WinRM HTTP/5985)' -AttemptComputerName $sqlTarget -UseSSL $false -AttemptCredential $null
                    $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    $cuHttpLastError = $sqlAttemptResult.LastError
                    if (-not $sqlAttemptSucceeded) {
                        $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'current user context (WinRM HTTPS/5986)' -AttemptComputerName $sqlTarget -UseSSL $true -AttemptCredential $null
                        $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    }
                    $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
                    if (-not $sqlAttemptSucceeded -and (($cuHttpLastError -match $crossDomainPattern) -or ($sqlAttemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                        $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'current user context (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $sqlTarget -UseSSL $false -AttemptCredential $null -Authentication 'Negotiate'
                        $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    }
                }

                if (-not $sqlAttemptSucceeded -and $credential) {
                    $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985)' -AttemptComputerName $sqlTarget -UseSSL $false -AttemptCredential $credential
                    $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    $httpLastError = $sqlAttemptResult.LastError
                    if (-not $sqlAttemptSucceeded -and $httpLastError -match '0x80090322|An unknown security error') {
                        $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 +IncludePortInSPN)' -AttemptComputerName $sqlTarget -UseSSL $false -AttemptCredential $credential -IncludePortInSPN $true
                        $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    }
                    if (-not $sqlAttemptSucceeded) {
                        $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'explicit credentials (WinRM HTTPS/5986)' -AttemptComputerName $sqlTarget -UseSSL $true -AttemptCredential $credential
                        $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    }
                    $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
                    if (-not $sqlAttemptSucceeded -and (($httpLastError -match $crossDomainPattern) -or ($sqlAttemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                        $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $sqlTarget -UseSSL $false -AttemptCredential $credential -Authentication 'Negotiate'
                        $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                        if (-not $sqlAttemptSucceeded) {
                            $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'explicit credentials (WinRM HTTPS/5986 Basic)' -AttemptComputerName $sqlTarget -UseSSL $true -AttemptCredential $credential -Authentication 'Basic'
                            $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                        }
                    }
                }

                if (-not $preferCurrentUserFirst -and -not $sqlAttemptSucceeded) {
                    $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'current user context (WinRM HTTP/5985)' -AttemptComputerName $sqlTarget -UseSSL $false -AttemptCredential $null
                    $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    $cuHttpLastError = $sqlAttemptResult.LastError
                    if (-not $sqlAttemptSucceeded) {
                        $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'current user context (WinRM HTTPS/5986)' -AttemptComputerName $sqlTarget -UseSSL $true -AttemptCredential $null
                        $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    }
                    $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'
                    if (-not $sqlAttemptSucceeded -and (($cuHttpLastError -match $crossDomainPattern) -or ($sqlAttemptErrors | Where-Object { $_ -match $crossDomainPattern }))) {
                        $sqlAttemptResult = Invoke-SqlRemoteAttempt -AttemptLabel 'current user context (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $sqlTarget -UseSSL $false -AttemptCredential $null -Authentication 'Negotiate'
                        $sqlAttemptSucceeded = [bool]$sqlAttemptResult.Succeeded
                    }
                }
            }

            if (-not $sqlAttemptSucceeded) {
                throw "Failed to connect to $RemoteServer with all available methods. Attempts: $($sqlAttemptErrors -join ' | ')"
            }

            $remoteResult = $sqlAttemptResult.Data

            # Save the remote result locally
            Write-Info "Remote execution returned data type: $($remoteResult.GetType().Name)"
            Write-Info "Remote result has Cluster: $($null -ne $remoteResult.Cluster)"
            Write-Info "Remote result has SQL count: $($remoteResult.Sql.Count)"
            Write-Info "Remote result warnings count: $($remoteResult.Warnings.Count)"

            $script:Result = $remoteResult
            Write-Info "Remote data collection completed successfully."
            Write-Info "Final script result warnings count: $($script:Result.Warnings.Count)"
            Write-Info "Final script result cluster present: $($null -ne $script:Result.Cluster)"

        }
        catch {
            $err = "Failed to execute remote data collection on '$RemoteServer': $($_.Exception.Message)"
            Write-Err $err
            $script:Result.Errors += $err
            throw
        }

        # Write JSON for remote execution
        try {
            $dir = Split-Path -Path $OutputPath -Parent
            if (-not [string]::IsNullOrWhiteSpace($dir) -and -not (Test-Path $dir)) {
                New-Item -ItemType Directory -Path $dir -Force | Out-Null
            }

            $json = $script:Result | ConvertTo-Json -Depth 100
            $json | Out-File -FilePath $OutputPath -Encoding UTF8

            Write-Host "`nExport complete:" -ForegroundColor Green
            Write-Host "  JSON: $OutputPath" -ForegroundColor Green

            # Convert JSON to HTML
            try {
                $htmlScriptPath = Join-Path $PSScriptRoot "Convert-SQLConfigToHTML.ps1"

                if (-not (Test-Path $htmlScriptPath)) {
                    Write-Info "HTML converter script not found. JSON export completed; skipping HTML generation."
                    return
                }

                Write-Host "`nConverting JSON to HTML..." -ForegroundColor Yellow
                & $htmlScriptPath -JsonFile $OutputPath
                Write-Host "HTML conversion completed successfully." -ForegroundColor Green
            }
            catch {
                Write-Warning "Failed to convert JSON to HTML: $($_.Exception.Message)"
            }
        }
        catch {
            $err = "Failed to write JSON to '$OutputPath': $($_.Exception.Message)"
            Write-Err $err
            throw
        }

        # Skip local processing since we did it remotely
        return
    }

    # Local execution continues here for non-remote scenarios
    # Collect OS information directly from the operating system for local execution
    Write-Info "Collecting OS information independently of SQL Server..."
    $script:Result.OSInfo = Get-OSInformation -ComputerName $env:COMPUTERNAME

    # --- FailoverClusters module (PS5.1-friendly) ---
    try {
        Import-Module FailoverClusters -ErrorAction Stop
        Write-Info "FailoverClusters module loaded."
    }
    catch {
        $msg = "FailoverClusters module not found/loaded. Only SQL section (if any) can be exported."
        Write-Warn $msg
        $Result.Warnings += $msg
    }

    # --- Connect to cluster ---
    $clusterObj = $null
    if (Get-Module FailoverClusters) {
        try {
            if ($RemoteServer) {
                # Remote cluster connection using current Windows credentials
                $clusterObj = if ([string]::IsNullOrWhiteSpace($ClusterName)) {
                    Write-Info "Attempting to discover cluster on remote server: $RemoteServer"
                    # Try to get cluster from remote server
                    Get-Cluster -ErrorAction Stop
                }
                else {
                    Write-Info "Connecting to remote cluster: $ClusterName"
                    Get-Cluster -Name $ClusterName -ErrorAction Stop
                }
            }
            else {
                # Local cluster connection
                $clusterObj = if ([string]::IsNullOrWhiteSpace($ClusterName)) {
                    Get-Cluster -ErrorAction Stop
                }
                else {
                    Get-Cluster -Name $ClusterName -ErrorAction Stop
                }
            }
            Write-Info ("Successfully connected to cluster: {0}" -f $clusterObj.Name)
        }
        catch {
            $targetLocation = if ($RemoteServer) { "remote server '$RemoteServer'" } else { "local machine" }
            $clusterTarget = if ($ClusterName) { "'$ClusterName'" } else { "(auto-discover)" }
            $err = "Unable to connect to cluster $clusterTarget on $targetLocation using current Windows credentials: $($_.Exception.Message)"
            Write-Err $err
            $Result.Errors += $err
        }
    }
    try {
        Import-Module FailoverClusters -ErrorAction Stop
        Write-Info "FailoverClusters module loaded."
    }
    catch {
        $msg = "FailoverClusters module not found/loaded. Only SQL section (if any) can be exported."
        Write-Warn $msg
        $Result.Warnings += $msg
    }

    # --- Connect to cluster ---
    $clusterObj = $null
    if (Get-Module FailoverClusters) {
        try {
            if ($RemoteServer) {
                # Remote cluster connection using current Windows credentials
                $clusterObj = if ([string]::IsNullOrWhiteSpace($ClusterName)) {
                    Write-Info "Attempting to discover cluster on remote server: $RemoteServer"
                    # Try to get cluster from remote server
                    Get-Cluster -ErrorAction Stop
                }
                else {
                    Write-Info "Connecting to remote cluster: $ClusterName"
                    Get-Cluster -Name $ClusterName -ErrorAction Stop
                }
            }
            else {
                # Local cluster connection
                $clusterObj = if ([string]::IsNullOrWhiteSpace($ClusterName)) {
                    Get-Cluster -ErrorAction Stop
                }
                else {
                    Get-Cluster -Name $ClusterName -ErrorAction Stop
                }
            }
            Write-Info ("Successfully connected to cluster: {0}" -f $clusterObj.Name)
        }
        catch {
            $targetLocation = if ($RemoteServer) { "remote server '$RemoteServer'" } else { "local machine" }
            $clusterTarget = if ($ClusterName) { "'$ClusterName'" } else { "(auto-discover)" }
            $err = "Unable to connect to cluster $clusterTarget on $targetLocation using current Windows credentials: $($_.Exception.Message)"
            Write-Err $err
            $Result.Errors += $err
        }
    }

    # --- WSFC collection (PS5-safe props only) ---
    if ($clusterObj) {
        try {
            # Cluster parameters
            $clusterParams = @()
            try {
                # Get-ClusterParameter with InputObject parameter (excluding security descriptors)
                $clusterParams = (Get-ClusterParameter -InputObject $clusterObj | Sort-Object Name) | Where-Object { $_.Name -notin @('SharedVolumeSecurityDescriptor', 'SecurityDescriptor') } | ForEach-Object {
                    [ordered]@{ Name = $_.Name; Value = $_.Value }
                }
            }
            catch { $Result.Warnings += "Failed to read cluster parameters: $($_.Exception.Message)" }

            # Quorum
            $quorum = [ordered]@{}
            try {
                $q = Get-ClusterQuorum
                # Only include fields that exist commonly in PS5 era
                $quorum.Type = $q.QuorumType
                $quorum.Resource = $q.QuorumResource
                if ($q.PSObject.Properties.Name -contains 'WitnessShare') { $quorum.WitnessShare = $q.WitnessShare }
            }
            catch { $Result.Warnings += "Failed to read quorum info: $($_.Exception.Message)" }

            # Nodes (PS5-safe fields)
            $nodes = @()
            try {
                $nodes = Get-ClusterNode | ForEach-Object {
                    $n = $_
                    [ordered]@{
                        Name          = $n.Name
                        State         = $n.State
                        ID            = $n.Id
                        NodeWeight    = $n.NodeWeight
                        DynamicWeight = $n.DynamicWeight
                    }
                }
            }
            catch { $Result.Warnings += "Failed to read nodes: $($_.Exception.Message)" }

            # Networks
            $networks = @()
            try {
                $networks = Get-ClusterNetwork | ForEach-Object {
                    $nw = $_
                    [ordered]@{
                        Name        = $nw.Name
                        Role        = $nw.Role
                        State       = $nw.State
                        Metric      = $nw.Metric
                        AutoMetric  = $nw.AutoMetric
                        Address     = $nw.Address
                        AddressMask = $nw.AddressMask
                        Description = $nw.Description
                    }
                }
            }
            catch { $Result.Warnings += "Failed to read networks: $($_.Exception.Message)" }

            # Groups & Resources (PS5-safe) + dependencies via Get-ClusterResourceDependency
            $groups = @()
            try {
                $groups = Get-ClusterGroup | ForEach-Object {
                    $g = $_
                    $resList = @()
                    try {
                        $resList = Get-ClusterResource | Where-Object { $_.OwnerGroup -eq $g.Name } | ForEach-Object {
                            $r = $_

                            $params = @()
                            $privProps = @()

                            if ($IncludeVerboseResourceProps) {
                                try {
                                    $params = (Get-ClusterParameter -InputObject $r -ErrorAction Stop) |
                                    Where-Object { $_.Name -notin @('SharedVolumeSecurityDescriptor', 'SecurityDescriptor') } |
                                    Sort-Object Name | ForEach-Object {
                                        [ordered]@{ Name = $_.Name; Value = $_.Value }
                                    }
                                }
                                catch {
                                    $Result.Warnings += "Failed to read parameters for resource '$($r.Name)': $($_.Exception.Message)"
                                }

                                # Private params are not always supported; guard strictly
                                try {
                                    $privTry = Get-ClusterParameter -InputObject $r -Private -ErrorAction Stop
                                    if ($privTry) {
                                        $privProps = $privTry | Where-Object { $_.Name -notin @('SharedVolumeSecurityDescriptor', 'SecurityDescriptor') } | Sort-Object Name | ForEach-Object {
                                            [ordered]@{ Name = $_.Name; Value = $_.Value }
                                        }
                                    }
                                }
                                catch { }
                            }

                            # Dependencies (expression style)
                            $deps = @()
                            try {
                                $depObjs = Get-ClusterResourceDependency -Resource $r -ErrorAction SilentlyContinue
                                if ($depObjs) {
                                    $deps = $depObjs | ForEach-Object {
                                        [string]$_.DependencyExpression
                                    }
                                }
                            }
                            catch { }

                            [ordered]@{
                                Name              = $r.Name
                                Type              = $r.ResourceType
                                State             = $r.State
                                OwnerGroup        = $r.OwnerGroup
                                OwnerNode         = $r.OwnerNode
                                IsCore            = $r.CoreResource
                                PersistentState   = $r.PersistentState
                                Parameters        = $params
                                PrivateProperties = $privProps
                                Dependencies      = $deps
                            }
                        }
                    }
                    catch {
                        $Result.Warnings += "Failed to read resources for group '$($g.Name)': $($_.Exception.Message)"
                    }

                    [ordered]@{
                        Name        = $g.Name
                        Id          = $g.Id
                        State       = $g.State
                        OwnerNode   = $g.OwnerNode
                        IsCoreGroup = $g.CoreGroup
                        Resources   = $resList
                    }
                }
            }
            catch {
                $Result.Warnings += "Failed to read groups/resources: $($_.Exception.Message)"
            }

            # Storage (disk-like resources)
            $storage = @()
            try {
                $storage = Get-ClusterResource |
                Where-Object { $_.ResourceType -match 'Disk' } |
                ForEach-Object {
                    [ordered]@{
                        Name       = $_.Name
                        Type       = $_.ResourceType
                        State      = $_.State
                        OwnerGroup = $_.OwnerGroup
                        OwnerNode  = $_.OwnerNode
                    }
                }
            }
            catch { $Result.Warnings += "Failed to enumerate storage resources: $($_.Exception.Message)" }

            # AG Listener Configuration (detailed listener port and IP information)
            $agListenerConfig = [ordered]@{}
            try {
                Write-Info "Collecting AG Listener configuration details..."

                # 1) Pull resources first (avoid piping Get-ClusterResource directly)
                $all = Get-ClusterResource -ErrorAction Stop

                # 2) Find the AG resource robustly
                $agRes = $all | Where-Object { $_.ResourceType -eq 'SQL Server Availability Group' } | Select-Object -First 1
                if (-not $agRes) {
                    # Some builds/locales return a slightly different type string; match loosely
                    $agRes = $all | Where-Object { ($_.ResourceType -like 'SQL Server Availability Group*') -or ($_.Name -match 'AG|Availability') } | Select-Object -First 1
                }

                if ($agRes) {
                    # 3) Use the AG's owner group to find the listener network name
                    $agGroup = $agRes.OwnerGroup
                    $listenerNN = $all | Where-Object { $_.OwnerGroup -eq $agGroup -and $_.ResourceType -eq 'Network Name' } | Select-Object -First 1

                    if ($listenerNN) {
                        # 4) Get the dependent IP resource (where ProbePort lives)
                        $listenerIp = $null
                        try {
                            $listenerIp = (Get-ClusterResourceDependency -Resource $listenerNN.Name -ErrorAction SilentlyContinue) |
                            Where-Object ResourceType -eq 'IP Address' | Select-Object -First 1
                        }
                        catch {
                            # Fallback: find IP in same group
                            $listenerIp = $all | Where-Object { $_.OwnerGroup -eq $agGroup -and $_.ResourceType -eq 'IP Address' } | Select-Object -First 1
                        }

                        if (-not $listenerIp) {
                            $listenerIp = $all | Where-Object { $_.OwnerGroup -eq $agGroup -and $_.ResourceType -eq 'IP Address' } | Select-Object -First 1
                        }

                        if ($listenerIp) {
                            # 5) Get the key values
                            $dns = $null
                            $addr = $null
                            $probe = $null

                            try {
                                $dns = (Get-ClusterParameter -InputObject $listenerNN | Where-Object Name -eq 'DnsName').Value
                            }
                            catch { $Result.Warnings += "Failed to get listener DNS name: $($_.Exception.Message)" }

                            try {
                                $ipParams = Get-ClusterParameter -InputObject $listenerIp
                                $addr = ($ipParams | Where-Object Name -eq 'Address').Value
                                $probe = ($ipParams | Where-Object Name -eq 'ProbePort').Value
                            }
                            catch { $Result.Warnings += "Failed to get listener IP parameters: $($_.Exception.Message)" }

                            $agListenerConfig = [ordered]@{
                                AGResourceName         = $agRes.Name
                                AGGroupName            = $agGroup.Name
                                ListenerResourceName   = $listenerNN.Name
                                ListenerDNSName        = $dns
                                ListenerIPResourceName = $listenerIp.Name
                                ListenerIPAddress      = $addr
                                ListenerProbePort      = $probe
                                AGResourceState        = $agRes.State
                                ListenerResourceState  = $listenerNN.State
                                IPResourceState        = $listenerIp.State
                            }

                            Write-Info "Found AG Listener: $dns at $addr with ProbePort $probe"
                        }
                        else {
                            $Result.Warnings += "No IP Address resource found for AG listener '$($listenerNN.Name)'"
                        }
                    }
                    else {
                        $Result.Warnings += "No Network Name (listener) found in AG group '$($agGroup.Name)'"
                    }
                }
                else {
                    Write-Info "No SQL Server Availability Group resource found in cluster"
                }

            }
            catch {
                $Result.Warnings += "Failed to collect AG Listener configuration: $($_.Exception.Message)"
            }

            # --- Enhanced Cluster Listener Detection ---
            $clusterListeners = @()
            try {
                Write-Info "Collecting comprehensive cluster listener information..."

                # Get all cluster resources
                $all = Get-ClusterResource -ErrorAction Stop

                # Get all Network Name resources (potential listeners)
                $networkNameResources = $all | Where-Object ResourceType -eq 'Network Name'

                foreach ($nnRes in $networkNameResources) {
                    try {
                        $listenerInfo = [ordered]@{
                            ResourceName    = $nnRes.Name
                            ResourceType    = $nnRes.ResourceType
                            OwnerGroup      = $nnRes.OwnerGroup
                            State           = $nnRes.State
                            DnsName         = $null
                            IPAddress       = $null
                            ProbePort       = $null
                            AssociatedPorts = @()
                        }

                        # Get DNS name
                        try {
                            $dnsParam = Get-ClusterParameter -InputObject $nnRes | Where-Object Name -eq 'DnsName'
                            $listenerInfo.DnsName = $dnsParam.Value
                        }
                        catch { }

                        # Find associated IP Address resources
                        $ipResources = @()
                        try {
                            # Get dependencies
                            $ipResources = (Get-ClusterResourceDependency -Resource $nnRes.Name -ErrorAction SilentlyContinue) |
                            Where-Object ResourceType -eq 'IP Address'
                        }
                        catch { }

                        # Fallback: find IP resources in the same group
                        if (-not $ipResources) {
                            $ipResources = $all | Where-Object { $_.OwnerGroup -eq $nnRes.OwnerGroup -and $_.ResourceType -eq 'IP Address' }
                        }

                        foreach ($ipRes in $ipResources) {
                            try {
                                $ipParams = Get-ClusterParameter -InputObject $ipRes
                                $address = ($ipParams | Where-Object Name -eq 'Address').Value
                                $probePort = ($ipParams | Where-Object Name -eq 'ProbePort').Value

                                if ($address) {
                                    $listenerInfo.IPAddress = $address
                                }
                                if ($probePort) {
                                    $listenerInfo.ProbePort = $probePort
                                    $listenerInfo.AssociatedPorts += "ProbePort: $probePort"
                                }

                                # Check for any other port-related parameters
                                $portParams = $ipParams | Where-Object { $_.Name -like '*Port*' -or $_.Name -like '*port*' }
                                foreach ($portParam in $portParams) {
                                    if ($portParam.Name -ne 'ProbePort' -and $portParam.Value) {
                                        $listenerInfo.AssociatedPorts += "$($portParam.Name): $($portParam.Value)"
                                    }
                                }
                            }
                            catch {
                                $Result.Warnings += "Failed to get IP parameters for $($ipRes.Name): $($_.Exception.Message)"
                            }
                        }

                        $clusterListeners += $listenerInfo

                        if ($listenerInfo.ProbePort) {
                            Write-Info "Found cluster listener: $($listenerInfo.DnsName) with ProbePort $($listenerInfo.ProbePort)"
                        }
                    }
                    catch {
                        $Result.Warnings += "Failed to process Network Name resource $($nnRes.Name): $($_.Exception.Message)"
                    }
                }

            }
            catch {
                $Result.Warnings += "Failed to collect comprehensive cluster listener information: $($_.Exception.Message)"
            }

            # Cluster object (stick to broadly available props)
            $dnsSuffix = $null
            if ($clusterObj.PSObject.Properties.Name -contains 'DNSDomain') { $dnsSuffix = $clusterObj.DNSDomain }

            $Result.Cluster = [ordered]@{
                Name             = $clusterObj.Name
                Description      = $clusterObj.Description
                Id               = $clusterObj.Id
                DnsSuffix        = $dnsSuffix
                Quorum           = $quorum
                Parameters       = $clusterParams
                Nodes            = $nodes
                Networks         = $networks
                Groups           = $groups
                Storage          = $storage
                AGListenerConfig = $agListenerConfig
                ClusterListeners = $clusterListeners
            }

        }
        catch {
            $err = "Unhandled error while collecting WSFC details: $($_.Exception.Message)"
            Write-Err $err
            $Result.Errors += $err
        }
    }

    # --- Detect local SQL instances if none specified ---
    if (-not $SqlInstance -or $SqlInstance.Count -eq 0) {
        $targetServer = if ($RemoteServer) { $RemoteServer } else { "localhost" }
        Write-Info "No SQL instances specified, attempting to detect instances on $targetServer..."
        $detectedInstances = @()

        try {
            if ($RemoteServer) {
                # Remote detection using current Windows credentials
                Write-Info "Detecting SQL instances remotely on $RemoteServer using current Windows credentials..."

                # Method 1: Remote registry check
                try {
                    $regPath = "SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"
                    $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $RemoteServer)
                    $regKey = $reg.OpenSubKey($regPath)
                    if ($regKey) {
                        $valueNames = $regKey.GetValueNames()
                        foreach ($valueName in $valueNames) {
                            if ($valueName -eq "MSSQLSERVER") {
                                $detectedInstances += $RemoteServer
                            }
                            else {
                                $detectedInstances += "$RemoteServer\$valueName"
                            }
                        }
                        $regKey.Close()
                    }
                    $reg.Close()
                }
                catch {
                    Write-Warn "Remote registry access failed: $($_.Exception.Message)"
                }

                # Method 2: Remote service check using WMI with current credentials
                try {
                    $sqlServices = Get-WmiObject -Class Win32_Service -ComputerName $RemoteServer -Filter "Name LIKE 'MSSQL%' AND State = 'Running'" -ErrorAction SilentlyContinue
                    foreach ($service in $sqlServices) {
                        if ($service.Name -eq "MSSQLSERVER") {
                            if ($RemoteServer -notin $detectedInstances) {
                                $detectedInstances += $RemoteServer
                            }
                        }
                        elseif ($service.Name -like "MSSQL`$*") {
                            $instanceName = $service.Name -replace "MSSQL`$", ""
                            $fullInstanceName = "$RemoteServer\$instanceName"
                            if ($fullInstanceName -notin $detectedInstances) {
                                $detectedInstances += $fullInstanceName
                            }
                        }
                    }
                }
                catch {
                    Write-Warn "Remote WMI service check failed: $($_.Exception.Message)"
                }
            }
            else {
                # Local detection (existing logic)
                # Method 1: Check registry for installed instances
                $regPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"
                if (Test-Path $regPath) {
                    $instances = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue
                    if ($instances) {
                        foreach ($prop in $instances.PSObject.Properties) {
                            if ($prop.Name -ne "PSPath" -and $prop.Name -ne "PSParentPath" -and $prop.Name -ne "PSChildName" -and $prop.Name -ne "PSDrive" -and $prop.Name -ne "PSProvider") {
                                if ($prop.Name -eq "MSSQLSERVER") {
                                    $detectedInstances += "localhost"
                                }
                                else {
                                    $detectedInstances += "localhost\$($prop.Name)"
                                }
                            }
                        }
                    }
                }

                # Method 2: Check for running SQL Server services
                $sqlServices = Get-Service -Name "MSSQL*" -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Running" }
                foreach ($service in $sqlServices) {
                    if ($service.Name -eq "MSSQLSERVER") {
                        if ("localhost" -notin $detectedInstances) {
                            $detectedInstances += "localhost"
                        }
                    }
                    elseif ($service.Name -match "MSSQL\$(.+)") {
                        $instanceName = "localhost\$($Matches[1])"
                        if ($instanceName -notin $detectedInstances) {
                            $detectedInstances += $instanceName
                        }
                    }
                }
            }

            if ($detectedInstances.Count -gt 0) {
                # Remove duplicates - prefer named server over localhost
                $deduplicatedInstances = @()
                $hasNamedInstance = $false

                # Check if we have a named server instance (not localhost)
                foreach ($inst in $detectedInstances) {
                    if ($inst -ne "localhost" -and $inst -notlike "localhost\*") {
                        $hasNamedInstance = $true
                        $deduplicatedInstances += $inst
                    }
                }

                # If we don't have named instances, keep localhost entries
                if (-not $hasNamedInstance) {
                    $deduplicatedInstances = $detectedInstances
                }
                else {
                    # Also add named instances of localhost if they don't conflict
                    foreach ($inst in $detectedInstances) {
                        if ($inst -like "localhost\*") {
                            $instancePart = $inst.Replace("localhost\", "")
                            $namedEquivalent = "$targetServer\$instancePart"
                            if ($namedEquivalent -notin $deduplicatedInstances) {
                                $deduplicatedInstances += $inst
                            }
                        }
                    }
                }

                $SqlInstance = $deduplicatedInstances
                Write-Info "Detected SQL instances: $($SqlInstance -join ', ')"
            }
            else {
                Write-Info "No SQL instances detected on $targetServer."
            }
        }
        catch {
            $warn = "Failed to detect SQL instances on ${targetServer}: $($_.Exception.Message)"
            Write-Warn $warn
            $Result.Warnings += $warn
        }
    }

    # --- SQL AG (using .NET SqlConnection as primary method) ---
    if ($SqlInstance -and $SqlInstance.Count -gt 0) {
        $useDotNetMethod = $false
        $haveSqlCmd = $false
        $useSqlcmdFallback = $false

        # Try .NET SqlConnection first (most reliable, always available)
        try {
            [System.Data.SqlClient.SqlConnection] | Out-Null
            $useDotNetMethod = $true
            Write-Info "Using .NET SqlConnection for SQL Server queries (primary method)."
        }
        catch {
            # Fallback to SqlServer module
            try {
                # try the legacy name
                if (Import-AvailableSqlModule -TryInstall:$ForceInstall) {
                    Write-Info "SQL module loaded successfully."
                }
                else {
                    $sqlModuleError = if ($ForceInstall) { "SQL PowerShell module not available and installation failed." } else { "SQL PowerShell module not available. ForceInstall is not set, so installation was skipped." }
                    Write-Err $sqlModuleError
                    throw $sqlModuleError
                }

                $haveSqlCmd = $true
                Write-Info ".NET SqlConnection not available, using SqlServer module fallback."
            }
            catch {
                # Final fallback to sqlcmd
                try {
                    Get-Command sqlcmd -ErrorAction Stop | Out-Null
                    $useSqlcmdFallback = $true
                    Write-Info "Neither .NET SqlConnection nor SqlServer module available, using sqlcmd fallback."
                }
                catch {
                    $warn = "No SQL query methods available (.NET SqlConnection, SqlServer module, or sqlcmd); skipping SQL AG query."
                    Write-Warn $warn
                    $Result.Warnings += $warn
                }
            }
        }

        if ($useDotNetMethod -or $haveSqlCmd -or $useSqlcmdFallback) {
            $tsql = @"
SET NOCOUNT ON;

-- Availability Groups basic info (SQL Server 2016 compatible)
SELECT
    GETDATE() AS SnapshotTime,
    @@SERVERNAME AS ServerName,
    SERVERPROPERTY('ServerName') AS ServerName_Property,
    SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS PhysicalServerName,
    ag.group_id,
    ag.name AS AGName,
    ag.resource_id,
    ag.failure_condition_level,
    ag.health_check_timeout,
    ag.automated_backup_preference_desc,
    CAST(NULL AS bit) AS basic_features,
    'WSFC' AS cluster_type_desc,
    CAST(NULL AS bit) AS db_failover,
    CAST(NULL AS bit) AS dtc_support,
    CAST(NULL AS bit) AS is_distributed
FROM sys.availability_groups AS ag;

-- Availability Replicas with detailed state info (SQL Server 2016 compatible)
SELECT
    ar.replica_id,
    ag.name AS AGName,
    ar.replica_server_name,
    ar.endpoint_url,
    ar.availability_mode_desc,
    ar.failover_mode_desc,
    CAST(NULL AS nvarchar(60)) AS seeding_mode_desc,
    ar.session_timeout,
    ar.primary_role_allow_connections_desc,
    ar.secondary_role_allow_connections_desc,
    ar.backup_priority,
    ar.read_only_routing_url,
    ars.role_desc,
    ars.connected_state_desc,
    ars.operational_state_desc,
    ars.synchronization_health_desc,
    ars.recovery_health_desc,
    ars.synchronization_state_desc,
    ars.last_connect_error_number,
    ars.last_connect_error_description,
    ars.last_connect_error_timestamp
FROM sys.availability_groups ag
JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
LEFT JOIN sys.dm_hadr_availability_replica_states ars ON ar.replica_id = ars.replica_id;

-- Database replica states with performance metrics (SQL Server 2016 compatible)
SELECT
    ag.name AS AGName,
    ar.replica_server_name,
    adc.database_name,
    d.state_desc AS database_state_desc,
    adrs.database_id,
    adrs.is_local,
    adrs.is_primary_replica,
    adrs.synchronization_state_desc,
    adrs.synchronization_health_desc,
    adrs.database_state_desc as replica_database_state,
    adrs.is_commit_participant,
    adrs.is_suspended,
    adrs.suspend_reason_desc,
    adrs.recovery_lsn,
    adrs.truncation_lsn,
    adrs.last_sent_lsn,
    adrs.last_sent_time,
    adrs.last_received_lsn,
    adrs.last_received_time,
    adrs.last_hardened_lsn,
    adrs.last_hardened_time,
    adrs.last_redone_lsn,
    adrs.last_redone_time,
    adrs.log_send_queue_size,
    adrs.log_send_rate,
    adrs.redo_queue_size,
    adrs.redo_rate,
    adrs.filestream_send_rate,
    CASE
        WHEN adrs.last_sent_time IS NOT NULL AND adrs.last_hardened_time IS NOT NULL
        THEN DATEDIFF(second, adrs.last_hardened_time, adrs.last_sent_time)
        ELSE NULL
    END AS lag_seconds
FROM sys.availability_groups ag
JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
JOIN sys.availability_databases_cluster adc ON ag.group_id = adc.group_id
LEFT JOIN sys.databases d ON adc.database_name = d.name
LEFT JOIN sys.dm_hadr_database_replica_states adrs ON adc.database_name = DB_NAME(adrs.database_id) AND ar.replica_id = adrs.replica_id
ORDER BY ag.name, ar.replica_server_name, adc.database_name;

-- AG Listeners with detailed network info
SELECT
    agl.listener_id,
    ag.name AS AGName,
    agl.dns_name AS ListenerDNSName,
    agl.port AS ListenerPort,
    agl.is_conformant,
    agl.ip_configuration_string_from_cluster
FROM sys.availability_groups ag
LEFT JOIN sys.availability_group_listeners agl ON ag.group_id = agl.group_id;

-- Listener IP addresses
SELECT
    agl.listener_id,
    ag.name AS AGName,
    agl.dns_name AS ListenerDNSName,
    ip.ip_address,
    ip.ip_subnet_mask,
    ip.network_subnet_ip,
    ip.network_subnet_prefix_length,
    ip.network_subnet_ipv4_mask,
    ip.state_desc as ip_state_desc,
    ip.is_dhcp
FROM sys.availability_groups ag
LEFT JOIN sys.availability_group_listeners agl ON ag.group_id = agl.group_id
LEFT JOIN sys.availability_group_listener_ip_addresses ip ON agl.listener_id = ip.listener_id;

-- Read-only routing lists
SELECT
    ag.name AS AGName,
    ar.replica_server_name,
    rr.routing_priority,
    rr.read_only_replica_id,
    ar2.replica_server_name AS read_only_replica_server_name
FROM sys.availability_groups ag
JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
LEFT JOIN sys.availability_read_only_routing_lists rr ON ar.replica_id = rr.replica_id
LEFT JOIN sys.availability_replicas ar2 ON rr.read_only_replica_id = ar2.replica_id
ORDER BY ag.name, ar.replica_server_name, rr.routing_priority;

-- AG Health (SQL Server 2016 compatible - using available DMVs)
SELECT
    'AGHealth' AS Category,
    ag.name AS AGName,
    'Available' AS ag_status,
    'Data collection from SQL Server 2016' AS status_desc
FROM sys.availability_groups ag;
"@

            foreach ($instance in $SqlInstance) {
                Write-Info "Querying SQL instance: $instance"
                try {
                    $sqlParams = @{
                        ServerInstance = $instance
                        ErrorAction    = 'Stop'
                    }
                    # Use SQL credentials if provided, otherwise use current Windows credentials (Integrated Security)
                    if ($SqlCredential) {
                        $sqlParams.Credential = $SqlCredential
                    }
                    else {
                        # Let SQL Server use current Windows credentials (default behavior)
                        Write-Info "Using current Windows credentials for SQL Server authentication"
                    }

                    # Execute individual SQL queries with error handling
                    $allResults = Invoke-SqlQueriesWithErrorHandling -ServerInstance $instance -SqlQueries $script:SqlQueries -UseDotNetMethod $useDotNetMethod -HaveSqlCmd $haveSqlCmd -UseSqlcmdFallback $useSqlcmdFallback -SqlParams $sqlParams

                    # Group results by Category for processing
                    $categoryGroups = $allResults | Group-Object -Property Category -ErrorAction SilentlyContinue
                    $ds = @{
                        Tables = @()
                    }

                    if ($categoryGroups) {
                        foreach ($group in $categoryGroups) {
                            $ds.Tables += , $group.Group
                        }
                    }
                    else {
                        # If no Category column, treat all as one table
                        if ($allResults) {
                            $ds.Tables += , $allResults
                        }
                    }

                    # Extract data by Category from the grouped results
                    $ag = @()
                    $replicas = @()
                    $dbs = @()
                    $databases = @()
                    $databaseFiles = @()
                    $sqlAgentJobs = @()
                    $serverInfo = @()
                    $backupHistory = @()
                    $endpoints = @()
                    $performanceHealth = @()

                    foreach ($table in $ds.Tables) {
                        $rows = @($table)
                        if ($rows.Count -gt 0) {
                            $firstRow = $rows | Select-Object -First 1
                            if (-not $firstRow) {
                                continue
                            }
                            $category = [string]$firstRow.Category
                            if ([string]::IsNullOrWhiteSpace($category)) {
                                continue
                            }
                            switch ($category) {
                                'AvailabilityGroups' { $ag = $rows }
                                'AGReplicas' { $replicas = $rows }
                                'AGDatabases' { $dbs = $rows }
                                'Databases' { $databases = $rows }
                                'DatabaseFiles' { $databaseFiles = $rows }
                                'SqlAgentJobs' { $sqlAgentJobs = $rows }
                                'ServerInfo' { $serverInfo = $rows }
                                'BackupHistory' { $backupHistory = $rows }
                                'Endpoints' { $endpoints = $rows }
                                default {
                                    # Capture all SQLPerformanceHealth_* categories
                                    if ($category -like 'SQLPerformanceHealth_*') {
                                        $performanceHealth += $rows
                                    }
                                }
                            }
                        }
                    }

                    $agGroups = @()

                    foreach ($row in $ag) {
                        $thisAgName = $row.AGName
                        $agObj = [ordered]@{
                            AGName                    = $thisAgName
                            GroupId                   = $row.group_id
                            ClusterType               = $row.cluster_type_desc
                            FailureConditionLevel     = $row.failure_condition_level
                            HealthCheckTimeoutMs      = $row.health_check_timeout
                            AutomatedBackupPreference = $row.automated_backup_preference_desc
                            BasicFeatures             = $row.basic_features
                            DbFailover                = $row.db_failover
                            DtcSupport                = $row.dtc_support
                            Replicas                  = @()
                            Databases                 = @()
                            Listeners                 = @()
                        }

                        $repRows = $replicas | Where-Object { $_.AGName -eq $thisAgName }
                        foreach ($rr in $repRows) {
                            $agObj.Replicas += [ordered]@{
                                ReplicaId        = $rr.replica_id
                                ServerName       = $rr.replica_server_name
                                AvailabilityMode = $rr.availability_mode_desc
                                FailoverMode     = $rr.failover_mode_desc
                                SeedingMode      = $rr.seeding_mode_desc
                                SessionTimeout   = $rr.session_timeout
                                Role             = $rr.role_desc
                                ConnectedState   = $rr.connected_state_desc
                                OperationalState = $rr.operational_state_desc
                                SyncHealth       = $rr.synchronization_health_desc
                                RecoveryHealth   = $rr.recovery_health_desc
                                SyncState        = $rr.synchronization_state_desc
                            }
                        }

                        $dbRows = $dbs | Where-Object { $_.AGName -eq $thisAgName }
                        foreach ($dr in $dbRows) {
                            $agObj.Databases += [ordered]@{
                                Name  = $dr.database_name
                                State = $dr.database_state_desc
                            }
                        }

                        $lstRows = $listeners | Where-Object { $_.AGName -eq $thisAgName }
                        foreach ($lr in $lstRows) {
                            $ips = @()
                            $ipRows = $listenerIp | Where-Object { $_.listener_id -eq $lr.listener_id }
                            foreach ($ipr in $ipRows) {
                                $ips += [ordered]@{
                                    IPAddress  = $ipr.ip_address
                                    SubnetMask = $ipr.subnet_mask
                                    State      = $ipr.ip_address_state_desc
                                }
                            }
                            $agObj.Listeners += [ordered]@{
                                ListenerDNSName = $lr.ListenerDNSName
                                ListenerPort    = $lr.ListenerPort
                                IPAddresses     = $ips
                            }
                        }

                        $agGroups += $agObj
                    }

                    $Result.Sql += [ordered]@{
                        Instance           = $instance
                        CollectedOnUtc     = (Get-Date).ToUniversalTime().ToString("o")
                        ServerInfo         = if ($serverInfo) { $serverInfo } else { @() }
                        DatabaseInventory  = if ($databases) { $databases } else { @() }
                        DatabaseFiles      = if ($databaseFiles) { $databaseFiles } else { @() }
                        AgentJobs          = if ($sqlAgentJobs) { $sqlAgentJobs } else { @() }
                        AvailabilityGroups = $agGroups
                        AGDatabases        = if ($dbs) { $dbs } else { @() }
                        BackupHistory      = if ($backupHistory) { $backupHistory } else { @() }
                        Endpoints          = if ($endpoints) { $endpoints } else { @() }
                        PerformanceHealth  = if ($performanceHealth) { $performanceHealth } else { @() }
                    }
                }
                catch {
                    $err = "Failed to query SQL instance '$instance': $($_.Exception.Message)"
                    Write-Err $err
                    $Result.Errors += $err
                }
            }
        }
    }

    # --- Write JSON for local execution (PS5.1-safe) ---
    try {
        # Determine the output directory and file name
        $baseOutputDir = Split-Path -Path $OutputPath -Parent
        $fileName = Split-Path -Path $OutputPath -Leaf

        # Try to get the server name from the first SQL instance, fallback to COMPUTERNAME
        $serverNameForDir = $null
        if ($Result.Sql -and $Result.Sql.Count -gt 0) {
            $firstInstance = $Result.Sql[0].Instance
            if ($firstInstance) {
                # Remove instance name if present (e.g., SERVER\INSTANCE)
                $serverNameForDir = $firstInstance.Split('\')[0]
            }
        }
        if (-not $serverNameForDir) {
            $serverNameForDir = $env:COMPUTERNAME
        }

        $finalOutputDir = Join-Path $baseOutputDir $serverNameForDir
        if (-not (Test-Path $finalOutputDir)) {
            New-Item -ItemType Directory -Path $finalOutputDir -Force | Out-Null
        }
        $finalOutputPath = Join-Path $finalOutputDir $fileName

        $json = $script:Result | ConvertTo-Json -Depth 100
        $json | Out-File -FilePath $finalOutputPath -Encoding UTF8

        Write-Host "`nExport complete:" -ForegroundColor Green
        Write-Host "  JSON: $finalOutputPath" -ForegroundColor Green

        # Convert JSON to HTML
        try {
            $htmlScriptPath = Join-Path $PSScriptRoot "Convert-SQLConfigToHTML.ps1"

            if (-not (Test-Path $htmlScriptPath)) {
                Write-Info "HTML converter script not found. JSON export completed; skipping HTML generation."
                return
            }

            Write-Host "`nConverting JSON to HTML..." -ForegroundColor Yellow
            & $htmlScriptPath -JSONFilePath $finalOutputPath
            Write-Host "HTML conversion completed successfully." -ForegroundColor Green
        }
        catch {
            Write-Warning "Failed to convert JSON to HTML: $($_.Exception.Message)"
        }
    }
    catch {
        $err = "Failed to write JSON to '$finalOutputPath': $($_.Exception.Message)"
        Write-Err $err
        throw
    }
}


# Define individual SQL queries with error handling
$script:SqlQueries = @{
    'ServerInfo'           = @"
SET NOCOUNT ON;
SELECT
    'ServerInfo' AS Category,
    GETDATE() AS SnapshotTime,
    @@SERVERNAME AS ServerName,
    SERVERPROPERTY('ServerName') AS ServerName_Property,
    SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS PhysicalServerName,
    SERVERPROPERTY('ProductVersion') AS SQLVersion,
    SERVERPROPERTY('ProductLevel') AS SQLServicePack,
    SERVERPROPERTY('Edition') AS SQLEdition,
    SERVERPROPERTY('EngineEdition') AS EngineEdition,
    SERVERPROPERTY('Collation') AS Collation,
    SERVERPROPERTY('IsHadrEnabled') AS IsHadrEnabled,
    SERVERPROPERTY('HadrManagerStatus') AS HadrManagerStatus,
    SERVERPROPERTY('IsClustered') AS IsClustered,
    (SELECT sqlserver_start_time FROM sys.dm_os_sys_info) AS SQLServerStartTime;
"@
    'Databases'            = @"
SET NOCOUNT ON;
SELECT
    'Databases' AS Category,
    d.name AS DatabaseName,
    d.database_id,
    d.state_desc,
    d.recovery_model_desc,
    d.collation_name,
    CASE d.page_verify_option
        WHEN 0 THEN 'NONE'
        WHEN 1 THEN 'TORN_PAGE_DETECTION'
        WHEN 2 THEN 'CHECKSUM'
        ELSE 'UNKNOWN'
    END AS page_verify_option_desc,
    d.is_encrypted,
    d.is_read_only,
    d.compatibility_level,
    CASE WHEN d.is_in_standby = 1 THEN 'Yes' ELSE 'No' END AS IsInStandby,
    CASE WHEN d.source_database_id IS NOT NULL THEN 'Yes' ELSE 'No' END AS IsSnapshot,
    ISNULL(mf.SizeMB, 0) AS SizeMB,
    ISNULL(mf.DataFiles, 0) AS DataFiles,
    ISNULL(mf.LogFiles, 0) AS LogFiles
FROM sys.databases d
LEFT JOIN (
    SELECT
        database_id,
        SUM(CASE WHEN type = 0 THEN CAST(size AS BIGINT) * 8 / 1024 ELSE 0 END) AS SizeMB,
        COUNT(CASE WHEN type = 0 THEN 1 END) AS DataFiles,
        COUNT(CASE WHEN type = 1 THEN 1 END) AS LogFiles
    FROM sys.master_files
    GROUP BY database_id
) mf ON d.database_id = mf.database_id
WHERE d.database_id > 4 OR d.name IN ('master', 'model', 'msdb', 'tempdb')
ORDER BY d.name;
"@
    'DatabaseFiles'        = @"
SET NOCOUNT ON;
SELECT
    'DatabaseFiles' AS Category,
    d.name AS DatabaseName,
    mf.name AS FileName,
    mf.physical_name AS PhysicalName,
    CASE mf.type
        WHEN 0 THEN 'Data'
        WHEN 1 THEN 'Log'
        WHEN 2 THEN 'FileStream'
        WHEN 3 THEN 'FullText'
        WHEN 4 THEN 'FullText'
    END AS FileType,
    mf.size * 8 / 1024 AS SizeMB,
    CASE mf.max_size
        WHEN -1 THEN 'Unlimited'
        WHEN 268435456 THEN 'Unlimited'
        ELSE CAST(mf.max_size * 8 / 1024 AS VARCHAR(20))
    END AS MaxSizeMB,
    mf.growth AS GrowthIncrement,
    CASE mf.is_percent_growth
        WHEN 1 THEN 'Percent'
        ELSE 'MB'
    END AS GrowthType,
    mf.state_desc AS State
FROM sys.master_files mf
INNER JOIN sys.databases d ON mf.database_id = d.database_id
WHERE d.database_id > 4 OR d.name IN ('master', 'model', 'msdb', 'tempdb')
ORDER BY d.name, mf.type, mf.file_id;
"@
    'SqlAgentJobs'         = @"
SET NOCOUNT ON;
IF (
    HAS_PERMS_BY_NAME('msdb.dbo.sysjobs', 'OBJECT', 'SELECT') = 1
    AND HAS_PERMS_BY_NAME('msdb.dbo.sysjobhistory', 'OBJECT', 'SELECT') = 1
    AND HAS_PERMS_BY_NAME('msdb.dbo.sysjobschedules', 'OBJECT', 'SELECT') = 1
    AND HAS_PERMS_BY_NAME('msdb.dbo.sysschedules', 'OBJECT', 'SELECT') = 1
)
BEGIN
    SELECT
        'SqlAgentJobs' AS Category,
        j.name AS JobName,
        j.job_id,
        j.enabled,
        j.description,
        CASE j.notify_level_email
            WHEN 0 THEN 'Never'
            WHEN 1 THEN 'On Success'
            WHEN 2 THEN 'On Failure'
            WHEN 3 THEN 'Always'
        END AS EmailNotificationLevel,
        s.name AS ScheduleName,
        s.enabled AS ScheduleEnabled,
        jh.run_date AS last_run_date,
        jh.run_time AS last_run_time,
        CASE jh.run_status
            WHEN 0 THEN 'Failed'
            WHEN 1 THEN 'Succeeded'
            WHEN 2 THEN 'Retry'
            WHEN 3 THEN 'Canceled'
            WHEN 4 THEN 'In Progress'
            ELSE 'Unknown'
        END AS LastRunOutcome,
        ISNULL(ns.next_run_date, 0) AS next_run_date,
        ISNULL(ns.next_run_time, 0) AS next_run_time
    FROM msdb.dbo.sysjobs j
    LEFT JOIN (
        SELECT job_id, run_date, run_time, run_status,
               ROW_NUMBER() OVER (PARTITION BY job_id ORDER BY run_date DESC, run_time DESC) as rn
        FROM msdb.dbo.sysjobhistory
        WHERE step_id = 0
    ) jh ON j.job_id = jh.job_id AND jh.rn = 1
    LEFT JOIN msdb.dbo.sysjobschedules js ON j.job_id = js.job_id
    LEFT JOIN msdb.dbo.sysschedules s ON js.schedule_id = s.schedule_id
    LEFT JOIN (
        SELECT job_id, next_run_date, next_run_time
        FROM msdb.dbo.sysjobschedules js2
        INNER JOIN msdb.dbo.sysschedules s2 ON js2.schedule_id = s2.schedule_id
        WHERE s2.enabled = 1
    ) ns ON j.job_id = ns.job_id
    ORDER BY j.name;
END
ELSE
BEGIN
    SELECT TOP 0
        'SqlAgentJobs' AS Category,
        CAST(NULL AS nvarchar(128)) AS JobName,
        CAST(NULL AS uniqueidentifier) AS job_id,
        CAST(NULL AS tinyint) AS enabled,
        CAST(NULL AS nvarchar(512)) AS description,
        CAST(NULL AS nvarchar(20)) AS EmailNotificationLevel,
        CAST(NULL AS nvarchar(128)) AS ScheduleName,
        CAST(NULL AS tinyint) AS ScheduleEnabled,
        CAST(NULL AS int) AS last_run_date,
        CAST(NULL AS int) AS last_run_time,
        CAST(NULL AS nvarchar(20)) AS LastRunOutcome,
        CAST(NULL AS int) AS next_run_date,
        CAST(NULL AS int) AS next_run_time;
END;
"@
    'AvailabilityGroups'   = @"
SET NOCOUNT ON;
IF (OBJECT_ID('sys.availability_groups') IS NOT NULL AND ISNULL(CONVERT(int, SERVERPROPERTY('IsHadrEnabled')), 0) = 1)
BEGIN
    DECLARE @agSql nvarchar(max) =
        N'SELECT ' +
        N'''AvailabilityGroups'' AS Category, ' +
        N'ag.group_id, ag.name AS AGName, ag.resource_id, ag.failure_condition_level, ag.health_check_timeout, ag.automated_backup_preference_desc, ' +
        CASE WHEN COL_LENGTH('sys.availability_groups', 'basic_features') IS NOT NULL THEN N'CAST(ag.basic_features AS bit) AS basic_features, ' ELSE N'CAST(NULL AS bit) AS basic_features, ' END +
        N'''WSFC'' AS cluster_type_desc, ' +
        CASE WHEN COL_LENGTH('sys.availability_groups', 'db_failover') IS NOT NULL THEN N'CAST(ag.db_failover AS bit) AS db_failover, ' ELSE N'CAST(NULL AS bit) AS db_failover, ' END +
        CASE WHEN COL_LENGTH('sys.availability_groups', 'dtc_support') IS NOT NULL THEN N'CAST(ag.dtc_support AS bit) AS dtc_support, ' ELSE N'CAST(NULL AS bit) AS dtc_support, ' END +
        CASE WHEN COL_LENGTH('sys.availability_groups', 'is_distributed') IS NOT NULL THEN N'CAST(ag.is_distributed AS bit) AS is_distributed ' ELSE N'CAST(NULL AS bit) AS is_distributed ' END +
        N'FROM sys.availability_groups AS ag;';

    EXEC sys.sp_executesql @agSql;
END
ELSE
BEGIN
    SELECT TOP 0
        'AvailabilityGroups' AS Category,
        CAST(NULL AS uniqueidentifier) AS group_id,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS uniqueidentifier) AS resource_id,
        CAST(NULL AS int) AS failure_condition_level,
        CAST(NULL AS int) AS health_check_timeout,
        CAST(NULL AS nvarchar(60)) AS automated_backup_preference_desc,
        CAST(NULL AS bit) AS basic_features,
        CAST(NULL AS nvarchar(20)) AS cluster_type_desc,
        CAST(NULL AS bit) AS db_failover,
        CAST(NULL AS bit) AS dtc_support,
        CAST(NULL AS bit) AS is_distributed;
END;
"@
    'AGReplicas'           = @"
SET NOCOUNT ON;
IF (OBJECT_ID('sys.availability_groups') IS NOT NULL AND OBJECT_ID('sys.availability_replicas') IS NOT NULL AND ISNULL(CONVERT(int, SERVERPROPERTY('IsHadrEnabled')), 0) = 1)
BEGIN
    DECLARE @agReplicaSql nvarchar(max) =
        N'SELECT ' +
        N'''AGReplicas'' AS Category, ' +
        N'ag.name AS AGName, ar.replica_server_name, ar.endpoint_url, ar.availability_mode_desc, ar.failover_mode_desc, ' +
        CASE WHEN COL_LENGTH('sys.availability_replicas', 'seeding_mode_desc') IS NOT NULL THEN N'CAST(ar.seeding_mode_desc AS nvarchar(60)) AS seeding_mode_desc, ' ELSE N'CAST(NULL AS nvarchar(60)) AS seeding_mode_desc, ' END +
        N'ar.session_timeout, ar.primary_role_allow_connections_desc, ar.secondary_role_allow_connections_desc, ar.backup_priority, ar.read_only_routing_url, ' +
        N'ISNULL(ars.role_desc, ''UNKNOWN'') AS role_desc, ISNULL(ars.connected_state_desc, ''DISCONNECTED'') AS connected_state_desc, ' +
        N'ISNULL(ars.operational_state_desc, ''NOT_PRIMARY'') AS operational_state_desc, ISNULL(ars.synchronization_health_desc, ''NOT_HEALTHY'') AS synchronization_health_desc, ' +
        N'ISNULL(ars.recovery_health_desc, ''ONLINE_IN_PROGRESS'') AS recovery_health_desc, CASE WHEN ar.replica_server_name = @@SERVERNAME THEN ''Yes'' ELSE ''No'' END AS is_local_replica, ' +
        N'ag.automated_backup_preference_desc AS ag_backup_preference, ag.failure_condition_level AS ag_failure_condition_level, ag.health_check_timeout AS ag_health_check_timeout ' +
        N'FROM sys.availability_groups ag ' +
        N'JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id ' +
        N'LEFT JOIN sys.dm_hadr_availability_replica_states ars ON ar.replica_id = ars.replica_id ' +
        N'ORDER BY ag.name, ar.replica_server_name;';

    EXEC sys.sp_executesql @agReplicaSql;
END
ELSE
BEGIN
    SELECT TOP 0
        'AGReplicas' AS Category,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS nvarchar(128)) AS replica_server_name,
        CAST(NULL AS nvarchar(256)) AS endpoint_url,
        CAST(NULL AS nvarchar(60)) AS availability_mode_desc,
        CAST(NULL AS nvarchar(60)) AS failover_mode_desc,
        CAST(NULL AS nvarchar(60)) AS seeding_mode_desc,
        CAST(NULL AS int) AS session_timeout,
        CAST(NULL AS nvarchar(60)) AS primary_role_allow_connections_desc,
        CAST(NULL AS nvarchar(60)) AS secondary_role_allow_connections_desc,
        CAST(NULL AS tinyint) AS backup_priority,
        CAST(NULL AS nvarchar(256)) AS read_only_routing_url,
        CAST(NULL AS nvarchar(60)) AS role_desc,
        CAST(NULL AS nvarchar(60)) AS connected_state_desc,
        CAST(NULL AS nvarchar(60)) AS operational_state_desc,
        CAST(NULL AS nvarchar(60)) AS synchronization_health_desc,
        CAST(NULL AS nvarchar(60)) AS recovery_health_desc,
        CAST(NULL AS nvarchar(3)) AS is_local_replica,
        CAST(NULL AS nvarchar(60)) AS ag_backup_preference,
        CAST(NULL AS int) AS ag_failure_condition_level,
        CAST(NULL AS int) AS ag_health_check_timeout;
END;
"@
    'AGDatabases'          = @"
SET NOCOUNT ON;
IF (OBJECT_ID('sys.availability_groups') IS NOT NULL AND OBJECT_ID('sys.availability_replicas') IS NOT NULL AND OBJECT_ID('sys.availability_databases_cluster') IS NOT NULL AND ISNULL(CONVERT(int, SERVERPROPERTY('IsHadrEnabled')), 0) = 1)
BEGIN
    SELECT
        'AGDatabases' AS Category,
        AG.name AS AGName,
        AR.replica_server_name,
        DB.database_name,
        ARS.role_desc AS replica_role,
        DBRS.synchronization_state_desc,
        DBRS.synchronization_health_desc,
        CASE WHEN DBRS.is_suspended = 1 THEN 'Yes' ELSE 'No' END AS is_suspended,
        CASE
            WHEN D.database_id IS NOT NULL THEN D.state_desc
            ELSE 'REMOTE'
        END AS database_state_desc,
        (SELECT ar_primary.replica_server_name
         FROM sys.availability_replicas ar_primary
         INNER JOIN sys.dm_hadr_availability_replica_states ars_primary
            ON ar_primary.replica_id = ars_primary.replica_id
         WHERE ar_primary.group_id = AG.group_id
           AND ars_primary.role_desc = 'PRIMARY') AS primary_server_name
    FROM sys.availability_groups AS AG
    INNER JOIN sys.availability_replicas AS AR ON AG.group_id = AR.group_id
    INNER JOIN sys.dm_hadr_availability_replica_states AS ARS ON AR.replica_id = ARS.replica_id
    INNER JOIN sys.dm_hadr_database_replica_states AS DBRS ON AR.replica_id = DBRS.replica_id
    INNER JOIN sys.databases AS D ON DBRS.database_id = D.database_id
    INNER JOIN sys.availability_databases_cluster AS DB
        ON AG.group_id = DB.group_id AND D.name = DB.database_name
    ORDER BY AG.name, AR.replica_server_name, DB.database_name;
END
ELSE
BEGIN
    SELECT TOP 0
        'AGDatabases' AS Category,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS nvarchar(128)) AS replica_server_name,
        CAST(NULL AS sysname) AS database_name,
        CAST(NULL AS nvarchar(60)) AS replica_role,
        CAST(NULL AS nvarchar(60)) AS synchronization_state_desc,
        CAST(NULL AS nvarchar(60)) AS synchronization_health_desc,
        CAST(NULL AS nvarchar(3)) AS is_suspended,
        CAST(NULL AS nvarchar(60)) AS database_state_desc,
        CAST(NULL AS nvarchar(128)) AS primary_server_name;
END;
"@
    'Endpoints'            = @"
SET NOCOUNT ON;
SELECT
    'Endpoints' AS Category,
    e.name AS EndpointName,
    e.endpoint_id,
    e.principal_id,
    e.protocol_desc,
    e.type_desc,
    e.state_desc,
    e.is_admin_endpoint,
    te.port,
    te.ip_address
FROM sys.endpoints e
LEFT JOIN sys.tcp_endpoints te ON e.endpoint_id = te.endpoint_id
WHERE e.type_desc != 'TSQL_DEFAULT_TCP'
ORDER BY e.name;
"@
    'BackupHistory'        = @"
SET NOCOUNT ON;
IF (HAS_PERMS_BY_NAME('msdb.dbo.backupset', 'OBJECT', 'SELECT') = 1 AND HAS_PERMS_BY_NAME('msdb.dbo.backupmediafamily', 'OBJECT', 'SELECT') = 1)
BEGIN
    SELECT
        'BackupHistory' AS Category,
        d.name AS DatabaseName,
        bs.type AS BackupType,
        CASE bs.type
            WHEN 'D' THEN 'Full'
            WHEN 'I' THEN 'Differential'
            WHEN 'L' THEN 'Log'
            WHEN 'F' THEN 'File'
            WHEN 'G' THEN 'Partial'
            WHEN 'P' THEN 'Partial Differential'
            WHEN 'Q' THEN 'Partial Log'
        END AS BackupTypeDesc,
        bs.backup_start_date,
        bs.backup_finish_date,
        bs.backup_size / 1024 / 1024 AS BackupSizeMB,
        bmf.physical_device_name AS BackupPath,
        bs.name AS BackupSetName
    FROM msdb.dbo.backupset bs
    INNER JOIN msdb.dbo.backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
    INNER JOIN sys.databases d ON bs.database_name = d.name
    WHERE bs.backup_start_date >= DATEADD(DAY, -30, GETDATE())
    ORDER BY d.name, bs.backup_start_date DESC;
END
ELSE
BEGIN
    SELECT TOP 0
        'BackupHistory' AS Category,
        CAST(NULL AS sysname) AS DatabaseName,
        CAST(NULL AS char(1)) AS BackupType,
        CAST(NULL AS nvarchar(30)) AS BackupTypeDesc,
        CAST(NULL AS datetime) AS backup_start_date,
        CAST(NULL AS datetime) AS backup_finish_date,
        CAST(NULL AS bigint) AS BackupSizeMB,
        CAST(NULL AS nvarchar(260)) AS BackupPath,
        CAST(NULL AS nvarchar(128)) AS BackupSetName;
END;
"@
    'SQLPerformanceHealth' = @"
SET NOCOUNT ON;

-- SQL Server Memory & Performance Health Deep-Dive Query
-- Returns comprehensive memory, cache, performance counters, wait stats, IO latency, scheduler, and query stats

-- 1. Instance & OS Memory Summary
SELECT
    'SQLPerformanceHealth_MemorySummary' AS Category,
    SERVERPROPERTY('MachineName') AS MachineName,
    SERVERPROPERTY('ServerName') AS ServerName,
    SERVERPROPERTY('InstanceName') AS InstanceName,
    SERVERPROPERTY('ProductVersion') AS ProductVersion,
    SERVERPROPERTY('Edition') AS Edition,
    CONVERT(int, (SELECT value_in_use FROM sys.configurations WHERE name = 'max server memory (MB)')) AS MaxServerMemory_MB,
    CONVERT(int, (SELECT value_in_use FROM sys.configurations WHERE name = 'min server memory (MB)')) AS MinServerMemory_MB,
    sm.total_physical_memory_kb / 1024 AS TotalOSMemory_MB,
    sm.available_physical_memory_kb / 1024 AS OSMemoryFree_MB,
    sm.system_memory_state_desc AS OSMemoryState
FROM sys.dm_os_sys_memory AS sm;

-- 2. SQL Server process memory
SELECT
    'SQLPerformanceHealth_ProcessMemory' AS Category,
    physical_memory_in_use_kb / 1024.0 AS SQLProcessMemoryUsed_MB,
    large_page_allocations_kb / 1024.0 AS LargePageAllocations_MB,
    locked_page_allocations_kb / 1024.0 AS LockedPages_MB,
    total_virtual_address_space_kb / 1024.0 AS TotalVASpace_MB,
    virtual_address_space_reserved_kb / 1024.0 AS VAS_Reserved_MB,
    virtual_address_space_committed_kb / 1024.0 AS VAS_Committed_MB,
    virtual_address_space_available_kb / 1024.0 AS VAS_Available_MB,
    page_fault_count AS PageFaultCount,
    memory_utilization_percentage AS SQLProcessUtilizationPercent,
    process_physical_memory_low AS IsProcessPhysicalMemoryLow,
    process_virtual_memory_low AS IsProcessVirtualMemoryLow
FROM sys.dm_os_process_memory;

-- 3. Committed vs Target Memory
SELECT
    'SQLPerformanceHealth_CommittedMemory' AS Category,
    (committed_kb / 1024.0) AS CommittedMemory_MB,
    (committed_target_kb / 1024.0) AS TargetMemory_MB,
    (committed_kb - committed_target_kb) / 1024.0 AS CommittedMinusTarget_MB
FROM sys.dm_os_sys_info;

-- 4. Memory by Clerk Type (Top 20)
SELECT TOP 20
    'SQLPerformanceHealth_MemoryClerks' AS Category,
    mc.type AS ClerkType,
    mc.memory_node_id AS MemoryNode,
    SUM(mc.pages_kb) / 1024.0 AS Pages_MB,
    SUM(mc.virtual_memory_committed_kb) / 1024.0 AS VirtualMemoryCommitted_MB,
    SUM(mc.awe_allocated_kb) / 1024.0 AS AWEAllocated_MB,
    COUNT(*) AS ClerkCount
FROM sys.dm_os_memory_clerks AS mc
GROUP BY mc.type, mc.memory_node_id
ORDER BY SUM(mc.pages_kb) DESC;

-- 5. Cache Stores Breakdown (Top 20)
SELECT TOP 20
    'SQLPerformanceHealth_CacheStores' AS Category,
    mc.type AS CacheStoreType,
    SUM(mc.pages_kb) / 1024.0 AS CacheStorePages_MB,
    SUM(mc.virtual_memory_committed_kb) / 1024.0 AS CacheStoreVASCommitted_MB,
    COUNT(*) AS EntryCount
FROM sys.dm_os_memory_clerks AS mc
WHERE mc.type LIKE 'CACHESTORE_%'
GROUP BY mc.type
ORDER BY SUM(mc.pages_kb) DESC;

-- 6. Buffer Pool Usage by Database (Top 20)
SELECT TOP 20
    'SQLPerformanceHealth_BufferPoolByDB' AS Category,
    bd.database_id,
    DB_NAME(bd.database_id) AS DatabaseName,
    COUNT(*) AS PageCount,
    COUNT(*) * 8 / 1024.0 AS BufferPool_MB
FROM sys.dm_os_buffer_descriptors AS bd
WHERE bd.database_id <> 32767
GROUP BY bd.database_id
ORDER BY COUNT(*) DESC;

-- 7. Plan Cache Breakdown (Top 20)
SELECT TOP 20
    'SQLPerformanceHealth_PlanCache' AS Category,
    cp.objtype,
    cp.cacheobjtype,
    COUNT(*) AS PlanCount,
    SUM(cp.size_in_bytes) / 1024.0 / 1024.0 AS TotalSize_MB,
    AVG(cp.usecounts * 1.0) AS AvgUseCount
FROM sys.dm_exec_cached_plans AS cp
GROUP BY cp.objtype, cp.cacheobjtype
ORDER BY SUM(cp.size_in_bytes) DESC;

-- 8. Overall Memory Roll-up
SELECT
    'SQLPerformanceHealth_MemoryRollup' AS Category,
    pm.physical_memory_in_use_kb / 1024.0 AS SQLProcessUsed_MB,
    si.committed_kb / 1024.0 AS Committed_MB,
    si.committed_target_kb / 1024.0 AS Target_MB,
    (SELECT SUM(virtual_memory_committed_kb) / 1024.0 FROM sys.dm_os_memory_clerks WHERE type = 'MEMORYCLERK_SQLBUFFERPOOL') AS BufferPool_MB,
    (SELECT SUM(pages_kb)/1024.0 FROM sys.dm_os_memory_clerks WHERE type LIKE 'CACHESTORE_%') AS PlanCache_MB,
    (SELECT SUM(pages_kb)/1024.0 FROM sys.dm_os_memory_clerks) AS AllClerks_MB
FROM sys.dm_os_process_memory pm
CROSS JOIN sys.dm_os_sys_info si;

-- 9. Key Perf Counters
SELECT
    'SQLPerformanceHealth_PerfCounters' AS Category,
    object_name,
    counter_name,
    instance_name,
    cntr_value
FROM sys.dm_os_performance_counters
WHERE
    (object_name LIKE '%Buffer Manager%' AND counter_name IN ('Buffer cache hit ratio','Buffer cache hit ratio base','Lazy writes/sec','Checkpoint pages/sec','Free list stalls/sec'))
    OR (object_name LIKE '%Buffer Node%' AND counter_name IN ('Page life expectancy'))
    OR (object_name LIKE '%Memory Manager%' AND counter_name IN ('Memory Grants Pending','Target Server Memory (KB)','Total Server Memory (KB)'))
    OR (object_name LIKE '%SQL Statistics%' AND counter_name IN ('Batch Requests/sec','SQL Compilations/sec','SQL Re-Compilations/sec'));

-- 10. Top Wait Stats (Top 30)
SELECT TOP 30
    'SQLPerformanceHealth_WaitStats' AS Category,
    wait_type,
    waiting_tasks_count,
    wait_time_ms,
    signal_wait_time_ms,
    wait_time_ms - signal_wait_time_ms AS resource_wait_time_ms,
    wait_time_ms * 1.0 / NULLIF(SUM(wait_time_ms) OVER(), 0) AS pct_of_total
FROM sys.dm_os_wait_stats
WHERE wait_type NOT LIKE 'SLEEP%'
  AND wait_type NOT LIKE 'XE_TIMER_EVENT%'
  AND wait_type NOT LIKE 'BROKER_TASK_STOP%'
  AND wait_type NOT LIKE 'BROKER_TO_FLUSH%'
  AND wait_type NOT LIKE 'BROKER_EVENTHANDLER%'
  AND wait_type NOT LIKE 'SQLTRACE_%'
ORDER BY wait_time_ms DESC;

-- 11. IO Latency per File (Top 50)
SELECT TOP 50
    'SQLPerformanceHealth_IOLatency' AS Category,
    DB_NAME(vfs.database_id) AS DatabaseName,
    vfs.database_id,
    vfs.file_id,
    mf.type_desc AS FileType,
    mf.physical_name,
    vfs.num_of_reads,
    vfs.io_stall_read_ms,
    CASE WHEN vfs.num_of_reads = 0 THEN NULL ELSE vfs.io_stall_read_ms / vfs.num_of_reads END AS avg_read_latency_ms,
    vfs.num_of_writes,
    vfs.io_stall_write_ms,
    CASE WHEN vfs.num_of_writes = 0 THEN NULL ELSE vfs.io_stall_write_ms / vfs.num_of_writes END AS avg_write_latency_ms,
    vfs.io_stall,
    CASE WHEN (vfs.num_of_reads + vfs.num_of_writes) = 0 THEN NULL ELSE vfs.io_stall / (vfs.num_of_reads + vfs.num_of_writes) END AS avg_io_latency_ms
FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs
LEFT JOIN sys.master_files AS mf ON mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id
ORDER BY CASE WHEN (vfs.num_of_reads + vfs.num_of_writes) = 0 THEN NULL ELSE vfs.io_stall / (vfs.num_of_reads + vfs.num_of_writes) END DESC;

-- 12. Scheduler Info
SELECT
    'SQLPerformanceHealth_Schedulers' AS Category,
    scheduler_id,
    cpu_id,
    is_online,
    is_idle,
    current_tasks_count,
    runnable_tasks_count,
    active_workers_count,
    load_factor,
    pending_disk_io_count
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255;

-- 13. Tempdb Usage
SELECT
    'SQLPerformanceHealth_TempdbUsage' AS Category,
    SUM(user_object_reserved_page_count)*8 AS user_object_KB,
    SUM(internal_object_reserved_page_count)*8 AS internal_object_KB,
    SUM(version_store_reserved_page_count)*8 AS version_store_KB,
    SUM(unallocated_extent_page_count)*8 AS unallocated_extent_KB,
    SUM(mixed_extent_page_count)*8 AS mixed_extent_KB
FROM tempdb.sys.dm_db_file_space_usage;

-- 14. Top 10 Queries by CPU
SELECT TOP 10
    'SQLPerformanceHealth_TopCPUQueries' AS Category,
    qs.total_worker_time / 1000.0 AS total_cpu_ms,
    qs.total_worker_time / NULLIF(qs.execution_count,0) / 1000.0 AS avg_cpu_ms,
    qs.execution_count,
    qs.total_logical_reads,
    qs.total_logical_reads / NULLIF(qs.execution_count,0) AS avg_logical_reads,
    qs.total_elapsed_time / 1000.0 AS total_elapsed_ms,
    qs.total_elapsed_time / NULLIF(qs.execution_count,0) / 1000.0 AS avg_elapsed_ms,
    DB_NAME(st.dbid) AS database_name,
    SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
              CASE WHEN qs.statement_end_offset = -1
                   THEN LEN(CONVERT(nvarchar(max), st.text))
                   ELSE (qs.statement_end_offset - qs.statement_start_offset)/2 + 1
              END) AS query_text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
ORDER BY qs.total_worker_time DESC;

-- 15. Top 10 Queries by Logical Reads
SELECT TOP 10
    'SQLPerformanceHealth_TopIOQueries' AS Category,
    qs.total_logical_reads,
    qs.total_logical_reads / NULLIF(qs.execution_count,0) AS avg_logical_reads,
    qs.execution_count,
    qs.total_worker_time / 1000.0 AS total_cpu_ms,
    qs.total_elapsed_time / 1000.0 AS total_elapsed_ms,
    DB_NAME(st.dbid) AS database_name,
    SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
              CASE WHEN qs.statement_end_offset = -1
                   THEN LEN(CONVERT(nvarchar(max), st.text))
                   ELSE (qs.statement_end_offset - qs.statement_start_offset)/2 + 1
              END) AS query_text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
ORDER BY qs.total_logical_reads DESC;
"@
}

# Set default output path if not provided or handle directory path
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $targetServer = if ($RemoteServer) { $RemoteServer } else { $env:COMPUTERNAME }
    $baseDir = "C:\temp"
    $serverDir = Join-Path $baseDir $targetServer
    $OutputPath = Join-Path $serverDir "$($targetServer)_$($CheckTypeShort)_SQL_Config.json"

    # Ensure the server directory exists
    if (-not (Test-Path $serverDir)) {
        try {
            New-Item -ItemType Directory -Path $serverDir -Force | Out-Null
            Write-Info "Created directory: $serverDir"
        }
        catch {
            Write-Err "Failed to create directory '$serverDir': $($_.Exception.Message)"
            throw
        }
    }

    Write-Info "No output path specified, using default: $OutputPath"
}
else {
    # Resolve relative paths to absolute paths using .NET method
    if (-not [System.IO.Path]::IsPathRooted($OutputPath)) {
        $OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
    }

    # Handle case where user provided a directory path instead of full file path
    if ((Test-Path $OutputPath -PathType Container) -or $OutputPath.EndsWith('\') -or $OutputPath.EndsWith('/')) {
        $targetServer = if ($RemoteServer) { $RemoteServer } else { $env:COMPUTERNAME }
        $fileName = "$($targetServer)_$($CheckTypeShort)_SQL_Config.json"
        $OutputPath = Join-Path $OutputPath $fileName
        Write-Info "Directory path provided, using: $OutputPath"
    }

    # Ensure the output directory exists
    $outputDir = Split-Path $OutputPath -Parent
    Write-Info "Output file path: $OutputPath"
    Write-Info "Output directory: $outputDir"

    if (-not (Test-Path $outputDir)) {
        try {
            Write-Info "Creating directory: $outputDir"
            New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
            Write-Info "Successfully created directory: $outputDir"
        }
        catch {
            Write-Err "Failed to create directory '$outputDir': $($_.Exception.Message)"
            Write-Err "Full exception: $($_.Exception.ToString())"
            throw
        }
    }
    else {
        Write-Info "Output directory already exists: $outputDir"
    }
}

$script:Now = Get-Date
$script:Result = [ordered]@{
    Metadata = [ordered]@{
        CollectedOnUtc   = ($Now.ToUniversalTime().ToString("o"))
        CollectedOnLocal = $Now.ToString("o")
        ComputerName     = $env:COMPUTERNAME
        ScriptName       = "Export-SqlClusterConfig.ps1"
        ScriptVersion    = "1.0.1"
        User             = "$($env:USERDOMAIN)\$($env:USERNAME)"
    }
    Cluster  = $null
    Sql      = @()
    OSInfo   = $null
    Notes    = @()
    Warnings = @()
    Errors   = @()
}
# Determine target servers using standardized logic
$targetServers = @()
$MyHostName = (Get-CimInstance -ClassName Win32_ComputerSystem).DNSHostName
if ($RunLocally -or $ServerName -eq "localhost") {
    $targetServers = @($MyHostName)
}
elseif ($ServerName) {
    # Handle comma-separated server names
    if ($ServerName -match ',') {
        $targetServers = $ServerName -split ',' | ForEach-Object { $_.Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    }
    else {
        $targetServers = @($ServerName.Trim())
    }
}
else {
    if (Test-Path $ServerList) {
        try {
            $csv = Import-Csv -Path $ServerList
            foreach ($entry in $csv) {
                # Only include rows that provide an actual host name (Server or ServerName).
                $hostPart = $null
                if ($entry.Server) { $hostPart = $entry.Server }
                elseif ($entry.ServerName) { $hostPart = $entry.ServerName }

                if ($hostPart) {
                    $NewServerNameFQDN = $hostPart
                    if ($entry.DomainName) {
                        $NewServerNameFQDN += "." + $entry.DomainName
                    }
                    $targetServers += $NewServerNameFQDN
                }
                else {
                    # Skip rows that do not contain a host; avoid creating entries like ".domain.com" which yield empty hostnames later
                    continue
                }
            }
        }
        catch {
            Write-Warning "Failed to import CSV. Defaulting to localhost."
            $targetServers = @($MyHostName)
        }
    }
    else {
        Write-Warning "Server list file not found. Defaulting to localhost."
        $targetServers = @($MyHostName)
    }
}
# Normalize the target servers list: trim whitespace, remove empty entries, and deduplicate
$targetServers = $targetServers | ForEach-Object { $_.ToString().Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
Write-Host "Target servers: $($targetServers -join ', ')"

Write-Info "Processing $($targetServers.Count) target server(s)"

# Determine base output directory
$baseOutputDir = if ($OutputPath) {
    # If OutputPath is provided, use it as base directory
    if (Test-Path $OutputPath -PathType Container) {
        $OutputPath
    }
    else {
        Split-Path $OutputPath -Parent
    }
}
else {
    # Default to current directory + "Artifacts"
    Join-Path (Get-Location) "Artifacts"
}

Write-Info "Base output directory: $baseOutputDir"

# Ensure base output directory exists
if (-not (Test-Path $baseOutputDir)) {
    try {
        New-Item -ItemType Directory -Path $baseOutputDir -Force | Out-Null
        Write-Info "Created base output directory: $baseOutputDir"
    }
    catch {
        Write-Err "Failed to create base output directory '$baseOutputDir': $($_.Exception.Message)"
        throw
    }
}

# Process each server
$successCount = 0
$failCount = 0
$totalServers = $targetServers.Count

foreach ($serverFQDN in $targetServers) {
    Write-Info "Processing server $($successCount + $failCount + 1) of $totalServers`: $serverFQDN"

    # Extract hostname from FQDN for directory/file naming
    $serverNameToProcess = if ($serverFQDN -match '\.') {
        $serverFQDN.Split('.')[0]
    }
    else {
        $serverFQDN
    }

    Write-Info "Using hostname '$serverNameToProcess' for output directory"

    # Resolve connect target: try FQDN first, fall back to short hostname if DNS fails
    $connectTarget = $serverFQDN
    if ($serverFQDN -ne $serverNameToProcess) {
        try {
            $dnsCheck = Resolve-DnsName -Name $serverFQDN -Type A -ErrorAction Stop | Where-Object { $_.IPAddress -match '^[0-9]+\.' } | Select-Object -First 1
            if (-not $dnsCheck) {
                $shortCheck = Resolve-DnsName -Name $serverNameToProcess -Type A -ErrorAction Stop | Where-Object { $_.IPAddress -match '^[0-9]+\.' } | Select-Object -First 1
                if ($shortCheck) {
                    Write-Info "FQDN '$serverFQDN' did not resolve; using short hostname '$serverNameToProcess' for connection"
                    $connectTarget = $serverNameToProcess
                }
            }
        }
        catch {
            try {
                $null = Resolve-DnsName -Name $serverNameToProcess -Type A -ErrorAction Stop
                Write-Info "FQDN '$serverFQDN' did not resolve; using short hostname '$serverNameToProcess' for connection"
                $connectTarget = $serverNameToProcess
            }
            catch {
                Write-Warn "Neither FQDN '$serverFQDN' nor short hostname '$serverNameToProcess' resolved via DNS; attempting connection anyway"
            }
        }
    }

    try {
        # Create server-specific output directory.
        # If the caller already resolved a per-server path (e.g. MigrationCheck-DataCollector
        # passes <Artifacts>\<ServerName>), use it directly to avoid double-nesting.
        # Otherwise append <serverName> under the base dir.
        $serverOutputDir = if ($OutputPath -and (Split-Path $baseOutputDir -Leaf) -ieq $serverNameToProcess) {
            $baseOutputDir
        }
        else {
            Join-Path $baseOutputDir $serverNameToProcess
        }
        if (-not (Test-Path $serverOutputDir)) {
            New-Item -ItemType Directory -Path $serverOutputDir -Force | Out-Null
            Write-Info "Created output directory for $serverNameToProcess`: $serverOutputDir"
        }

        # Set server-specific output path
        $serverOutputPath = Join-Path $serverOutputDir "$($serverNameToProcess)_$($CheckTypeShort)_SQL_Config.json"

        Write-Info "Collecting data for server: $serverFQDN (hostname: $serverNameToProcess, connect target: $connectTarget)"
        Write-Info "Output path: $serverOutputPath"

        # Call the main collection function with retry logic (use resolved connect target)
        Export-SqlClusterConfigWithRetry -OutputPath $serverOutputPath -RemoteServer $connectTarget

        $successCount++
        Write-Info "Successfully processed server: $serverNameToProcess"

    }
    catch {
        $failCount++
        Write-Err "Failed to process server '$serverFQDN' (hostname: $serverNameToProcess): $($_.Exception.Message)"
        # Continue with next server instead of stopping
    }
}

Write-Info "Processing completed:"
Write-Info "  Total servers: $totalServers"
Write-Info "  Successful: $successCount"
Write-Info "  Failed: $failCount"

if ($failCount -gt 0) {
    Write-Warn "$failCount servers failed processing. Check error messages above for details."
}
