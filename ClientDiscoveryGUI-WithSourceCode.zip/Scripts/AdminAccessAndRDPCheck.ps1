﻿<#
.SYNOPSIS
    Check RDP (TCP 3389) connectivity, administrative share access (C$), PowerShell remoting, and WMI access for Windows servers.

.DESCRIPTION
    This comprehensive server access validation script tests multiple connectivity methods:
    - Administrative share access (C$ by default, configurable)
    - RDP port connectivity (TCP 3389 by default, configurable)
    - PowerShell remoting (WinRM/WSMan)
    - WMI/CIM access for OS information
    - Port 445 (SMB) connectivity

    **Compatible with Windows PowerShell 5.1+; the client package does not require PowerShell 7 on the operator VM.**

    Test Priority Order:
    1. PowerShell Remoting (Primary access indicator)
    2. WMI Access
    3. Share Access (C$)

    Overall 'Access' status is determined by PowerShell remoting success.

    You can provide either:
      * A CSV file with a column named 'Server' (use -ServerList), OR
      * A single server name (use -ServerName)

    By default the script uses the current logged-on user context and will NOT prompt for credentials.
    Use -UseCreds to be prompted for alternate credentials which will be used for share access, PS remoting, and WMI tests.

    Output:
      * AdminAccessStatus.csv - Detailed results for all servers (unless -NoCsv is specified)
      * AdminAccessStatus.html - Interactive HTML report with filtering and export capabilities

.PARAMETER ServerList
    Path to a CSV file with at least a 'Server' column. The script will auto-detect various column name variants
    (Server, Servername, etc.) and normalize them.

.PARAMETER ServerName
    Single server name to test. Use this parameter set for testing individual servers.

.PARAMETER UseCreds
    Switch. When supplied, prompts for credentials (Get-Credential) and uses them for administrative share access,
    PowerShell remoting, and WMI tests. Without this switch, current user context is used.

.PARAMETER OutputPath
    Directory to place output files (CSV and HTML). Defaults to current directory ('.').

.PARAMETER HtmlOutputPath
    Name or full path for the HTML report file. If not specified, will be auto-generated with datestamp.
    Defaults to 'AdminAccessStatus-{datestamp}.html' in OutputPath\Reports\Access\

.PARAMETER NoCsv
    Switch. Suppresses CSV output generation. Only HTML report will be created.

.PARAMETER RdpPort
    TCP port number to test for RDP connectivity. Defaults to 3389.

.PARAMETER RdpTimeoutMs
    Timeout in milliseconds for RDP port connectivity test. Defaults to 1500ms.

.PARAMETER PsTimeoutSec
    Timeout in seconds for PowerShell remoting tests. Defaults to 5 seconds.

.PARAMETER ShareCandidates
    Array of administrative shares to test. Defaults to @('C$'). You can specify multiple shares like @('C$','D$','ADMIN$').

.PARAMETER FqdnSuffix
    Optional domain suffix to append to server names for additional connectivity attempts.
    Useful when servers might need FQDN resolution.

.PARAMETER Diagnostics
    Switch. Enables additional diagnostic output and DNS resolution attempts for troubleshooting.

.PARAMETER MaxConcurrent
    Maximum number of concurrent checks for job-based processing where supported.
    Defaults to 8. Set to 1 for sequential processing. (Currently disabled for VS Code compatibility)

.OUTPUTS
    CSV File: Contains columns for Server, AdminAccess, ShareStatus, RDPPort, PSRemoting, WmiStatus, errors, and diagnostics
    HTML File: Interactive report with filtering, sorting, status pills, and failed server export functionality

.EXAMPLES
    # Basic usage with CSV file
    .\AdminAccessAndRDPCheck.ps1 -ServerList .\serverlist.csv

    # Test single server
    .\AdminAccessAndRDPCheck.ps1 -ServerName MyServer01

    # Use alternate credentials and custom output location
    .\AdminAccessAndRDPCheck.ps1 -ServerList .\servers.csv -UseCreds -OutputPath C:\Reports

    # Test with custom RDP port and domain suffix
    .\AdminAccessAndRDPCheck.ps1 -ServerList .\servers.csv -RdpPort 3390 -FqdnSuffix "contoso.com"

    # Generate only HTML report (no CSV)
    .\AdminAccessAndRDPCheck.ps1 -ServerList .\servers.csv -NoCsv -HtmlOutputPath "AccessReport.html"

    # Test multiple share types with diagnostics
    .\AdminAccessAndRDPCheck.ps1 -ServerList .\servers.csv -ShareCandidates @('C$','D$','ADMIN$') -Diagnostics

    # Sequential processing with custom timeouts
    .\AdminAccessAndRDPCheck.ps1 -ServerList .\servers.csv -MaxConcurrent 1 -RdpTimeoutMs 3000 -PsTimeoutSec 10

.NOTES
    Original Authors: Prashant Budhalakoti /
    Maintainer: Avanade - Cloud Managed Services

    CSV Requirements:
    - Must contain a column with 'Server' in the name (case-insensitive)
    - Supported column variants: Server, Servername, server, SERVERNAME, etc.
    - Empty server names will be skipped

    Network Requirements:
    - Port 445 (SMB) for administrative shares
    - Port 3389 (or custom) for RDP connectivity test
    - Port 5985/5986 for PowerShell remoting (WinRM)
    - ICMP and various WMI ports for CIM access

    Permissions Required:
    - Current user (or specified credentials) must have:
      * Administrative rights on target servers for C$ access
      * Remote management permissions for PS remoting and WMI

.LINK
    Repo: https://dev.azure.com/CMSMigrations/AMDM%20-%20LiftAndShift/_git/AMDM%20-%20LiftAndShift?path=05%20-%20Migration/02%20-%20Validation/Pre_Post%20Migration%20Checks/AdminAccess&RDPCheck.ps1


    .CHANGELOG
    2026-06-04: Aligned console progress and success summary with OS-specific success logic
    2026-06-04: Changed HTML export button to export currently visible filtered rows
    2026-06-04: Treated successful IPv6 ping replies as resolved targets
    2026-06-04: Decoded settings.json credentials using CMSLibrary-compatible Unicode DPAPI only
    2026-06-08: Reported Personal JSON credential decrypt failures as warnings without false success messages
    2026-06-04: Trimmed hostname resolver candidates before Linux SSH checks
    2026-06-04: Used the successful ping hostname for follow-on connectivity checks
    2026-06-04: Switched Linux SSH authentication test to Posh-SSH credential sessions
    2026-06-04: Preserved ServerList OSType hints so Linux targets skip Windows-only checks
    2026-06-04: Added hostname/FQDN ping-based resolution fallback for hosts-file entries before reporting unresolved targets
    2026-06-17: Prefer pass-through credentials first on domain-joined operator machines, then fall back to configured alternate credentials
    2026-06-17: Prevented invalid TrustedHosts updates when TrustedHosts is already '*' and skipped Basic WinRM attempts without explicit credentials
    2026-06-04: Added Linux SSH authentication test via PS7 SSH transport (Test-LinuxSshAccess)
    2025-11-03: Enhanced with comprehensive connectivity testing (RDP, WMI, SMB, PS remoting)
    2024-06-15: Initial version focusing on Admin Share and RDP checks


    #>

[CmdletBinding(DefaultParameterSetName = 'Default')]
param(
    [Parameter(Mandatory = $false)]
    [switch]$RunLocally = $false,

    [Parameter(Mandatory = $false)]
    [string]$ServerName,

    [Parameter(Mandatory = $false)]
    [string]$ServerList = '.\serverlist.csv',

    [switch]$UseCreds,
    [string]$Username,
    [string]$Password,

    [Parameter(Mandatory = $false)]
    [string]$PersonalJson,

    [Alias('OutputPath')]
    [string]$OutputDir = '.',
    [string]$HtmlOutputPath,
    [switch]$NoCsv,
    [int]$RdpPort = 3389,
    [int]$RdpTimeoutMs = 1500,
    [int]$PingTimeoutMs = 10000,
    [int]$PsTimeoutSec = 5,
    [string[]]$ShareCandidates = @('C$'),
    [string]$FqdnSuffix,
    [switch]$Diagnostics,
    [int]$MaxConcurrent = 25,
    [switch]$DisableParallel
)
$ScriptVersion = "26.06.28"
# 2026-06-17: Prefer pass-through credentials first on domain-joined operator machines, then fall back to configured alternate credentials
# 2026-06-17: Prevented invalid TrustedHosts updates when TrustedHosts is already '*' and skipped Basic WinRM attempts without explicit credentials
# 2026-06-16: PS5-compatible job-based multithreading (Start-Job/Wait-Job instead of ForEach-Object -Parallel)
# 2026-06-16: Implements MaxConcurrent throttling for controlled job execution
# 2026-06-16: Maintains identical CSV/HTML output format as PS7 parallel version
# 2026-06-04: Aligned console progress and success summary with OS-specific success logic
# 2026-06-04: Changed HTML export button to export currently visible filtered rows
# 2026-06-04: Treated successful IPv6 ping replies as resolved targets
# 2026-06-04: Decoded settings.json credentials using CMSLibrary-compatible Unicode DPAPI only
# 2026-06-08: Reported Personal JSON credential decrypt failures as warnings without false success messages
# 2026-06-04: Trimmed hostname resolver candidates before Linux SSH checks
# 2026-06-04: Used the successful ping hostname for follow-on connectivity checks
# 2026-06-04: Preserved ServerList OSType hints so Linux targets skip Windows-only checks
# 2026-06-04: Added hostname/FQDN ping-based resolution fallback for hosts-file entries before reporting unresolved targets
# 2026-06-04: Added Start-Transcript diagnostic log to $OutputDir\Logs\

# ── Transcript / diagnostic log ───────────────────────────────────────────────
$_logDir = Join-Path $OutputDir 'Logs'
if (-not (Test-Path $_logDir)) { New-Item -ItemType Directory -Path $_logDir -Force | Out-Null }
$_logFile = Join-Path $_logDir ("AdminAccessCheck-{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
Start-Transcript -Path $_logFile -Append -NoClobber -ErrorAction SilentlyContinue
Write-Host "=== Transcript started: $_logFile ===" -ForegroundColor DarkGray

# Servers are processed sequentially in this script regardless of PS major version.
$script:RunningUnderLegacyPowerShell = $PSVersionTable.PSVersion.Major -lt 7

$summaryReport = @()

# Function to decrypt passwords using DPAPI (same as PAT-Decrypt)
# Handles both script and compiled EXE contexts
function Decrypt-Password {
    param([string]$EncryptedPassword)
    try {
        if ([string]::IsNullOrWhiteSpace($EncryptedPassword)) {
            return $null
        }
        $encryptedBytes = [Convert]::FromBase64String($EncryptedPassword)
        
        # Try to access the type directly first (works in script context)
        try {
            $decryptedBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($encryptedBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        }
        catch {
            # Fallback: Use reflection for compiled EXE context where type resolution may differ
            $protectedDataType = [System.Reflection.Assembly]::LoadWithPartialName('System.Security').GetType('System.Security.Cryptography.ProtectedData')
            $dataProtectionScope = [System.Reflection.Assembly]::LoadWithPartialName('System.Security').GetType('System.Security.Cryptography.DataProtectionScope')
            $unprotectMethod = $protectedDataType.GetMethod('Unprotect', [System.Reflection.BindingFlags]::Public -bor [System.Reflection.BindingFlags]::Static)
            $decryptedBytes = $unprotectMethod.Invoke($null, @($encryptedBytes, $null, $dataProtectionScope.GetField('CurrentUser').GetValue($null)))
        }
        
        return [System.Text.Encoding]::Unicode.GetString($decryptedBytes)
    }
    catch {
        Write-Warning "Failed to decrypt password: $($_.Exception.Message)"
        return $null
    }
}

function PAT-Decrypt {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$EncryptedPAT
    )

    $script:LastPATDecryptError = $null

    try {
        if (-not $EncryptedPAT) {
            throw "Encrypted value is null or empty."
        }
        # Convert the Base64-encoded string back to an array of bytes.
        $encryptedBytes = [Convert]::FromBase64String($EncryptedPAT)

        # Decrypt the bytes using DPAPI with the current user scope.
        # Try to access the type directly first (works in script context)
        try {
            $decryptedBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($encryptedBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        }
        catch {
            # Fallback: Use reflection for compiled EXE context where type resolution may differ
            $protectedDataType = [System.Reflection.Assembly]::LoadWithPartialName('System.Security').GetType('System.Security.Cryptography.ProtectedData')
            $dataProtectionScope = [System.Reflection.Assembly]::LoadWithPartialName('System.Security').GetType('System.Security.Cryptography.DataProtectionScope')
            $unprotectMethod = $protectedDataType.GetMethod('Unprotect', [System.Reflection.BindingFlags]::Public -bor [System.Reflection.BindingFlags]::Static)
            $decryptedBytes = $unprotectMethod.Invoke($null, @($encryptedBytes, $null, $dataProtectionScope.GetField('CurrentUser').GetValue($null)))
        }

        # Convert the decrypted bytes back into a string.
        $decryptedPAT = [System.Text.Encoding]::Unicode.GetString($decryptedBytes)
    }
    catch {
        $msg = if ($_.Exception -and $_.Exception.Message) { $_.Exception.Message } else { "Unknown error" }
        $script:LastPATDecryptError = "Failed to decrypt encrypted value from Personal JSON (DPAPI CurrentUser). Re-save the credential value from the current Windows user profile. Details: $msg"
        $decryptedPAT = $null
    }

    return $decryptedPAT
}

# Function to get alternate credentials based on parameters (enhanced to match MigrationCheck logic)
function Get-AlternateCredentials {
    param(
        [string]$PersonalJson,
        [string]$Username,
        [string]$Password,
        [switch]$UseCreds,
        [string]$TargetOS
    )

    # Check if username and password parameters were provided (automatically use credentials)
    if (![string]::IsNullOrEmpty($Username) -and ![string]::IsNullOrEmpty($Password)) {
        Write-Host "Using credentials provided via parameters..." -ForegroundColor Green
        $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
        $credential = New-Object System.Management.Automation.PSCredential($Username, $securePassword)
        return $credential
    }
    # Check if personal JSON file was provided (automatically use credentials)
    elseif (![string]::IsNullOrEmpty($PersonalJson) -and (Test-Path $PersonalJson)) {
        # Normalize the personal JSON path to remove PowerShell provider prefixes
        $normalizedPersonalJSON = $PersonalJson
        if ($normalizedPersonalJSON -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
            $normalizedPersonalJSON = $normalizedPersonalJSON -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
        }
        $normalizedPersonalJSON = $normalizedPersonalJSON.Trim().Trim("'`"")

        Write-Host "Loading credentials from personal JSON: $normalizedPersonalJSON" -ForegroundColor Green
        try {
            $personalData = Get-Content $normalizedPersonalJSON | ConvertFrom-Json

            # Extract credentials based on TargetOS
            $username = $null
            $password = $null

            if ($TargetOS -eq "Windows") {
                # Use AlternateUsername and AlternatePassword for Windows
                if ($personalData.PSObject.Properties.Name -contains 'AlternateUsername' -and
                    $personalData.PSObject.Properties.Name -contains 'AlternatePassword' -and
                    -not [string]::IsNullOrWhiteSpace($personalData.AlternateUsername) -and
                    -not [string]::IsNullOrWhiteSpace($personalData.AlternatePassword)) {

                    $username = $personalData.AlternateUsername
                    $password = PAT-Decrypt -EncryptedPAT $personalData.AlternatePassword
                    if (-not [string]::IsNullOrEmpty($password)) {
                        Write-Host "Successfully loaded and decrypted AlternateUsername/AlternatePassword." -ForegroundColor Green
                    }
                    else {
                        Write-Warning "Failed to decrypt AlternatePassword: $script:LastPATDecryptError"
                    }
                }
            }
            elseif ($TargetOS -eq "Linux") {
                # Use AlternateLinuxUsername and AlternateLinuxPassword for Linux
                if ($personalData.PSObject.Properties.Name -contains 'AlternateLinuxUsername' -and
                    $personalData.PSObject.Properties.Name -contains 'AlternateLinuxPassword' -and
                    -not [string]::IsNullOrWhiteSpace($personalData.AlternateLinuxUsername) -and
                    -not [string]::IsNullOrWhiteSpace($personalData.AlternateLinuxPassword)) {

                    $username = $personalData.AlternateLinuxUsername
                    $password = PAT-Decrypt -EncryptedPAT $personalData.AlternateLinuxPassword
                    if (-not [string]::IsNullOrEmpty($password)) {
                        Write-Host "Successfully loaded and decrypted AlternateLinuxUsername/AlternateLinuxPassword." -ForegroundColor Green
                    }
                    else {
                        Write-Warning "Failed to decrypt AlternateLinuxPassword: $script:LastPATDecryptError"
                    }
                }
            }

            if ($username -and $password) {
                $securePassword = ConvertTo-SecureString $password -AsPlainText -Force
                $credential = New-Object System.Management.Automation.PSCredential($username, $securePassword)
                Write-Host "Credentials loaded successfully from personal JSON." -ForegroundColor Green
                return $credential
            }
            else {
                Write-Warning "Personal JSON file does not contain valid credentials for $TargetOS."
            }
        }
        catch {
            Write-Warning "Failed to load credentials from personal JSON: $($_.Exception.Message)"
        }
    }
    # If UseCredential is specified but no JSON or user/pass provided, prompt for credentials
    elseif ($UseCreds) {
        # Check if username and password are blank (not provided via command line or JSON)
        if ([string]::IsNullOrEmpty($Username) -and [string]::IsNullOrEmpty($Password)) {
            Write-Host "UseCredential switch specified but no credentials were provided." -ForegroundColor Yellow
            Write-Host "Prompting for credentials..." -ForegroundColor Yellow

            # Try to prompt for credentials
            try {
                # Check if we're in an interactive session
                if ([Environment]::UserInteractive -and $Host.Name -ne "ServerRemoteHost") {
                    $credential = Get-Credential -Message "Enter credentials for connecting to remote servers"
                    if ($null -eq $credential) {
                        Write-Host "Credential prompt was cancelled. Will use current user context." -ForegroundColor Yellow
                        return $null
                    }
                    else {
                        Write-Host "Using prompted credentials for user: $($credential.UserName)" -ForegroundColor Green
                        return $credential
                    }
                }
                else {
                    Write-Error "UseCredential switch requires either:"
                    Write-Error "  1. An interactive PowerShell session (PowerShell Console, ISE, or Windows Terminal)"
                    Write-Error "  2. Username and Password parameters provided"
                    Write-Error "  3. PersonalJSON parameter with path to personal JSON file containing credentials"
                    return $null
                }
            }
            catch {
                Write-Error "Failed to capture credentials: $_"
                Write-Error "Consider using the Username and Password parameters instead."
                return $null
            }
        }
    }

    # If no credentials provided at all, will use current user context (credential = $null)
    return $null
}

# Resolve primary IPv4 address (fallback to server name if resolution fails)
function Resolve-PrimaryIp {
    param([string]$Server)
    try {
        $ip = Resolve-DnsName -Name $Server -Type A -ErrorAction Stop |
        Where-Object { $_.IPAddress -match '^[0-9]+\.' } |
        Select-Object -First 1 -ExpandProperty IPAddress
        if ($ip) { return $ip } else { return $Server }
    }
    catch { return $Server }
}

# Standardized server list processing logic
# Determine target servers
$targetServers = @()
$ServerOsHints = @{}
$MyHostName = (Get-CimInstance -ClassName Win32_ComputerSystem).DNSHostName
if ($RunLocally -or $ServerName -eq "localhost") {
    $targetServers = @($MyHostName)
}
elseif ($ServerName) {
    # Handle comma-separated server names
    if ($ServerName -match ',') {
        $targetServers = $ServerName -split ',' | ForEach-Object { $_.Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    }
    else {
        $targetServers = @($ServerName.Trim())
    }
}
else {
    if (Test-Path $ServerList) {
        try {
            $csv = Import-Csv -Path $ServerList
            foreach ($entry in $csv) {
                # Only include rows that provide an actual host name (Server or ServerName).
                $hostPart = $null
                if ($entry.Server) { $hostPart = $entry.Server }
                elseif ($entry.ServerName) { $hostPart = $entry.ServerName }

                if ($hostPart) { $hostPart = ([string]$hostPart).Trim() }

                if ($hostPart) {
                    $NewServerNameFQDN = $hostPart
                    if ($entry.DomainName) {
                        $NewServerNameFQDN += "." + $entry.DomainName
                    }
                    $targetServers += $NewServerNameFQDN

                    $osHint = if ($entry.PSObject.Properties['OSType']) { $entry.OSType }
                              elseif ($entry.PSObject.Properties['OS']) { $entry.OS }
                              elseif ($entry.PSObject.Properties['OperatingSystem']) { $entry.OperatingSystem }
                              else { '' }
                    if (-not [string]::IsNullOrWhiteSpace($osHint)) {
                        $ServerOsHints[$NewServerNameFQDN.ToLower()] = $osHint
                        $ServerOsHints[($hostPart -split '\.')[0].ToLower()] = $osHint
                    }

                }
                else {
                    # Skip rows that do not contain a host; avoid creating entries like ".domain.com" which yield empty hostnames later
                    continue
                }
            }
        }
        catch {
            Write-Warning "Failed to import CSV. Defaulting to localhost."
            $targetServers = @($MyHostName)
        }
    }
    else {
        Write-Warning "Server list file not found. Defaulting to localhost."
        $targetServers = @($MyHostName)
    }
}
# Normalize the target servers list: trim whitespace, remove empty entries, and deduplicate
$targetServers = @($targetServers | ForEach-Object { $_.ToString().Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
Write-Host "Target servers: $($targetServers -join ', ')"

function New-OutputDirectory {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Verbose "Creating output directory: $Path"
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

New-OutputDirectory -Path $OutputDir

# Posh-SSH v2.x (SSH.NET 2013.4.7) uses HMACRIPEMD160 which was removed in .NET 5+.
# Detect this and try to auto-update; fail with a clear message if we can't.
$_poshSsh = Get-Module -ListAvailable -Name Posh-SSH | Sort-Object Version -Descending | Select-Object -First 1
if (-not $_poshSsh) {
    Write-Warning "Posh-SSH is not installed. Attempting to install..."
    try {
        Install-Module Posh-SSH -Scope CurrentUser -Force -ErrorAction Stop
        $_poshSsh = Get-Module -ListAvailable -Name Posh-SSH | Sort-Object Version -Descending | Select-Object -First 1
        Write-Host "Posh-SSH $($_poshSsh.Version) installed successfully." -ForegroundColor Green
    } catch {
        Write-Warning "Auto-install failed: $($_.Exception.Message)"
        Write-Warning "Please install manually before running Access Check against Linux targets:"
        Write-Warning "  Install-Module Posh-SSH -Scope CurrentUser -Force"
    }
} elseif ($_poshSsh.Version.Major -le 2) {
    Write-Warning "Posh-SSH $($_poshSsh.Version) is installed. This version is incompatible with newer .NET hosts (missing HMACRIPEMD160). There is a known bug in Posh-SSH v2.x that can cause this failure."
    Write-Host "Attempting to update Posh-SSH..." -ForegroundColor Yellow
    try {
        Update-Module Posh-SSH -Force -ErrorAction Stop
        $_poshSsh = Get-Module -ListAvailable -Name Posh-SSH | Sort-Object Version -Descending | Select-Object -First 1
        Write-Host "Posh-SSH updated to $($_poshSsh.Version)." -ForegroundColor Green
    } catch {
        Write-Warning "Auto-update failed: $($_.Exception.Message)"
        Write-Warning "Please update manually before running Access Check against Linux targets:"
        Write-Warning "  Update-Module Posh-SSH -Force"
        Write-Warning "  -- or --"
        Write-Warning "  Install-Module Posh-SSH -Scope CurrentUser -Force"
    }
}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  Server Access & Connectivity Report" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Servers: $($targetServers.Count)" -ForegroundColor White
if ($MaxConcurrent -gt 1) {
    Write-Host "Parallel Threads: $MaxConcurrent" -ForegroundColor White
}
Write-Host "Output Path: $OutputDir" -ForegroundColor White
Write-Host "========================================`n" -ForegroundColor Cyan

# Assign the processed target servers to the working variable
$Servers = $targetServers

# Get alternate credentials if UseCreds is specified
Write-Host "[1/4] Validating credentials..." -ForegroundColor Yellow
$AlternateCred = Get-AlternateCredentials -PersonalJson $PersonalJson -Username $Username -Password $Password -UseCreds:$UseCreds -TargetOS "Windows"
$AlternateLinuxCred = Get-AlternateCredentials -PersonalJson $PersonalJson -Username $Username -Password $Password -UseCreds:$UseCreds -TargetOS "Linux"
if ($AlternateCred) {
    Write-Host "      ✓ Windows credentials loaded for: $($AlternateCred.UserName)" -ForegroundColor Green
}
if ($AlternateLinuxCred) {
    Write-Host "      ✓ Linux credentials loaded for: $($AlternateLinuxCred.UserName)" -ForegroundColor Green
}
if (-not $AlternateCred -and -not $AlternateLinuxCred) {
    Write-Host "      ✓ Using current user context" -ForegroundColor Green
}

$script:LocalComputerPartOfDomain = $true
try {
    $localComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
    $script:LocalComputerPartOfDomain = [bool]$localComputerSystem.PartOfDomain
    if ($script:LocalComputerPartOfDomain) {
        Write-Host "      ✓ Local machine is domain-joined; pass-through credentials will be preferred first." -ForegroundColor Green
    }
    else {
        Write-Host "      ! Local machine is not domain-joined; configured alternate credentials will be preferred first." -ForegroundColor Yellow
    }
}
catch {
    Write-Host "      ! Could not determine local domain membership; assuming pass-through can be tried first. Details: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host "`n[2/4] Testing server connectivity..." -ForegroundColor Yellow
Write-Host "      Processing $($Servers.Count) servers (PowerShell $($PSVersionTable.PSVersion))..." -ForegroundColor White
if ($script:RunningUnderLegacyPowerShell -and $MaxConcurrent -gt 1) {
    Write-Host "      Sequential mode enabled for compiled EXE host; MaxConcurrent is ignored." -ForegroundColor Yellow
}
$startTime = Get-Date

# Progress tracking with synchronized hashtable
$progressSync = [hashtable]::Synchronized(@{ Count = 0 })

function Invoke-AccessCheckForServer {
    param(
        [object]$CurrentItem,
        [int]$TotalCount,
        [hashtable]$ProgressSync
    )

    function Write-ServerProgress {
        param(
            [hashtable]$ProgressSync,
            [int]$TotalCount,
            [string]$DisplayName,
            [bool]$Success,
            [string]$Detail
        )

        $lockTaken = $false
        try {
            [System.Threading.Monitor]::Enter($ProgressSync.SyncRoot, [ref]$lockTaken)
            $ProgressSync.Count = [int]$ProgressSync.Count + 1
            $completedCount = [int]$ProgressSync.Count
            $percent = [Math]::Round(($completedCount / $TotalCount) * 100, 1)
            $statusIcon = if ($Success) { '✓' } else { '✗' }
            $suffix = if ([string]::IsNullOrWhiteSpace($Detail)) { '' } else { " - $Detail" }
            $color = if ($Success) { 'Green' } else { 'Yellow' }
            Write-Host "      [$completedCount/$TotalCount - $percent%] $statusIcon $DisplayName$suffix" -ForegroundColor $color
        }
        finally {
            if ($lockTaken) {
                [System.Threading.Monitor]::Exit($ProgressSync.SyncRoot)
            }
        }
    }

    # Import functions (they need to be redefined in parallel scope)
    function Resolve-PrimaryIp {
        param([string]$Server)
        try {
            $resolved = Resolve-DnsName -Name $Server -Type A -ErrorAction Stop | Select-Object -First 1
            $ip = $resolved.IPAddress
            if ($ip -eq '44.244.22.128') { return $null }
            return $ip
        }
        catch { return $null }
    }

    function Test-Ping {
        param([string]$Server, [int]$TimeoutMs = 10000)
        try {
            $pinger = New-Object System.Net.NetworkInformation.Ping
            $reply = $pinger.Send($Server, $TimeoutMs)
            return ($reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success)
        }
        catch {
            return $false
        }
    }

    function Test-PingResolution {
        param([string]$Server, [int]$TimeoutMs = 10000)
        if ([string]::IsNullOrWhiteSpace($Server)) {
            return [pscustomobject]@{ Target = $Server; Success = $false; IPAddress = $null; Status = 'InvalidTarget'; Error = 'Server name is empty.' }
        }

        try {
            $pinger = New-Object System.Net.NetworkInformation.Ping
            $reply = $pinger.Send($Server, $TimeoutMs)
            $resolvedAddress = $null
            if ($reply -and $reply.Address) {
                $addressText = ([string]$reply.Address).Trim()
                $addressMatch = [regex]::Match($addressText, '\d{1,3}(?:\.\d{1,3}){3}')
                if ($addressMatch.Success) {
                    $resolvedAddress = $addressMatch.Value
                } else {
                    $resolvedAddress = $addressText
                }
            }
            return [pscustomobject]@{
                Target    = $Server
                Success   = ($reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success)
                IPAddress = $resolvedAddress
                Status    = if ($reply) { $reply.Status.ToString() } else { 'NoReply' }
                Error     = ''
            }
        }
        catch {
            return [pscustomobject]@{ Target = $Server; Success = $false; IPAddress = $null; Status = 'ResolveFailed'; Error = $_.Exception.Message }
        }
    }

    function Resolve-ConnectTarget {
        param(
            [string]$OriginalTarget,
            [string]$ShortTarget,
            [int]$TimeoutMs = 10000
        )

        $candidateNames = [System.Collections.Generic.List[string]]::new()
        if (-not [string]::IsNullOrWhiteSpace($OriginalTarget)) { [void]$candidateNames.Add(([string]$OriginalTarget).Trim()) }
        if (-not [string]::IsNullOrWhiteSpace($ShortTarget) -and $ShortTarget -ne $OriginalTarget) { [void]$candidateNames.Add(([string]$ShortTarget).Trim()) }

        $attempts = foreach ($candidateName in ($candidateNames | Select-Object -Unique)) {
            $candidateName = ([string]$candidateName).Trim()
            $pingAttempt = Test-PingResolution -Server $candidateName -TimeoutMs $TimeoutMs
            if ($pingAttempt.Success) {
                return [pscustomobject]@{
                    ConnectTarget = $candidateName
                    DnsTarget     = $pingAttempt.IPAddress
                    Ping          = [bool]$pingAttempt.Success
                    Resolved      = $true
                    Attempts      = @($pingAttempt)
                    Error         = ''
                }
            }
            $pingAttempt
        }

        return [pscustomobject]@{
            ConnectTarget = if ($candidateNames.Count -gt 0) { $candidateNames[0] } else { $OriginalTarget }
            DnsTarget     = $null
            Ping          = $false
            Resolved      = $false
            Attempts      = @($attempts)
            Error         = "Unable to resolve target by ping. Tried: $($candidateNames -join ', ')"
        }
    }

    function Test-TcpPort {
        param([string]$Server, [int]$Port, [int]$TimeoutMs = 3000)
        try {
            $tcp = New-Object System.Net.Sockets.TcpClient
            $connect = $tcp.BeginConnect($Server, $Port, $null, $null)
            $success = $connect.AsyncWaitHandle.WaitOne($TimeoutMs, $false)
            if ($success) { $tcp.EndConnect($connect); $tcp.Close(); return $true }
            else { $tcp.Close(); return $false }
        }
        catch { return $false }
    }

    function Test-SshPort {
        param([string]$Server, [int]$TimeoutMs = 3000)
        return Test-TcpPort -Server $Server -Port 22 -TimeoutMs $TimeoutMs
    }

    function Test-SshConnectivity {
        param([string]$Server, [pscredential]$Credential, [int]$TimeoutMs = 3000)
        # Confirm SSH by reading the banner (expects "SSH-2.0-..." or similar)
        try {
            $tcp = New-Object System.Net.Sockets.TcpClient
            $connect = $tcp.BeginConnect($Server, 22, $null, $null)
            $success = $connect.AsyncWaitHandle.WaitOne($TimeoutMs, $false)
            if ($success) {
                $tcp.EndConnect($connect)
                $stream = $tcp.GetStream()
                $stream.ReadTimeout = $TimeoutMs
                $buffer = New-Object byte[] 256
                $bytesRead = $stream.Read($buffer, 0, $buffer.Length)
                $banner = [System.Text.Encoding]::ASCII.GetString($buffer, 0, $bytesRead)
                $tcp.Close()
                return $banner -match '^SSH-'
            }
            $tcp.Close()
            return $false
        }
        catch { return $false }
    }

    function Get-OSType {
        param([string]$Server, [int]$TimeoutMs = 3000, [pscredential]$Credential)

        $rdpOpen = Test-TcpPort -Server $Server -Port 3389 -TimeoutMs $TimeoutMs
        $sshOpen = Test-SshPort -Server $Server -TimeoutMs $TimeoutMs

        if ($sshOpen) {
            $sshConnected = Test-SshConnectivity -Server $Server -Credential $Credential -TimeoutMs $TimeoutMs
            if ($sshConnected) {
                return "Linux"
            }
        }

        if ($rdpOpen) {
            return "Windows"
        }

        return "Unknown"
    }

    function Test-RdpPort {
        param([string]$Server, [int]$Port = 3389, [int]$TimeoutMs = 3000)
        $result = Test-TcpPort -Server $Server -Port $Port -TimeoutMs $TimeoutMs
        return $(if ($result) { 'Enabled' } else { 'Disabled' })
    }

    function Test-WmiAdmin {
        param([string]$Server, [pscredential]$AlternateCredential, [int]$TimeoutSec = 5)

        # Try default credentials first
        try {
            $os = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $Server -ErrorAction Stop
            $osVersion = if ($os.Version) { $os.Version } else { 'Unknown' }
            return [pscustomobject]@{
                Success = $true; Caption = $os.Caption; Version = $osVersion; CredentialUsed = "Default"; Error = ''
            }
        }
        catch {
            $defaultError = $_.Exception.Message
        }

        # If default failed and we have alternate credentials, try them
        if ($AlternateCredential) {
            try {
                $os = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $Server -Credential $AlternateCredential -ErrorAction Stop
                $osVersion = if ($os.Version) { $os.Version } else { 'Unknown' }
                return [pscustomobject]@{
                    Success = $true; Caption = $os.Caption; Version = $osVersion; CredentialUsed = "Alternate"; Error = ''
                }
            }
            catch {
                return [pscustomobject]@{
                    Success = $false; Caption = ''; Version = ''; CredentialUsed = "Alternate"; Error = $_.Exception.Message
                }
            }
        }

        return [pscustomobject]@{
            Success = $false; Caption = ''; Version = ''; CredentialUsed = "Default"; Error = $defaultError
        }
    }

    function Test-RemotePowerShell {
        param([string]$Server, [pscredential]$AlternateCredential, [int]$TimeoutSec = 5)

        # Test port availability for status reporting
        $httpOpen = Test-TcpPort -Server $Server -Port 5985 -TimeoutMs 1500
        $httpsOpen = Test-TcpPort -Server $Server -Port 5986 -TimeoutMs 1500
        $portStatus = "HTTP:$httpOpen HTTPS:$httpsOpen"

        $transportAttempts = @()
        $transportAttempts += New-Object PSObject -Property @{ UseSSL = $false; Port = 5985; Label = 'WinRM HTTP/5985 Kerberos'; Protocol = 'HTTP'; Authentication = '' }
        $transportAttempts += New-Object PSObject -Property @{ UseSSL = $true; Port = 5986; Label = 'WinRM HTTPS/5986 Kerberos'; Protocol = 'HTTPS'; Authentication = '' }
        $transportAttempts += New-Object PSObject -Property @{ UseSSL = $false; Port = 5985; Label = 'WinRM HTTP/5985 Negotiate/NTLM'; Protocol = 'HTTP'; Authentication = 'Negotiate' }
        $transportAttempts += New-Object PSObject -Property @{ UseSSL = $true; Port = 5986; Label = 'WinRM HTTPS/5986 Basic'; Protocol = 'HTTPS'; Authentication = 'Basic' }

        function Add-WinRmTrustedHostIfNeeded {
            param([string]$RemoteServer)

            try {
                $currentTrustedHosts = (Get-Item WSMan:\localhost\Client\TrustedHosts -ErrorAction SilentlyContinue).Value
                $trustedHostPatterns = @($currentTrustedHosts -split ',' | ForEach-Object { ([string]$_).Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

                # '*' must be the only pattern when used. If present, everything is already trusted.
                # If a previous run left an invalid value like '*,server', normalize it back to '*'.
                if ($trustedHostPatterns -contains '*') {
                    if ($trustedHostPatterns.Count -gt 1) {
                        Set-Item WSMan:\localhost\Client\TrustedHosts -Value '*' -Force -ErrorAction Stop
                    }
                    return
                }

                if ($trustedHostPatterns -contains $RemoteServer) {
                    return
                }

                $newTrustedHosts = @($trustedHostPatterns + $RemoteServer) -join ','
                Set-Item WSMan:\localhost\Client\TrustedHosts -Value $newTrustedHosts -Force -ErrorAction Stop
            }
            catch {
                Write-Host "      ! Unable to update WinRM TrustedHosts for ${RemoteServer}: $($_.Exception.Message)" -ForegroundColor DarkGray
            }
        }

        function Invoke-PSVersionAttemptList {
            param(
                [string]$RemoteServer,
                [pscredential]$Cred,
                [object[]]$Attempts
            )

            $lastError = $null
            foreach ($attempt in $Attempts) {
                $attemptUser = if ($Cred) { $Cred.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
                try {
                    if ($attempt.Authentication -eq 'Basic' -and -not $Cred) {
                        Write-Host "      - Skipping $($attempt.Label) to $RemoteServer because Basic authentication requires explicit credentials." -ForegroundColor DarkGray
                        continue
                    }

                    Write-Host "      -> Invoke-Command attempt to $RemoteServer via $($attempt.Label) as $attemptUser" -ForegroundColor DarkGray
                    if ($attempt.Authentication) {
                        Add-WinRmTrustedHostIfNeeded -RemoteServer $RemoteServer
                    }

                    $invokeParams = @{
                        ComputerName = $RemoteServer
                        ScriptBlock  = { $PSVersionTable.PSVersion.ToString() }
                        ErrorAction  = 'Stop'
                        UseSSL       = [bool]$attempt.UseSSL
                        Port         = [int]$attempt.Port
                    }
                    if ($attempt.UseSSL) {
                        try { $invokeParams.SessionOption = (New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck) }
                        catch { }
                    }
                    if ($Cred) { $invokeParams.Credential = $Cred }
                    if ($attempt.Authentication) { $invokeParams.Authentication = $attempt.Authentication }

                    $version = Invoke-Command @invokeParams
                    Write-Host "      OK Invoke-Command succeeded to $RemoteServer via $($attempt.Label) as $attemptUser" -ForegroundColor DarkGray
                    return @{ Version = $version; Port = $attempt.Port; Protocol = $attempt.Protocol; UserName = $attemptUser }
                }
                catch {
                    $lastError = "$($attempt.Label) as ${attemptUser}: $($_.Exception.Message)"
                    Write-Host "      X Invoke-Command failed to $RemoteServer via $($attempt.Label) as ${attemptUser}: $($_.Exception.Message)" -ForegroundColor DarkGray
                }
            }

            throw $lastError
        }
        $preferDefaultFirst = (-not $AlternateCredential -or [bool]$script:LocalComputerPartOfDomain)

        if ($preferDefaultFirst) {
            # Try default/pass-through credentials first on domain-joined operator machines.
            # Note: Do NOT gate with Test-WSMan — it defaults to HTTP/5985 and would
            # block the fallback to HTTPS/5986 on servers that only have 5986 enabled.
            try {
                $result = Invoke-PSVersionAttemptList -RemoteServer $Server -Attempts $transportAttempts
                $psVersion = if ($result.Version) { $result.Version } else { 'Unknown' }
                return @{
                    Success        = 'Success'
                    Error          = ''
                    CredentialUsed = 'Default'
                    PSVersion      = $psVersion
                    Port           = $result.Port
                    Protocol       = $result.Protocol
                    PortStatus     = $portStatus
                }
            }
            catch {
                $defaultError = $_.Exception.Message
            }
        }

        if ($AlternateCredential) {
            try {
                $result = Invoke-PSVersionAttemptList -RemoteServer $Server -Cred $AlternateCredential -Attempts $transportAttempts
                $psVersion = if ($result.Version) { $result.Version } else { 'Unknown' }
                return @{
                    Success        = 'Success'
                    Error          = ''
                    CredentialUsed = 'Alternate'
                    PSVersion      = $psVersion
                    Port           = $result.Port
                    Protocol       = $result.Protocol
                    PortStatus     = $portStatus
                }
            }
            catch {
                $alternateError = $_.Exception.Message
            }
        }

        if (-not $preferDefaultFirst) {
            try {
                $result = Invoke-PSVersionAttemptList -RemoteServer $Server -Attempts $transportAttempts
                $psVersion = if ($result.Version) { $result.Version } else { 'Unknown' }
                return @{
                    Success        = 'Success'
                    Error          = ''
                    CredentialUsed = 'Default'
                    PSVersion      = $psVersion
                    Port           = $result.Port
                    Protocol       = $result.Protocol
                    PortStatus     = $portStatus
                }
            }
            catch {
                $defaultError = $_.Exception.Message
            }
        }

        # Both failed, return error
        $finalError = if ($AlternateCredential) {
            "Default: $defaultError | Alternate: $alternateError"
        }
        else {
            $defaultError
        }

        return @{
            Success        = 'Failed'
            Error          = $finalError
            CredentialUsed = if ($AlternateCredential) { 'Alternate' } else { 'Default' }
            PSVersion      = ''
            Port           = ''
            Protocol       = ''
            PortStatus     = $portStatus
        }
    }

    function Test-AdminShare {
        param([string]$Server, [pscredential]$AlternateCredential, [string[]]$Candidates = @('C$'))
        $share = $Candidates[0]
        $targets = @($Server)

        $variants = @()
        foreach ($t in $targets) { $variants += "\\$t\$share"; $variants += "\\$t\$share\" }

        $success = $false
        $myerror = ""
        $method = ""
        $sample = ""
        $attemptDetails = @()

        foreach ($p in $variants) {
            $detail = [ordered]@{
                Path = $p
                TestPath = $false
                ListRoot = $false
                Method = ''
                Error = ''
                ListSample = ''
            }
            try {
                if (Test-Path -LiteralPath $p -ErrorAction Stop) {
                    $detail.TestPath = $true
                    $detail.Method = 'TestPath'
                    $success = $true
                    $method = 'TestPath'
                    break
                }
            }
            catch {
                $detail.Error = 'TestPath:' + $_.Exception.Message
                $myerror = $_.Exception.Message
            }

            if (-not $detail.TestPath) {
                try {
                    $lr = Get-ChildItem -LiteralPath $p -Force -ErrorAction Stop | Select-Object -First 3 Name
                    if ($lr) {
                        $detail['ListRoot'] = $true
                        $detail['Method'] = 'List'
                        $detail['ListSample'] = ($lr.Name -join ';')
                        $success = $true
                        $method = 'List'
                        $sample = $detail['ListSample']
                        break
                    }
                }
                catch {
                    if (-not $detail.Error) {
                        $detail.Error = 'List:' + $_.Exception.Message
                        $myerror = $_.Exception.Message
                    }
                }
            }
            $attemptDetails += [pscustomobject]$detail
        }

        $shareResult = if ($success) { $share } else { '' }
        $statusResult = if ($success) { 'C$Success' } else { 'C$Failed' }
        return @{
            Success = $success; Share = $shareResult
            Status = $statusResult
            Error = $myerror; Attempts = $attemptDetails
            Method = $method; Sample = $sample
        }
    }

    function Test-LinuxSshAccess {
        param([string]$Server, [pscredential]$Credential, [int]$TimeoutSec = 10)
        $Server = ([string]$Server).Trim()
        if (-not $Credential) {
            return @{ Success = $false; Method = 'Posh-SSH'; Error = 'No Linux credentials configured' }
        }

        $availableVersion = (Get-Module -ListAvailable -Name Posh-SSH | Sort-Object Version -Descending | Select-Object -First 1).Version
        if (-not $availableVersion) {
            return @{ Success = $false; Method = 'Posh-SSH'; Error = 'Posh-SSH module is not installed. Run: Install-Module Posh-SSH -Scope CurrentUser -Force' }
        }
        if ($availableVersion.Major -le 2) {
            return @{ Success = $false; Method = 'Posh-SSH'; Error = "Posh-SSH $availableVersion has a known bug incompatible with newer .NET hosts. Run: Update-Module Posh-SSH -Force" }
        }

        try {
            Import-Module Posh-SSH -ErrorAction Stop
            $session = New-SSHSession -ComputerName $Server -Credential $Credential -AcceptKey -ConnectionTimeout $TimeoutSec -ErrorAction Stop
            if ($session) {
                $probe = Invoke-SSHCommand -SessionId $session.SessionId -Command 'echo ACCESS_OK' -TimeOut $TimeoutSec -ErrorAction Stop
                Remove-SSHSession -SessionId $session.SessionId -ErrorAction SilentlyContinue | Out-Null
                $output = ($probe.Output -join '').Trim()
                return @{ Success = ($output -eq 'ACCESS_OK'); Method = 'Posh-SSH'; Error = $(if ($output -eq 'ACCESS_OK') { '' } else { 'SSH command probe did not return expected output' }) }
            }
        }
        catch {
            $errMsg = $_.Exception.Message
            $errorType = if ($errMsg -match 'Permission denied|Authentication failed|access denied|invalid credentials') {
                'AuthFailed'
            } elseif ($errMsg -match 'Connection refused|No route|timed out|Network unreachable') {
                'ConnectionFailed'
            } else {
                'SshFailed'
            }
            if ($session) { Remove-SSHSession -SessionId $session.SessionId -ErrorAction SilentlyContinue | Out-Null }
            return @{ Success = $false; Method = 'Posh-SSH'; Error = "Target '$Server': $errMsg"; ErrorType = $errorType }
        }
        return @{ Success = $false; Method = 'Posh-SSH'; Error = 'SSH session was not created' }
    }

    function New-ServerResultObject {
        param([string]$Server, [string]$DnsTarget, [bool]$Ping, $adminAccessResult, $rdpOpen, $psResult, $port445, $port22, $wmi, $osType, $linuxSshResult)

        # Collect all error messages for consolidated Messages column
        $errorMessages = @()
        $isUnresolved = $adminAccessResult.Status -eq 'Unresolved'
        if ($isUnresolved) {
            $errorMessages += "Resolution: $($adminAccessResult.Error)"
        } else {
            if ($psResult.Error) { $errorMessages += "PowerShell: $($psResult.Error)" }
            if ($wmi.Error) { $errorMessages += "WMI: $($wmi.Error)" }
            if ($adminAccessResult.Error) { $errorMessages += "Share: $($adminAccessResult.Error)" }
            if ($linuxSshResult -and $osType -eq 'Linux' -and -not $linuxSshResult.Success -and $linuxSshResult.Error) {
                $errorMessages += "SSH: $($linuxSshResult.Error)"
            }
        }
        $messages = if ($errorMessages.Count -gt 0) { $errorMessages -join " | " } else { "" }

        return [pscustomobject]@{
            Server = $Server; DnsTarget = $DnsTarget; Ping = $(if ($Ping) { 'Success' } else { 'Failed' }); OSType = $osType
            AdminAccess = [bool]$adminAccessResult.Success
            PSRemoting = $(if ($psResult.Success -eq 'Success') { 'Success' } elseif ($psResult.Success -eq 'N/A') { 'N/A' } else { 'Failed' })
            PSVersion = $(if ($psResult.PSVersion) { $psResult.PSVersion } else { '' })
            PSPort = $(if ($psResult.Port) { $psResult.Port } else { '' })
            PSProtocol = $(if ($psResult.Protocol) { $psResult.Protocol } else { '' })
            PSPortStatus = $(if ($psResult.PortStatus) { $psResult.PortStatus } else { '' })
            WmiStatus = $(if ($wmi.Success -eq $true -or $wmi.Success -eq 'Success') { 'Success' } elseif ($wmi.Success -eq 'N/A') { 'N/A' } else { 'Failed' })
            ShareStatus = $(if ($adminAccessResult.Status) { $adminAccessResult.Status } else { $(if ($adminAccessResult.Success) { 'Success' } else { 'Failed' }) })
            RDPPort = $(if ($rdpOpen -eq 'Enabled') { 'Open' } else { 'Closed' })
            Port445 = $(if ($port445) { 'Open' } else { 'Closed' })
            Port22 = $(if ($port22) { 'Open' } else { 'Closed' })
            OSCaption = $(if (($wmi.Success -eq $true -or $wmi.Success -eq 'Success') -and $wmi.Caption) { $wmi.Caption } else { '' })
            OSVersion = $(if (($wmi.Success -eq $true -or $wmi.Success -eq 'Success') -and $wmi.Version) { $wmi.Version } else { '' })
            Messages = $messages
            ShareUsed = $(if ($adminAccessResult.Share) { $adminAccessResult.Share } else { '' })
            ShareError = $(if ($isUnresolved) { '' } else { $adminAccessResult.Error })
            ShareAttemptDetail = $(if ($adminAccessResult.Attempts) { ($adminAccessResult.Attempts | ConvertTo-Json -Depth 3 -Compress) } else { '' })
            PSError = $(if ($isUnresolved -or $psResult.Success -eq 'Success' -or -not $psResult.Error) { '' } else { $psResult.Error })
            WmiError = $(if ($isUnresolved -or $wmi.Success -or -not $wmi.Error) { '' } else { $wmi.Error })
            LinuxSshAccess = $(if ($osType -eq 'Linux') {
                if ($linuxSshResult -and $linuxSshResult.Success) { 'Success' } else { 'Failed' }
            } else { 'N/A' })
            LinuxSshError  = $(if ($osType -eq 'Linux' -and $linuxSshResult -and -not $linuxSshResult.Success) { $linuxSshResult.Error } else { '' })
        }
    }

    # Process current server - $currentItem is now a string (FQDN)
    $serverFQDN = ([string]$currentItem).Trim()
    if ([string]::IsNullOrWhiteSpace($serverFQDN)) { return $null }

    # Extract hostname from FQDN for display purposes
    $serverNameToProcess = if ($serverFQDN -match '\.') {
        $serverFQDN.Split('.')[0].Trim()
    }
    else {
        $serverFQDN.Trim()
    }

    $osHint = ''
    foreach ($key in @($serverFQDN.ToLower(), $serverNameToProcess.ToLower())) {
        if ($ServerOsHints.ContainsKey($key)) {
            $osHint = $ServerOsHints[$key]
            break
        }
    }

    $fqdnCandidate = if ($serverFQDN -match '\.' -or [string]::IsNullOrWhiteSpace($FqdnSuffix)) {
        $serverFQDN
    } else {
        "$serverNameToProcess.$($FqdnSuffix.Trim('.'))"
    }

    # Determine connect target: try the provided/FQDN target and the short hostname. Ping resolution honors local hosts-file entries.
    $targetResolution = Resolve-ConnectTarget -OriginalTarget $fqdnCandidate -ShortTarget $serverNameToProcess -TimeoutMs $PingTimeoutMs
    $connectTarget = $targetResolution.ConnectTarget
    $dnsTarget = $targetResolution.DnsTarget
    $pingResult = [bool]$targetResolution.Ping
    $connectTarget = ([string]$connectTarget).Trim()
    $dnsTarget = ([string]$dnsTarget).Trim()

    foreach ($targetValueName in @('connectTarget', 'dnsTarget')) {
        $targetValue = Get-Variable -Name $targetValueName -ValueOnly
        $targetIpMatch = [regex]::Match([string]$targetValue, '\d{1,3}(?:\.\d{1,3}){3}')
        if ($targetIpMatch.Success) {
            Set-Variable -Name $targetValueName -Value $targetIpMatch.Value
        }
    }

    if (-not $targetResolution.Resolved) {
        $unresolvedError = $targetResolution.Error
        $psResult = @{ Success = 'Failed'; Error = $unresolvedError; CredentialUsed = ''; PSVersion = ''; Port = ''; Protocol = ''; PortStatus = 'Unresolved' }
        $wmi = [pscustomobject]@{ Success = $false; Caption = ''; Version = ''; CredentialUsed = ''; Error = $unresolvedError }
        $adminAccessResult = @{ Success = $false; Status = 'Unresolved'; Share = ''; Error = $unresolvedError; Attempts = @() }
        $linuxSshResult = @{ Success = $false; Method = 'Skipped'; Error = '' }

        $displayName = if ($serverFQDN -ne $serverNameToProcess) { "$serverNameToProcess ($serverFQDN)" } else { $serverNameToProcess }
        Write-ServerProgress -ProgressSync $progressSync -TotalCount $totalCount -DisplayName $displayName -Success $false -Detail 'unresolved'

        return New-ServerResultObject -Server $serverNameToProcess -DnsTarget $null -Ping $false -adminAccessResult $adminAccessResult -rdpOpen 'Disabled' -psResult $psResult -port445 $false -port22 $false -wmi $wmi -osType 'Unknown' -linuxSshResult $linuxSshResult
    }

    # Test order: OS Type → PowerShell → WMI → C$ Share
    $detectedOsType = Get-OSType -Server $connectTarget -TimeoutMs $RdpTimeoutMs
    $osType = if ($osHint -imatch 'linux') { 'Linux' }
              elseif ($osHint -imatch 'windows') { 'Windows' }
              else { $detectedOsType }

    # Select the appropriate credential set based on detected OS type
    $effectiveCred = if ($osType -eq 'Linux') { $AlternateLinuxCred } else { $AlternateCred }

    $linuxSshResult = @{ Success = $false; Method = 'Skipped'; Error = '' }
    if ($osType -eq 'Linux') {
        $psResult = @{ Success = 'N/A'; Error = ''; CredentialUsed = ''; PSVersion = ''; Port = ''; Protocol = ''; PortStatus = 'N/A' }
        $wmi = [pscustomobject]@{ Success = 'N/A'; Caption = ''; Version = ''; CredentialUsed = ''; Error = '' }
        $adminAccessResult = @{ Success = $false; Status = 'N/A'; Share = ''; Error = ''; Attempts = @() }
        $linuxSshResult = Test-LinuxSshAccess -Server $connectTarget -Credential $AlternateLinuxCred -TimeoutSec $PsTimeoutSec
    } else {
        $psResult = Test-RemotePowerShell -Server $connectTarget -AlternateCredential $effectiveCred -TimeoutSec $PsTimeoutSec
        $wmi = Test-WmiAdmin -Server $connectTarget -AlternateCredential $effectiveCred -TimeoutSec 6
        $adminAccessResult = Test-AdminShare -Server $connectTarget -AlternateCredential $effectiveCred -Candidates $ShareCandidates
    }

    # Additional port tests
    $rdpOpen = Test-RdpPort -Server $connectTarget -Port $RdpPort -TimeoutMs $RdpTimeoutMs
    $port445 = Test-TcpPort -Server $connectTarget -Port 445 -TimeoutMs 1500
    $port22 = Test-TcpPort -Server $connectTarget -Port 22 -TimeoutMs 1500

    $displayName = if ($serverFQDN -ne $serverNameToProcess) { "$serverNameToProcess ($serverFQDN)" } else { $serverNameToProcess }
    $serverSuccess = if ($osType -eq 'Linux') { [bool]$linuxSshResult.Success } else { $psResult.Success -eq 'Success' }
    $progressDetail = if ($osType -eq 'Linux') {
        if ($linuxSshResult.Success) { 'Linux SSH Success' } else { 'Linux SSH Failed' }
    } else {
        if ($psResult.Success -eq 'Success') { 'PowerShell Success' } else { 'PowerShell Failed' }
    }
    Write-ServerProgress -ProgressSync $progressSync -TotalCount $totalCount -DisplayName $displayName -Success $serverSuccess -Detail $progressDetail

    # Output result (use hostname for Server column for consistency with file naming)
    New-ServerResultObject -Server $serverNameToProcess -DnsTarget $dnsTarget -Ping $pingResult -adminAccessResult $adminAccessResult -rdpOpen $rdpOpen -psResult $psResult -port445 $port445 -port22 $port22 -wmi $wmi -osType $osType -linuxSshResult $linuxSshResult

}

Write-Host "`n[2/4] Testing server connectivity..." -ForegroundColor Yellow
Write-Host "      Processing $($Servers.Count) servers (PowerShell $($PSVersionTable.PSVersion), PS5-compatible sequential mode)..." -ForegroundColor White
$startTime = Get-Date

# Progress tracking with synchronized hashtable
$progressSync = [hashtable]::Synchronized(@{ Count = 0 })

# Sequential processing (PS5-compatible, uses local function calls)
$summaryReport = foreach ($serverItem in $Servers) {
    Invoke-AccessCheckForServer -CurrentItem $serverItem -TotalCount $Servers.Count -ProgressSync $progressSync
}

# Filter out null results (force array so .Count works on single results under PS5.1)
$summaryReport = @($summaryReport | Where-Object { $_ -ne $null })

$elapsed = ((Get-Date) - $startTime).TotalSeconds
Write-Host "`n      ✓ Connectivity testing completed in $([Math]::Round($elapsed, 1)) seconds" -ForegroundColor Green
Write-Host "      ✓ Successfully analyzed $($summaryReport.Count) servers" -ForegroundColor Green

# Post-processing classification for ShareFailureType
Write-Host "`n[3/4] Analyzing results..." -ForegroundColor Yellow
foreach ($r in $summaryReport) {
    $type = 'None'
    if ($r.ShareStatus -in @('N/A', 'Unresolved')) {
        $type = 'None'
    } elseif (-not $r.AdminAccess) {
        $e = $r.ShareError
        if ([string]::IsNullOrWhiteSpace($e)) { $type = 'Unknown' }
        elseif ($e -match 'cannot find path|network path was not found|The system cannot find the path') { $type = 'NotFound' }
        elseif ($e -match 'access is denied') { $type = 'AccessDenied' }
        elseif ($e -match 'timeout') { $type = 'Timeout' }
        else { $type = 'Other' }
    }
    Add-Member -InputObject $r -NotePropertyName ShareFailureType -NotePropertyValue $type -Force
}

# Calculate summary statistics
$psSummaryRows = @($summaryReport | Where-Object { $_.PSRemoting -ne 'N/A' })
$successCount = ($psSummaryRows | Where-Object { $_.PSRemoting -eq 'Success' }).Count
$failedCount = ($psSummaryRows | Where-Object { $_.PSRemoting -ne 'Success' }).Count
$linuxSummaryRows = @($summaryReport | Where-Object { $_.OSType -eq 'Linux' })
$linuxSuccessCount = ($linuxSummaryRows | Where-Object { $_.LinuxSshAccess -eq 'Success' }).Count
$overallConsoleSuccessCount = ($summaryReport | Where-Object { ($_.OSType -eq 'Linux' -and $_.LinuxSshAccess -eq 'Success') -or ($_.OSType -ne 'Linux' -and $_.PSRemoting -eq 'Success') }).Count
$overallConsoleFailedCount = $summaryReport.Count - $overallConsoleSuccessCount
$adminSummaryRows = @($summaryReport | Where-Object { $_.ShareStatus -notin @('N/A', 'Unresolved') })
$adminShareSuccess = ($adminSummaryRows | Where-Object { $_.AdminAccess -eq $true }).Count

if ($summaryReport.Count -gt 0) {
    $successPercent = if ($psSummaryRows.Count -gt 0) { [Math]::Round(($successCount / $psSummaryRows.Count) * 100, 1) } else { 0 }
    Write-Host "      ✓ PS Remoting Success: $successCount/$($psSummaryRows.Count) ($successPercent%)" -ForegroundColor $(if ($successCount -gt $failedCount) { 'Green' } else { 'Yellow' })
    if ($linuxSummaryRows.Count -gt 0) {
        $linuxSuccessPercent = [Math]::Round(($linuxSuccessCount / $linuxSummaryRows.Count) * 100, 1)
        Write-Host "      ✓ Linux SSH Success: $linuxSuccessCount/$($linuxSummaryRows.Count) ($linuxSuccessPercent%)" -ForegroundColor $(if ($linuxSuccessCount -eq $linuxSummaryRows.Count) { 'Green' } else { 'Yellow' })
    }
    Write-Host "      ✓ Admin Share Access: $adminShareSuccess/$($adminSummaryRows.Count)" -ForegroundColor White
}
else {
    Write-Host "      ! No servers were successfully processed" -ForegroundColor Yellow
}

$resolvedOut = (Resolve-Path -Path $OutputDir).Path
if ($resolvedOut -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
    $resolvedOut = $resolvedOut -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
}

Write-Host "`n[4/4] Generating reports..." -ForegroundColor Yellow

# Create Reports\Access directory structure
$reportsAccessDir = Join-Path -Path $resolvedOut -ChildPath "Reports\Access"
if (-not (Test-Path -LiteralPath $reportsAccessDir)) {
    New-Item -ItemType Directory -Path $reportsAccessDir -Force | Out-Null
    Write-Verbose "Created reports directory: $reportsAccessDir"
}

# Generate datestamp for filenames
$datestamp = Get-Date -Format 'yyyyMMdd_HHmmss'

if (-not $NoCsv) {
    Write-Host "      → Creating CSV report..." -ForegroundColor White
    $csvPath = Join-Path -Path $reportsAccessDir -ChildPath "AdminAccessStatus-$datestamp.csv"
    $summaryReport | Export-Csv -Path $csvPath -NoTypeInformation
    Write-Host "      ✓ CSV saved: $csvPath" -ForegroundColor Green
}

# ---------------- HTML REPORT -----------------
Write-Host "      → Creating HTML report..." -ForegroundColor White
function HtmlEncode { param([string]$s) if ($null -eq $s) { return '' } [System.Net.WebUtility]::HtmlEncode($s) }

$style = @'
<style>
    :root { --bg:#fff; --ink:#1e2430; --grid:#d3d8e0; --accent:#FF6600; --accent2:#8B3F99; --good:#107C10; --bad:#D13438; }
    body { font-family:Segoe UI,Roboto,Arial,sans-serif; margin:0; background:var(--bg); color:var(--ink); }
    header { padding:12px 20px; border-bottom:3px solid var(--accent); background:linear-gradient(90deg,#FF6600,#FF5800,#FF4500,#E83B6B,#B8357A,#890078); color:#fff; display:flex; align-items:center; }
    h1 { font-size:18px; margin:0; }
    .container { max-width:1700px; margin:0 auto; padding:16px; }
    .input { background:#fff; border:2px solid var(--accent); padding:8px 12px; border-radius:8px; width:340px; font-size:14px; }
    .table-wrap { overflow:auto; border:1.5px solid var(--grid); border-radius:12px; background:#f8f9fb; box-shadow:0 2px 6px rgba(0,0,0,.08); }
    table { border-collapse:separate; border-spacing:0; width:100%; min-width:950px; font-size:14px; }
    th,td { padding:8px 10px; border-bottom:1px solid var(--grid); white-space:nowrap; overflow:visible; text-align:center; }
    td.err { white-space: normal; overflow: visible; max-width:380px; text-align:left; }
    td.wrap { white-space: normal; }
    thead th { position:sticky; background:var(--accent2); color:#fff; cursor:pointer; }
    thead tr.grp th { top:0; z-index:3; }
    /* Provide a reasonable default; JS will recalc exact height */
    thead tr.sub th { top:34px; z-index:2; }
    th[data-dir="asc"]::after { content:" ▲"; color:#FFD600; }
    th[data-dir="desc"]::after { content:" ▼"; color:#FFD600; }
    tbody tr:nth-child(odd){ background:#fff; } tbody tr:nth-child(even){ background:#f3f5f8; }
    tbody tr:hover { background:#FFD600; }
    td:first-child, th:first-child { position:sticky; left:0; }
    th:first-child { background:var(--accent2); }
    td:first-child { background:inherit; }
    .pill { display:inline-block; padding:3px 8px; border-radius:12px; font-weight:600; font-size:12px; }
    .ok { background:linear-gradient(90deg,#0F7B0F,#0D6B0D); color:#fff; }
    .bad { background:linear-gradient(90deg,#D13438,#A62A2E); color:#fff; }
    .warn { background:linear-gradient(90deg,#FFB900,#FF8C00); color:#222; }
    .os-windows { background:linear-gradient(90deg,#2B88D8,#106EBE); color:#fff; }
    .os-linux { background:linear-gradient(90deg,#8E44AD,#6B2D90); color:#fff; }
    .os-mixed { background:linear-gradient(90deg,#2B88D8,#8E44AD); color:#fff; }
    .os-unknown { background:#e8e8e8; color:#666; }
    footer { margin-top:28px; padding:8px 12px; border-top:2px solid var(--accent); display:flex; justify-content:space-between; font-size:13px; }
    .muted { color:#606978; }
</style>
'@

$script = @'
<script>
    function applyFilters(){
        const t = document.getElementById('filter').value.toLowerCase();
        const mode = document.querySelector('input[name="viewMode"]:checked')?.value || 'all';
        document.querySelectorAll('tbody tr').forEach(r=>{
            const textMatch = r.innerText.toLowerCase().includes(t);
            const success = r.getAttribute('data-success') === 'True';
            const statusMatch = mode === 'all' || (mode === 'success' && success) || (mode === 'failed' && !success);
            r.style.display = (textMatch && statusMatch) ? '' : 'none';
        });
    }
    function csvEscape(value){
        return '"' + String(value ?? '').replace(/"/g,'""') + '"';
    }
    function exportVisibleRows(){
        const headers = Array.from(document.querySelectorAll('thead tr:last-child th')).map(th=>csvEscape(th.innerText.replace(/\s+/g,' ').trim()));
        const rows = Array.from(document.querySelectorAll('tbody tr')).filter(r=> r.style.display !== 'none');
        let csv = headers.join(',')+'\n';
        rows.forEach(r=>{
            const cells = Array.from(r.children).map(td=>csvEscape(td.textContent.replace(/\s+/g,' ').trim()));
            csv += cells.join(',')+'\n';
        });
        const blob = new Blob([csv],{type:'text/csv;charset=utf-8;'});
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'AccessReportFilteredRows.csv';
        document.body.appendChild(a); a.click(); a.remove();
    }
    document.addEventListener('DOMContentLoaded', () => {
        document.getElementById('filter').addEventListener('input', applyFilters);
        document.querySelectorAll('input[name="viewMode"]').forEach(r=> r.addEventListener('change',applyFilters));
        document.getElementById('exportCsvBtn').addEventListener('click',exportVisibleRows);
        // Apply sorting handlers
        document.querySelectorAll('thead th').forEach((th,i)=>{
            th.addEventListener('click',()=>{
                const dir = th.dataset.dir === 'asc' ? 'desc' : 'asc';
                document.querySelectorAll('thead th').forEach(h=>h.removeAttribute('data-dir'));
                th.dataset.dir = dir;
                const rows = Array.from(document.querySelectorAll('tbody tr'));
                const getVal = (tr)=> tr.children[i].getAttribute('data-sort') || tr.children[i].innerText;
                rows.sort((a,b)=>{
                    const A=getVal(a), B=getVal(b); const nA=parseFloat(A), nB=parseFloat(B);
                    if(!isNaN(nA)&&!isNaN(nB)) return dir==='asc'? nA-nB : nB-nA;
                    return dir==='asc'? A.localeCompare(B,undefined,{numeric:true}) : B.localeCompare(A,undefined,{numeric:true});
                });
                rows.forEach(r=>r.parentNode.appendChild(r));
            });
        });
        function recalcHeader(){
            const grpRow = document.querySelector('thead tr.grp');
            if(!grpRow) return;
            // Use offsetHeight after layout
            const h = grpRow.offsetHeight;
            document.querySelectorAll('thead tr.sub th').forEach(th=> th.style.top = h + 'px');
        }
        // Initial after DOM ready
        recalcHeader();
        // After full load (fonts) & on resize
        window.addEventListener('load', recalcHeader);
        window.addEventListener('resize', recalcHeader);
        applyStatusFilter();
    });
</script>
'@

$generated = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
$total = $summaryReport.Count

# Admin Share Statistics
$adminRows = @($summaryReport | Where-Object { $_.ShareStatus -notin @('N/A', 'Unresolved') })
$adminTotal = $adminRows.Count
$adminOk = ($adminRows | Where-Object { $_.AdminAccess -eq $true }).Count
$failedAdmin = $adminTotal - $adminOk
$adminSharePercent = if ($adminTotal -gt 0) { [Math]::Round(($adminOk / $adminTotal) * 100, 1) } else { 0 }

# OS Type Statistics
$windowsCount = ($summaryReport | Where-Object { $_.OSType -eq 'Windows' }).Count
$linuxCount = ($summaryReport | Where-Object { $_.OSType -eq 'Linux' }).Count
$windowsPercent = if ($total -gt 0) { [Math]::Round(($windowsCount / $total) * 100, 1) } else { 0 }
$linuxPercent = if ($total -gt 0) { [Math]::Round(($linuxCount / $total) * 100, 1) } else { 0 }

# Other Statistics
$p445Ok = ($summaryReport | Where-Object { $_.Port445 -eq 'Open' }).Count
$p445Percent = if ($total -gt 0) { [Math]::Round(($p445Ok / $total) * 100, 1) } else { 0 }
$failedRdp = ($summaryReport | Where-Object { $_.RDPPort -ne 'Open' }).Count
$rdpOpenCount = $total - $failedRdp
$rdpPercent = if ($total -gt 0) { [Math]::Round(($rdpOpenCount / $total) * 100, 1) } else { 0 }
$psRows = @($summaryReport | Where-Object { $_.PSRemoting -ne 'N/A' })
$psTotal = $psRows.Count
$failedPs = ($psRows | Where-Object { $_.PSRemoting -ne 'Success' }).Count
$psSuccessCount = $psTotal - $failedPs
$psSuccessPercent = if ($psTotal -gt 0) { [Math]::Round(($psSuccessCount / $psTotal) * 100, 1) } else { 0 }
$wmiRows = @($summaryReport | Where-Object { $_.WmiStatus -ne 'N/A' })
$wmiTotal = $wmiRows.Count
$failedWmi = ($wmiRows | Where-Object { $_.WmiStatus -ne 'Success' }).Count
$wmiSuccessCount = $wmiTotal - $failedWmi
$wmiSuccessPercent = if ($wmiTotal -gt 0) { [Math]::Round(($wmiSuccessCount / $wmiTotal) * 100, 1) } else { 0 }
$overallSuccessCount = ($summaryReport | Where-Object { ($_.OSType -eq 'Linux' -and $_.LinuxSshAccess -eq 'Success') -or ($_.OSType -ne 'Linux' -and $_.PSRemoting -eq 'Success') }).Count
$overallSuccessPercent = if ($total -gt 0) { [Math]::Round(($overallSuccessCount / $total) * 100, 1) } else { 0 }
$shareFailureGroups = ($summaryReport | Group-Object ShareFailureType | Sort-Object Name)

function Get-Pill {
    param([string]$status, [string]$type)
    switch ($type) {
        'Access' { if ($status -eq 'Success') { return '<span class="pill ok">Success</span>' } elseif ($status -eq 'N/A') { return '<span class="pill muted" style="background:#e8e8e8;color:#888;">N/A</span>' } else { return '<span class="pill bad">Failed</span>' } }
        'Admin' { if ($status -match '^(True|Yes)$') { return '<span class="pill ok">Yes</span>' } elseif ($status -eq 'N/A') { return '<span class="pill muted" style="background:#e8e8e8;color:#888;">N/A</span>' } else { return '<span class="pill bad">No</span>' } }
        'ShareStatus' { if ($status -eq 'N/A') { return '<span class="pill muted" style="background:#e8e8e8;color:#888;">N/A</span>' } elseif ($status -match 'Access|Success') { return '<span class="pill ok">Access</span>' } elseif ($status -match 'Failed|Fail') { return '<span class="pill bad">Fail</span>' } else { return '<span class="pill warn">Unknown</span>' } }
        'RDP' { if ($status -eq 'Open') { return '<span class="pill ok">Open</span>' } else { return '<span class="pill bad">Closed</span>' } }
        'Port' { if ($status -eq 'Open') { return '<span class="pill ok">Open</span>' } else { return '<span class="pill bad">Closed</span>' } }
        'PS' { if ($status -eq 'Success') { return '<span class="pill ok">Success</span>' } elseif ($status -eq 'N/A') { return '<span class="pill muted" style="background:#e8e8e8;color:#888;">N/A</span>' } else { return '<span class="pill bad">Failed</span>' } }
        'WMI' { if ($status -eq 'Success') { return '<span class="pill ok">Success</span>' } elseif ($status -eq 'N/A') { return '<span class="pill muted" style="background:#e8e8e8;color:#888;">N/A</span>' } else { return '<span class="pill bad">Failed</span>' } }
        'Ping' { if ($status -eq 'Success') { return '<span class="pill ok">Success</span>' } else { return '<span class="pill bad">Failed</span>' } }
        'OSType' {
            switch ($status) {
                'Windows' { return '<span class="pill os-windows">&#x1FA9F; Windows</span>' }
                'Linux' { return '<span class="pill os-linux">&#x1F427; Linux</span>' }
                'Mixed' { return '<span class="pill os-mixed">&#x1FA9F;&#x1F427; Mixed</span>' }
                Default { return '<span class="pill os-unknown">Unknown</span>' }
            }
        }
        Default { return '<span class="pill warn">NA</span>' }
    }
}

function Format-PortStatus {
    param([string]$portStatus)
    if ([string]::IsNullOrWhiteSpace($portStatus)) {
        return '<span class="muted">—</span>'
    }

    # Parse the port status string like "HTTP:True HTTPS:False"
    $formatted = $portStatus
    $formatted = $formatted -replace 'HTTP:True', '<span class="pill ok" style="font-size:10px;">HTTP:✓</span>'
    $formatted = $formatted -replace 'HTTP:False', '<span class="pill bad" style="font-size:10px;">HTTP:✗</span>'
    $formatted = $formatted -replace 'HTTPS:True', '<span class="pill ok" style="font-size:10px;">HTTPS:✓</span>'
    $formatted = $formatted -replace 'HTTPS:False', '<span class="pill bad" style="font-size:10px;">HTTPS:✗</span>'

    return $formatted
}

$rowsHtml = foreach ($row in $summaryReport) {
    $adminPill = Get-Pill -status $(if ($row.ShareStatus -eq 'N/A') { 'N/A' } else { [string]$row.AdminAccess }) -type 'Admin'
    $shareStatusPill = Get-Pill -status $row.ShareStatus -type 'ShareStatus'
    $rdpPill = Get-Pill -status $row.RDPPort -type 'RDP'
    $p445Pill = Get-Pill -status $row.Port445 -type 'Port'
    $p22Pill = Get-Pill -status $row.Port22 -type 'Port'
    $psPill = Get-Pill -status $row.PSRemoting -type 'PS'
    $wmiPill = Get-Pill -status $row.WmiStatus -type 'WMI'
    $osTypePill = Get-Pill -status $row.OSType -type 'OSType'
    $pingPill = Get-Pill -status $row.Ping -type 'Ping'
    $accessStatuses = @()
    if (-not [string]::IsNullOrWhiteSpace($row.PSRemoting) -and $row.PSRemoting -ne 'N/A') { $accessStatuses += [string]$row.PSRemoting }
    if (-not [string]::IsNullOrWhiteSpace($row.LinuxSshAccess) -and $row.LinuxSshAccess -ne 'N/A') { $accessStatuses += [string]$row.LinuxSshAccess }
    $accessStatus = if ($accessStatuses.Count -eq 0) {
        'N/A'
    }
    elseif ($accessStatuses -contains 'Success') {
        'Success'
    }
    elseif ($accessStatuses -contains 'Failed') {
        'Failed'
    }
    else {
        'Failed'
    }
    $accessPill = Get-Pill -status $accessStatus -type 'Access'
    $psErrHtml = if ([string]::IsNullOrWhiteSpace($row.PSError)) { '<span class="muted">—</span>' } else { HtmlEncode $row.PSError }
    $wmiErrHtml = if ($row.WmiError) { HtmlEncode $row.WmiError } else { '<span class="muted">—</span>' }
    $shareFailureHtml = if ($row.ShareFailureType -eq 'None') { '<span class="muted">—</span>' } else { HtmlEncode $row.ShareFailureType }
    $psVersionHtml = if ([string]::IsNullOrWhiteSpace($row.PSVersion)) { '<span class="muted">—</span>' } else { HtmlEncode $row.PSVersion }
    $psPortHtml = if ([string]::IsNullOrWhiteSpace($row.PSPort)) { '<span class="muted">—</span>' } else { HtmlEncode $row.PSPort }
    $psProtocolHtml = if ([string]::IsNullOrWhiteSpace($row.PSProtocol)) { '<span class="muted">—</span>' } else { HtmlEncode $row.PSProtocol }
    $psPortStatusHtml = Format-PortStatus -portStatus $row.PSPortStatus
    $linuxSshPill = if ($row.LinuxSshAccess -eq 'Success') {
        "<span class='pill ok'>Success</span>"
    } elseif ($row.LinuxSshAccess -eq 'Failed') {
        "<span class='pill bad'>Failed</span>"
    } else {
        "<span class='pill muted' style='background:#e8e8e8;color:#888;'>$([string]$row.LinuxSshAccess)</span>"
    }
    $linuxSshErrHtml = if ([string]::IsNullOrWhiteSpace($row.LinuxSshError)) { '<span class="muted">—</span>' } else { HtmlEncode $row.LinuxSshError }
        $success = $accessStatus -eq 'Success'
    @"
<tr data-success='$success'>
  <td data-sort='$(HtmlEncode $row.Server)'>$(HtmlEncode $row.Server)</td>
  <td data-sort='$(HtmlEncode $row.DnsTarget)'>$(if ($row.DnsTarget) { HtmlEncode $row.DnsTarget } else { HtmlEncode $row.Server })</td>
    <td data-sort='$(HtmlEncode $accessStatus)'>$accessPill</td>
  <td data-sort='$(HtmlEncode $row.Ping)'>$pingPill</td>
  <td data-sort='$(HtmlEncode $row.OSType)'>$osTypePill</td>
  <td data-sort='$(HtmlEncode $row.PSVersion)'>$psVersionHtml</td>
  <td data-sort='$(HtmlEncode $row.PSPort)'>$psPortHtml</td>
  <td data-sort='$(HtmlEncode $row.PSProtocol)'>$psProtocolHtml</td>
  <td data-sort='$(HtmlEncode $row.PSPortStatus)'>$psPortStatusHtml</td>
  <td class='err' data-sort='$(HtmlEncode $row.PSError)'>$psErrHtml</td>
  <td data-sort='$($row.WmiStatus)'>$wmiPill</td>
  <td class='err' data-sort='$(HtmlEncode $row.WmiError)'>$wmiErrHtml</td>
  <td data-sort='$(HtmlEncode $row.ShareStatus)'>$shareStatusPill</td>
  <td data-sort='$($row.AdminAccess)'>$adminPill</td>
  <td data-sort='$(HtmlEncode $row.ShareFailureType)'>$shareFailureHtml</td>
  <td data-sort='$($row.RDPPort)'>$rdpPill</td>
  <td data-sort='$($row.Port445)'>$p445Pill</td>
  <td data-sort='$($row.Port22)'>$p22Pill</td>
  <td class='err' data-sort='$(HtmlEncode $row.LinuxSshError)'>$linuxSshErrHtml</td>
</tr>
"@
}

$html = @"
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Server Access & RDP & PSRemoting Report</title>
    $style
</head>
<body>
    <header>
        <h1>Server Access / RDP / PSRemoting Report</h1>
        <div style='margin-left:auto;font-size:13px;'>$generated | $total servers</div>
    </header>
    <div class='container'>
        <div style='display:flex;gap:12px;align-items:center;margin-bottom:12px;'>
            <input id='filter' class='input' placeholder='Filter servers or status...'/>
                        <div style='display:flex;gap:8px;font-size:13px;'>
                            <label><input type='radio' name='viewMode' value='all' checked /> All</label>
                            <label><input type='radio' name='viewMode' value='success' /> Success</label>
                            <label><input type='radio' name='viewMode' value='failed' /> Failed</label>
                        </div>
                        <button id='exportCsvBtn' style='background:var(--accent2);color:#fff;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-weight:600;'>Export CSV</button>
        </div>

                <!-- Summary Statistics Section -->
                <div style='margin:0 0 12px 0; padding:10px; background:#f8f9fb; border-radius:8px; border:1px solid var(--grid);'>
                    <div style='display:flex; align-items:center; gap:20px; flex-wrap:wrap; font-size:12px;'>
                        <!-- Overall Success - Prominent (Windows PS Remoting, Linux SSH) -->
                        <div style='padding:10px 14px; background:$(if($overallSuccessPercent -ge 80){'linear-gradient(135deg,#107C10,#0D6B0D)'}elseif($overallSuccessPercent -ge 50){'linear-gradient(135deg,#FFB900,#FF8C00)'}else{'linear-gradient(135deg,#D13438,#A62A2E)'}); border-radius:6px; color:#fff; font-weight:700;'>
                            <div style='font-size:11px; opacity:0.9;'>Overall Success</div>
                            <div style='font-size:20px;'>$overallSuccessCount/$total <span style='font-size:16px;'>($overallSuccessPercent%)</span></div>
                        </div>

                        <!-- OS Types -->
                        <div style='padding:6px 10px; background:#fff; border-radius:6px; border:1px solid var(--grid);'>
                            <div style='font-size:10px; color:#606978; font-weight:600;'>💻 OS Types</div>
                            <div><span style='color:#107C10;'>🪟</span> $windowsCount ($windowsPercent%) <span style='color:#FF8C00; margin-left:8px;'>🐧</span> $linuxCount ($linuxPercent%)</div>
                        </div>

                        <!-- PS Remoting -->
                        <div style='padding:6px 10px; background:#fff; border-radius:6px; border:1px solid var(--grid);'>
                            <div style='font-size:10px; color:#606978; font-weight:600;'>⚡ PS Remoting</div>
                            <div>$psSuccessCount/$psTotal ($psSuccessPercent%) <span style='color:var(--bad);'>✗ $failedPs</span></div>
                        </div>

                        <!-- Admin Share -->
                        <div style='padding:6px 10px; background:#fff; border-radius:6px; border:1px solid var(--grid);'>
                            <div style='font-size:10px; color:#606978; font-weight:600;'>📁 Admin Share</div>
                            <div>$adminOk/$adminTotal ($adminSharePercent%) <span style='color:var(--bad);'>✗ $failedAdmin</span></div>
                        </div>

                        <!-- WMI -->
                        <div style='padding:6px 10px; background:#fff; border-radius:6px; border:1px solid var(--grid);'>
                            <div style='font-size:10px; color:#606978; font-weight:600;'>🔧 WMI</div>
                            <div>$wmiSuccessCount/$wmiTotal ($wmiSuccessPercent%) <span style='color:var(--bad);'>✗ $failedWmi</span></div>
                        </div>

                        <!-- RDP -->
                        <div style='padding:6px 10px; background:#fff; border-radius:6px; border:1px solid var(--grid);'>
                            <div style='font-size:10px; color:#606978; font-weight:600;'>🖥️ RDP:3389</div>
                            <div>$rdpOpenCount/$total ($rdpPercent%)</div>
                        </div>

                        <!-- SMB -->
                        <div style='padding:6px 10px; background:#fff; border-radius:6px; border:1px solid var(--grid);'>
                            <div style='font-size:10px; color:#606978; font-weight:600;'>🌐 SMB:445</div>
                            <div>$p445Ok/$total ($p445Percent%)</div>
                        </div>

                        <!-- Share Failures -->
                        $(if($failedAdmin -gt 0){"
                        <div style='padding:6px 10px; background:#fff; border-radius:6px; border:1px solid var(--grid);'>
                            <div style='font-size:10px; color:#606978; font-weight:600;'>⚠️ Share Failures</div>
                            <div style='font-size:11px;'>$(($shareFailureGroups | Where-Object { $_.Name -ne 'None' } | ForEach-Object { "$($_.Name):$($_.Count)" }) -join ' | ')</div>
                        </div>
                        "}else{''})
                    </div>
                </div>
        <div class='table-wrap'>
            <table>
                <thead>
                  <tr>
                    <th>Server</th>
                    <th>DNS Target</th>
                                        <th>Access</th>
                    <th>Ping</th>
                    <th>OS Type</th>
                    <th>PS Version</th>
                    <th>PS Port</th>
                    <th>PS Protocol</th>
                    <th>PS Port Status</th>
                    <th>PS Error</th>
                    <th>WMI Status</th>
                    <th>WMI Error</th>
                    <th>Share Status</th>
                    <th>Admin Share</th>
                    <th>Share Failure</th>
                    <th>RDP Port</th>
                    <th>Port 445</th>
                    <th>Port 22</th>
                    <th>Linux SSH Error</th>
                  </tr>
                </thead>
                                <tbody>
                                    $($rowsHtml -join "`n")
                                </tbody>
            </table>
        </div>
    </div>

    <!-- Test Descriptions Section -->
    <div class='container' style='margin-top:32px;border-top:2px solid var(--grid);padding-top:24px;'>
        <details style='border:1px solid var(--grid);border-radius:8px;background:#fff;padding:12px;'>
            <summary style='color:var(--accent);font-size:20px;font-weight:700;cursor:pointer;'>Test Descriptions</summary>
            <div style='display:grid;gap:16px;margin-top:12px;'>

            <div style='background:#f8f9fb;border:1px solid var(--grid);border-radius:8px;padding:16px;'>
                <h3 style='color:var(--accent2);margin:0 0 8px 0;font-size:16px;'>Target Resolution</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>Purpose:</strong> Confirms that the target can be reached before platform-specific access checks run.<br>
                    <strong>Method:</strong> Pings the provided server/FQDN first, then tries the short hostname when the FQDN cannot be reached.<br>
                    <strong>Address support:</strong> Successful IPv4 and IPv6 ping replies both count as alive. The report stores the reply address in DNS Target.<br>
                    <strong>Connection target:</strong> Follow-on checks use the hostname that answered ping, so Linux hosts that exist only in the local hosts file can still be checked.<br>
                    <strong>Results:</strong> <span class='pill ok' style='font-size:11px;'>Success</span> (target answered ping) or <span class='pill bad' style='font-size:11px;'>Failed</span> (no candidate answered ping)
                </p>
            </div>

            <div style='background:#f8f9fb;border:1px solid var(--grid);border-radius:8px;padding:16px;'>
                <h3 style='color:var(--accent2);margin:0 0 8px 0;font-size:16px;'>OS Type Selection</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>Purpose:</strong> Chooses the correct Windows or Linux access path.<br>
                    <strong>Method:</strong> Uses OSType, OS, or OperatingSystem from the server list when present. If no OS hint is supplied, network probes are used as a fallback.<br>
                    <strong>Linux behavior:</strong> Windows-only checks are skipped and shown as <span class='pill muted' style='background:#e8e8e8;color:#888;font-size:11px;'>N/A</span>.<br>
                    <strong>Windows behavior:</strong> WinRM, WMI, admin share, RDP, and SMB checks are performed.
                </p>
            </div>

            <div style='background:#f0f7ff;border:2px solid var(--accent);border-radius:8px;padding:16px;'>
                <h3 style='color:var(--accent);margin:0 0 8px 0;font-size:16px;'>PowerShell Remoting</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>Purpose:</strong> Validates Windows WinRM/PowerShell remoting access.<br>
                    <strong>Method:</strong> Tests WinRM availability, then attempts a lightweight PowerShell command with the available credential context.<br>
                    <strong>Ports:</strong> 5985 (HTTP) and 5986 (HTTPS).<br>
                    <strong>Linux rows:</strong> Not applicable and reported as N/A.<br>
                    <strong>Results:</strong> <span class='pill ok' style='font-size:11px;'>Success</span>, <span class='pill bad' style='font-size:11px;'>Failed</span>, or <span class='pill muted' style='background:#e8e8e8;color:#888;font-size:11px;'>N/A</span>
                </p>
            </div>

            <div style='background:#eefaf2;border:1px solid #107C10;border-radius:8px;padding:16px;'>
                <h3 style='color:#107C10;margin:0 0 8px 0;font-size:16px;'>Linux SSH Access</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>Purpose:</strong> Validates Linux SSH authentication with the configured Linux credential set.<br>
                    <strong>Method:</strong> Uses Posh-SSH to open an SSH session to the hostname that answered ping, then runs a simple command probe.<br>
                    <strong>Credential source:</strong> AlternateLinuxUsername and AlternateLinuxPassword from settings.json, or supplied username/password parameters.<br>
                    <strong>Settings format:</strong> settings.json passwords use CMSLibrary-compatible DPAPI CurrentUser encryption with Unicode text encoding.<br>
                    <strong>Results:</strong> <span class='pill ok' style='font-size:11px;'>Success</span> (SSH login and command probe worked) or <span class='pill bad' style='font-size:11px;'>Failed</span> (connection/authentication/probe failed)
                </p>
            </div>

            <div style='background:#fff8f0;border:1px solid #ff8c00;border-radius:8px;padding:16px;'>
                <h3 style='color:#e67e22;margin:0 0 8px 0;font-size:16px;'>WMI Testing</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>Purpose:</strong> Validates Windows remote management and system information access.<br>
                    <strong>Method:</strong> Queries Win32_OperatingSystem and records OS caption/version when available.<br>
                    <strong>Linux rows:</strong> Not applicable and reported as N/A.<br>
                    <strong>Results:</strong> <span class='pill ok' style='font-size:11px;'>Success</span>, <span class='pill bad' style='font-size:11px;'>Failed</span>, or <span class='pill muted' style='background:#e8e8e8;color:#888;font-size:11px;'>N/A</span>
                </p>
            </div>

            <div style='background:#f8fff0;border:1px solid #8bc34a;border-radius:8px;padding:16px;'>
                <h3 style='color:#689f38;margin:0 0 8px 0;font-size:16px;'>Admin Share Access</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>Purpose:</strong> Validates Windows administrative file share access for deployment and maintenance tasks.<br>
                    <strong>Method:</strong> Attempts to access configured admin shares, usually \\server\C$, using Test-Path and directory listing.<br>
                    <strong>Linux rows:</strong> Not applicable and reported as N/A.<br>
                    <strong>Failure types:</strong> AccessDenied, NotFound, Timeout, Other, None.<br>
                    <strong>Results:</strong> <span class='pill ok' style='font-size:11px;'>Access</span>, <span class='pill bad' style='font-size:11px;'>Fail</span>, or <span class='pill muted' style='background:#e8e8e8;color:#888;font-size:11px;'>N/A</span>
                </p>
            </div>

            <div style='background:#f8f9fb;border:1px solid var(--grid);border-radius:8px;padding:16px;'>
                <h3 style='color:var(--accent2);margin:0 0 8px 0;font-size:16px;'>Network Port Tests</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>RDP Port:</strong> Remote desktop availability on the configured RDP port, usually 3389.<br>
                    <strong>SMB Port 445:</strong> File sharing protocol used by Windows admin shares.<br>
                    <strong>SSH Port 22:</strong> Linux secure shell service availability.<br>
                    <strong>Method:</strong> TCP socket connection tests with timeout.<br>
                    <strong>Results:</strong> <span class='pill ok' style='font-size:11px;'>Open</span> or <span class='pill bad' style='font-size:11px;'>Closed</span>
                </p>
            </div>

            <div style='background:#f8f9fb;border:1px solid var(--grid);border-radius:8px;padding:16px;'>
                <h3 style='color:var(--accent2);margin:0 0 8px 0;font-size:16px;'>Filtering And Export</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>Text filter:</strong> Searches visible table text across all columns.<br>
                    <strong>Status filter:</strong> All, Success, and Failed use the combined Access result. N/A values are ignored for Access and only all-N/A rows remain N/A.<br>
                    <strong>Export CSV:</strong> Exports exactly the rows currently visible after the text and status filters are applied.
                </p>
            </div>

            <div style='background:#f8f9fb;border:1px solid var(--grid);border-radius:8px;padding:16px;'>
                <h3 style='color:var(--accent2);margin:0 0 8px 0;font-size:16px;'>Credential Handling</h3>
                <p style='margin:0;font-size:14px;line-height:1.5;'>
                    <strong>Windows credentials:</strong> Used for PowerShell remoting, WMI, and admin share tests when configured.<br>
                    <strong>Linux credentials:</strong> Used only for SSH authentication to Linux rows.<br>
                    <strong>Sources:</strong> settings.json, username/password parameters, or prompted credentials when requested.<br>
                    <strong>Security:</strong> settings.json secrets are encrypted with DPAPI CurrentUser scope and are only decryptable by the same Windows user on the same machine.
                </p>
            </div>

            </div>
        </details>
    </div>

    <footer>
        <span style='font-weight:600;color:var(--accent);'>Do what matters</span>
        <span class='muted'>&copy; 2025 Avanade. All rights reserved.</span>
        <span class='muted' style='font-size:12px;'>Script Version: v$ScriptVersion</span>
    </footer>
    $script
</body>
</html>
"@

# Resolve HTML path
if ([string]::IsNullOrWhiteSpace($HtmlOutputPath)) {
    # Default: Reports\Access\AdminAccessStatus-datestamp.html
    $finalHtmlPath = Join-Path -Path $reportsAccessDir -ChildPath "AdminAccessStatus-$datestamp.html"
}
else {
    $finalHtmlPath = $HtmlOutputPath
    if ($finalHtmlPath -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
        $finalHtmlPath = $finalHtmlPath -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
    }
    $finalHtmlPath = $finalHtmlPath.Trim().Trim("'`"")
    # If relative path provided, place in Reports\Access directory
    if (-not (Split-Path -IsAbsolute $finalHtmlPath) -and ($finalHtmlPath -notmatch '^[\\]{2}')) {
        $finalHtmlPath = Join-Path -Path $reportsAccessDir -ChildPath $finalHtmlPath
    }
}

function ConvertTo-LatestHtmlReportPath {
    param([string]$Path)

    $parent = Split-Path -Parent $Path
    $leaf = Split-Path -Leaf $Path
    $latestLeaf = $leaf -replace '[-_]\d{8}[-_]\d{6}\.html$', '-latest.html'
    if ($latestLeaf -eq $leaf) {
        $latestLeaf = [System.IO.Path]::GetFileNameWithoutExtension($leaf) + '-latest.html'
    }
    if ($parent) { return Join-Path $parent $latestLeaf }
    return $latestLeaf
}

$latestHtmlPath = ConvertTo-LatestHtmlReportPath -Path $finalHtmlPath

try {
    # Ensure output directory exists
    $htmlDir = Split-Path -Parent $finalHtmlPath
    if ($htmlDir -and -not (Test-Path -LiteralPath $htmlDir)) {
        New-Item -ItemType Directory -Path $htmlDir -Force | Out-Null
    }

    [IO.File]::WriteAllText($finalHtmlPath, $html, [Text.Encoding]::UTF8)
    Write-Host "      ✓ HTML saved: $finalHtmlPath" -ForegroundColor Green
    if ($latestHtmlPath -and ($latestHtmlPath -ne $finalHtmlPath)) {
        [IO.File]::WriteAllText($latestHtmlPath, $html, [Text.Encoding]::UTF8)
        Write-Host "      ✓ Latest HTML saved: $latestHtmlPath" -ForegroundColor Green
    }
    Write-Host "      → Opening report in browser..." -ForegroundColor White
    Invoke-Item -Path $finalHtmlPath
}
catch {
    Write-Warning "Failed to write HTML report to '$finalHtmlPath': $($_.Exception.Message)"
}

# Update variable so any subsequent messaging uses normalized path
$HtmlOutputPath = $finalHtmlPath

if ($summaryReport.Count -eq 0) {
    Write-Warning "No server results generated. Ensure the CSV has a 'Server' column (case-insensitive) and contains at least one non-empty server name."
}
else {
    $finalSuccessRate = if ($summaryReport.Count -gt 0) { [Math]::Round(($overallConsoleSuccessCount / $summaryReport.Count) * 100, 1) } else { 0 }
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "  Report Generation Complete!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Total Execution Time: $([Math]::Round(((Get-Date) - $startTime).TotalSeconds, 1)) seconds" -ForegroundColor White
    Write-Host "Servers Analyzed: $($summaryReport.Count)" -ForegroundColor White
    Write-Host "Success Rate: $finalSuccessRate%" -ForegroundColor $(if ($overallConsoleSuccessCount -gt $overallConsoleFailedCount) { 'Green' } else { 'Yellow' })
    Write-Host "========================================`n" -ForegroundColor Cyan
}

Write-Host "=== Transcript saved: $_logFile ===" -ForegroundColor DarkGray
Stop-Transcript -ErrorAction SilentlyContinue
