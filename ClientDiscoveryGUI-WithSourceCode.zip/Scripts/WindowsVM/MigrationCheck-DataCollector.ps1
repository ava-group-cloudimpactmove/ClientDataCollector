﻿<#
.SYNOPSIS
Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Running MigrationCheck-DataCollector from: $PSCommandPath (PSVersion=$($PSVersionTable.PSVersion))"
    Performs pre-migration validation checks on a Windows server and generates JSON data for further processing.
.DESCRIPTION
    Collects system information and runs a series of checks in preparation for migrating a server to Azure.
    The script outputs machine data in JSON format for consumption by other tools such as the HTML report generator.

    COMPATIBILITY: This script has been modified to run on PowerShell 5.1 by replacing ForEach-Object -Parallel
    with PowerShell Jobs for parallel execution.

.PARAMETER RunLocally
    Run the script on the local machine. If omitted, the script will attempt to run remotely on target servers.
.PARAMETER CheckType
    Label for the check phase (e.g. Pre_Migration, Post_Migration, Test_Migration) used in file names and report headers.
.PARAMETER ServerList
    Path to a CSV file containing a list of target servers (with a header "Server" or "ServerName"). Ignored if ServerName is provided.
.PARAMETER ScanIP
    Switch to enable scanning of files on C: drive for hardcoded IP addresses. If found, they are reported in the HTML and XML output.
.PARAMETER OutputDir
    Directory where output files will be saved. Defaults to "C:\Avanade\<Username>".
.PARAMETER ServerName
    Target server to scan. If provided, overrides ServerList. Use "localhost" for the local machine.
.PARAMETER GenerateSampleCSV
    Generate a sample CSV file named as specified in ServerList (default "serverlist.csv") with a "Server" header and a localhost entry.
.PARAMETER UseCredential
    Switch to enable credential prompting for remote connections. Only required if you want to be prompted for credentials interactively. If you provide PersonalJSON or Username/Password parameters, credentials will be used automatically without this switch.
.PARAMETER Username
    Username for remote connections. When provided along with Password, credentials will be used automatically without requiring the UseCredential switch.
.PARAMETER Password
    Plain text password for remote connections. When provided along with Username, credentials will be used automatically without requiring the UseCredential switch.
.PARAMETER SkipEventLog
    Switch to skip collecting Windows Event Log entries. Useful when event log collection is slow or times out,
    or when a quick scan is preferred. When set, the EventLogs section of the report will be empty.
.PARAMETER EventLogMaxEvents
    Maximum number of events to retrieve per event log (System and Application). Defaults to 1000.
    Lower this value if RAM usage during collection is too high. Set 0 to disable the cap (not recommended on busy servers).
.PARAMETER PersonalJSON
    Path to a personal JSON file containing encrypted credentials for remote connections. When provided, credentials will be used automatically without requiring the UseCredential switch.

    The JSON file should contain one of the following credential sets:
    1. AlternateUsername/AlternatePassword (encrypted)
    2. TestUsername/TestPassword (plain text)

    Example JSON structure:
    {
        "AlternateUsername": "domain\\user",
        "AlternatePassword": "encrypted_password_string",
        "TestUsername": "domain\\testuser",
        "TestPassword": "plain_text_password"
    }

    When multiple credential sets are present, AlternateUsername/AlternatePassword takes priority.

    Usage examples:
    .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -PersonalJSON "C:\personal.json"
    .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -Username "domain\user" -Password "password"
    .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -UseCredential  # Only prompts for credentials
.NOTES
Author: Ryan Ferguson
Modified for PowerShell 5.1 compatibility by replacing parallel processing with PowerShell Jobs
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("Pre_Migration", "Post_Migration", "Test_Migration")]
    [string]$CheckType,
    [switch]$RunLocally = $false,
    [string]$ServerList = ".\serverlist.csv",
    [switch]$ScanIP = $false,
    [string]$ScanIPPath = '',
    [string]$ProjectName,
    [string]$PersonalAccessToken,
    [string]$OutputDir = "C:\Avanade\$env:USERNAME",
    [string]$ServerName,
    [switch]$GenerateSampleCSV,
    [string]$OrganizationName = "CMSMigrations",
    [switch]$UseCredential = $false,
    [string]$Username ,
    [string]$Password ,
    [string]$PersonalJSON ,
    [string]$ProjectJson ,
    [int]$MaxThreads = 25,
    [switch]$SkipEventLog = $false,
    [int]$EventLogMaxEvents = 1000,
    [switch]$ServerOnlyData = $false,
    [int]$JobTimeoutSeconds = 600,
    [string]$ProgressStatusPath

)
$ScriptVersion = "26.07.04"
$licenseExpiryDate = Get-Date "2026-12-01"
function Get-CurrentScriptDirectory {
    $candidatePaths = @(
        $PSScriptRoot,
        $PSCommandPath,
        $MyInvocation.MyCommand.Path
    )

    foreach ($candidatePath in $candidatePaths) {
        if (-not [string]::IsNullOrWhiteSpace([string]$candidatePath) -and (Test-Path -LiteralPath $candidatePath)) {
            if (Test-Path -LiteralPath $candidatePath -PathType Container) {
                return $candidatePath
            }
            return (Split-Path -Parent $candidatePath)
        }
    }

    try {
        $processPath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        if (-not [string]::IsNullOrWhiteSpace([string]$processPath) -and (Test-Path -LiteralPath $processPath)) {
            $processName = [System.IO.Path]::GetFileNameWithoutExtension($processPath)
            if ($processName -notmatch '^(?i)(pwsh|powershell|powershell_ise)$') {
                return (Split-Path -Parent $processPath)
            }
        }
    }
    catch {
    }

    return (Get-Location).Path
}

$scriptDirectory = Get-CurrentScriptDirectory
Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Running MigrationCheck-DataCollector from: $scriptDirectory (PSVersion=$($PSVersionTable.PSVersion))"

function Resolve-CollectorCommandPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$BaseName,
        [Parameter(Mandatory = $true)]
        [string]$CurrentScriptDirectory
    )

    $parentDir = Split-Path -Parent $CurrentScriptDirectory
    $grandParentDir = Split-Path -Parent $parentDir

    $candidateDirectories = @(
        $CurrentScriptDirectory,
        (Join-Path $parentDir 'WindowsVM'),
        $parentDir,
        (Join-Path $grandParentDir 'Scripts\\WindowsVM'),
        (Join-Path $grandParentDir 'Scripts'),
        $grandParentDir
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | Select-Object -Unique

    $searchPaths = @()
    foreach ($dir in $candidateDirectories) {
        foreach ($ext in @('.exe', '.ps1')) {
            $candidate = Join-Path $dir ($BaseName + $ext)
            $searchPaths += $candidate
            if (Test-Path -LiteralPath $candidate) {
                return [PSCustomObject]@{
                    Path        = $candidate
                    SearchPaths = $searchPaths
                }
            }
        }
    }

    return [PSCustomObject]@{
        Path        = $null
        SearchPaths = $searchPaths
    }
}
try {
    Add-Type -AssemblyName System.Security -ErrorAction Stop
}
catch {
    Write-Warning "Could not load System.Security for DPAPI credential decrypt: $($_.Exception.Message)"
}
# CHANGELOG
# 2026-07-16: Added PotentialUsers collection with C:\Users directory timestamps, Security 4624 user logons, and inbound RDP/WinRM connections excluding the collector's own WinRM session.
# 2026-06-17: Hardened WinRM TrustedHosts fallback handling. Avoids invalid values like '*,server', normalizes previously malformed wildcard entries, and skips Basic authentication when no explicit credential is available.
# 2026-06-15: Added network connectivity collection (IPv4, active TCP only) with Direction and InternalExternal markers. Excludes 0.0.0.0/listening rows and records in NetworkConnectivityDetails.
# 2026-06-04: Normalized listening port State to a string before JSON serialization. Get-NetTCPConnection returns enum objects that can serialize as both 'value' and 'Value', which can cause ConvertFrom-Json casing errors in downstream reports.
# 2026-06-10: Broadened WinRM no-trust detection so explicit credential Negotiate/NTLM fallback runs for TrustedHosts/auth-scheme failures, not only 0x80090311 Kerberos realm failures.
# 2026-04-24: PowerShell 5.1 compatibility fix for path normalization. Replaced quote-trimming expressions that could misparse under Windows PowerShell 5.1 with explicit chained Trim("'").Trim('"') calls.
# 2026-04-21: Fixed roles/features collection in remote sessions: ServerManager module is now imported before checking for Get-WindowsFeature. Previously, Get-WindowsFeature was checked first (before import), which could fail in fresh remote PS sessions where the module hadn't auto-loaded, causing a silent fall-through to Get-WindowsOptionalFeature -Online and empty RolesAndFeatures results.
# 2026-04-21: Fixed remote result handling. Invoke-Command returns remote Write-Output log lines together with the final payload object; the caller now separates strings from the actual data object so remote scans are no longer misclassified as "No data collected".
# 2026-04-21: Clarified startup credential handling/logging to match actual remoting behavior. When -UseCredential is not supplied, current logged-in user context is attempted first and PersonalJSON/explicit credentials are treated as fallback only.
# 2026-04-18: Updated remoting credential order for GUI-driven runs: when -UseCredential is not supplied, current user context is attempted first, then PersonalJSON/explicit credentials. When -UseCredential is supplied, explicit credential-first behavior is preserved.
# 2026-04-17: Added credential username override behavior for PersonalJSON mode: when -Username is supplied with -PersonalJSON, the script now uses the supplied username with the decrypted JSON password. This allows domain/UPN identity overrides without editing stored secrets.
# 2026-04-16: Made FailoverClusters and ServerManager module imports remoting-compatible by conditionally applying -SkipEditionCheck only when supported by the active Import-Module command. Prevents roles/features and cluster warnings on Windows PowerShell 5.1 remoting endpoints. Added Negotiate/NTLM (HTTP) and Basic (HTTPS) authentication fallback attempts after Kerberos 0x80090311 errors to unblock cross-domain / no-trust environments.
# 2026-03-18: Fixed disk/volume collection: Get-Disk and Get-Volume now wrapped in try/catch with -ErrorAction SilentlyContinue; DriveLetter filtering replaced with regex '^[A-Za-z]$' to correctly exclude [char]0 (unassigned partition placeholder) that was corrupting disk-to-volume lookup tables. Fixed RAID UniqueId comparison from -match to -eq (UniqueId contains regex metacharacters). Fixed cluster collection: ResourceType comparisons now use explicit [string] cast; Get-ClusterResourceDependency now receives resource object via pipeline instead of -Resource name string; Get-ClusterParameter now uses pipeline instead of -InputObject; OwnerGroup fallback filter now compares .Name instead of object reference; ResourceType stored as [string] in $resources flat object.
# 2026-02-25: HTTPS remoting fallback (5986) now always applies SessionOption SkipCA/SkipCN/SkipRevocation checks so self-signed/untrusted certificates are accepted by default.
# 2026-02-25: Added -SkipEventLog and -EventLogMaxEvents (default 1000) parameters; $SkipEventLog and $EventLogMaxEvents now correctly threaded through serverScanScriptBlock and remoteScript param chains and all invocation sites; replaced Win32_Product software query with fast registry-based lookup (eliminates MSI reconfiguration overhead and reduces peak RAM); Get-WinEvent calls now capped by $EventLogMaxEvents to prevent the 20GB RAM spikes seen on servers with large event logs.
# 2026-02-24: Local servers now run in the current thread (no Start-Job) for real-time output; event log collection uses a runspace-based timeout so a hung Get-WinEvent call is cancelled and a timeout message is written into the EventLogs section of the report; Stop-Job/Remove-Job calls now use ErrorAction SilentlyContinue/try-catch to avoid -Force related errors.
# 2026-02-18: Prevent duplicate Event Log HTML generation by skipping if an Event Log report already exists and standardizing output naming.
# License validation check

$currentDate = Get-Date

Write-Host "Checking script license..." -ForegroundColor Yellow

if ($currentDate -gt $licenseExpiryDate) {
    Write-Host "License validation failed. This script version has expired." -ForegroundColor Red
    Write-Host "Deleting expired script..." -ForegroundColor Red

    # Delete the current script file
    try {
        Remove-Item -Path $PSCommandPath -Force
        Write-Host "Script deleted successfully." -ForegroundColor Red
        Write-Host "Please download the latest version from the Cloud Impact Move site." -ForegroundColor Yellow
        exit 1
    }
    catch {
        Write-Error "Failed to delete script: $_"
        Write-Host "Please manually delete this script and download the latest version from the Cloud Impact Move site." -ForegroundColor Yellow
        exit 1
    }
}

Write-Host "License validation passed." -ForegroundColor Green

# Function to decrypt encrypted credentials from PersonalJSON file
function PAT-Decrypt {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$EncryptedPAT
    )

    try {
        if (-not $EncryptedPAT) {
            throw "Encrypted value is null or empty."
        }
        # Convert the Base64-encoded string back to an array of bytes.
        $encryptedBytes = [Convert]::FromBase64String($EncryptedPAT)

        # Decrypt the bytes using DPAPI with the current user scope.
        $decryptedBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($encryptedBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)

        # Convert the decrypted bytes back into a string.
        $decryptedPAT = [System.Text.Encoding]::Unicode.GetString($decryptedBytes)
    }
    catch {
        $msg = if ($_.Exception -and $_.Exception.Message) { $_.Exception.Message } else { "Unknown error" }
        Write-Verbose "Could not decrypt Personal JSON value with DPAPI CurrentUser: $msg"
        $decryptedPAT = $null
    }

    return $decryptedPAT
}

# Ensure script is running as administrator
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Continuing without Administrator privileges. Some operations may fail." -ForegroundColor Yellow
}

# Handle credentials for remote connections
$credential = $null
$credentialSource = 'current user context'
$preferCurrentUserFirst = (-not $UseCredential)

# Check if username and password parameters were provided (automatically use credentials)
if (![string]::IsNullOrEmpty($Username) -and ![string]::IsNullOrEmpty($Password)) {
    if ($preferCurrentUserFirst) {
        Write-Host "Loading fallback credentials provided via parameters. Current user context will be attempted first." -ForegroundColor Green
    }
    else {
        Write-Host "Using credentials provided via parameters as the primary remoting credentials..." -ForegroundColor Green
    }
    $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($Username, $securePassword)
    $credentialSource = "supplied parameters ($Username)"
}
# Check if personal JSON file was provided (automatically use credentials)
elseif (![string]::IsNullOrEmpty($PersonalJSON) -and (Test-Path $PersonalJSON)) {
    # Normalize the personal JSON path to remove PowerShell provider prefixes
    $normalizedPersonalJSON = $PersonalJSON
    if ($normalizedPersonalJSON -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
        $normalizedPersonalJSON = $normalizedPersonalJSON -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
    }
    $normalizedPersonalJSON = $normalizedPersonalJSON.Trim().Trim("'").Trim('"')

    if ($preferCurrentUserFirst) {
        Write-Host "Loading fallback credentials from personal JSON: $normalizedPersonalJSON" -ForegroundColor Green
    }
    else {
        Write-Host "Loading primary credentials from personal JSON: $normalizedPersonalJSON" -ForegroundColor Green
    }
    try {
        $personalData = Get-Content $normalizedPersonalJSON | ConvertFrom-Json

        # Extract credentials from personal JSON with priority order
        $username = $null
        $password = $null
        $credentialIssue = $null

        # Priority 1: AlternateUsername/AlternatePassword (encrypted)
        $hasAlternateCreds = ($personalData.PSObject.Properties.Name -contains 'AlternateUsername' -and
            $personalData.PSObject.Properties.Name -contains 'AlternatePassword' -and
            -not [string]::IsNullOrWhiteSpace($personalData.AlternateUsername) -and
            -not [string]::IsNullOrWhiteSpace($personalData.AlternatePassword))

        if ($hasAlternateCreds) {

            $username = $personalData.AlternateUsername
            $password = PAT-Decrypt -EncryptedPAT $personalData.AlternatePassword
            if (-not [string]::IsNullOrWhiteSpace($password)) {
                Write-Host "Successfully loaded and decrypted AlternateUsername/AlternatePassword." -ForegroundColor Green
            }
            else {
                $password = $null
                $credentialIssue = "Personal JSON contains AlternateUsername/AlternatePassword, but AlternatePassword could not be decrypted (DPAPI CurrentUser). This usually means it was encrypted under a different Windows user profile or on a different machine."
            }
        }

        # Priority 2: TestUsername/TestPassword (plain text) - only if alternate not available
        $hasTestCreds = ($personalData.PSObject.Properties.Name -contains 'TestUsername' -and
            $personalData.PSObject.Properties.Name -contains 'TestPassword' -and
            -not [string]::IsNullOrWhiteSpace($personalData.TestUsername) -and
            -not [string]::IsNullOrWhiteSpace($personalData.TestPassword))

        if (-not $password -and $hasTestCreds) {

            $username = $personalData.TestUsername
            $password = $personalData.TestPassword
            $credentialIssue = $null
            Write-Host "Successfully loaded TestUsername/TestPassword." -ForegroundColor Green
        }

        if ($username -and $password) {
            if (-not [string]::IsNullOrWhiteSpace($Username) -and ($Username -ne $username)) {
                Write-Host "Overriding Personal JSON username '$username' with supplied -Username '$Username' while reusing decrypted JSON password." -ForegroundColor Yellow
                $username = $Username
            }
            $securePassword = ConvertTo-SecureString $password -AsPlainText -Force
            $credential = New-Object System.Management.Automation.PSCredential($username, $securePassword)
            $credentialSource = "personal JSON ($username)"
            if ($preferCurrentUserFirst) {
                Write-Host "Fallback credentials loaded successfully from personal JSON." -ForegroundColor Green
            }
            else {
                Write-Host "Credentials loaded successfully from personal JSON and will be attempted first." -ForegroundColor Green
            }
        }
        else {
            if ($credentialIssue) {
                Write-Warning $credentialIssue
            }
            else {
                Write-Warning "Personal JSON file does not contain valid credentials. Expected AlternateUsername/AlternatePassword or TestUsername/TestPassword."
            }
        }
    }
    catch {
        Write-Warning "Failed to load credentials from personal JSON: $($_.Exception.Message)"
    }
}
# If UseCredential is specified but no JSON or user/pass provided, check if credentials are actually available
elseif ($UseCredential) {
    # Check if username and password are blank (not provided via command line or JSON)
    if ([string]::IsNullOrEmpty($Username) -and [string]::IsNullOrEmpty($Password)) {
        Write-Host "UseCredential switch specified but no credentials were provided." -ForegroundColor Yellow
        Write-Host "No alternate credentials will be attempted. Will use current user context." -ForegroundColor Yellow
        Write-Host "" -ForegroundColor Yellow
        Write-Host "To provide credentials, use one of these methods:" -ForegroundColor Cyan
        Write-Host "  1. Username and Password parameters: -Username 'domain\user' -Password 'password'" -ForegroundColor Gray
        Write-Host "  2. PersonalJSON parameter: -PersonalJSON 'C:\personal.json'" -ForegroundColor Gray
        Write-Host "" -ForegroundColor Yellow
        # Continue without credentials (use current user context)
        $credential = $null
    }
    else {
        # Credentials are available, try to prompt
        Write-Host "Prompting for credentials to connect to remote servers..." -ForegroundColor Yellow
        try {
            # Check if we're in an interactive session
            if ([Environment]::UserInteractive -and $Host.Name -ne "ServerRemoteHost") {
                $credential = Get-Credential -Message "Enter credentials for connecting to remote servers"
                if ($null -eq $credential) {
                    Write-Warning "No credentials provided at prompt. Will use current user context."
                    $credential = $null
                }
                else {
                    Write-Host "Credentials captured successfully. Will use these for all remote connections." -ForegroundColor Green
                }
            }
            else {
                Write-Error "UseCredential switch requires either:"
                Write-Error "  1. An interactive PowerShell session (PowerShell Console, ISE, or Windows Terminal)"
                Write-Error "  2. Username and Password parameters provided"
                Write-Error "  3. PersonalJSON parameter with path to personal JSON file containing credentials"
                Write-Error ""
                Write-Error "Current host: $($Host.Name)"
                Write-Error ""
                Write-Error "Example with parameters:"
                Write-Error "  .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -Username 'domain\user' -Password 'password'"
                Write-Error ""
                Write-Error "Example with personal JSON:"
                Write-Error "  .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -PersonalJSON 'C:\personal.json'"
                Write-Error ""
                Write-Error "Alternatively, run without any credential parameters to use current user context."
                exit 1
            }
        }
        catch {
            Write-Error "Failed to capture credentials: $_"
            Write-Error "This may be due to running in a non-interactive environment."
            Write-Error "Consider using the Username and Password parameters instead:"
            Write-Error "  .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -Username 'domain\user' -Password 'password'"
            exit 1
        }
    }
}
# If no credentials provided at all, will use current user context (credential = $null)

if ($credential -and $preferCurrentUserFirst) {
    try {
        $computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
        if (-not [bool]$computerSystem.PartOfDomain) {
            $preferCurrentUserFirst = $false
            Write-Host "Local computer is not domain-joined; explicit credentials will be attempted before current user context." -ForegroundColor Yellow
        }
    }
    catch {
        Write-Verbose "Could not determine local domain membership: $($_.Exception.Message)"
    }
}

if ($RunLocally) {
    Write-Host "Remote credential mode: local execution only; no remoting credentials needed." -ForegroundColor Cyan
}
elseif ($credential) {
    if ($preferCurrentUserFirst) {
        Write-Host "Remote credential order: current user context first, then fallback credentials from $credentialSource." -ForegroundColor Cyan
    }
    else {
        Write-Host "Remote credential order: explicit credentials from $credentialSource first, then current user context." -ForegroundColor Cyan
    }
}
else {
    Write-Host "Remote credential order: current user context only." -ForegroundColor Cyan
}


if ($GenerateSampleCSV) {
    Write-Host "Generating sample CSV: $ServerList"
    "Server,DomainName" | Out-File -FilePath $ServerList -Encoding UTF8
    "localhost,cms.local" | Out-File -FilePath $ServerList -Append -Encoding UTF8
    return
}

# Suppress progress bars (Copy-Item, etc.) to keep console output clean
$ProgressPreference = 'SilentlyContinue'

# Ensure the output directory exists
if (!(Test-Path $OutputDir)) {
    New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null
}

# Initialize transcript logging using standardized function
# Note: Initialize-TranscriptLogging is defined in CMSLibrary.ps1
if (Get-Command -Name Initialize-TranscriptLogging -ErrorAction SilentlyContinue) {
    # Place transcripts in parent directory of OutputDir + \Transcripts
    $transcriptOutputDir = Split-Path $OutputDir -Parent
    $transcriptPath = Initialize-TranscriptLogging -OutputDir $transcriptOutputDir -ScriptName "MigrationCheck-DataCollector"
} else {
    # Fallback for standalone execution without CMSLibrary.ps1
    # Place transcripts in parent directory of OutputDir + \Transcripts
    $transcriptParentDir = Split-Path $OutputDir -Parent
    $transcriptsDir = Join-Path $transcriptParentDir "Transcripts"
    if (!(Test-Path $transcriptsDir)) {
        New-Item -Path $transcriptsDir -ItemType Directory -Force | Out-Null
    }
    $transcriptFileName = "MigrationCheck-DataCollector-transcript-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt"
    $transcriptPath = Join-Path $transcriptsDir $transcriptFileName
    Start-Transcript -Path $transcriptPath
}

# Logging helper function to output messages with timestamps
function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message"
}
Write-Log "Script started. CheckType: $CheckType, OutputDir: $OutputDir, RunLocally: $RunLocally, IPScan: $ScanIP"

# Post_Migration always collects event logs even when -SkipEventLog was requested.
# Default floor for post-migration event capture is 2000 if no explicit value was given.
if ($CheckType -match 'Post' -and $SkipEventLog) {
    Write-Host "[INFO] Post_Migration: overriding -SkipEventLog; event logs will always be collected for post-migration checks." -ForegroundColor Yellow
    $SkipEventLog = $false
    if ($EventLogMaxEvents -le 1000) { $EventLogMaxEvents = 2000 }
}

#======================================================================
# LOCAL HELPER FUNCTIONS
#======================================================================


# Determine target servers.
$targetServers = @()
$MyHostName = (Get-CimInstance -ClassName Win32_ComputerSystem).DNSHostName
if ($RunLocally -or $ServerName -eq "localhost") {
    $targetServers = @($MyHostName)
}
elseif ($ServerName) {
    # Handle comma-separated server names
    if ($ServerName -match ',') {
        $targetServers = $ServerName -split ',' | ForEach-Object { $_.Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    }
    else {
        $targetServers = @($ServerName.Trim())
    }
}
else {
    if (Test-Path $ServerList) {
        try {
            $csv = Import-Csv -Path $ServerList
            foreach ($entry in $csv) {
                # Only include rows that provide an actual host name (Server or ServerName).
                $hostPart = $null
                if ($entry.Server) { $hostPart = $entry.Server }
                elseif ($entry.ServerName) { $hostPart = $entry.ServerName }

                if ($hostPart) {
                    $NewServerNameFQDN = $hostPart
                    if ($entry.DomainName) {
                        $NewServerNameFQDN += "." + $entry.DomainName
                    }
                    $targetServers += $NewServerNameFQDN
                }
                else {
                    # Skip rows that do not contain a host; avoid creating entries like ".domain.com" which yield empty hostnames later
                    continue
                }
            }
        }
        catch {
            Write-Warning "Failed to import CSV. Defaulting to localhost."
            $targetServers = @($MyHostName)
        }
    }
    else {
        Write-Warning "Server list file not found. Defaulting to localhost."
        $targetServers = @($MyHostName)
    }
}
# Normalize the target servers list: trim whitespace, remove empty entries, and deduplicate
$targetServers = $targetServers | ForEach-Object { $_.ToString().Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
Write-Host "Target servers: $($targetServers -join ', ')"

# Get script directory for calling auxiliary collection scripts
if ([string]::IsNullOrWhiteSpace([string]$scriptDirectory)) {
    $scriptDirectory = Get-CurrentScriptDirectory
}

# --- REMOTE CALLS (PowerShell 5.1 Compatible) ---
$jobs = @()
$jobToServer = @{}
$results = @()

# Script block for per-server data collection.
# For local servers this is invoked directly in the current thread (no background job) so
# the user sees real-time output and error messages.  For remote servers it runs via Start-Job.
$serverScanScriptBlock = {
    param($ServerName, $CheckType, $ScanIP, $ScanIPPath, $ScriptVersion, $OutputDir, $credential, $PersonalAccessToken, $ProjectName, $OrganizationName, $scriptDirectory, $SkipEventLog, $EventLogMaxEvents, $ServerOnlyData, $PreferCurrentUserFirst)

    function Resolve-CollectorCommandPath {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)]
            [string]$BaseName,
            [Parameter(Mandatory = $true)]
            [string]$CurrentScriptDirectory
        )

        $parentDir = Split-Path -Parent $CurrentScriptDirectory
        $grandParentDir = Split-Path -Parent $parentDir

        $candidateDirectories = @(
            $CurrentScriptDirectory,
            (Join-Path $parentDir 'WindowsVM'),
            $parentDir,
            (Join-Path $grandParentDir 'Scripts\WindowsVM'),
            (Join-Path $grandParentDir 'Scripts'),
            $grandParentDir
        ) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | Select-Object -Unique

        $searchPaths = @()
        foreach ($dir in $candidateDirectories) {
            foreach ($ext in @('.exe', '.ps1')) {
                $candidate = Join-Path $dir ($BaseName + $ext)
                $searchPaths += $candidate
                if (Test-Path -LiteralPath $candidate) {
                    return [PSCustomObject]@{
                        Path        = $candidate
                        SearchPaths = $searchPaths
                    }
                }
            }
        }

        return [PSCustomObject]@{
            Path        = $null
            SearchPaths = $searchPaths
        }
    }

    # Resolve CMSLibrary.ps1 location - searches multiple locations to support deployment flexibility
    $cmsLibraryPath = $null
    $searchPaths = @(
        (Join-Path $scriptDirectory 'CMSLibrary.ps1'),                    # Same directory as script
        (Join-Path (Split-Path -Parent $scriptDirectory) 'CMSLibrary.ps1'),  # Parent directory (for nested scripts like WindowsVM/)
        (Join-Path (Split-Path -Parent (Split-Path -Parent $scriptDirectory)) 'CMSLibrary.ps1'),  # Two levels up
        (Join-Path (Split-Path -Parent $scriptDirectory) '../Scripts/CMSLibrary.ps1'),  # ../Scripts relative
        (Join-Path (Split-Path -Parent $scriptDirectory) '../../Scripts/CMSLibrary.ps1')  # ../../Scripts relative
    )
    
    foreach ($path in $searchPaths) {
        $resolvedPath = Resolve-Path -Path $path -ErrorAction SilentlyContinue
        if ($resolvedPath -and (Test-Path $resolvedPath)) {
            $cmsLibraryPath = $resolvedPath
            break
        }
    }
    
    if ($cmsLibraryPath) {
        try {
            . $cmsLibraryPath
        }
        catch {
            Write-Warning "Failed to load CMSLibrary.ps1 from '$cmsLibraryPath' in this runspace: $($_.Exception.Message)"
        }
    }
    else {
        Write-Warning "CMSLibrary.ps1 not found in any standard location. Shared ADO helper functions will be unavailable in this runspace. Search paths: $($searchPaths -join ', ')"
    }

    # --- REMOTE SCRIPT BLOCK ---
    $remoteScript = {
        param([string]$CheckType, [bool]$ScanIP, [string]$ScanIPPath = '', [bool]$SkipEventLog = $false, [int]$EventLogMaxEvents = 1000, [string[]]$CollectorClientAddresses = @(), [bool]$LocalDebug = $false)
        $StartTime = Get-Date
        $ServerName = $env:COMPUTERNAME
        if ($LocalDebug) {
            Write-Output "[0 (s)] [$ServerName] Initializing local data collection context..."
            Write-Output "[0 (s)] [$ServerName] Resolving host identity (Win32_ComputerSystem)..."
        }
        $MyHostName = (Get-CimInstance -ClassName Win32_ComputerSystem).DNSHostName
        $ServerName = $MyHostName

            if ($LocalDebug) {
                Write-Output "[$([math]::Round(((Get-Date) - $StartTime).TotalSeconds, 2)) (s)] [$ServerName] Host identity resolved. Starting detailed collection steps..."
            }

            function Write-Log {
                param([string]$Servername, [string]$Message)
                $Now = Get-Date
                $TimeSoFar = $Now - $StartTime
                $TimeSoFar = [math]::Round($TimeSoFar.TotalSeconds, 2)
                Write-Output "[$TimeSoFar (s)] [$Servername] $Message"
            }

            # Emits a result-summary line after a collection step - local thread only, never in a job.
            function Write-StepResult {
                param([string]$Step, [string]$Detail)
                if ($LocalDebug) { write-log $ServerName "    >> [$Step] $Detail" }
            }

            function Get-LogonTypeName {
                param([string]$LogonType)

                switch ($LogonType) {
                    '2'  { return 'Interactive' }
                    '3'  { return 'Network' }
                    '10' { return 'RemoteInteractive' }
                    default { return $LogonType }
                }
            }

            function Get-EventDataValue {
                param(
                    [xml]$EventXml,
                    [string]$Name
                )

                try {
                    $node = $EventXml.Event.EventData.Data | Where-Object { $_.Name -eq $Name } | Select-Object -First 1
                    if ($node) { return [string]$node.'#text' }
                }
                catch {
                }

                return ''
            }

            function Test-IsPotentialUserAccount {
                param([string]$UserName)

                $excludedLogonAccounts = @('ANONYMOUS LOGON', 'SYSTEM', 'LOCAL SERVICE', 'NETWORK SERVICE')
                return (
                    -not [string]::IsNullOrWhiteSpace($UserName) -and
                    $UserName -notmatch '\$$' -and
                    $UserName -notin $excludedLogonAccounts
                )
            }

            function Get-PotentialUsersData {
                param(
                    [DateTime]$EventCutoffDate,
                    [bool]$SkipLogonEvents,
                    [int]$MaxEvents,
                    [string[]]$CollectorAddresses
                )

                $defaultMaxLogonEvents = 1000
                $logonTypeInteractive = '2'
                $logonTypeNetwork = '3'
                $logonTypeRemoteInteractive = '10'
                $userLogonTypes = @($logonTypeInteractive, $logonTypeNetwork, $logonTypeRemoteInteractive)

                $userDirectories = @()
                try {
                    if (Test-Path -LiteralPath 'C:\Users') {
                        $userDirectories = @(
                            Get-ChildItem -LiteralPath 'C:\Users' -Directory -Force -ErrorAction SilentlyContinue |
                                Sort-Object LastWriteTime -Descending |
                                Select-Object @{Name = 'Path'; Expression = { $_.FullName }},
                                    Name,
                                    @{Name = 'LastModified'; Expression = { $_.LastWriteTime }},
                                    @{Name = 'LastModifiedUtc'; Expression = { $_.LastWriteTimeUtc }}
                        )
                    }
                }
                catch {
                    $userDirectories = @(
                        [PSCustomObject]@{
                            Path            = 'C:\Users'
                            Name            = ''
                            LastModified    = ''
                            LastModifiedUtc = ''
                            Error           = "Unable to enumerate C:\Users: $($_.Exception.Message)"
                        }
                    )
                }

                $logonEvents = @()
                if (-not $SkipLogonEvents) {
                    try {
                        $eventCap = if ($MaxEvents -gt 0) { $MaxEvents } else { $defaultMaxLogonEvents }
                        $logonEvents = @(
                            Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4624; StartTime = $EventCutoffDate } -MaxEvents $eventCap -ErrorAction Stop |
                                ForEach-Object {
                                    $eventXml = [xml]$_.ToXml()
                                    $logonType = Get-EventDataValue -EventXml $eventXml -Name 'LogonType'
                                    $targetUser = Get-EventDataValue -EventXml $eventXml -Name 'TargetUserName'
                                    if (($logonType -in $userLogonTypes) -and (Test-IsPotentialUserAccount -UserName $targetUser)) {

                                        $targetDomain = Get-EventDataValue -EventXml $eventXml -Name 'TargetDomainName'
                                        $ipAddress = Get-EventDataValue -EventXml $eventXml -Name 'IpAddress'
                                        $workstationName = Get-EventDataValue -EventXml $eventXml -Name 'WorkstationName'

                                        [PSCustomObject]@{
                                            TimeCreated     = $_.TimeCreated
                                            UserId          = if ([string]::IsNullOrWhiteSpace($targetDomain)) { $targetUser } else { "$targetDomain\$targetUser" }
                                            LogonType       = $logonType
                                            LogonTypeName   = Get-LogonTypeName -LogonType $logonType
                                            SourceIpAddress = $ipAddress
                                            WorkstationName = $workstationName
                                            EventId         = $_.Id
                                            ProviderName    = $_.ProviderName
                                        }
                                    }
                                } |
                                Where-Object { $null -ne $_ } |
                                Sort-Object TimeCreated -Descending
                        )
                    }
                    catch {
                        $logonEvents = @(
                            [PSCustomObject]@{
                                TimeCreated     = ''
                                UserId          = ''
                                LogonType       = ''
                                LogonTypeName   = ''
                                SourceIpAddress = ''
                                WorkstationName = ''
                                EventId         = 4624
                                ProviderName    = 'Security'
                                Error           = "Unable to query Security logon events: $($_.Exception.Message)"
                            }
                        )
                    }
                }

                $collectorAddressSet = @{}
                foreach ($addr in @($CollectorAddresses)) {
                    $addrText = [string]$addr
                    if (-not [string]::IsNullOrWhiteSpace($addrText)) {
                        $collectorAddressSet[$addrText] = $true
                    }
                }

                $inboundConnections = @()
                try {
                    $managementPorts = @(3389, 5985, 5986)
                    $winRmPorts = @(5985, 5986)
                    $inboundConnections = @(
                        Get-NetTCPConnection -State Established -ErrorAction Stop |
                            Where-Object {
                                # Best-effort exclusion for this collector run: when scanning remotely, the
                                # collector's directly enumerated IP addresses are passed in and matching
                                # inbound WinRM connections are hidden. NAT/proxy paths may still appear.
                                ($_.LocalPort -in $managementPorts) -and
                                ($_.LocalAddress -notlike '127.*') -and
                                ($_.LocalAddress -ne '::1') -and
                                ($_.LocalAddress -ne '0.0.0.0') -and
                                ($_.RemoteAddress -notlike '127.*') -and
                                ($_.RemoteAddress -ne '::1') -and
                                ($_.RemoteAddress -ne '0.0.0.0') -and
                                -not (($_.LocalPort -in $winRmPorts) -and $collectorAddressSet.ContainsKey([string]$_.RemoteAddress))
                            } |
                            Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort,
                                @{Name = 'State'; Expression = { [string]$_.State }},
                                OwningProcess,
                                @{Name = 'ProcessName'; Expression = {
                                    try { (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName } catch { '' }
                                }},
                                @{Name = 'Protocol'; Expression = { 'TCP' }}
                    )
                }
                catch {
                    $inboundConnections = @(
                        [PSCustomObject]@{
                            LocalAddress  = ''
                            LocalPort     = ''
                            RemoteAddress = ''
                            RemotePort    = ''
                            State         = ''
                            OwningProcess = ''
                            ProcessName   = ''
                            Protocol      = 'TCP'
                            Error         = "Unable to collect inbound RDP/WinRM connections: $($_.Exception.Message)"
                        }
                    )
                }

                return [PSCustomObject]([ordered]@{
                    UserProfileDirectories       = $userDirectories
                    LogonEvents                  = $logonEvents
                    InboundManagementConnections = $inboundConnections
                })
            }

            function Test-TcpPortWithTimeout {
                param(
                    [Parameter(Mandatory = $true)][string]$ComputerName,
                    [Parameter(Mandatory = $true)][int]$Port,
                    [int]$TimeoutMs = 5000
                )

                $client = New-Object System.Net.Sockets.TcpClient
                $asyncResult = $null
                try {
                    $asyncResult = $client.BeginConnect($ComputerName, $Port, $null, $null)
                    if (-not $asyncResult.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
                        return $false
                    }
                    $null = $client.EndConnect($asyncResult)
                    return $true
                }
                catch {
                    return $false
                }
                finally {
                    try { $client.Close() } catch { }
                    if ($asyncResult -and $asyncResult.AsyncWaitHandle) {
                        try { $asyncResult.AsyncWaitHandle.Close() } catch { }
                    }
                }
            }

            $script:localStepCounter = 0
            $script:localStepTotal = 17

            function Write-Stage {
                param([string]$Message)
                if ($LocalDebug) {
                    $script:localStepCounter++
                    if ($script:localStepCounter -gt $script:localStepTotal) {
                        $script:localStepTotal = $script:localStepCounter
                    }
                    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [local-step $($script:localStepCounter)/$($script:localStepTotal)] [$ServerName] $Message" -ForegroundColor Cyan
                }
            }

            Write-Stage "Starting core system inventory"
            Write-log $ServerName "Starting data collection on $MyHostName..."



            function IPscan {
                $scanIPStart = Get-Date

                $localIPs = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                Select-Object -ExpandProperty IPAddress

                # When a specific scan path is provided, limit the scan to that directory only
                if (-not [string]::IsNullOrWhiteSpace($ScanIPPath)) {
                    Write-Log $ServerName "IP scan starting — limited scan of '$ScanIPPath' only..."
                    $RootPath = $null
                    $Includes = @()
                    if (Test-Path $ScanIPPath -ErrorAction SilentlyContinue) {
                        $Includes = @(Get-ChildItem -Path $ScanIPPath -File -ErrorAction SilentlyContinue |
                            Select-Object -ExpandProperty FullName)
                    }
                } else {
                    Write-Log $ServerName "IP scan starting — scanning C:\ for hardcoded RFC-1918 addresses..."
                    $Includes = @('C:\Windows\System32\drivers\etc\hosts')
                    $RootPath = 'C:\'
                }

                $Excludes = @(
                    'C:\Program Files\WindowsPowerShell\',
                    'C:\Windows\',
                    'C:\Users\',
                    'C:\Avanade\',
                    '\Microsoft',
                    '\Tmp\',
                    'PowerShell\Modules',
                    'ShellExtensions\Platform',
                    'Reference Assemblies\Microsoft\Framework',
                    'Program Files\nodejs\',
                    '\lib\',
                    'README',
                    '\log\',
                    'agent\plugin\',
                    'sf3\',
                    'WinPcap\',
                    'C:\Scripts\',
                    '\Temp\'
                )
                $ExcludesNormalized = $Excludes | ForEach-Object { $_.Trim().TrimEnd('\').ToLower() }

                $ExcludeFiles = @(
                    '*.dll', '*.ex*', '*.gif', '*.png', '*.bmp', '*.ico', '*.mui', '*.sys', '*.chm',
                    '*.pfx', '*.cer', '*.evtx', '*.tlb', '*.zip', '*.htm*', '*.msi', '*.csv', '*.doc*',
                    '*.xls*', '*.ppt*', '*.rtf', '*.cat', '*.manifest', '*.svc', '*.svg',
                    '*.dat', '*.pyc', '*.hpp', '*.lib*', '*.rst', '*.avi', '*.mp*', '*.pdf', '*.wmf',
                    '*.jp*', '*.ttf', '*.wav', '*.vs*', '*.pak', '*.bundle', '*.nls', '*.deploy',
                    '*.jar', '*.sav', '*.xml', '*.adt', '*.tim', '*.dvd', '*.cfs', '*.pos',
                    '*.bin', '*.cab', '*.msp', '*.etl', '*.dmp', '*.mdmp', '*.pdb', '*.ilk',
                    '*.cache', '*.tmp', '*.temp', '*.bak', '*.old', '*.orig', '*.swp', '*.swo',
                    '*.iso', '*.img', '*.vhd*', '*.vmdk', '*.ova', '*.ovf', '*.wim', '*.esd',
                    '*.mof', '*.p7*', '*.crl', '*.sst', '*.stl', '*.crt', '*.key', '*.pem',
                    '*.font', '*.fon', '*.eot', '*.woff*', '*.otf', '*.cur', '*.ani',
                    '*.db', '*.mdb', '*.ldb', '*.sqlite*', '*.log', '*.trace', '*.out',
                    '*.o', '*.obj', '*.a', '*.so', '*.dylib', '*.class', '*.pyc', '*.pyo',
                    '*.bsc', '*.sbr', '*.pch', '*.idb', '*.suo', '*.user', '*.sdf',
                    '*.resx', '*.resources', '*.designer.*', '*.generated.*', '*.g.cs',
                    '*.min.*', '*.compressed.*', '*.obfuscated.*', '*.merged.*'
                )

                $ipRegex = '\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b'
                $ipRegexCompiled = [regex]::new($ipRegex, [System.Text.RegularExpressions.RegexOptions]::Compiled)

                $IPMatches = @()

                function Test-IsBinaryFile {
                    param ([string]$FilePath)

                    try {
                        # Read first 4KB of file as raw bytes
                        $stream = [System.IO.File]::OpenRead($FilePath)
                        $buffer = New-Object byte[] 4096
                        $bytesRead = $stream.Read($buffer, 0, 4096)
                        $stream.Close()

                        if ($bytesRead -eq 0) { return $false } # Empty = not binary

                        # Define printable characters (tab, LF, CR, and 32–126 ASCII range)
                        $printableCount = ($buffer[0..($bytesRead - 1)] | Where-Object {
                                ($_ -eq 9) -or ($_ -eq 10) -or ($_ -eq 13) -or ($_ -ge 32 -and $_ -le 126)
                            }).Count

                        $printableRatio = $printableCount / $bytesRead
                        return ($printableRatio -lt 0.80)  # If < 80% printable = binary
                    }
                    catch {
                        return $true  # Unreadable = assume binary
                    }
                }


                # Scan manually-included files
                foreach ($filePath in $Includes) {
                    if (Test-Path $filePath -PathType Leaf) {
                        #Write-Log $ServerName "Scanning single file: $filePath"
                        try {
                            if (Test-IsBinaryFile -FilePath $filePath) {
                                #Write-Log "Skipping binary file: $filePath"
                                continue
                            }
                            $mymatches = Select-String -Path $filePath -Pattern $ipRegex -AllMatches -ErrorAction SilentlyContinue
                            foreach ($match in $mymatches) {
                                $line = $match.Line
                                $ipList = foreach ($m in $ipRegexCompiled.Matches($line)) {
                                    $ip = $m.Value
                                    if (($ip -match '^192\.168\.') -or ($ip -match '^10\.') -or ($ip -match '^172\.(1[6-9]|2[0-9]|3[01])\.')) {
                                        if ($line -notmatch 'Ver') { $ip }
                                    }
                                }
                                if ($ipList.Count -gt 0) {
                                    $cleanLine = $line -replace "[^\p{L}\p{Nd}/ .]", ""
                                    foreach ($ip in $ipList) {
                                        $IPMatches += [PSCustomObject]@{
                                            FilePath   = $filePath
                                            IPAddress  = $ip
                                            LineText   = $cleanLine
                                            LineNumber = $match.LineNumber
                                            IsLocal    = $localIPs -contains $ip
                                        }
                                    }
                                }
                            }
                        }
                        catch {
                            #Write-Log "Error processing file: $filePath - $_"
                        }
                    }
                }

                # Get top-level folders from the root path (skipped in limited-scan mode)
                $topLevelDirs = if ($RootPath) { Get-ChildItem -Path $RootPath -Directory -ErrorAction SilentlyContinue } else { @() }

                foreach ($dir in $topLevelDirs) {
                    $dirPath = $dir.FullName.TrimEnd('\').ToLower()

                    # Check for path containment
                    if ($ExcludesNormalized | Where-Object { $dirPath -like "*$_*" }) {
                        continue
                    }

                    Write-Log $ServerName "IP scan — scanning: $($dir.FullName)"

                    Get-ChildItem -Path $dir.FullName -Recurse -File -Exclude $ExcludeFiles -ErrorAction SilentlyContinue |
                    Where-Object {
                        $_.Length -lt 5MB -and
                        ($fullPath = $_.FullName.ToLower()) -and
                        ($ExcludesNormalized | Where-Object { $fullPath -like "*$_*" }).Count -eq 0
                    } |
                    ForEach-Object {
                        $file = $_.FullName
                        if (Test-IsBinaryFile -FilePath $file) {
                            #Write-Log "Skipping binary file: $file"
                            return
                        }

                        #Write-Progress -Activity "Scanning for hardcoded IPs" -Status "Checking: $file"
                        try {
                            $mymatches = Select-String -Path $file -Pattern $ipRegex -AllMatches -ErrorAction SilentlyContinue
                            foreach ($match in $mymatches) {
                                $line = $match.Line
                                $ipList = foreach ($m in $ipRegexCompiled.Matches($line)) {
                                    $ip = $m.Value
                                    if (($ip -match '^192\.168\.') -or ($ip -match '^10\.') -or ($ip -match '^172\.(1[6-9]|2[0-9]|3[01])\.')) {
                                        if ($line -notmatch 'Ver') { $ip }
                                    }
                                }
                                if ($ipList.Count -gt 0) {
                                    $cleanLine = $line -replace "[^\p{L}\p{Nd}/ .]", ""
                                    foreach ($ip in $ipList) {
                                        $IPMatches += [PSCustomObject]@{
                                            FilePath   = $file
                                            IPAddress  = $ip
                                            LineText   = $cleanLine
                                            LineNumber = $match.LineNumber
                                            IsLocal    = $localIPs -contains $ip
                                        }
                                    }
                                }
                            }
                        }
                        catch {
                            #Write-Log "Error processing file: $file - $_"
                        }
                    }
                }

               # Write-Progress -Activity "Scanning for hardcoded IPs" -Completed

                $scanIPElapsed = [math]::Round(((Get-Date) - $scanIPStart).TotalSeconds, 1)
                if ($IPMatches.Count -eq 0) {
                    Write-Log $ServerName "IP scan complete in ${scanIPElapsed}s — no hardcoded IPs found."
                    return $null
                }

                Write-Log $ServerName "IP scan complete in ${scanIPElapsed}s — found $($IPMatches.Count) hit(s)."
                return $IPMatches
            }



            function Test-PendingReboot {
                $RebootReasons = @()
                $AccessDeniedKeys = @()

                function Test-Key {
                    param (
                        [string]$Path,
                        [string]$Name = $null
                    )
                    # Check existence silently first - avoids TerminatingError transcript entries
                    # when the registry key simply does not exist.
                    if (-not (Test-Path -Path $Path -ErrorAction SilentlyContinue)) {
                        return $false
                    }
                    try {
                        if ($Name) {
                            $null = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
                        }
                        return $true
                    }
                    catch {
                        if ($_.Exception.Message -like "*Requested registry access is not allowed*") {
                            $AccessDeniedKeys += $Path
                        }
                        return $false
                    }
                }

                if (Test-Key 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') {
                    $RebootReasons += "Windows Update"
                }

                if (Test-Key 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') {
                    $RebootReasons += "Component-Based Servicing"
                }

                # if (Test-Key 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'PendingFileRenameOperations') {
                #     $RebootReasons += "Pending File Rename Operations (ignored)"
                # }

                if (Test-Key 'HKLM:\SOFTWARE\Microsoft\CCM\PendingReboot') {
                    $RebootReasons += "SCCM"
                }

                if ($RebootReasons.Count -gt 0) {
                    return ($RebootReasons -join ', ')
                }
                elseif ($AccessDeniedKeys.Count -gt 0) {
                    return "AccessDenied: " + ($AccessDeniedKeys -join ', ')
                }
                else {
                    return $false
                }
            }
            Write-Stage "Collecting system information (OS, uptime, architecture)"
            write-log $ServerName "Collecting system information..."
            $os = Get-CimInstance -ClassName Win32_OperatingSystem
            $cs = Get-CimInstance -ClassName Win32_ComputerSystem
            $lastBoot = [DateTime]$os.LastBootUpTime
            $uptime = New-TimeSpan -Start $lastBoot -End (Get-Date)
            write-log $ServerName "OS: $($os.Caption), LastBoot: $lastBoot, Uptime (days): $($uptime.TotalDays)"
            Write-StepResult "System Info" "OS: $($os.Caption) | Build: $($os.BuildNumber) | Uptime: $([math]::Round($uptime.TotalDays,1)) days | Arch: $($os.OSArchitecture)"

            Write-Stage "Collecting CPU and memory metrics"
            write-log $ServerName "Collecting CPU and Memory usage..."
            $cpuLoad = [math]::Round((Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples[0].CookedValue, 2)
            $memTotal = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
            $memUsedPct = if ($os.TotalVisibleMemorySize) { [math]::Round((1 - ($os.FreePhysicalMemory / $os.TotalVisibleMemorySize)) * 100, 2) } else { 0 }
            write-log $ServerName "CPU Load: $cpuLoad%, Memory Used: $memUsedPct%"
            Write-StepResult "CPU / Memory" "CPU: $cpuLoad% | RAM: $memTotal GB | Memory used: $memUsedPct% | Logical processors: $((Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum)"

            write-log $ServerName "Checking Windows activation status..."
            Write-Stage "Collecting Windows activation and licensing details"
            $licensing = Get-CimInstance -ClassName SoftwareLicensingProduct | Where-Object { $_.PartialProductKey }
            $windowsLicense = if ($licensing -and $licensing.LicenseStatus -eq 1) { "Activated" } else { "Not Activated" }
            write-log $ServerName "Windows License: $windowsLicense"

            # Collect comprehensive KMS licensing information
            write-log $ServerName "Collecting KMS licensing details..."
            $kmsServerInfo = "Not Available"
            $kmsProductKey = "Not Available"
            $activationMethod = "Unknown"
            $licenseDescription = "Unknown"
            $gracePeriodRemaining = "N/A"
            $lastKmsServer = "Not Available"

            try {
                # Get KMS server information from multiple sources
                $kmsData = Get-CimInstance -ClassName SoftwareLicensingService -ErrorAction SilentlyContinue
                if ($kmsData -and $kmsData.KeyManagementServiceMachine) {
                    $kmsServerInfo = "$($kmsData.KeyManagementServiceMachine):$($kmsData.KeyManagementServicePort)"
                }

                # Get the last KMS server that this client authenticated against
                # This is captured from slmgr /dlv output which shows "Registered KMS machine name"
                try {
                    $slmgrOutput = & cscript //nologo C:\Windows\System32\slmgr.vbs /dlv 2>$null
                    if ($slmgrOutput) {
                        $registeredKmsLine = $slmgrOutput | Where-Object { $_ -match "Registered KMS machine name:" }
                        if ($registeredKmsLine) {
                            $lastKmsServer = ($registeredKmsLine -split ":", 2)[1].Trim()
                            # If we got a KMS server from slmgr but not from WMI, use this as primary
                            if ($kmsServerInfo -eq "Not Available" -and $lastKmsServer -ne "Not Available") {
                                $kmsServerInfo = $lastKmsServer
                            }
                        }
                    }
                }
                catch {
                    write-log $ServerName "Warning: Could not run slmgr /dlv to get last KMS server"
                }

                # Get detailed licensing information
                if ($licensing) {
                    $kmsProductKey = if ($licensing.PartialProductKey) { "*****-$($licensing.PartialProductKey)" } else { "Not Available" }
                    $licenseDescription = if ($licensing.Description) { $licensing.Description } else { "Unknown" }
                    $gracePeriodRemaining = if ($licensing.GracePeriodRemaining) { "$([math]::Round($licensing.GracePeriodRemaining / 1440, 1)) days" } else { "N/A" }

                    # Determine activation method
                    if ($licensing.LicenseStatus -eq 1) {
                        if ($kmsData -and $kmsData.KeyManagementServiceMachine) {
                            $activationMethod = "KMS Activation"
                        }
                        elseif ($licensing.Description -match "MAK") {
                            $activationMethod = "MAK Activation"
                        }
                        else {
                            $activationMethod = "Retail/OEM Activation"
                        }
                    }
                    else {
                        $activationMethod = "Not Activated"
                    }
                }
            }
            catch {
                write-log $ServerName "Warning: Could not collect complete KMS information"
            }

            write-log $ServerName "KMS Server: $kmsServerInfo, Last KMS Server: $lastKmsServer, Activation Method: $activationMethod"
            Write-StepResult "Licensing" "Status: $windowsLicense | Method: $activationMethod | KMS: $kmsServerInfo | Grace: $gracePeriodRemaining"

            write-log $ServerName "Determining system environment..."
            $model = $cs.Model
            $environment = if ($model -match "Virtual Machine") { "Hyper-V Virtual Machine" } elseif ($model -match "VMware") { $model } else { $model }
            write-log $ServerName "Environment: $environment"

            write-log $ServerName "Collecting page file configuration..."
            Write-Stage "Collecting page file and virtual memory settings"
            $pagefileSetting = Get-CimInstance Win32_PageFileSetting -ErrorAction SilentlyContinue
            $pageFileLocation = if ($pagefileSetting) { ($pagefileSetting | Select-Object -ExpandProperty Name) -join ";" } else { "null" }
            write-log $ServerName "Page File Location: $pageFileLocation"
            Write-StepResult "Page File" "Location: $pageFileLocation"

            write-log $ServerName "Collecting Domain/AD information..."
            Write-Stage "Collecting domain and Active Directory information"
            $domainJoined = $cs.PartOfDomain
            $domainName = $cs.Domain
            $DcSiteName = $ClientSiteName = $DomainControllerName = "NA"
            $domainInfo = Get-CimInstance -ClassName Win32_NTDomain -ErrorAction SilentlyContinue
            if ($domainInfo -and $domainInfo.Count -ge 2) {
                $DcSiteName = $domainInfo[1].DcSiteName
                $ClientSiteName = $domainInfo[1].ClientSiteName
                $DomainControllerName = $domainInfo[1].DomainControllerName
            }
            write-log $ServerName "Domain: $domainName, DC: $DomainControllerName"

            write-log $ServerName "Checking domain connection..."
            try {
                if (Test-ComputerSecureChannel -ErrorAction Stop) {
                    $DCConnectionStatus = "Connected"
                }
                else {
                    $DCConnectionStatus = "Not Connected"
                }
            }
            catch {
                $DCConnectionStatus = "Not Connected"
            }
            write-log $ServerName "Domain Connection Status: $DCConnectionStatus"
            Write-StepResult "Domain / AD" "Domain: $domainName | Joined: $domainJoined | DC: $DomainControllerName | Site: $ClientSiteName | Secure channel: $DCConnectionStatus"

            write-log $ServerName "Checking for pending Windows updates..."
            Write-Stage "Checking pending Windows updates"
            try {
                $updateSession = New-Object -ComObject Microsoft.Update.Session
                $updateSearcher = $updateSession.CreateUpdateSearcher()
                $searchResult = $updateSearcher.Search("IsHidden=0 and IsInstalled=0")
                $PendingUpdates = @($searchResult.Updates)
            }
            catch {
                $PendingUpdates = @()
            }
            $pendingUpdatesCount = $PendingUpdates.Count
            write-log $ServerName "Pending Updates Count: $pendingUpdatesCount"
            Write-StepResult "Pending Updates" "$pendingUpdatesCount update(s) available"
            $PendingUpdatesFlag = "Passed"
            if ($PendingUpdates) {
                foreach ($update in $PendingUpdates) {
                    if ($update.IsInstalled -eq $true -or $update.RebootRequired -eq $true) {
                        $PendingUpdatesFlag = "Failed"
                        break
                    }
                }
            }

            $errorLogs = @()
            if ($SkipEventLog) {
                Write-Stage "Skipping event logs (-SkipEventLog)"
                write-log $ServerName "Skipping event log collection (-SkipEventLog specified)."
            }
            else {
            Write-Stage "Collecting event logs (System/Application, last 14 days)"
            write-log $ServerName "Collecting event logs (last 14 days)..."
            $cutoffDate = (Get-Date).AddDays(-14)

            # Use runspace-based hard timeout for each Get-WinEvent call so a hung/slow
            # event log query is cancelled rather than blocking indefinitely.
            $eventLogTimeoutSeconds = 180  # per-log timeout (3 minutes)
            $eventLogPollSeconds = 5
            $eventLogTimeoutOccurred = $false
            $errorLogsSystem = @()
            $errorLogsApplication = @()

            # --- System event log ---
            try {
                $rsSystem = [System.Management.Automation.PowerShell]::Create()
                $null = $rsSystem.AddScript({
                    param($cutoff, $maxEvents)
                    $cap = if ($maxEvents -gt 0) { $maxEvents } else { [System.Int32]::MaxValue }
                    Get-WinEvent -FilterHashtable @{ LogName = 'System'; StartTime = $cutoff } -MaxEvents $cap -ErrorAction SilentlyContinue |
                        Where-Object { $_.LevelDisplayName -in @("Error", "Warning", "Information") } |
                        Select-Object TimeCreated,
                            @{Name = "EntryType"; Expression = { $_.LevelDisplayName }},
                            ProviderName, Id,
                            @{Name = "Message"; Expression = {
                                $msg = ($_.Message -replace "[^\p{L}\p{Nd}/ ]", "")
                                if ($msg.Length -gt 2000) { $msg.Substring(0, 2000) + " ...[truncated]" } else { $msg }
                            }},
                            @{Name = "LogName"; Expression = { "System" }}
                }).AddArgument($cutoffDate).AddArgument($EventLogMaxEvents)
                $handleSystem = $rsSystem.BeginInvoke()
                $systemLogStart = Get-Date
                $systemTimedOut = $false
                while (-not $handleSystem.IsCompleted) {
                    if ($handleSystem.AsyncWaitHandle.WaitOne([TimeSpan]::FromSeconds($eventLogPollSeconds))) { break }
                    $systemElapsed = [int]((Get-Date) - $systemLogStart).TotalSeconds
                    if ($systemElapsed -ge $eventLogTimeoutSeconds) {
                        $systemTimedOut = $true
                        break
                    }
                    if ($LocalDebug) {
                        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [local-step] [$ServerName] Still collecting System event log... ${systemElapsed}s elapsed (timeout ${eventLogTimeoutSeconds}s)" -ForegroundColor DarkCyan
                    }
                }
                if (-not $systemTimedOut -and $handleSystem.IsCompleted) {
                    $errorLogsSystem = @($rsSystem.EndInvoke($handleSystem))
                }
                else {
                    $rsSystem.Stop()
                    $eventLogTimeoutOccurred = $true
                    write-log $ServerName "WARNING: System event log collection timed out after $eventLogTimeoutSeconds seconds."
                }
                $rsSystem.Dispose()
            }
            catch {
                write-log $ServerName "Error collecting System event logs: $_"
                $errorLogsSystem = @()
            }

            # --- Application event log (skip if System log already timed out) ---
            if (-not $eventLogTimeoutOccurred) {
                try {
                    $rsApp = [System.Management.Automation.PowerShell]::Create()
                    $null = $rsApp.AddScript({
                        param($cutoff, $maxEvents)
                        $cap = if ($maxEvents -gt 0) { $maxEvents } else { [System.Int32]::MaxValue }
                        Get-WinEvent -FilterHashtable @{ LogName = 'Application'; StartTime = $cutoff } -MaxEvents $cap -ErrorAction SilentlyContinue |
                            Where-Object { $_.LevelDisplayName -in @("Error", "Warning") } |
                            Select-Object TimeCreated,
                                @{Name = "EntryType"; Expression = { $_.LevelDisplayName }},
                                ProviderName, Id,
                                @{Name = "Message"; Expression = {
                                    $msg = ($_.Message -replace "[^\p{L}\p{Nd}/ ]", "")
                                    if ($msg.Length -gt 2000) { $msg.Substring(0, 2000) + " ...[truncated]" } else { $msg }
                                }},
                                @{Name = "LogName"; Expression = { "Application" }}
                    }).AddArgument($cutoffDate).AddArgument($EventLogMaxEvents)
                    $handleApp = $rsApp.BeginInvoke()
                    $appLogStart = Get-Date
                    $appTimedOut = $false
                    while (-not $handleApp.IsCompleted) {
                        if ($handleApp.AsyncWaitHandle.WaitOne([TimeSpan]::FromSeconds($eventLogPollSeconds))) { break }
                        $appElapsed = [int]((Get-Date) - $appLogStart).TotalSeconds
                        if ($appElapsed -ge $eventLogTimeoutSeconds) {
                            $appTimedOut = $true
                            break
                        }
                        if ($LocalDebug) {
                            Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [local-step] [$ServerName] Still collecting Application event log... ${appElapsed}s elapsed (timeout ${eventLogTimeoutSeconds}s)" -ForegroundColor DarkCyan
                        }
                    }
                    if (-not $appTimedOut -and $handleApp.IsCompleted) {
                        $errorLogsApplication = @($rsApp.EndInvoke($handleApp))
                    }
                    else {
                        $rsApp.Stop()
                        $eventLogTimeoutOccurred = $true
                        write-log $ServerName "WARNING: Application event log collection timed out after $eventLogTimeoutSeconds seconds."
                    }
                    $rsApp.Dispose()
                }
                catch {
                    write-log $ServerName "Error collecting Application event logs: $_"
                    $errorLogsApplication = @()
                }
            }
            else {
                write-log $ServerName "Skipping Application event log collection due to System log timeout."
            }

            # Build the combined list; prepend a visible timeout notice when applicable.
            $errorLogs = @()
            if ($eventLogTimeoutOccurred) {
                $errorLogs += [PSCustomObject]@{
                    TimeCreated  = (Get-Date)
                    EntryType    = "Warning"
                    ProviderName = "MigrationCheck"
                    Id           = 0
                    Message      = "EVENT LOG COLLECTION TIMED OUT: Get-WinEvent exceeded $eventLogTimeoutSeconds seconds and was cancelled. Event log data below (if any) is partial. This typically indicates a very large event log or a slow server."
                    LogName      = "MigrationCheck"
                }
            }
            if ($errorLogsSystem) { $errorLogs += $errorLogsSystem }
            if ($errorLogsApplication) { $errorLogs += $errorLogsApplication }
            write-log $ServerName "Collected event logs count: $($errorLogs.Count)"
            Write-StepResult "Event Logs" "$(if ($eventLogTimeoutOccurred) {'TIMED OUT - partial data. '})System: $($errorLogsSystem.Count) event(s) | Application: $($errorLogsApplication.Count) event(s) | Errors: $(($errorLogs | Where-Object {$_.EntryType -eq 'Error'}).Count) | Warnings: $(($errorLogs | Where-Object {$_.EntryType -eq 'Warning'}).Count)"
            } # end -not SkipEventLog

            write-log $ServerName "Collecting potential user evidence..."
            Write-Stage "Collecting potential user evidence (C:\Users, logon events, inbound RDP/WinRM)"
            $potentialUsersLogonLookbackDays = 14
            $potentialUsers = Get-PotentialUsersData -EventCutoffDate (Get-Date).AddDays(-1 * $potentialUsersLogonLookbackDays) -SkipLogonEvents ([bool]$SkipEventLog) -MaxEvents $EventLogMaxEvents -CollectorAddresses $CollectorClientAddresses
            Write-StepResult "Potential Users" "Profiles: $(@($potentialUsers.UserProfileDirectories).Count) | Logons: $(@($potentialUsers.LogonEvents).Count) | Inbound mgmt connections: $(@($potentialUsers.InboundManagementConnections).Count)"

            write-log $ServerName "Counting enabled network adapters..."
            Write-Stage "Collecting network adapter and firewall details"
            $nicCount = 0
            try {
                # Prefer modern network stack objects because Win32_NetworkAdapter.NetEnabled
                # can be null/empty in some remote sessions.
                $activeNics = @(Get-NetIPConfiguration -Detailed -ErrorAction Stop | Where-Object {
                        $_.NetAdapter -and $_.NetAdapter.Status -eq 'Up' -and (
                            $_.IPv4Address -or $_.IPv6Address -or $_.NetAdapter.MacAddress
                        )
                    })
                $nicCount = $activeNics.Count
            }
            catch {
                try {
                    $nicCount = @(Get-CimInstance Win32_NetworkAdapter | Where-Object { $_.NetEnabled -eq $true }).Count
                }
                catch {
                    $nicCount = @(Get-WmiObject Win32_NetworkAdapter | Where-Object { $_.NetEnabled -eq $true }).Count
                }
            }
            write-log $ServerName "Enabled Network Adapters: $nicCount"
            Write-StepResult "Network Adapters" "$nicCount enabled NIC(s)"

            write-log $ServerName "Retrieving firewall profiles..."
            $firewallDomain = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile' -ErrorAction SilentlyContinue).EnableFirewall
            $firewallPublic = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile' -ErrorAction SilentlyContinue).EnableFirewall
            $firewallStandard = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile' -ErrorAction SilentlyContinue).EnableFirewall
            $winHttpProxy = (netsh.exe winhttp show proxy)[3].replace("    ", "")

            write-log $ServerName "Firewall Profiles - Domain: $firewallDomain, Public: $firewallPublic, Private: $firewallStandard"
            Write-StepResult "Firewall" "Domain: $(if ($firewallDomain -eq 1){'ON'}else{'off'}) | Public: $(if ($firewallPublic -eq 1){'ON'}else{'off'}) | Private: $(if ($firewallStandard -eq 1){'ON'}else{'off'}) | WinHTTP proxy: $winHttpProxy"

            write-log $ServerName "Collecting Disk details..."
            Write-Stage "Collecting disk, volume, and storage layout"
            $disks = @()
            try {
                $disks = @(Get-Disk -ErrorAction SilentlyContinue | Select-Object Number, FriendlyName, @{Name = "SizeGB"; Expression = { "{0:N1}" -f ($_.Size / 1GB) } }, PartitionStyle, IsBoot, IsSystem)
            }
            catch {
                write-log $ServerName "Warning: Could not retrieve disk information: $_"
            }

            # Build a partition lookup table: DiskNumber -> drive letters, and DriveLetter -> DiskNumber
            # Filter using a regex match to exclude unassigned drive letters ([char]0 passes -ne '' checks
            # but is not a valid drive letter and corrupts the lookup tables).
            $allPartitions = Get-Partition -ErrorAction SilentlyContinue | Where-Object { "$($_.DriveLetter)" -match '^[A-Za-z]$' }
            $diskToLetters  = @{}   # DiskNumber -> list of drive letters
            $letterToDisk   = @{}   # DriveLetter -> DiskNumber
            foreach ($part in $allPartitions) {
                $dl = "$($part.DriveLetter)"
                $dn = [string]$part.DiskNumber
                if (-not $diskToLetters.ContainsKey($dn)) { $diskToLetters[$dn] = [System.Collections.Generic.List[string]]::new() }
                $diskToLetters[$dn].Add($dl)
                $letterToDisk[$dl] = $dn
            }

            # Enrich each disk with a CSV list of its volumes
            $disks = $disks | Select-Object *,
                @{Name = 'Volumes'; Expression = {
                    $key = [string]$_.Number
                    if ($diskToLetters.ContainsKey($key)) { ($diskToLetters[$key] | Sort-Object) -join ',' } else { '' }
                }}
            # Calculate total disk space in GB
            $TotalDiskSpace = ($disks | Measure-Object -Property SizeGB -Sum).Sum
            if (-not $TotalDiskSpace) {
                # If SizeGB is a string, convert to float
                $TotalDiskSpace = ($disks | ForEach-Object { [float]$_.SizeGB }) | Measure-Object -Sum | Select-Object -ExpandProperty Sum
            }
            $TotalDiskSpace = [math]::Round($TotalDiskSpace, 1)
            Write-StepResult "Disks" "$($disks.Count) disk(s) | Total: $TotalDiskSpace GB | Styles: $(($disks | Select-Object -ExpandProperty PartitionStyle -Unique) -join ', ')"
            write-log $ServerName "Collecting Volume details..."
            $volumes = @(Get-Volume -ErrorAction SilentlyContinue | Select-Object DriveLetter, FileSystemLabel,
            @{Name = "DiskNumber"; Expression = {
                    # Use regex match to exclude [char]0 (unassigned placeholder) and other non-letter values
                    $dl = "$($_.DriveLetter)"
                    if ($dl -match '^[A-Za-z]$' -and $letterToDisk.ContainsKey($dl)) { [int]$letterToDisk[$dl] } else { $null }
                }},
            @{Name = "TotalCapacityGB"; Expression = { [math]::Ceiling($_.Size / 1GB) } },
            @{Name = "FreeSpaceGB"; Expression = { [math]::Ceiling($_.SizeRemaining / 1GB) } },
            @{Name = "FreeSpacePercent"; Expression = { if ($_.Size -gt 0) { "{0:P0}" -f ($_.SizeRemaining / $_.Size) } else { "0%" } } },
            @{Name = "AttentionNeeded"; Expression = {
                    if ([math]::Ceiling($_.Size / 1GB) -le 32) { "No" }
                    elseif (([math]::Ceiling($_.Size / 1GB) -ge 32) -and ([math]::Ceiling($_.SizeRemaining / 1GB) -ge 10)) { "No" }
                    else { "Yes" }
                }
            },
            FileSystemType, HealthStatus, OperationalStatus)
            $volumeFlag = $false
            foreach ($vol in $volumes) {
                if ($vol.AttentionNeeded -eq "Yes") { $volumeFlag = $true; break }
            }
            Write-StepResult "Volumes" "$($volumes.Count) volume(s) | Attention needed: $(($volumes | Where-Object { $_.AttentionNeeded -eq 'Yes' }).Count) | Free space flags: $(($volumes | Where-Object {$_.FreeSpaceGB -lt 10} | Measure-Object).Count) volume(s) < 10 GB free"

            Try {
                $DiskPolicy = (Get-StorageSetting -ErrorAction SilentlyContinue).NewDiskPolicy
            }
            Catch {
                $DiskPolicy = "null"
            }
            Write-StepResult "Disk Policy" "NewDiskPolicy = $DiskPolicy"

            write-log $ServerName "Collecting RAID details..."
            $raidVolumes = @()
            $raidStatus = "null"
            try {
                $virtualDisks = Get-VirtualDisk -ErrorAction SilentlyContinue
            }
            catch { $virtualDisks = $null }
            if ($virtualDisks) {
                foreach ($vd in $virtualDisks) {
                    if ($vd.ResiliencySettingName -match 'Mirror|Parity') {
                        # Use -eq instead of -match: UniqueId contains regex metacharacters (braces, backslashes)
                        $volMatch = Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.ObjectId -eq $vd.UniqueId }
                        $driveLetter = ($volMatch | Select-Object -ExpandProperty DriveLetter -Unique) -join ','
                        $raidVolumes += [PSCustomObject]@{
                            Volume      = $vd.FriendlyName
                            DriveLetter = $driveLetter
                            Type        = $vd.ResiliencySettingName
                            SizeGB      = ("{0:N1}" -f ($vd.Size / 1GB))
                        }
                        $raidStatus = "Warning"
                    }
                }
            }
            if ($raidVolumes.Count -eq 0) { $raidStatus = "null" }
            Write-StepResult "RAID / Storage Spaces" "$(if ($raidVolumes.Count -gt 0) { "$($raidVolumes.Count) RAID/Storage Spaces volume(s): $(($raidVolumes | ForEach-Object { "$($_.Volume) ($($_.Type))" }) -join ', ')" } else { 'None detected' })"
            write-log $ServerName "Collecting Shares..."
            $shares = Get-SmbShare | Select-Object Name, ScopeName, Path, Description
            Write-StepResult "SMB Shares" "$($shares.Count) share(s): $(($shares | Select-Object -ExpandProperty Name) -join ', ')"
            write-log $ServerName "Collecting Network Routes..."
            Write-Stage "Collecting routing and networking configuration"
            $routes = Get-NetRoute -ErrorAction SilentlyContinue | Where-Object { $_.DestinationPrefix -like "*.*" } |
            Select-Object ifIndex, DestinationPrefix, NextHop, RouteMetric, ifMetric, PolicyStore
            Write-StepResult "Network Routes" "$($routes.Count) route(s)"
            write-log $ServerName "Collecting Persistent Routes..."
            try {
                    $persistedRoutes = Get-CimInstance -ClassName Win32_IP4PersistedRouteTable -ErrorAction Stop |
                    Select-Object Destination, NextHop, Mask, Metric1, Name, Status
            }
            catch {
                Write-Warning "Unable to retrieve persisted routes. Defaulting to empty."
                $persistedRoutes = @()
            }
            Write-StepResult "Persistent Routes" "$(if ($persistedRoutes.Count -gt 0) { "$($persistedRoutes.Count) persistent route(s) - may need attention: $(($persistedRoutes | ForEach-Object { $_.Destination }) -join ', ')" } else { 'None' })"
            write-log $ServerName "Collecting Listening Ports..."
            $ports = Get-NetTCPConnection -State Listen | Where-Object { ($_.LocalAddress -notlike "127.*") -and ($_.LocalAddress -ne "::1") } |
            Select-Object LocalAddress, LocalPort, @{Name = 'State'; Expression = { [string]$_.State } }, OwningProcess
            foreach ($p in $ports) {
                $procName = (Get-Process -Id $p.OwningProcess -ErrorAction SilentlyContinue).ProcessName
                $p | Add-Member -NotePropertyName ProcessName -NotePropertyValue $procName -Force
            }
            Write-StepResult "Listening Ports" "$($ports.Count) TCP listening port(s): $(($ports | Sort-Object LocalPort | Select-Object -ExpandProperty LocalPort -Unique) -join ', ')"

            # Collect Network Connectivity (IPv4 only, active connections only)
            write-log $ServerName "Collecting network connections (IPv4 only, active connections only)..."
            $networkConnections = @()
            try {
                # IPv4 regex pattern and RFC1918 private ranges for internal/external classification
                $ipv4Pattern = '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'
                $internalIpv4Pattern = '^(10\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})|192\.168\.(\d{1,3})\.(\d{1,3})|172\.(1[6-9]|2[0-9]|3[0-1])\.(\d{1,3})\.(\d{1,3}))$'

                # Active TCP only: exclude listening, 0.0.0.0, and loopback
                $tcpConnections = Get-NetTCPConnection -ErrorAction Stop |
                    Where-Object {
                        ($_.LocalAddress -notlike "127.*") -and
                        ($_.LocalAddress -ne "::1") -and
                        ($_.LocalAddress -ne "0.0.0.0") -and
                        ($_.LocalAddress -match $ipv4Pattern) -and
                        ([string]$_.State -notmatch "^(Listening|Listen)$")
                    } |
                    Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, @{Name = 'State'; Expression = { [string]$_.State } }, OwningProcess -First 1000

                foreach ($conn in $tcpConnections) {
                    $procName = ""
                    try { $procName = (Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue).ProcessName } catch { }

                    # Direction and internal/external classification
                    $direction = if ([int]$conn.RemotePort -lt 10000) { "Outbound" } else { "Inbound" }
                    $internalExternal = if ($conn.RemoteAddress -match $internalIpv4Pattern) { "Internal" } else { "External" }

                    $networkConnections += [PSCustomObject]@{
                        LocalAddress      = $conn.LocalAddress
                        LocalPort         = $conn.LocalPort
                        RemoteAddress     = $conn.RemoteAddress
                        RemotePort        = $conn.RemotePort
                        State             = $conn.State
                        Direction         = $direction
                        InternalExternal  = $internalExternal
                        ProcessName       = $procName
                        Protocol          = "TCP"
                    }
                }
            }
            catch {
                write-log $ServerName "Warning: Failed to collect network connections: $($_.Exception.Message)"
            }

            Write-StepResult "Network Connectivity" "$($networkConnections.Count) connection(s) detected"

            function Get-WsfcClusterConfiguration {
                param(
                    [Parameter(Mandatory = $false)]
                    [string]$ServerName
                )

                $moduleAvailable = $false
                try {
                    $importParams = @{
                        Name          = 'FailoverClusters'
                        WarningAction = 'SilentlyContinue'
                        ErrorAction   = 'Stop'
                    }
                    if ((Get-Command -Name Import-Module -ErrorAction SilentlyContinue).Parameters.ContainsKey('SkipEditionCheck')) {
                        $importParams.SkipEditionCheck = $true
                    }
                    Import-Module @importParams
                    $moduleAvailable = $true
                }
                catch {
                    return [PSCustomObject]@{
                        Available = $false
                        Reason    = 'FailoverClusters module not available'
                        Error     = $_.Exception.Message
                    }
                }

                if (-not $moduleAvailable) {
                    return [PSCustomObject]@{
                        Available = $false
                        Reason    = 'FailoverClusters module not available'
                    }
                }

                try {
                    $cluster = Get-Cluster -ErrorAction Stop
                }
                catch {
                    return [PSCustomObject]@{
                        Available = $false
                        Reason    = 'No cluster detected or access denied'
                        Error     = $_.Exception.Message
                    }
                }

                $quorum = $null
                try { $quorum = Get-ClusterQuorum -Cluster $cluster -ErrorAction SilentlyContinue } catch { $quorum = $null }

                # Flatten quorum to avoid embedding complex cluster resource objects (serialization can be extremely slow)
                $quorumInfo = $null
                if ($quorum) {
                    $quorumResource = $null
                    try { $quorumResource = $quorum.QuorumResource } catch { $quorumResource = $null }
                    $quorumInfo = [pscustomobject]@{
                        QuorumType         = $(try { $quorum.QuorumType } catch { $null })
                        QuorumResourceName = if ($quorumResource) { $quorumResource.Name } else { $null }
                        QuorumResourceType = if ($quorumResource) { $quorumResource.ResourceType } else { $null }
                    }
                }

                $nodes = @()
                try { $nodes = @(Get-ClusterNode -Cluster $cluster -ErrorAction SilentlyContinue | Select-Object Name, State, Id, NodeWeight, DynamicWeight) } catch { $nodes = @() }

                $networks = @()
                try { $networks = @(Get-ClusterNetwork -Cluster $cluster -ErrorAction SilentlyContinue | Select-Object Name, Role, State, Address, AddressMask, Metric, AutoMetric) } catch { $networks = @() }

                $groups = @()
                try {
                    $groups = @(Get-ClusterGroup -Cluster $cluster -ErrorAction SilentlyContinue | ForEach-Object {
                            [pscustomobject]@{
                                Name        = $_.Name
                                State       = $_.State
                                OwnerNode   = if ($_.OwnerNode) { $_.OwnerNode.Name } else { $null }
                                Description = $_.Description
                            }
                        })
                }
                catch { $groups = @() }

                $resources = @()
                try {
                    $resources = @(Get-ClusterResource -Cluster $cluster -ErrorAction SilentlyContinue | ForEach-Object {
                            [pscustomobject]@{
                                Name         = $_.Name
                                State        = $_.State
                                ResourceType = [string]$_.ResourceType
                                OwnerGroup   = if ($_.OwnerGroup) { $_.OwnerGroup.Name } else { $null }
                                OwnerNode    = if ($_.OwnerNode) { $_.OwnerNode.Name } else { $null }
                            }
                        })
                }
                catch { $resources = @() }

                # Build listener-style objects for report UI (Network Name resources + their IP dependencies)
                $listeners = @()
                try {
                    $networkNames = @(Get-ClusterResource -Cluster $cluster -ErrorAction SilentlyContinue | Where-Object { [string]$_.ResourceType -eq 'Network Name' })
                    foreach ($nn in $networkNames) {
                        $ownerGroup = $nn.OwnerGroup

                        $ownerGroupInfo = $null
                        try {
                            if ($ownerGroup) {
                                $ownerGroupInfo = [pscustomobject]@{
                                    Name        = $ownerGroup.Name
                                    State       = $ownerGroup.State
                                    OwnerNode   = if ($ownerGroup.OwnerNode) { $ownerGroup.OwnerNode.Name } else { $null }
                                    Description = $ownerGroup.Description
                                }
                            }
                        }
                        catch { $ownerGroupInfo = $null }

                        $ipResources = @()
                        try {
                            # Pass the resource object directly (more reliable than passing by name string)
                            $deps = @($nn | Get-ClusterResourceDependency -ErrorAction SilentlyContinue)
                            foreach ($d in $deps) {
                                if ($d -and $d.DependencyResource -and [string]$d.DependencyResource.ResourceType -eq 'IP Address') {
                                    $ipResources += $d.DependencyResource
                                }
                            }
                        }
                        catch { $ipResources = @() }

                        if (-not $ipResources -or $ipResources.Count -eq 0) {
                            try {
                                if ($ownerGroup) {
                                    # Compare by name rather than object reference to avoid false negatives
                                    $ipResources = @(Get-ClusterResource -Cluster $cluster -ErrorAction SilentlyContinue | Where-Object { $_.OwnerGroup.Name -eq $ownerGroup.Name -and [string]$_.ResourceType -eq 'IP Address' })
                                }
                            }
                            catch { $ipResources = @() }
                        }

                        $ipAddresses = @()
                        $probePorts = @()
                        $associatedPorts = @()

                        foreach ($ipRes in $ipResources) {
                            try {
                                $params = @($ipRes | Get-ClusterParameter -ErrorAction SilentlyContinue)

                                foreach ($p in $params) {
                                    if (-not $p -or -not $p.Name) { continue }

                                    if ($p.Name -eq 'Address' -and $p.Value) {
                                        $addr = $p.Value.ToString()
                                        if (-not [string]::IsNullOrWhiteSpace($addr) -and $addr -ne '0.0.0.0') {
                                            $ipAddresses += $addr
                                        }
                                    }

                                    if ($p.Name -match '^ProbePort$' -and $p.Value) {
                                        $probePorts += $p.Value
                                    }

                                    if ($p.Name -match 'Port' -and $p.Value) {
                                        # Capture additional port-like parameters (exclude ProbePort to avoid duplication)
                                        if ($p.Name -ne 'ProbePort') {
                                            $associatedPorts += $p.Value
                                        }
                                    }
                                }
                            }
                            catch {
                                continue
                            }
                        }

                        $ipAddresses = @($ipAddresses | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
                        $probePorts = @($probePorts | Where-Object { $_ -ne $null -and $_ -ne '' } | Select-Object -Unique)
                        $associatedPorts = @($associatedPorts | Where-Object { $_ -ne $null -and $_ -ne '' } | Select-Object -Unique)

                        $listeners += [PSCustomObject]@{
                            Name            = $nn.Name
                            State           = $nn.State
                            OwnerGroupName  = if ($ownerGroup) { $ownerGroup.Name } else { $null }
                            OwnerGroup      = $ownerGroupInfo
                            IPAddresses     = $ipAddresses
                            ProbePorts      = $probePorts
                            IPAddress       = if ($ipAddresses.Count -gt 0) { $ipAddresses[0] } else { $null }
                            ProbePort       = if ($probePorts.Count -gt 0) { $probePorts[0] } else { $null }
                            AssociatedPorts = $associatedPorts
                        }
                    }
                }
                catch {
                    $listeners = @()
                }

                return [PSCustomObject]@{
                    Available = $true
                    Cluster   = ($cluster | Select-Object Name, Id, Domain, Description, S2DEnabled, QuorumArbitrationTimeMax, QuorumArbitrationTimeMin)
                    Quorum    = $quorumInfo
                    Nodes     = $nodes
                    Networks  = $networks
                    Groups    = $groups
                    Resources = $resources
                    Listeners = $listeners
                }
            }

            write-log $ServerName "Collecting Cluster Configuration (WSFC)..."
            Write-Stage "Collecting WSFC cluster configuration"
            $clusterConfiguration = Get-WsfcClusterConfiguration -ServerName $ServerName
            Write-StepResult "WSFC Cluster" "$(if ($clusterConfiguration.Available) { "Cluster detected: $($clusterConfiguration.Cluster.Name) | Nodes: $($clusterConfiguration.Nodes.Count) | Groups: $($clusterConfiguration.Groups.Count) | Listeners: $($clusterConfiguration.Listeners.Count)" } else { "Not clustered ($($clusterConfiguration.Reason))" })"

            Write-Stage "Collecting installed software inventory"
            write-log $ServerName "Collecting Installed Software..."
            # Registry-based approach: much faster than Win32_Product, avoids MSI reconfiguration triggers.
            $regPaths = @(
                'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
            )
            $software = $regPaths | ForEach-Object {
                if (Test-Path $_) {
                    Get-ItemProperty -Path $_ -ErrorAction SilentlyContinue |
                        Where-Object { $_.DisplayName } |
                        Select-Object @{Name='Name';Expression={$_.DisplayName}},
                            @{Name='Vendor';Expression={$_.Publisher}},
                            @{Name='Version';Expression={$_.DisplayVersion}}
                }
            } | Where-Object { $_ -and $_.Name }
            Write-StepResult "Installed Software" "$($software.Count) package(s) found"

            Write-Stage "Collecting Windows roles and features"
            write-log $ServerName "Collecting Roles and Features..."
            $rolesAndFeatures = @()
            try {
                # Import ServerManager first so Get-WindowsFeature is discoverable in fresh remote sessions
                $importParams = @{
                    Name          = 'ServerManager'
                    WarningAction = 'SilentlyContinue'
                    ErrorAction   = 'SilentlyContinue'
                }
                if ((Get-Command -Name Import-Module -ErrorAction SilentlyContinue).Parameters.ContainsKey('SkipEditionCheck')) {
                    $importParams.SkipEditionCheck = $true
                }
                Import-Module @importParams
                if (Get-Command -Name Get-WindowsFeature -ErrorAction SilentlyContinue) {
                    $rolesAndFeatures = @(Get-WindowsFeature | Where-Object { $_.Installed -eq $true } | Select-Object Name, DisplayName, FeatureType, Installed)
                }
                elseif (Get-Command -Name Get-WindowsOptionalFeature -ErrorAction SilentlyContinue) {
                    $rolesAndFeatures = @(Get-WindowsOptionalFeature -Online | Where-Object { $_.State -eq 'Enabled' } | Select-Object @{Name = 'Name'; Expression = { $_.FeatureName } }, @{Name = 'DisplayName'; Expression = { '' } }, @{Name = 'FeatureType'; Expression = { 'OptionalFeature' } }, @{Name = 'Installed'; Expression = { $true } })
                }
            }
            catch {
                Write-Warning "Failed to retrieve roles/features: $($_.Exception.Message)"
                $rolesAndFeatures = @()
            }
            Write-StepResult "Roles and Features" "$($rolesAndFeatures.Count) installed | Types: $(($rolesAndFeatures | Group-Object FeatureType | ForEach-Object { "$($_.Count) $($_.Name)" }) -join ', ')"

            Write-Stage "Collecting services and startup modes"
            write-log $ServerName "Collecting Services..."
            try {
                $services = Get-CimInstance -Class Win32_Service -ErrorAction Stop |
                Select-Object DisplayName, Name, State, StartMode, StartName,
                @{Name = "Description"; Expression = { ($_.Description -replace "[^\p{L}\p{Nd}/ ]", "") } }
            }
            catch {
                Write-Warning "Falling back to Get-WmiObject for services."
                try {
                    $services = Get-WmiObject -Class Win32_Service -ErrorAction SilentlyContinue |
                    Select-Object DisplayName, Name, State, StartMode, StartName,
                    @{Name = "Description"; Expression = { ($_.Description -replace "[^\p{L}\p{Nd}/ ]", "") } }
                }
                catch {
                    Write-Warning "Failed to retrieve services."
                    $services = @()
                }
            }
            Write-StepResult "Services" "$($services.Count) total | Running: $(($services | Where-Object { $_.State -eq 'Running' }).Count) | Auto-start: $(($services | Where-Object { $_.StartMode -eq 'Auto' }).Count) | Stopped auto-start: $(($services | Where-Object { $_.StartMode -eq 'Auto' -and $_.State -ne 'Running' }).Count)"
            Write-Stage "Collecting running processes"
            write-log $ServerName "Collecting Processes..."
            $processes = Get-Process -ErrorAction SilentlyContinue | Select-Object ProcessName, Id, CPU,
            @{Name = "MemoryUsageMB"; Expression = { "{0:N2}" -f ($_.WS / 1MB) } }
            Write-StepResult "Processes" "$($processes.Count) running | Top 5 by RAM (MB): $(($processes | Sort-Object { [float]$_.MemoryUsageMB } -Descending | Select-Object -First 5 | ForEach-Object { "$($_.ProcessName):$($_.MemoryUsageMB)" }) -join ', ')"
            Write-Stage "Collecting scheduled tasks"
            write-log $ServerName "Collecting Scheduled Tasks..."
            $tasks = Get-ScheduledTask | ForEach-Object {
                $info = Get-ScheduledTaskInfo -TaskName $_.TaskName -TaskPath $_.TaskPath
                [PSCustomObject]@{
                    TaskName       = $_.TaskName
                    TaskPath       = $_.TaskPath
                    LastRunTime    = $info.LastRunTime
                    NextRunTime    = $info.NextRunTime
                    LastTaskResult = $info.LastTaskResult
                    Status         = $info.State
                }
            }
            Write-StepResult "Scheduled Tasks" "$($tasks.Count) task(s) | Failed last run: $(($tasks | Where-Object { $_.LastTaskResult -ne 0 -and $_.LastTaskResult -ne $null }).Count)"
            # ─── NEW: Collect NIC settings ───────────────────────────────────────────
            Write-Log $ServerName "Collecting Network Interface details..."
            $nicConfigs = @(Get-NetIPConfiguration -Detailed | Where-Object {
                # Exclude loopback pseudo-interface and any interface with no real NetAdapter
                $_.InterfaceAlias -notmatch 'Loopback' -and
                $_.NetAdapter -and
                $_.NetAdapter.Status -eq 'Up'
            } | ForEach-Object {
                $cfg = $_
                # Pick the first IPv4 address (if any)
                $ipv4 = $cfg.IPv4Address | Where-Object { $_.IPAddress -notmatch '^127\.' } | Select-Object -First 1

                # Build DNS string or blank
                $dnsServers = if ($cfg.DNSServer -and $cfg.DNSServer.ServerAddresses) {
                    $cfg.DNSServer.ServerAddresses -join ', '
                }
                else {
                    ''
                }

                # Calculate SubnetMask from PrefixLength
                if ($ipv4) {
                    $prefix = $ipv4.PrefixLength
                    $fullOctets = [math]::Floor($prefix / 8)
                    $remBits = $prefix % 8

                    $maskOctets = for ($i = 0; $i -lt 4; $i++) {
                        if ($i -lt $fullOctets) {
                            255
                        }
                        elseif ($i -eq $fullOctets) {
                            [byte](((0xFF -shl (8 - $remBits)) -band 0xFF))
                        }
                        else {
                            0
                        }
                    }
                    $subnetMask = $maskOctets -join '.'
                }
                else {
                    $subnetMask = ''
                }

                # First default gateway, if any
                $gateway = $cfg.IPv4DefaultGateway | Select-Object -First 1

                [PSCustomObject]@{
                    InterfaceAlias = $cfg.InterfaceAlias
                    MacAddress     = $cfg.NetAdapter.LinkLayerAddress
                    DhcpEnabled    = $cfg.NetIPv4Interface.Dhcp
                    IPAddress      = if ($ipv4) { $ipv4.IPAddress } else { '' }
                    PrefixLength   = if ($ipv4) { $ipv4.PrefixLength } else { '' }
                    SubnetMask     = $subnetMask
                    DefaultGateway = if ($gateway) { $gateway.NextHop } else { '' }
                    DnsServers     = $dnsServers
                }
            })

            $nicInterfaceCount = @($nicConfigs).Count


            Write-StepResult "Network Interfaces" "$nicInterfaceCount interface(s): $(($nicConfigs | Where-Object { $_.IPAddress } | ForEach-Object { "$($_.InterfaceAlias)=$($_.IPAddress)/$(if ($_.PrefixLength) {$_.PrefixLength} else {'?'})" }) -join ', ')"

            write-log $ServerName "Performing Validation Checks..."

            $UptimeCheck = if ($uptime.Days -lt 30) { "Passed" } else { "Failed" }




            $PendingRebootFlag = Test-PendingReboot
            $PendingRebootCheck = if (-not $PendingRebootFlag) { "Passed" } else { "Failed" }
            $errorOnlyCount = ($errorLogs | Where-Object { $_.EntryType -eq 'Error' }).Count
            $ErrorCountCheck = if ($SkipEventLog) { $null } elseif ($errorOnlyCount -lt 300) { "Passed" } else { "Failed" }
            $DiskCheck = if ($DiskPolicy -eq "OnlineAll") { "Passed" } else { "Failed" }
            $rdpTimeoutMs = 5000
            write-log $ServerName "Checking RDP port 3389 with timeout ${rdpTimeoutMs}ms..."
            $rdpPortReachable = Test-TcpPortWithTimeout -ComputerName $MyHostName -Port 3389 -TimeoutMs $rdpTimeoutMs
            $RDPCheck = if ($rdpPortReachable -or $RunLocally) { "Passed" } else { "Failed" }
            $psMajorVersion = $PSVersionTable.PSVersion.Major
            $PowerShellVersionCheck = if ($psMajorVersion -ge 5) { "Passed" } else { "Failed" }
            $VolumeCheck = if ($volumeFlag) { "Failed" } else { "Passed" }
            $ProxyServerCheck = if ($winHttpProxy -like "*Direct*") { "Passed" } else { "Failed" }
            $PersistentRouteCheck = if ($persistedRoutes -and $persistedRoutes.Count -gt 0) { "Failed" } else { "Passed" }
            $WindowsFirewallCheck = if (($firewallDomain -eq 1) -or ($firewallPublic -eq 1) -or ($firewallStandard -eq 1)) { "Failed" } else { "Passed" }
            Write-StepResult "Validation Results" "Uptime=$UptimeCheck | Reboot=$PendingRebootCheck | Updates=$PendingUpdatesFlag | ErrorLog=$ErrorCountCheck (errors: $errorOnlyCount) | DiskPolicy=$DiskCheck | RDP=$RDPCheck | PS=$PowerShellVersionCheck | Volumes=$VolumeCheck | Proxy=$ProxyServerCheck | PersistRoutes=$PersistentRouteCheck | Firewall=$WindowsFirewallCheck"
            $RegPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine\Extension-List\{00000000-0000-0000-0000-000000000000}'
            $LowTime = Get-ItemProperty -Path $RegPath -Name "EndTimeLo"
            $HighTime = Get-ItemProperty -Path $RegPath -Name "EndTimeHi"
            $CompTime = ([long]$HighTime.EndTimeHi -shl 32) + [long]$LowTime.EndTimeLo
            $LastGPOUpdate = "$([DateTime]::FromFileTime($CompTime))"
            $RunTime = [math]::Round(((Get-Date) - $StartTime).TotalSeconds, 2)
            $checksObj = [PSCustomObject]@{
                ServerName               = $MyHostName
                RAID                     = $raidStatus
                UptimeCheck              = $UptimeCheck
                PendingReboot            = $PendingRebootCheck
                PendingUpdates           = $PendingUpdatesFlag
                ErrorCount               = $ErrorCountCheck
                DiskCheck                = $DiskCheck
                RDPCheck                 = $RDPCheck
                PowerShellVersion        = $PowerShellVersionCheck
                ServiceCountStatus       = 'Unused'
                VolumeCheckStatus        = $VolumeCheck
                WinHttpProxyServerStatus = $ProxyServerCheck
                PersistentRouteStatus    = $PersistentRouteCheck
                WindowsFirewallStatus    = $WindowsFirewallCheck
            }
            $SystemOverviewObj = [PSCustomObject]@{
                ServerName             = $MyHostName
                OperatingSystem        = $os.Caption
                OSVersion              = $os.Version
                WindowsLicense         = $windowsLicense
                KMSServer              = $kmsServerInfo
                LastKMSServer          = $lastKmsServer
                ActivationMethod       = $activationMethod
                ProductKey             = $kmsProductKey
                LicenseDescription     = $licenseDescription
                GracePeriodRemaining   = $gracePeriodRemaining
                IPAddress              = $( $ip = Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias "Ethernet*" -ErrorAction SilentlyContinue |
                    Select-Object -ExpandProperty IPAddress -First 1; if ($ip) { $ip } else { $MyHostName } )
                NumberOfCores          = (Get-CimInstance Win32_Processor | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum
                'RAM(GB)'              = $memTotal
                TotalDiskSpaceGB       = $TotalDiskSpace
                pageFileLocation       = $pageFileLocation
                Environment            = $environment
                LastRebootTime         = $lastBoot
                'Uptime(Days)'         = [math]::Round($uptime.TotalDays, 2)
                PendingReboot          = [string]$PendingRebootFlag
                PendingUpdates         = $pendingUpdatesCount
                EventLogErrorsLastWeek = ($errorLogs | Where-Object { $_.EntryType -eq 'Error' }).Count
                NewDiskPolicy          = $DiskPolicy
                NICCount               = $nicInterfaceCount
                WinHTTP_Proxy          = $winHttpProxy
                FirewallDomainProfile  = $(if ($firewallDomain -eq 1) { "Enabled" } else { "Disabled" })
                FirewallPublicProfile  = $(if ($firewallPublic -eq 1) { "Enabled" } else { "Disabled" })
                FirewallPrivateProfile = $(if ($firewallStandard -eq 1) { "Enabled" } else { "Disabled" })
                "CurrentCPU%"          = "$cpuLoad%"
                "CurrentMemory%"       = "$memUsedPct%"
                TimeZone               = "$([System.TimeZoneInfo]::Local.StandardName)"
                PowerShellVersion      = "$($PSVersionTable.PSVersion)"
                LastGPOUpdate          = $LastGPOUpdate
                DomainJoined           = $domainJoined
                DomainName             = $domainName
                DomainControllerName   = $DomainControllerName
                DCConnectionStatus     = $DCConnectionStatus
                ClientSiteName         = $ClientSiteName
                DcSiteName             = $DcSiteName
                RanOn                  = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            }

            write-log $ServerName "Collecting Hosts file contents..."
                $hostsFileContents = @()
            try {
                $hostsFilePath = Join-Path $env:SystemRoot 'System32\drivers\etc\hosts'
                if (Test-Path -Path $hostsFilePath) {
                    $hostsLines = Get-Content -Path $hostsFilePath -ErrorAction Stop
                    $lineNumber = 0

                    foreach ($line in $hostsLines) {
                        $lineNumber++
                        $trimmed = if ($null -ne $line) { $line.Trim() } else { "" }

                        if ([string]::IsNullOrWhiteSpace($trimmed)) { continue }
                        if ($trimmed.StartsWith('#')) { continue }

                        $lineWithoutInlineComment = ($trimmed -split '\s+#', 2)[0].Trim()
                        if ([string]::IsNullOrWhiteSpace($lineWithoutInlineComment)) { continue }

                        $parts = @($lineWithoutInlineComment -split '\s+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
                        if ($parts.Count -lt 2) { continue }

                        $ipAddress = $parts[0]
                        $hostNames = @($parts[1..($parts.Count - 1)])

                        $hostsFileContents += [PSCustomObject]@{
                            LineNumber = $lineNumber
                            IPAddress  = $ipAddress
                            HostNames  = ($hostNames -join ', ')
                            HostCount  = $hostNames.Count
                            Entry      = $lineWithoutInlineComment
                        }
                    }
                }
            }
            catch {
                $hostsFileContents = @(
                    [PSCustomObject]@{
                        Error = "Error reading hosts file: $($_.Exception.Message)"
                    }
                )
            }

            # IPScanResults - collected inline via the IPscan function when -ScanIP is used.
            # Results are embedded in the main migration JSON under the IPScanResults field.
            $IPScanResults = $null
            if ($ScanIP) {
                Write-Stage "Running IP scan for hardcoded RFC-1918 addresses (this may take several minutes on large drives)..."
                Write-Log $ServerName "Performing IP scan for hardcoded IPs..."
                $IPScanResults = IPscan
                # Ensure we have proper array structure for serialization
                if ($IPScanResults -and $IPScanResults.Count -gt 0) {
                    Write-Log $ServerName "IP scan: $($IPScanResults.Count) hit(s) found — normalising result objects..."
                    $IPScanResults = @($IPScanResults | ForEach-Object {
                            [PSCustomObject]@{
                                FilePath   = $_.FilePath
                                IPAddress  = $_.IPAddress
                                LineText   = $_.LineText
                                LineNumber = $_.LineNumber
                                IsLocal    = $_.IsLocal
                            }
                        })
                }
            }

            $maxEventLogsInJson = 10000
            $eventLogsForJson = @($errorLogs)
            if ($eventLogsForJson.Count -gt $maxEventLogsInJson) {
                Write-Log $ServerName "Trimming EventLogs for JSON output from $($eventLogsForJson.Count) to $maxEventLogsInJson to avoid long serialization time."
                $eventLogsForJson = @($eventLogsForJson | Select-Object -First $maxEventLogsInJson)
            }

            $resultData = [PSCustomObject]([ordered]@{
                RunTime                = $RunTime
                SystemOverview         = $SystemOverviewObj
                MigrationChecks        = $checksObj
                PatchDetails           = ($PendingUpdates | Select-Object Title, IsDownloaded, IsInstalled, RebootRequired)
                DiskDetails            = $disks
                VolumeDetails          = $volumes
                RAIDDetails            = $raidVolumes
                ShareDetails           = $shares
                RouteDetails           = $routes
                PersistentRouteDetails = $persistedRoutes
                PortDetails            = $ports
                NetworkConnectivityDetails = $networkConnections
                ClusterConfiguration    = $clusterConfiguration
                SoftwareInstalled      = $software
                RolesAndFeatures        = $rolesAndFeatures
                ServiceDetails         = $services
                ProcessDetails         = $processes
                ScheduledTasks         = $tasks
                EventLogs              = $eventLogsForJson
                PotentialUsers         = $potentialUsers
                HostsFileContents       = $hostsFileContents
                IPScanResults          = $IPScanResults
                NetworkInterfaces      = $nicConfigs
            })
            Write-Log $ServerName "Data collection on remote server complete."
            return [PSCustomObject]@{ Data = $resultData }
        }

        # HTML Output functionality removed - this script now only generates JSON output

            # Shared ADO helper functions are loaded from CMSLibrary.ps1 in this runspace.

        function Test-IsPowerShellAccessFailure {
            param([string]$ErrorMessage)

            if ([string]::IsNullOrWhiteSpace($ErrorMessage)) { return $false }

            return ($ErrorMessage -match 'access denied|authentication|kerberos|negotiate|winrm|wsman|client cannot connect|connecting to remote server .* failed|cannot process the request|connection.*refused|network path was not found|name cannot be resolved|pSSessionOpenFailed')
        }


        # timestamp helper
        $ts = "[" + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + "]"

        # queueing log
        Write-Output "$ts Queuing remote server $serverName..."

        try {
            # actual work
            $computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem
            $localHostName = $computerSystem.DNSHostName
            $localDomain = $computerSystem.Domain
            $localFqdn = if (-not [string]::IsNullOrWhiteSpace($localDomain) -and ($localDomain -ne $localHostName)) { "$localHostName.$localDomain" } else { $localHostName }

            $serverNameNormalized = ($serverName | ForEach-Object { $_.ToString().Trim().TrimEnd('.') })
            $serverShortName = if ($serverNameNormalized -match '\.') { $serverNameNormalized.Split('.')[0] } else { $serverNameNormalized }

            $isLocalTarget = (
                $serverNameNormalized -ieq 'localhost' -or
                $serverShortName -ieq 'localhost' -or
                $serverNameNormalized -ieq $localHostName -or
                $serverShortName -ieq $localHostName -or
                $serverNameNormalized -ieq $localFqdn -or
                $serverNameNormalized -ieq $env:COMPUTERNAME -or
                $serverShortName -ieq $env:COMPUTERNAME
            )

            function Write-Stage {
                param([string]$Message)
                if ($isLocalTarget) {
                    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [local-step] [$serverNameNormalized] $Message" -ForegroundColor Cyan
                }
            }

            if ($isLocalTarget) {
                # Run locally (covers hostname, FQDN, and localhost).
                # Pipe the inner script's output so write-log strings are displayed in real-time
                # via Write-Host while the final PSCustomObject result is captured as $data.
                # This path never touches a background job.
                Write-Output "$ts Running script locally on $serverNameNormalized..."
                $data = $null
                & $remoteScript -CheckType $CheckType -ScanIP $ScanIP -ScanIPPath $ScanIPPath -SkipEventLog ([bool]$SkipEventLog) -EventLogMaxEvents $EventLogMaxEvents -CollectorClientAddresses @() -LocalDebug $true | ForEach-Object {
                    if ($_ -is [PSCustomObject]) {
                        $data = $_
                    }
                    else {
                        # Write log/progress lines directly to host with a distinct color so they
                        # stand out as step-by-step debug output (local thread only, never in a job).
                        Write-Host "  [local] $_" -ForegroundColor DarkCyan
                    }
                }
                $workingCredential = $null  # Local execution - no remote credentials needed
            }
            else {
                # Run remotely with credential fallback
                Write-Output "$ts Running script remotely on $serverNameNormalized..."

                $data = $null
                $connectionSucceeded = $false
                $workingCredential = $null  # Track which credentials successfully connected
                $attemptErrors = New-Object System.Collections.Generic.List[string]
                $collectorClientAddresses = @()
                try {
                    $collectorClientAddresses = @(
                        Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                            Where-Object { $_.IPAddress -and $_.IPAddress -notlike '127.*' -and $_.IPAddress -ne '0.0.0.0' } |
                            Select-Object -ExpandProperty IPAddress -Unique
                    )
                }
                catch {
                    try {
                        $collectorClientAddresses = @(
                            [System.Net.Dns]::GetHostAddresses($env:COMPUTERNAME) |
                                Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork } |
                                ForEach-Object {
                                    $addrText = $_.ToString()
                                    if ($addrText -and $addrText -notlike '127.*' -and $addrText -ne '0.0.0.0') { $addrText }
                                } |
                                Select-Object -Unique
                        )
                    }
                    catch {
                        $collectorClientAddresses = @()
                    }
                }

                function Add-WinRmTrustedHostIfNeeded {
                    param([string]$RemoteServer)

                    try {
                        $currentTrustedHosts = (Get-Item WSMan:\localhost\Client\TrustedHosts -ErrorAction SilentlyContinue).Value
                        $trustedHostPatterns = @($currentTrustedHosts -split ',' | ForEach-Object { ([string]$_).Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

                        # '*' must stand alone. If a previous run left '*,server', normalize it back to '*'.
                        if ($trustedHostPatterns -contains '*') {
                            if ($trustedHostPatterns.Count -gt 1) {
                                Set-Item WSMan:\localhost\Client\TrustedHosts -Value '*' -Force -ErrorAction Stop
                                Write-Output "$ts Normalized WSMan TrustedHosts wildcard entry back to '*'"
                            }
                            return
                        }

                        if ($trustedHostPatterns -contains $RemoteServer) {
                            return
                        }

                        $newTrustedHosts = @($trustedHostPatterns + $RemoteServer) -join ','
                        Set-Item WSMan:\localhost\Client\TrustedHosts -Value $newTrustedHosts -Force -ErrorAction Stop
                        Write-Output "$ts Added $RemoteServer to WSMan TrustedHosts for explicit-auth fallback"
                    }
                    catch {
                        Write-Warning "$ts Could not update TrustedHosts (non-fatal): $($_.Exception.Message)"
                    }
                }

                function Invoke-RemoteScanAttempt {
                    param(
                        [Parameter(Mandatory = $true)][string]$AttemptLabel,
                        [Parameter(Mandatory = $true)][string]$AttemptComputerName,
                        [Parameter(Mandatory = $true)][bool]$UseSSL,
                        [System.Management.Automation.PSCredential]$AttemptCredential,
                        [bool]$IncludePortInSPN = $false,
                        [string]$Authentication = ''
                    )

                    try {
                        $attemptUser = if ($AttemptCredential) { $AttemptCredential.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
                        if ($Authentication -eq 'Basic' -and -not $AttemptCredential) {
                            Write-Output "$ts Skipping $AttemptLabel for $AttemptComputerName because Basic authentication requires explicit credentials."
                            return [PSCustomObject]@{
                                Succeeded         = $false
                                Data              = $null
                                WorkingCredential = $null
                                LastError         = 'Basic authentication requires explicit credentials.'
                            }
                        }
                        if (-not [string]::IsNullOrWhiteSpace($Authentication)) {
                            Add-WinRmTrustedHostIfNeeded -RemoteServer $AttemptComputerName
                        }
                        Write-Output "$ts Attempting connection to $AttemptComputerName using $AttemptLabel as $attemptUser..."
                        $invokeParams = @{
                            ComputerName      = $AttemptComputerName
                            ScriptBlock       = $remoteScript
                            ArgumentList      = $CheckType, $ScanIP, $ScanIPPath, ([bool]$SkipEventLog), $EventLogMaxEvents, $collectorClientAddresses
                            InformationAction = 'Continue'
                            ErrorAction       = 'Stop'
                        }

                        if ($UseSSL -or $IncludePortInSPN) {
                            try {
                                $sessionOptionParams = @{}
                                if ($UseSSL) {
                                    $sessionOptionParams.SkipCACheck = $true
                                    $sessionOptionParams.SkipCNCheck = $true
                                    $sessionOptionParams.SkipRevocationCheck = $true
                                }
                                if ($IncludePortInSPN) {
                                    $sessionOptionParams.IncludePortInSPN = $true
                                }
                                $invokeParams.SessionOption = New-PSSessionOption @sessionOptionParams
                            }
                            catch {
                                Write-Warning "$ts Could not apply session options for ${AttemptComputerName}: $($_.Exception.Message)"
                            }
                        }

                        if ($UseSSL) {
                            $invokeParams.UseSSL = $true
                            $invokeParams.Port = 5986
                        }

                        if ($AttemptCredential) {
                            $invokeParams.Credential = $AttemptCredential
                        }

                        if (-not [string]::IsNullOrWhiteSpace($Authentication)) {
                            $invokeParams.Authentication = $Authentication
                        }

                        $rawResultData = @(Invoke-Command @invokeParams)
                        $resultData = $null
                        foreach ($outputItem in $rawResultData) {
                            if ($outputItem -is [string]) {
                                Write-Output $outputItem
                                continue
                            }

                            if ($outputItem -is [System.Management.Automation.PSCustomObject]) {
                                if ($outputItem.PSObject.Properties['Data']) {
                                    $resultData = $outputItem.Data
                                    continue
                                }
                                if ($outputItem.PSObject.Properties['SystemOverview']) {
                                    $resultData = $outputItem
                                    continue
                                }
                            }

                            if ($null -eq $resultData) {
                                $resultData = $outputItem
                            }
                        }

                        if ($null -eq $resultData) {
                            Write-Warning "$ts Remote command returned no payload object for $AttemptComputerName using $AttemptLabel"
                        }
                        Write-Output "$ts Successfully connected to $AttemptComputerName using $AttemptLabel as $attemptUser"

                        return [PSCustomObject]@{
                            Succeeded         = $true
                            Data              = $resultData
                            WorkingCredential = $AttemptCredential
                            LastError         = $null
                        }
                    }
                    catch {
                        $message = $_.Exception.Message
                        $attemptUser = if ($AttemptCredential) { $AttemptCredential.UserName } else { "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) (current user)" }
                        $attemptErrors.Add("$AttemptLabel as $attemptUser failed: $message") | Out-Null
                        Write-Warning "$ts Failed to connect to $AttemptComputerName using ${AttemptLabel} as ${attemptUser}: $message"

                        return [PSCustomObject]@{
                            Succeeded         = $false
                            Data              = $null
                            WorkingCredential = $null
                            LastError         = $message
                        }
                    }
                }

                $attemptSucceeded = $false
                $attemptResult = $null
                $crossDomainPattern = '0x80090311|0x8009030e|domain.*not.*available|We can.t sign you in|TrustedHosts|authentication scheme|HTTPS transport must be used'

                # Build connection targets list. Try the original input name (typically FQDN) first to
                # preserve historical DMZ behavior, then short-name and DNS-resolved fallbacks.
                $connectionTargets = New-Object System.Collections.Generic.List[string]
                if (-not [string]::IsNullOrWhiteSpace($serverNameNormalized)) {
                    $connectionTargets.Add($serverNameNormalized) | Out-Null
                }
                if (-not [string]::IsNullOrWhiteSpace($serverShortName) -and -not ($connectionTargets -contains $serverShortName)) {
                    $connectionTargets.Add($serverShortName) | Out-Null
                }
                # Optional: try DNS-resolved name if different from above
                try {
                    $resolvedHostName = ([System.Net.Dns]::GetHostEntry($serverNameNormalized)).HostName
                    if (-not [string]::IsNullOrWhiteSpace($resolvedHostName) -and -not ($connectionTargets -contains $resolvedHostName)) {
                        $connectionTargets.Add($resolvedHostName) | Out-Null
                    }
                }
                catch { }

                # AVAMoveOPS commonly passes -PersonalJSON for mixed environments. If -UseCredential was
                # not explicitly requested, prefer current logged-in context first (works for majority of
                # internal domain VMs) and then fall back to explicit JSON credentials for DMZ targets.
                $preferCurrentUserFirst = [bool]$PreferCurrentUserFirst

                foreach ($connectionTarget in $connectionTargets) {
                    if ($attemptSucceeded) { break }

                    if ($preferCurrentUserFirst) {
                        $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null
                        $attemptSucceeded = [bool]$attemptResult.Succeeded
                        $cuHttpLastError = $attemptResult.LastError
                        if (-not $attemptSucceeded) {
                            $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $null
                            $attemptSucceeded = [bool]$attemptResult.Succeeded
                        }
                        $cuIsCrossDomain = ($cuHttpLastError -match $crossDomainPattern) -or
                                          ($attemptErrors | Where-Object { $_ -match $crossDomainPattern })
                        if (-not $attemptSucceeded -and $cuIsCrossDomain) {
                            $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null -Authentication 'Negotiate'
                            $attemptSucceeded = [bool]$attemptResult.Succeeded
                        }
                    }

                    # When explicit credentials are provided, try them FIRST against each connection
                    # target. This is critical for cross-domain / DMZ environments where the current
                    # user's Kerberos realm has no trust to the target domain (0x80090311). Attempting
                    # current-user Kerberos first in those environments poisons the SSPI negative cache,
                    # causing subsequent explicit-credential attempts against the same host to also fail
                    # with "Access is denied" even when the credentials are valid.
                    if (-not $attemptSucceeded -and $credential) {
                        # Try explicit credentials with default auth (Kerberos) first for domain-joined workstations
                        $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 Kerberos)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $credential
                        $attemptSucceeded = [bool]$attemptResult.Succeeded
                        # Capture the HTTP error now before a subsequent attempt may overwrite $attemptResult
                        $httpLastError = $attemptResult.LastError
                        if (-not $attemptSucceeded -and $httpLastError -match '0x80090322|An unknown security error') {
                            $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 +IncludePortInSPN)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $credential -IncludePortInSPN $true
                            $attemptSucceeded = [bool]$attemptResult.Succeeded
                        }
                        if (-not $attemptSucceeded) {
                            $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $credential
                            $attemptSucceeded = [bool]$attemptResult.Succeeded
                        }
                        # Cross-domain / no-trust fallbacks: Negotiate forces NTLM when Kerberos realm is unavailable
                        # Check the HTTP error (captured above) because the HTTPS attempt that ran afterward overwrites $attemptResult
                        $isCrossDomainError = ($httpLastError -match $crossDomainPattern) -or
                                              ($attemptErrors | Where-Object { $_ -match $crossDomainPattern })
                        if (-not $attemptSucceeded -and $isCrossDomainError) {
                            Add-WinRmTrustedHostIfNeeded -RemoteServer $connectionTarget
                            $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $credential -Authentication 'Negotiate'
                            $attemptSucceeded = [bool]$attemptResult.Succeeded
                            if (-not $attemptSucceeded) {
                                $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'explicit credentials (WinRM HTTPS/5986 Basic)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $credential -Authentication 'Basic'
                                $attemptSucceeded = [bool]$attemptResult.Succeeded
                            }
                        }
                    }

                # Fall back to current user context if credentials weren't provided or didn't work
                if (-not $preferCurrentUserFirst -and -not $attemptSucceeded) {
                    $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null
                    $attemptSucceeded = [bool]$attemptResult.Succeeded
                    $cuHttpLastError = $attemptResult.LastError
                    if (-not $attemptSucceeded) {
                        $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $null
                        $attemptSucceeded = [bool]$attemptResult.Succeeded
                    }
                    $cuIsCrossDomain = ($cuHttpLastError -match $crossDomainPattern) -or
                                      ($attemptErrors | Where-Object { $_ -match $crossDomainPattern })
                    if (-not $attemptSucceeded -and $cuIsCrossDomain) {
                        $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'current user context (WinRM HTTP/5985 Negotiate/NTLM)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $null -Authentication 'Negotiate'
                        $attemptSucceeded = [bool]$attemptResult.Succeeded
                    }
                }

                if (-not $attemptSucceeded) {
                    # Inside a Start-Job, Get-Credential cannot display a UI prompt.
                    # Only attempt interactive prompt if NOT in a background job.
                    if (-not $credential -and [Environment]::UserInteractive -and $Host.Name -ne "ServerRemoteHost") {
                        try {
                            Write-Output "$ts All connection attempts failed. Prompting for credentials for $serverNameNormalized..."
                            $credential = Get-Credential -Message "Enter credentials for connecting to $serverNameNormalized"
                            if ($credential) {
                                Write-Output "$ts Credentials captured for $serverNameNormalized - retrying..."
                                $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'prompted credentials (WinRM HTTP/5985)' -AttemptComputerName $connectionTarget -UseSSL $false -AttemptCredential $credential
                                $attemptSucceeded = [bool]$attemptResult.Succeeded
                                if (-not $attemptSucceeded) {
                                    $attemptResult = Invoke-RemoteScanAttempt -AttemptLabel 'prompted credentials (WinRM HTTPS/5986)' -AttemptComputerName $connectionTarget -UseSSL $true -AttemptCredential $credential
                                    $attemptSucceeded = [bool]$attemptResult.Succeeded
                                }
                            }
                            else {
                                Write-Warning "$ts No credentials provided for $serverNameNormalized"
                            }
                        }
                        catch {
                            Write-Warning "$ts Failed to capture credentials for $serverNameNormalized`: $($_.Exception.Message)"
                        }
                    }
                }

                if ($attemptSucceeded) {
                    $data = $attemptResult.Data
                    $connectionSucceeded = $true
                    $workingCredential = $attemptResult.WorkingCredential
                }

            }

                # If all attempts failed across all connection targets, return an error object.
                if (-not $connectionSucceeded) {
                    $errorMessage = "Failed to connect to $serverNameNormalized over WinRM HTTP (5985) and HTTPS (5986) using both current user context and explicit credentials"
                    Write-Error $errorMessage

                    if ($attemptErrors.Count -gt 0) {
                        Write-Warning "$ts Connection attempts summary for ${serverNameNormalized}:"
                        foreach ($attemptError in $attemptErrors) {
                            Write-Warning "  - $attemptError"
                        }

                        $accessDeniedErrors = @($attemptErrors | Where-Object { $_ -match 'access is denied' })
                        if ($accessDeniedErrors.Count -gt 0) {
                            $credentialUserName = if ($credential) { $credential.UserName } else { '<current user context>' }
                            Write-Warning "$ts Remote server ${serverNameNormalized} is reachable, but WinRM authorization failed for $credentialUserName."
                            Write-Warning "Likely causes:"
                            Write-Warning "  - The supplied account is not a local Administrator on the target server"
                            Write-Warning "  - The supplied account is not in the 'Remote Management Users' group"
                            Write-Warning "  - The PowerShell remoting endpoint ACL on the target server does not allow this account"
                            Write-Warning "  - The stored username/password in Personal JSON are incorrect or expired"
                            Write-Warning "Recommended validation on one target server:"
                            Write-Warning "  - Confirm the credential can sign in interactively or via runas"
                            Write-Warning "  - Run 'winrm quickconfig' on the target server"
                            Write-Warning "  - Verify membership in local Administrators or Remote Management Users"
                            Write-Warning "  - Check the PowerShell session configuration with 'Get-PSSessionConfiguration | Select-Object Name, Permission'"
                        }
                    }

                    if (-not $credential) {
                        Write-Warning "Consider using -UseCredential switch with credentials for remote access"
                        Write-Warning "Example: .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -UseCredential -Username 'domain\user' -Password 'password'"
                        Write-Warning "Or use PersonalJSON: .\MigrationCheck-DataCollector.ps1 -CheckType Pre_Migration -UseCredential -PersonalJSON 'C:\personal.json'"
                    }

                    if ($PersonalAccessToken -and $ProjectName -and $CheckType -eq 'Pre_Migration') {
                        try {
                            Set-ADOWindowsAccessStatus -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $serverNameNormalized -HasPowerShellAccess $false | Out-Null
                        }
                        catch {
                            Write-Warning "Failed to update ADO access blocker for $serverNameNormalized : $($_.Exception.Message)"
                        }
                    }

                    return [PSCustomObject]@{
                        Server = $serverNameNormalized
                        Result = $null
                        Error  = $errorMessage
                    }
                }

            } # end remote execution path

            if ($null -ne $data -and $data.PSObject.Properties['Data'] -and -not $data.PSObject.Properties['SystemOverview']) {
                $data = $data.Data
            }
            # completion log + stream returned objects if any
            Write-Output "$ts Job $serverName completed. Streaming output..."
            # If ServerName is FQDN, extract just the hostname
            if ($serverName -match '\.') {
                $serverName = $serverName.Split('.')[0]
            }

            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Processing results for server $serverName..."

            $suffix = $CheckType
            $baseName = "${serverName}_${suffix}"

            # Ensure $OutputDir and $serverName are not null or empty
            $outputDirFinal = if ([string]::IsNullOrWhiteSpace($OutputDir)) { "C:\Avanade\$env:USERNAME" } else { $OutputDir }

            # Resolve output directory path (handle UNC paths and PowerShell provider prefixes)
            $resolvedOutputDir = $outputDirFinal
            if ($resolvedOutputDir -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
                $resolvedOutputDir = $resolvedOutputDir -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
            }
            $resolvedOutputDir = $resolvedOutputDir.Trim().Trim("'").Trim('"')
            if (-not (Split-Path -IsAbsolute $resolvedOutputDir) -and ($resolvedOutputDir -notmatch '^[\\]{2}')) {
                $resolvedOutputDir = Join-Path -Path (Get-Location).Path -ChildPath $resolvedOutputDir
            }

            # Ensure the per-server output directory exists before building file paths
            $serverOutputDir = Join-Path $resolvedOutputDir $serverName

            # Debug output for path resolution
            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Path resolution for $serverName - Original: '$OutputDir', Resolved: '$resolvedOutputDir', ServerDir: '$serverOutputDir'"

            if (!(Test-Path $serverOutputDir)) {
                New-Item -Path $serverOutputDir -ItemType Directory -Force | Out-Null
            }

            $jsonFile = Join-Path $serverOutputDir "$baseName.json"

            # Validate that JSON file path is not empty
            if ([string]::IsNullOrWhiteSpace($jsonFile)) {
                Write-Warning "JSON file path is empty. ServerOutputDir: '$serverOutputDir', BaseName: '$baseName'"
                return [PSCustomObject]@{
                    Server = $serverName
                    Result = $null
                    Error  = 'Invalid JSON file path'
                }
            }

            if (-not $data.SystemOverview) {
                Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] No data collected for server $serverName. Skipping report generation..."
                # Return a failure object so the main thread records this server as failed (don't touch outer-scope variables here)
                return [PSCustomObject]@{
                    Server = $serverName
                    Result = $null
                    Error  = 'No data collected'
                }
            }
            $serializeStart = Get-Date
            $eventCountForJson = @($data.EventLogs).Count
            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Serializing JSON for $serverName (EventLogs: $eventCountForJson)..."
            $serializeCounts = [pscustomobject]@{
                Software   = @($data.SoftwareInstalled).Count
                Tasks      = @($data.ScheduledTasks).Count
                Processes  = @($data.ProcessDetails).Count
                Services   = @($data.ServiceDetails).Count
                Ports      = @($data.PortDetails).Count
                Routes     = @($data.RouteDetails).Count
                Volumes    = @($data.VolumeDetails).Count
                Disks      = @($data.DiskDetails).Count
                Shares     = @($data.ShareDetails).Count
                Cluster    = if ($data.ClusterConfiguration -and $data.ClusterConfiguration.Available) { 'Yes' } else { 'No' }
                IPScanHits = @($data.IPScanResults).Count
            }
            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Serialization input sizes for ${serverName}: Software=$($serializeCounts.Software) Tasks=$($serializeCounts.Tasks) Processes=$($serializeCounts.Processes) Services=$($serializeCounts.Services) Ports=$($serializeCounts.Ports) Routes=$($serializeCounts.Routes) Volumes=$($serializeCounts.Volumes) Disks=$($serializeCounts.Disks) Shares=$($serializeCounts.Shares) Cluster=$($serializeCounts.Cluster) IPScanHits=$($serializeCounts.IPScanHits)"
            $psMajor = $PSVersionTable.PSVersion.Major
            # Remote data arrives as Deserialized.PSCustomObject from Invoke-Command.
            # ConvertTo-Json at high depth can hang indefinitely on deserialized objects
            # due to hidden property chains (.PSObject, .PSBase, type descriptors).
            # Use the same timeout-protected approach for remote data as for PS5.1.
            if ($isLocalTarget) {
                $jsonDepth = if ($psMajor -ge 7) { 25 } else { 8 }
                $jsonCompress = if ($psMajor -ge 7) { $true } else { $false }
                $jsonTimeoutSeconds = if ($psMajor -ge 7) { 0 } else { 30 }
            }
            else {
                # Remote: deserialized objects need lower depth and a timeout guard
                $jsonDepth = if ($psMajor -ge 7) { 10 } else { 8 }
                $jsonCompress = if ($psMajor -ge 7) { $true } else { $false }
                $jsonTimeoutSeconds = 45
                Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Remote data detected for $serverName - using timeout-protected JSON serialization (Depth=$jsonDepth, Timeout=${jsonTimeoutSeconds}s)"
            }

            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Starting ConvertTo-Json for $serverName (Depth=$jsonDepth, Compress=$jsonCompress, TimeoutSeconds=$jsonTimeoutSeconds)"
            $jsonConvertStart = Get-Date
            $jsonContent = $null

            if ($jsonTimeoutSeconds -gt 0) {
                $rsJson = [System.Management.Automation.PowerShell]::Create()
                $null = $rsJson.AddScript({
                        param($obj, $depth, $compress)
                        $obj | ConvertTo-Json -Depth $depth -Compress:$compress
                    }).AddArgument($data).AddArgument($jsonDepth).AddArgument($jsonCompress)

                $handleJson = $rsJson.BeginInvoke()
                $jsonTimedOut = $false
                $jsonPollSeconds = 5

                while (-not $handleJson.IsCompleted) {
                    if ($handleJson.AsyncWaitHandle.WaitOne([TimeSpan]::FromSeconds($jsonPollSeconds))) { break }
                    $elapsed = [int]((Get-Date) - $jsonConvertStart).TotalSeconds
                    Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ConvertTo-Json still running for $serverName... ${elapsed}s elapsed (timeout ${jsonTimeoutSeconds}s)"
                    if ($elapsed -ge $jsonTimeoutSeconds) {
                        $jsonTimedOut = $true
                        break
                    }
                }

                if (-not $jsonTimedOut -and $handleJson.IsCompleted) {
                    $jsonOut = $rsJson.EndInvoke($handleJson)
                    $jsonContent = ($jsonOut -join [Environment]::NewLine)
                }
                else {
                    $jsonTimeoutMsg = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ConvertTo-Json timed out after ${jsonTimeoutSeconds}s for $serverName. Writing truncated JSON payload (PS5.1 fallback)."
                    Write-Warning $jsonTimeoutMsg
                    Write-Output $jsonTimeoutMsg

                    # IMPORTANT: PowerShell.Stop() can itself block in PS5.1 for certain payloads.
                    # Use asynchronous BeginStop() so we can proceed to the fallback path.
                    try {
                        $null = $rsJson.BeginStop($null, $null)
                    }
                    catch {
                        try { $rsJson.Stop() } catch { }
                    }

                    # Identify which top-level property is causing ConvertTo-Json to stall in PS5.1
                    try {
                        Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Starting per-property JSON probe for $serverName (Depth=6, TimeoutSeconds=20)"
                        $probeDepth = 6
                        $probeTimeoutSeconds = 20
                        $probeCompress = $false
                        $propNames = @($data.PSObject.Properties | Where-Object { $_.MemberType -in @('NoteProperty', 'Property') } | Select-Object -ExpandProperty Name)

                        foreach ($propName in $propNames) {
                            $propValue = $data.$propName
                            $propType = if ($null -eq $propValue) { '<null>' } else { $propValue.GetType().FullName }
                            $propCount = 1
                            try {
                                if ($propValue -is [System.Collections.IEnumerable] -and -not ($propValue -is [string])) {
                                    $propCount = @($propValue).Count
                                }
                            }
                            catch { $propCount = 1 }

                            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Probe start: $propName (Type=$propType, Count=$propCount)"
                            $probeStart = Get-Date

                            $probeObj = [pscustomobject]([ordered]@{ ($propName) = $propValue })
                            $rsProbe = [System.Management.Automation.PowerShell]::Create()
                            $null = $rsProbe.AddScript({
                                    param($obj, $depth, $compress)
                                    $obj | ConvertTo-Json -Depth $depth -Compress:$compress
                                }).AddArgument($probeObj).AddArgument($probeDepth).AddArgument($probeCompress)

                            $handleProbe = $rsProbe.BeginInvoke()
                            $completed = $handleProbe.AsyncWaitHandle.WaitOne([TimeSpan]::FromSeconds($probeTimeoutSeconds))
                            if ($completed -and $handleProbe.IsCompleted) {
                                $probeOut = $rsProbe.EndInvoke($handleProbe)
                                $probeJson = ($probeOut -join [Environment]::NewLine)
                                $probeSeconds = [math]::Round(((Get-Date) - $probeStart).TotalSeconds, 2)
                                $probeLen = if ($null -ne $probeJson) { $probeJson.Length } else { 0 }
                                Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Probe OK: $propName in ${probeSeconds}s (chars: $probeLen)"
                            }
                            else {
                                try {
                                    $null = $rsProbe.BeginStop($null, $null)
                                }
                                catch {
                                    try { $rsProbe.Stop() } catch { }
                                }
                                $probeSeconds = [math]::Round(((Get-Date) - $probeStart).TotalSeconds, 2)
                                $probeTimeoutMsg = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Probe TIMEOUT: $propName after ${probeSeconds}s (Type=$propType)"
                                Write-Warning $probeTimeoutMsg
                                Write-Output $probeTimeoutMsg
                            }

                            try {
                                if ($handleProbe -and $handleProbe.AsyncWaitHandle) { $handleProbe.AsyncWaitHandle.Close() }
                            }
                            catch { }
                            # Avoid potential blocking Dispose() after a timeout; we prefer forward progress over cleanup.
                            if ($completed -and $handleProbe.IsCompleted) {
                                try { $rsProbe.Dispose() } catch { }
                            }
                        }
                    }
                    catch {
                        Write-Warning "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Per-property JSON probe failed for ${serverName}: $($_.Exception.Message)"
                    }

                    $dataLite = [PSCustomObject]([ordered]@{
                            RunTime                = $data.RunTime
                            SystemOverview         = $data.SystemOverview
                            MigrationChecks        = $data.MigrationChecks
                            PatchDetails           = @($data.PatchDetails | Select-Object -First 200)
                            DiskDetails            = @($data.DiskDetails | Select-Object -First 50)
                            VolumeDetails          = @($data.VolumeDetails | Select-Object -First 100)
                            RAIDDetails            = @($data.RAIDDetails | Select-Object -First 50)
                            ShareDetails           = @($data.ShareDetails | Select-Object -First 200)
                            RouteDetails           = @($data.RouteDetails | Select-Object -First 500)
                            PersistentRouteDetails = @($data.PersistentRouteDetails | Select-Object -First 500)
                            PortDetails            = @($data.PortDetails | Select-Object -First 500)
                            NetworkConnectivityDetails = @($data.NetworkConnectivityDetails | Select-Object -First 1000)
                            ClusterConfiguration    = if ($data.ClusterConfiguration) {
                                [PSCustomObject]@{
                                    Available = $data.ClusterConfiguration.Available
                                    Cluster   = $data.ClusterConfiguration.Cluster
                                    Quorum    = $data.ClusterConfiguration.Quorum
                                    Nodes     = @($data.ClusterConfiguration.Nodes | Select-Object -First 50)
                                    Groups    = @($data.ClusterConfiguration.Groups | Select-Object -First 200)
                                    Listeners = @($data.ClusterConfiguration.Listeners | Select-Object -First 200)
                                }
                            }
                            else { $null }
                            SoftwareInstalled      = @($data.SoftwareInstalled | Select-Object -First 200)
                            RolesAndFeatures        = @($data.RolesAndFeatures | Select-Object -First 500)
                            ServiceDetails         = @($data.ServiceDetails | Select-Object -First 300)
                            ProcessDetails         = @($data.ProcessDetails | Select-Object -First 200)
                            ScheduledTasks         = @($data.ScheduledTasks | Select-Object -First 300)
                            EventLogs              = @($data.EventLogs | Select-Object -First $EventLogMaxEvents)
                            PotentialUsers         = $data.PotentialUsers
                            HostsFileContents       = $data.HostsFileContents
                            IPScanResults          = @($data.IPScanResults | Select-Object -First 100)
                            NetworkInterfaces      = @($data.NetworkInterfaces | Select-Object -First 50)
                            JsonSerializationNote  = "Full JSON serialization timed out after ${jsonTimeoutSeconds}s under PowerShell $($PSVersionTable.PSVersion). Output was truncated to avoid indefinite hangs."
                        })

                    $jsonContent = $dataLite | ConvertTo-Json -Depth 8 -Compress:$false
                }

                try {
                    if ($handleJson -and $handleJson.AsyncWaitHandle) { $handleJson.AsyncWaitHandle.Close() }
                }
                catch { }
                # Avoid potential blocking Dispose() after a timeout; we prefer forward progress over cleanup.
                if (-not $jsonTimedOut) {
                    try { $rsJson.Dispose() } catch { }
                }
            }
            else {
                $jsonContent = $data | ConvertTo-Json -Depth $jsonDepth -Compress:$jsonCompress
            }

            $jsonConvertSeconds = [math]::Round(((Get-Date) - $jsonConvertStart).TotalSeconds, 2)
            $jsonChars = if ($null -ne $jsonContent) { $jsonContent.Length } else { 0 }
            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ConvertTo-Json completed in ${jsonConvertSeconds}s for $serverName (chars: $jsonChars)"

            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Writing JSON file for $serverName : $jsonFile"
            $jsonWriteStart = Get-Date
            [System.IO.File]::WriteAllText($jsonFile, $jsonContent, [System.Text.Encoding]::UTF8)
            $jsonWriteSeconds = [math]::Round(((Get-Date) - $jsonWriteStart).TotalSeconds, 2)
            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] JSON file write completed in ${jsonWriteSeconds}s for $serverName"
            $serializeSeconds = [math]::Round(((Get-Date) - $serializeStart).TotalSeconds, 2)
            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] JSON serialization+write completed in ${serializeSeconds}s for $serverName"

            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] JSON report generated for server $serverName`: $jsonFile"

            # Store the JSON file path in the result for later HTML generation
            $htmlGenerationInfo = @{
                JsonFilePath = $jsonFile
                ServerName = $serverName
            }

            # IPScanResults are already embedded in the main migration JSON (IPScanResults field).
            # No separate _ScanIP.json file is written.

            # ─── Check for SQL Server and IIS, run collection scripts if present ───
            # Note: $scriptDirectory is passed from main script context
            # Note: $workingCredential contains credentials that successfully connected (or $null if current user context worked)

            # ─── Workload-specific collections (SQL / IIS) ─────────────────────────
            # Skipped when -ServerOnlyData is set (e.g. Server-only button in AVAMoveOPS)
            if (-not $ServerOnlyData) {

            # Check for SQL Server services
            Write-Stage "Checking for SQL Server workload"
            $sqlServices = $data.ServiceDetails | Where-Object {
                $_.Name -match 'SQL' -and $_.State -eq 'Running'
            }
            if ($sqlServices) {
                $sqlCollector = Resolve-CollectorCommandPath -BaseName 'CollectSQLData' -CurrentScriptDirectory $scriptDirectory
                if ($sqlCollector.Path) {
                    $sqlScriptPath = $sqlCollector.Path
                    $sqlCommandName = [System.IO.Path]::GetFileName($sqlScriptPath)
                    Write-Stage "Collecting SQL Server details via $sqlCommandName"
                    Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] SQL Server service(s) detected on $serverName. Running $sqlCommandName..."
                    try {
                        $sqlParams = @{
                            CheckType = $CheckType
                            ServerName = $serverName
                            OutputPath = $serverOutputDir
                        }
                        # Use the same credentials that successfully connected to the server.
                        # Pass as Username/Password strings to survive the nested Start-Job serialization
                        # boundary — PSCredential.GetNetworkCredential() is unavailable on deserialized objects.
                        if ($workingCredential) {
                            try {
                                $sqlParams['Username'] = [string]$workingCredential.UserName
                                $credPwd = $null
                                try { $credPwd = $workingCredential.GetNetworkCredential().Password } catch { }
                                if (-not $credPwd) {
                                    $credPwd = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
                                        [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR(
                                            $workingCredential.Password))
                                }
                                if ($credPwd) { $sqlParams['Password'] = $credPwd }
                                Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Using explicit credentials for SQL data collection on $serverName"
                            } catch {
                                Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Unable to extract credentials for SQL on $serverName — using current user context"
                            }
                        }
                        else {
                            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Using current user context for SQL data collection on $serverName (same as server connection)"
                        }

                        # Run with 4-minute timeout
                        $sqlJob = Start-Job -ScriptBlock {
                            param($scriptPath, $params)

                            # Native executables can drop hashtable-splatted args in PS5 jobs.
                            # Build an explicit argument array to preserve every parameter value.
                            $argList = @()
                            foreach ($entry in $params.GetEnumerator()) {
                                if ($null -eq $entry.Value) { continue }
                                $valueText = [string]$entry.Value
                                if ([string]::IsNullOrWhiteSpace($valueText)) { continue }
                                $argList += "-$($entry.Key)"
                                $argList += $valueText
                            }

                            & $scriptPath @argList
                        } -ArgumentList $sqlScriptPath, $sqlParams

                        $sqlJobStart = Get-Date
                        $sqlJobTimeoutSeconds = $JobTimeoutSeconds
                        $sqlJobPollSeconds = 10
                        $sqlJobCompleted = $null
                        do {
                            $elapsed = [int]((Get-Date) - $sqlJobStart).TotalSeconds
                            $remaining = $sqlJobTimeoutSeconds - $elapsed
                            if ($remaining -le 0) { break }
                            $waitSeconds = [Math]::Min($sqlJobPollSeconds, $remaining)
                            $sqlJobCompleted = Wait-Job -Job $sqlJob -Timeout $waitSeconds
                            if (-not $sqlJobCompleted -and $LocalDebug) {
                                Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [local-step] [$ServerName] $sqlCommandName still running... ${elapsed}s elapsed (timeout ${sqlJobTimeoutSeconds}s)" -ForegroundColor DarkCyan
                            }
                        } while (-not $sqlJobCompleted)

                        if ($sqlJobCompleted) {
                            $sqlResult = Receive-Job -Job $sqlJob
                            if ($sqlResult) { Write-Output $sqlResult }
                            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] SQL data collection completed for $serverName"
                        }
                        else {
                            Stop-Job -Job $sqlJob -Force
                            Remove-Job -Job $sqlJob -Force
                            Write-Warning "Failed to run $sqlCommandName for $serverName - Timeout after 4 minutes"
                        }
                    }
                    catch {
                        Write-Warning "Failed to run $sqlCommandName for $serverName $($_.Exception.Message)"
                    }
                }
                else {
                    Write-Warning "CollectSQLData command not found in any standard location. Search paths: $($sqlCollector.SearchPaths -join ', ')"
                }
            }

            # Check for IIS on port 80 or 443, or via W3SVC service
            # Note: State is stored as an integer (2 = Listen) in the JSON, not the string 'Listen'.
            # All entries in PortDetails are already Listen-state (filtered at collection time),
            # so no State check is needed here.
            Write-Stage "Checking for IIS workload (ports 80/443 or W3SVC service)"
            $iisListening = $data.PortDetails | Where-Object {
                $_.LocalPort -eq 80 -or $_.LocalPort -eq 443
            }
            # Fallback: W3SVC service running means IIS is present even if bound on non-standard ports
            if (-not $iisListening) {
                $iisListening = $data.ServiceDetails | Where-Object {
                    $_.Name -eq 'W3SVC' -and $_.State -eq 'Running'
                }
                if ($iisListening) {
                    Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] IIS detected via W3SVC service (no port 80/443 in PortDetails) on $serverName."
                }
            }
            if ($iisListening) {
                $iisCollector = Resolve-CollectorCommandPath -BaseName 'CollectIISData' -CurrentScriptDirectory $scriptDirectory
                if ($iisCollector.Path) {
                    $iisScriptPath = $iisCollector.Path
                    $iisCommandName = [System.IO.Path]::GetFileName($iisScriptPath)
                    Write-Stage "Collecting IIS details via $iisCommandName"
                    Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] IIS service detected on port 80/443 on $serverName. Running $iisCommandName..."
                    try {
                        $iisParams = @{
                            CheckType = $CheckType
                            ServerName = $serverName
                            OutputPath = $resolvedOutputDir
                        }
                        # Use the same credentials that successfully connected to the server.
                        # Use the same safe extraction as SQL — avoid GetNetworkCredential() which
                        # is unavailable on Deserialized.PSCredential passed through Start-Job.
                        if ($workingCredential) {
                            try {
                                $iisParams['Username'] = [string]$workingCredential.UserName
                                $credPwd = $null
                                try { $credPwd = $workingCredential.GetNetworkCredential().Password } catch { }
                                if (-not $credPwd) {
                                    $credPwd = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
                                        [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR(
                                            $workingCredential.Password))
                                }
                                if ($credPwd) { $iisParams['Password'] = $credPwd }
                                Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Using explicit credentials for IIS data collection on $serverName"
                            } catch {
                                Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Unable to extract credentials for IIS on $serverName — using current user context"
                            }
                        }
                        else {
                            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Using current user context for IIS data collection on $serverName (same as server connection)"
                        }

                        # Run with 4-minute timeout
                        $iisJob = Start-Job -ScriptBlock {
                            param($scriptPath, $params)

                            # Native executables can drop hashtable-splatted args in PS5 jobs.
                            # Build an explicit argument array to preserve every parameter value.
                            $argList = @()
                            foreach ($entry in $params.GetEnumerator()) {
                                if ($null -eq $entry.Value) { continue }
                                $valueText = [string]$entry.Value
                                if ([string]::IsNullOrWhiteSpace($valueText)) { continue }
                                $argList += "-$($entry.Key)"
                                $argList += $valueText
                            }

                            & $scriptPath @argList
                        } -ArgumentList $iisScriptPath, $iisParams

                        $iisJobStart = Get-Date
                        $iisJobTimeoutSeconds = $JobTimeoutSeconds
                        $iisJobPollSeconds = 10
                        $iisJobCompleted = $null
                        do {
                            $elapsed = [int]((Get-Date) - $iisJobStart).TotalSeconds
                            $remaining = $iisJobTimeoutSeconds - $elapsed
                            if ($remaining -le 0) { break }
                            $waitSeconds = [Math]::Min($iisJobPollSeconds, $remaining)
                            $iisJobCompleted = Wait-Job -Job $iisJob -Timeout $waitSeconds
                            if (-not $iisJobCompleted -and $LocalDebug) {
                                Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [local-step] [$ServerName] $iisCommandName still running... ${elapsed}s elapsed (timeout ${iisJobTimeoutSeconds}s)" -ForegroundColor DarkCyan
                            }
                        } while (-not $iisJobCompleted)

                        if ($iisJobCompleted) {
                            $iisResult = Receive-Job -Job $iisJob
                            if ($iisResult) { Write-Output $iisResult }
                            Write-Output "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] IIS data collection completed for $serverName"
                        }
                        else {
                            Stop-Job -Job $iisJob -Force
                            Remove-Job -Job $iisJob -Force
                            Write-Warning "Failed to run $iisCommandName for $serverName - Timeout after 4 minutes"
                        }
                    }
                    catch {
                        Write-Warning "Failed to run $iisCommandName for $serverName $($_.Exception.Message)"
                    }
                }
                else {
                    Write-Warning "CollectIISData command not found in any standard location. Search paths: $($iisCollector.SearchPaths -join ', ')"
                }
            }

            } # end if (-not $ServerOnlyData)



            # Mark ADO Steps as completed
            # Mark the steps for successful connection to the VM
            if ($PersonalAccessToken -and $ProjectName -and $CheckType -eq "Pre_Migration") {
                $formattedDate = Get-CMSUtcMinus5Timestamp
                $accessStatusResult = Set-ADOWindowsAccessStatus -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -HasPowerShellAccess $true -LastBlockerCheckDate $formattedDate
                if ($null -eq $accessStatusResult -or $null -eq $accessStatusResult.AccessChildId) {
                    SubStepCompleted -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -SubStep '''[Pre-02] : Validate access to Source VM''' -StepStatus "Completed"
                }
                #SubStepCompleted -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -SubStep '''[Pre-03] : Request Access if required''' -StepStatus "Not Applicable"
                #SubStepCompleted -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -SubStep '''[Pre-04] : Grant Access to Source VM''' -StepStatus "Not Applicable"
                #SubStepCompleted -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -SubStep '''[Pre-05] : Verify the total disk size of a VM and if >=1 TB''' -StepStatus "Completed"
                if ($ScanIP -eq $True) {
                    SubStepCompleted -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -SubStep '''[Pre-06  ] : Run Pre-migration script with ScanIP Enabled''' -StepStatus "Completed"
                }
                else {
                    SubStepCompleted -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -SubStep '''[Pre-25] : Run Pre-migration script''' -StepStatus "Completed"
                }


                If ($TotalDiskSpace -ge 1TB) {
                    ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Path  '/fields/Custom.TypeofMigration' -Value "Agent-based Migration" -operation 'replace'
                }
                else {
                    ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Path  '/fields/Custom.TypeofMigration' -Value "Agent-less Migration" -operation 'replace'
                }

                if ($data.MigrationChecks.PendingReboot -eq "Failed") {
                    ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Value $True -Path '/fields/Custom.PendingReboot'
                }
                else {
                    ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Value $False -Path '/fields/Custom.PendingReboot'
                }

                if ($data.MigrationChecks.PendingUpdates -eq "Failed") {
                    ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Value $True -Path '/fields/Custom.PatchAvailable'
                }
                else {
                    ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Value $False -Path '/fields/Custom.PatchAvailable'


                }


                if ($data.MigrationChecks.PowerShellVersion -eq "Failed") {
                    ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Value $True -Path '/fields/Custom.PowerShellVersion'
                }
                else {
                    ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Value $False -Path '/fields/Custom.PowerShellVersion'

                }
                try {
                    if ([string]::IsNullOrWhiteSpace($OrganizationName) -or
                        [string]::IsNullOrWhiteSpace($ProjectName) -or
                        [string]::IsNullOrWhiteSpace($PersonalAccessToken)) {
                        Write-Warning "Skipping ADO updates: missing OrganizationName, ProjectName, or PersonalAccessToken."
                    }
                    else {
                        $workItemId = $null
                        try {
                            $workItemId = Get-WorkItemID -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -Title $ServerName
                        }
                        catch {
                            Write-Warning "Failed to resolve Work Item for $ServerName : $($_.Exception.Message)"
                        }

                        if ($null -eq $workItemId) {
                            Write-Warning "Work item not found for '$ServerName'. Skipping ADO updates."
                        }
                        else {
                            try {
                                ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Path '/fields/Custom.LastBlockerCheckDate' -Value $formattedDate -Operation 'replace'
                            }
                            catch {
                                Write-Warning "Failed to update LastBlockerCheckDate for $ServerName : $($_.Exception.Message)"
                            }

                            try {
                                $historyMsg = "Migration Check Script was ran on: " + (Get-Date -Format "MM/dd/yyyy HH:mm:ss")
                                ADO-MarkObject -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $ServerName -Path '/fields/System.History' -Value $historyMsg -Operation 'add'
                            }
                            catch {
                                Write-Warning "Failed to append history for $ServerName : $($_.Exception.Message)"
                            }

                            try {
                                Update-ADOServerBlockerSummary -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -WorkItemId ([int]$workItemId) | Out-Null
                            }
                            catch {
                                Write-Warning "Failed to synchronize blocker summary for $ServerName : $($_.Exception.Message)"
                            }
                        }
                    }
                }
                catch {
                    Write-Warning "Unexpected error during ADO updates: $($_.Exception.Message)"
                }

            }



            # return a PSCustomObject so $results collects it
            [PSCustomObject]@{
                Server = $serverName
                Result = $data
                Error  = $null
                HtmlGeneration = $htmlGenerationInfo
            }
        }
        catch {
            $errorMessage = $_.Exception.Message
            Write-Error "$ts Failed remote $serverName : $errorMessage"

            if ($PersonalAccessToken -and $ProjectName -and $CheckType -eq 'Pre_Migration' -and (Test-IsPowerShellAccessFailure -ErrorMessage $errorMessage)) {
                try {
                    Set-ADOWindowsAccessStatus -OrganizationName $OrganizationName -ProjectName $ProjectName -PersonalAccessToken $PersonalAccessToken -ServerName $serverName -HasPowerShellAccess $false | Out-Null
                }
                catch {
                    Write-Warning "Failed to update ADO access blocker for $serverName : $($_.Exception.Message)"
                }
            }

            # Provide specific guidance for common authentication errors
            if ($errorMessage -match "access denied|authentication|kerberos|negotiate" -and !$credential) {
                Write-Output ""
                Write-Output "AUTHENTICATION ERROR DETECTED:"
                Write-Output "The target server requires explicit credentials for remote access."
                Write-Output ""
                Write-Output "To fix this issue, re-run the script with the -UseCredential switch:"
                Write-Output "  .\MigrationCheck.ps1 -CheckType $CheckType -UseCredential"
                Write-Output ""
                Write-Output "Or provide credentials via parameters:"
                Write-Output "  `$securePassword = ConvertTo-SecureString 'YourPassword' -AsPlainText -Force"
                Write-Output "  .\MigrationCheck.ps1 -CheckType $CheckType -UseCredential -Username 'domain\user' -Password `$securePassword"
                Write-Output ""
            }

            [PSCustomObject]@{
                Server = $serverName
                Result = $null
                Error  = $_.Exception.Message
            }
        }
} # end $serverScanScriptBlock
# ---------------------------------------------------------------------------
# HTML generation helper
# Called for both local (inline) and remote (job) results so the same report
# generation logic runs regardless of which execution path was taken.
# ---------------------------------------------------------------------------
function Invoke-MigrationHtmlGeneration {
    param([PSCustomObject]$jobResult)
    if ($null -eq $jobResult) { return }
    if (-not ($jobResult.Result -and $null -eq $jobResult.Error -and $jobResult.HtmlGeneration)) { return }

    $htmlInfo    = $jobResult.HtmlGeneration
    $jsonFilePath = $htmlInfo.JsonFilePath
    if ($jsonFilePath -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
        $jsonFilePath = $jsonFilePath -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
    }
    $jsonFilePath = $jsonFilePath.Trim().Trim("'").Trim('"')
    $srvName = $htmlInfo.ServerName

    if (-not ($jsonFilePath -and (Test-Path $jsonFilePath))) { return }

    $script:generatedJsonFiles += $jsonFilePath

    try {
        $scriptsDir = Split-Path $OutputDir -Parent
        $htmlGeneratorPath = Join-Path $scriptsDir "Scripts\MigrationCheck-HtmlGenerator.ps1"
        if (-not (Test-Path $htmlGeneratorPath)) {
            $htmlGeneratorPath = Join-Path (Get-Location).Path "MigrationCheck-HtmlGenerator.ps1"
        }
        if (-not (Test-Path $htmlGeneratorPath)) {
            $currentScriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path $MyInvocation.MyCommand.Path -Parent }
            $htmlGeneratorPath = Join-Path $currentScriptDir "MigrationCheck-HtmlGenerator.ps1"
        }
        if ($htmlGeneratorPath -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
            $htmlGeneratorPath = $htmlGeneratorPath -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
        }

        if (Test-Path $htmlGeneratorPath) {
            Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Generating HTML report for $srvName..." -ForegroundColor Cyan
            try {
                & "$htmlGeneratorPath" -JsonFilePath "$jsonFilePath"
                $CompareScript = $htmlGeneratorPath -replace 'MigrationCheck-HtmlGenerator', 'MigrationCheck-CompareJSON'
                $htmlFilePath = $jsonFilePath -replace '\.json$', '.html'
                if (Test-Path $htmlFilePath) {
                    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] HTML report generated successfully for $srvName" -ForegroundColor Green
                    $script:generatedHtmlFiles += $htmlFilePath
                    $script:htmlGenerationCount++
                }
                else {
                    Write-Warning "HTML file not found after generation for $srvName"
                    $script:htmlGenerationFailed++
                }
                & $CompareScript -ParentDirectory (Split-Path $jsonFilePath -Parent)

                # EventLog report - skip when event log collection was disabled (SkipEventLog / light check)
                if (-not $SkipEventLog) {
                    # Avoid duplicates, use base name without ScanIP suffix
                    $eventLogGeneratorPath = $htmlGeneratorPath -replace 'HtmlGenerator', 'EventLog-JsonToHTML'
                    # Create EventLog filename without ScanIP suffix for consistency
                    $baseJsonPath = $jsonFilePath -replace '_ScanIP', ''
                    $eventLogReportCandidates = @(
                        ($baseJsonPath -replace '\.json$', '_EventLog_Report.html'),
                        ($baseJsonPath -replace '\.json$', '_EventLogs.html')
                    )

                    if (Test-Path $eventLogGeneratorPath) {
                        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Generating EventLog HTML report for $srvName..." -ForegroundColor Cyan
                        try {
                            & "$eventLogGeneratorPath" -JsonFilePath "$jsonFilePath" -OutputPath "$($eventLogReportCandidates[0])"
                        }
                        catch {
                            Write-Warning "EventLog HTML generator failed for $srvName`: $($_.Exception.Message)"
                        }
                    }
                    $resolvedEventLogReport = $eventLogReportCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
                    if ($resolvedEventLogReport) {
                        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] EventLog HTML report available for $srvName : $resolvedEventLogReport" -ForegroundColor Green
                        $script:generatedHtmlFiles += $resolvedEventLogReport
                        $script:htmlGenerationCount++
                    }
                }
                else {
                    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] EventLog HTML report skipped for $srvName (SkipEventLog is set)" -ForegroundColor DarkGray
                }
            }
            catch {
                Write-Warning "HTML generator failed for $srvName`: $($_.Exception.Message)"
                Write-Host "Manual command to generate HTML: & `"$htmlGeneratorPath`" -JsonFilePath `"$jsonFilePath`"" -ForegroundColor Yellow
                $script:htmlGenerationFailed++
            }
        }
        else {
            Write-Warning "MigrationCheck-HtmlGenerator.ps1 not found at $htmlGeneratorPath. Skipping HTML generation for $srvName."
            $script:htmlGenerationFailed++
        }
    }
    catch {
        Write-Warning "Failed to generate HTML report for ${srvName}: $($_.Exception.Message)"
        $script:htmlGenerationFailed++
    }
}

# Initialize tracking for generated files (must be before local and remote scans)
$htmlGenerationCount = 0
$htmlGenerationFailed = 0
$generatedJsonFiles = @()
$generatedHtmlFiles = @()

foreach ($ServerName in $targetServers) {
    # Detect whether this is the local machine.  If so, run the scan directly in the
    # current thread so error messages and progress output are visible in real-time.
    $serverNorm  = $ServerName.Trim().TrimEnd('.')
    $serverShort = if ($serverNorm -match '\.') { $serverNorm.Split('.')[0] } else { $serverNorm }
    $isLocalServer = (
        $RunLocally -or
        $serverNorm  -ieq 'localhost' -or
        $serverShort -ieq 'localhost' -or
        $serverNorm  -ieq $MyHostName -or
        $serverShort -ieq $MyHostName -or
        $serverNorm  -ieq $env:COMPUTERNAME -or
        $serverShort -ieq $env:COMPUTERNAME
    )

    if ($isLocalServer) {
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Running scan locally on $ServerName (current thread - no background job)..." -ForegroundColor Yellow
        # Invoke the script block directly.  Write-Output messages (progress logging) are
        # piped to Write-Host so they are displayed in real-time.  The final PSCustomObject
        # result (which has a 'Server' property) is captured for HTML generation and tracking.
        $localJobResult = $null
        & $serverScanScriptBlock $ServerName $CheckType $ScanIP $ScanIPPath $ScriptVersion $OutputDir $credential $PersonalAccessToken $ProjectName $OrganizationName $scriptDirectory ([bool]$SkipEventLog) $EventLogMaxEvents ([bool]$ServerOnlyData) ([bool]$preferCurrentUserFirst) | ForEach-Object {
            if ($_ -is [PSCustomObject] -and $null -ne ($_.PSObject.Properties['Server'])) {
                $localJobResult = $_
            }
            else {
                Write-Host $_
            }
        }
        if ($localJobResult) { $results += $localJobResult }
        Invoke-MigrationHtmlGeneration -jobResult $localJobResult
    }
    else {
        # Remote server: use a background job for parallel execution
        while ((@($jobs | Where-Object { $_ -and $_.State -eq 'Running' }).Count) -ge $MaxThreads) {
            Start-Sleep -Seconds 1
        }
        $job = Start-Job -ScriptBlock $serverScanScriptBlock -ArgumentList $ServerName, $CheckType, $ScanIP, $ScanIPPath, $ScriptVersion, $OutputDir, $credential, $PersonalAccessToken, $ProjectName, $OrganizationName, $scriptDirectory, ([bool]$SkipEventLog), $EventLogMaxEvents, ([bool]$ServerOnlyData), ([bool]$preferCurrentUserFirst)
        $jobs += $job
        $jobToServer[$job.Id] = $ServerName
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Started job $($job.Id) for server: $ServerName" -ForegroundColor Cyan
    }
}

# Wait for all remote jobs to complete and collect results
# (Local servers were already processed synchronously above)
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Waiting for all remote jobs to complete..." -ForegroundColor Yellow

if ($jobs.Count -gt 0) {
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Starting to collect results from $($jobs.Count) remote job(s)..." -ForegroundColor Cyan
}

foreach ($job in $jobs) {
    if (-not $job) { continue }

    # Add timeout to prevent infinite wait - default is 10 minutes per job
    $jobTimeout = 600  # 10 minutes per job
    $jobID   = $job.Id
    $jobName = $job.Name
    $serverLabel = if ($jobToServer.ContainsKey($jobID)) { $jobToServer[$jobID] } else { 'unknown-server' }
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Waiting for server $serverLabel (job $jobID, $jobName) with timeout of $($jobTimeout)s..." -ForegroundColor DarkGray

    $jobCompleted = Wait-Job -Job $job -Timeout $jobTimeout

    if ($jobCompleted) {
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Job $jobID ($jobName) completed successfully." -ForegroundColor Green
        $jobRawOutput = @(Receive-Job -Job $job)
        $jobResult = $null
        foreach ($item in $jobRawOutput) {
            if ($item -is [string]) {
                # Print all job log messages so connection errors etc. are visible
                Write-Host $item
            } elseif ($item -is [System.Management.Automation.PSCustomObject] -and $item.PSObject.Properties['Server']) {
                $jobResult = $item
            }
            $results += $item
        }
    }
    else {
        # Job timed out - stop and remove it gracefully
        Write-Error "Job $jobID ($jobName) exceeded timeout of $($jobTimeout) seconds. Forcefully terminating..."
        try { Stop-Job -Job $job -ErrorAction SilentlyContinue } catch { }
        try { Remove-Job -Job $job -Force -ErrorAction SilentlyContinue } catch { }
        Write-Warning "Job $jobID ($jobName) terminated due to timeout. Skipping HTML generation for this server."
        continue
    }

    if ($jobResult) {
        Invoke-MigrationHtmlGeneration -jobResult $jobResult
    }

    try { Remove-Job $job -ErrorAction SilentlyContinue } catch { }
}

Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] All jobs completed." -ForegroundColor Green

# --- PROCESS RESULTS AND GENERATE REPORTS ---
# Filter results to only count actual server response objects (not intermediate Write-Output messages)
$serverResults = $results | Where-Object {
    ($_.Server) -or ($_.Result -and $_.Result.SystemOverview -and $_.Result.SystemOverview.ServerName)
}
write-host "Processing results and generating reports...  $($serverResults.Count) Items of $($targetServers.Count)" -ForegroundColor Green
$Success = @()
$Failure = @()
$FailureErrors = @{}

# Process results: normalize server names and skip any empty entries to avoid blanks in reports
foreach ($entry in $serverResults) {
    # Determine server name from result object; fall back to Result.SystemOverview.ServerName if available
    $name = $null
    if ($entry.Server) { $name = $entry.Server }
    elseif ($entry.Result -and $entry.Result.SystemOverview -and $entry.Result.SystemOverview.ServerName) { $name = $entry.Result.SystemOverview.ServerName }

    if ($name) { $name = $name.ToString().Trim() }

    # If still empty, skip this entry entirely (prevents blank lines being counted as failures)
    if ([string]::IsNullOrWhiteSpace($name)) { continue }

    # Normalize to hostname only (strip domain if present)
    if ($name -match '\.') { $name = $name.Split('.')[0] }

    if ($entry.Result -and $null -eq $entry.Error) {
        $Success += $name
    }
    else {
        $Failure += $name
        $FailureErrors[$name] = if ($entry.Error) { [string]$entry.Error } else { 'Unknown error' }
    }
}



# Update success count for reporting
$SuccessCount = $Success.Count
$serverListDir = Join-Path $OutputDir "..\ServerList"
if (!(Test-Path $serverListDir)) {
    New-Item -Path $serverListDir -ItemType Directory -Force | Out-Null
}
# Write out the servers that were successful and those that failed
if ($Success.Count -gt 0) {
    # Write the list of successful servers to a CSV file with a timestamp
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $($Success.Count) Successful servers:" -ForegroundColor Green
    $Success | ForEach-Object { Write-Host $_ -ForegroundColor Green }
    $successCsvFileName = "Successful_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".csv"
    $successCsvPath = Join-Path $serverListDir $successCsvFileName
    $Success | ForEach-Object { [PSCustomObject]@{ ServerName = $_ } } | Export-Csv -Path $successCsvPath -NoTypeInformation -Encoding UTF8
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Successful server list written to: $successCsvPath" -ForegroundColor Green

}
else {
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] No successful servers." -ForegroundColor Yellow
}

if ($Failure.Count -gt 0) {
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $($Failure.Count) Failed servers:" -ForegroundColor Red
    $Failure | ForEach-Object {
        $errDetail = $FailureErrors[$_]
        Write-Host "  $_ — $errDetail" -ForegroundColor Red
    }
    # Write the list of failed servers to a CSV file with a timestamp
    # Ensure the ServerList directory exists

    $failedCsvFileName = "Failed_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".csv"
    $failedCsvPath = Join-Path $serverListDir $failedCsvFileName
    $Failure | ForEach-Object { [PSCustomObject]@{ ServerName = $_ } } | Export-Csv -Path $failedCsvPath -NoTypeInformation -Encoding UTF8
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Failed server list written to: $failedCsvPath" -ForegroundColor Yellow
}
else {
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] No failed servers." -ForegroundColor Green
}

# ─── CONSOLIDATED FILE GENERATION SUMMARY TABLE ───
# Scan each server's output directory from the filesystem so every file type is
# captured regardless of whether it was generated locally or in a background job.

$suffix = $CheckType
$resolvedOutputDirSummary = if ([string]::IsNullOrWhiteSpace($OutputDir)) { "C:\Avanade\$env:USERNAME" } else { $OutputDir }
if ($resolvedOutputDirSummary -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
    $resolvedOutputDirSummary = $resolvedOutputDirSummary -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
}
$resolvedOutputDirSummary = $resolvedOutputDirSummary.Trim().Trim("'").Trim('"')

# Build a per-server row by probing for known output files
$allServerNames = @($Success) + @($Failure) | Sort-Object -Unique
$fileSummaryRows = @()
$totalCounts = [ordered]@{
    MigrationJSON    = 0
    MigrationHTML    = 0
    EventLogHTML     = 0
    HardcodedIPsHTML = 0
    SQLJSON          = 0
    IISJSON          = 0
}

foreach ($srv in $allServerNames) {
    $srvDir = Join-Path $resolvedOutputDirSummary $srv
    $srvSuffix = "${srv}_${suffix}"
    $checkShort = ($CheckType -split '_')[0]   # Pre, Post, Test

    # Determine expected file paths
    $migJson          = Join-Path $srvDir "$srvSuffix.json"
    $migHtml          = Join-Path $srvDir "$srvSuffix.html"
    # EventLog report uses base name without ScanIP suffix for consistency
    $baseSuffix       = "${srv}_${CheckType}"
    $evtLogHtml       = Join-Path $srvDir "${baseSuffix}_EventLog_Report.html"
    $hardcodedIPsHtml = Join-Path $srvDir "${srv}_${checkShort}_HardcodedIPs.html"
    $sqlJson          = Join-Path $srvDir "${srv}_${checkShort}_SQL_Config.json"
    $iisJson          = Join-Path $srvDir "${srv}_${checkShort}_IIS_Config.json"

    $migJsonOk          = if (Test-Path $migJson)          { $true } else { $false }
    $migHtmlOk          = if (Test-Path $migHtml)          { $true } else { $false }
    $evtLogHtmlOk       = if (Test-Path $evtLogHtml)       { $true } else { $false }
    $hardcodedIPsHtmlOk = if (Test-Path $hardcodedIPsHtml) { $true } else { $false }
    $sqlJsonOk          = if (Test-Path $sqlJson)          { $true } else { $false }
    $iisJsonOk          = if (Test-Path $iisJson)          { $true } else { $false }

    if ($migJsonOk)          { $totalCounts.MigrationJSON++ }
    if ($migHtmlOk)          { $totalCounts.MigrationHTML++ }
    if ($evtLogHtmlOk)       { $totalCounts.EventLogHTML++ }
    if ($hardcodedIPsHtmlOk) { $totalCounts.HardcodedIPsHTML++ }
    if ($sqlJsonOk)          { $totalCounts.SQLJSON++ }
    if ($iisJsonOk)          { $totalCounts.IISJSON++ }

    $status = if ($Success -contains $srv) { 'Success' } else { 'FAILED' }

    $fileSummaryRows += [PSCustomObject]@{
        Server               = $srv
        Status               = $status
        'Migration JSON'     = if ($migJsonOk)          { 'YES' } else { '-' }
        'Migration HTML'     = if ($migHtmlOk)          { 'YES' } else { '-' }
        'EventLog HTML'      = if ($evtLogHtmlOk)       { 'YES' } else { '-' }
        "Hardcoded IP's"     = if ($hardcodedIPsHtmlOk) { 'YES' } else { '-' }
        'SQL JSON'           = if ($sqlJsonOk)          { 'YES' } else { '-' }
        'IIS JSON'           = if ($iisJsonOk)          { 'YES' } else { '-' }
    }
}

# Print the table
Write-Host ""
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ╔══════════════════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ║                     FILE GENERATION SUMMARY                                    ║" -ForegroundColor Cyan
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ╚══════════════════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan

if ($fileSummaryRows.Count -gt 0) {
    # Calculate column widths dynamically
    $colServer = [Math]::Max(8, ($allServerNames | ForEach-Object { $_.Length } | Measure-Object -Maximum).Maximum + 2)
    $colStatus = 8
    $colFile   = 16

    $headerFmt = "{0,-$colServer} {1,-$colStatus} {2,-$colFile} {3,-$colFile} {4,-$colFile} {5,-$colFile} {6,-$colFile} {7,-$colFile}"
    $header    = $headerFmt -f 'Server', 'Status', 'Migration JSON', 'Migration HTML', 'EventLog HTML', "Hardcoded IP's", 'SQL JSON', 'IIS JSON'
    $divider   = '-' * $header.Length

    Write-Host ""
    Write-Host $header -ForegroundColor White
    Write-Host $divider -ForegroundColor DarkGray

    foreach ($row in $fileSummaryRows) {
        $line = $headerFmt -f $row.Server, $row.Status, $row.'Migration JSON', $row.'Migration HTML', $row.'EventLog HTML', $row."Hardcoded IP's", $row.'SQL JSON', $row.'IIS JSON'
        $lineColor = if ($row.Status -eq 'FAILED') { 'Red' } else { 'Green' }
        Write-Host $line -ForegroundColor $lineColor
    }

    Write-Host $divider -ForegroundColor DarkGray

    # Totals row
    $totalsLine = $headerFmt -f 'TOTAL', '', "$($totalCounts.MigrationJSON)/$($allServerNames.Count)", "$($totalCounts.MigrationHTML)/$($allServerNames.Count)", "$($totalCounts.EventLogHTML)/$($allServerNames.Count)", "$($totalCounts.HardcodedIPsHTML)/$($allServerNames.Count)", "$($totalCounts.SQLJSON)/$($allServerNames.Count)", "$($totalCounts.IISJSON)/$($allServerNames.Count)"
    Write-Host $totalsLine -ForegroundColor Yellow
    Write-Host ""
}
else {
    Write-Host "  No servers were processed." -ForegroundColor Yellow
}

# Overall result line
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Servers: $($Success.Count) succeeded, $($Failure.Count) failed out of $($targetServers.Count) total" -ForegroundColor $(if ($Failure.Count -gt 0) { 'Yellow' } else { 'Green' })
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Files generated: $($totalCounts.MigrationJSON) JSON | $($totalCounts.MigrationHTML) HTML | $($totalCounts.EventLogHTML) EventLog | $($totalCounts.HardcodedIPsHTML) HardcodedIPs | $($totalCounts.SQLJSON) SQL | $($totalCounts.IISJSON) IIS" -ForegroundColor Cyan
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Output directory: $resolvedOutputDirSummary" -ForegroundColor Cyan
Write-Host ""

# Stop transcript using standardized function if available
if (Get-Command -Name Stop-TranscriptLogging -ErrorAction SilentlyContinue) {
    Stop-TranscriptLogging -TranscriptPath $transcriptPath
} else {
    # Fallback for standalone execution
    try { Stop-Transcript -ErrorAction SilentlyContinue } catch { }
}
