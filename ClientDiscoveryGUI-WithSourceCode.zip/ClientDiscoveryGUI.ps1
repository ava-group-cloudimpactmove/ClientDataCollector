﻿<#
.SYNOPSIS
    Avanade Cloud Impact MOVE - Client Discovery GUI - portable data collector front-end.

.DESCRIPTION
    Provides a guided WinForms interface for loading a server list CSV,
    configuring collection options, managing encrypted credentials, and
    launching ServerDataCollector.ps1 in a visible terminal window.

    JSON outputs plus client-facing HTML artifact reporting.

.NOTES
    Author  : Avanade Migration Team
    Version : 26.07.04
#>

$ScriptVersion = '26.07.06'
$GUITitle = "Avanade Cloud Impact MOVE - Client Discovery v$ScriptVersion"

$script:ClientDiscoveryProcessPath = $null
try {
    $script:ClientDiscoveryProcessPath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
}
catch {
    $script:ClientDiscoveryProcessPath = $null
}

$script:IsCompiledExeHost = $false
if (-not [string]::IsNullOrWhiteSpace([string]$script:ClientDiscoveryProcessPath)) {
    $processExtension = [System.IO.Path]::GetExtension([string]$script:ClientDiscoveryProcessPath)
    $processName = [System.IO.Path]::GetFileNameWithoutExtension([string]$script:ClientDiscoveryProcessPath)
    if ($processExtension -ieq '.exe' -and ($processName -notmatch '^(?i)(pwsh|powershell|powershell_ise)$')) {
        $script:IsCompiledExeHost = $true
    }
}

# ── GUI session log (written to OutputDir\Logs\ when a command is launched) ───
function Write-GuiLog {
    param([string]$Message, [string]$Level = 'INFO')
    $outDir = $txtOutputDir.Text.Trim()
    if (-not $outDir) { return }
    try {
        $logDir = Join-Path $outDir 'Logs'
        if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
        $logFile = Join-Path $logDir ("ClientDiscovery-GUI-{0}.log" -f (Get-Date -Format 'yyyyMMdd'))
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        Add-Content -Path $logFile -Value "[$ts] [$Level] $Message" -ErrorAction SilentlyContinue
    }
    catch { }
}

function Write-GuiLaunch {
    param([string]$Label, [string]$ArgString)
    Write-GuiLog "LAUNCH [$Label] $ArgString"
    Write-GuiLog "  User: $env:USERNAME  |  Machine: $env:COMPUTERNAME  |  GUI: v$ScriptVersion"
}

# ── PowerShell host resolution ───────────────────────────────────────────────
# Client packages are EXE-first and must not require PowerShell 7 on operator VMs.
# Use the current host for script-backed development runs, then fall back to any
# installed PowerShell host. Compiled child EXEs are launched directly.
function Resolve-AvailablePowerShellHost {
    $windowsPowerShell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'

    try {
        $processPath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        if (-not [string]::IsNullOrWhiteSpace([string]$processPath) -and (Test-Path -LiteralPath $processPath -PathType Leaf)) {
            $processName = [System.IO.Path]::GetFileNameWithoutExtension($processPath)
            if ($processName -match '^(?i)(powershell|powershell_ise)$') {
                return $processPath
            }
        }
    }
    catch {
    }

    if (Test-Path -LiteralPath $windowsPowerShell -PathType Leaf) { return $windowsPowerShell }

    $cmd = Get-Command 'powershell' -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Path) { return $cmd.Path }

    return 'powershell.exe'
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Security

[System.Windows.Forms.Application]::EnableVisualStyles()

# ── Script root resolution (works as .ps1 and compiled .exe) ─────────────────
$ScriptRoot = if ($script:IsCompiledExeHost -and $script:ClientDiscoveryProcessPath -and (Test-Path -LiteralPath $script:ClientDiscoveryProcessPath)) {
    Split-Path -Parent $script:ClientDiscoveryProcessPath
}
elseif ($PSCommandPath -and (Test-Path -LiteralPath $PSCommandPath)) {
    Split-Path -Parent $PSCommandPath
}
elseif ($MyInvocation -and $MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path -and (Test-Path -LiteralPath $MyInvocation.MyCommand.Path)) {
    Split-Path -Parent $MyInvocation.MyCommand.Path
}
else {
    (Get-Location).Path
}
$ScriptsDir = Join-Path $ScriptRoot 'Scripts'
$SettingsFile = Join-Path $ScriptRoot 'settings.json'
$SampleCsvPath = Join-Path $ScriptRoot 'serverlist-sample.csv'

function Normalize-NativePath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace([string]$Path)) { return $Path }
    $normalized = $Path.Trim().Trim('"').Trim("'")
    if ($normalized -match '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::') {
        $normalized = $normalized -replace '^(?i)Microsoft\.PowerShell\.Core\\FileSystem::', ''
    }
    return $normalized
}

function Convert-ToLaunchRelativePath {
    param([string]$TargetPath)

    $nativeTarget = Normalize-NativePath -Path $TargetPath
    if (-not $script:IsCompiledExeHost -or [string]::IsNullOrWhiteSpace([string]$nativeTarget)) {
        return $nativeTarget
    }

    try {
        $baseFull = [System.IO.Path]::GetFullPath((Normalize-NativePath -Path $ScriptRoot))
        $targetFull = [System.IO.Path]::GetFullPath($nativeTarget)
        $relative = [System.IO.Path]::GetRelativePath($baseFull, $targetFull)
        if ([string]::IsNullOrWhiteSpace([string]$relative)) {
            return '.\\' + [System.IO.Path]::GetFileName($targetFull)
        }
        if (-not ($relative.StartsWith('.\\') -or $relative.StartsWith('..\\'))) {
            $relative = '.\\' + $relative
        }
        return $relative
    }
    catch {
        return $nativeTarget
    }
}

$script:PowerShellHostPath = Resolve-AvailablePowerShellHost

# ── ToolTip provider (shared across all controls) ─────────────────────────────
$toolTip = New-Object System.Windows.Forms.ToolTip
$toolTip.AutoPopDelay = 8000
$toolTip.InitialDelay = 400
$toolTip.ReshowDelay = 200

# ── Colours & fonts ───────────────────────────────────────────────────────────
$clrBackground = [System.Drawing.Color]::FromArgb(255, 255, 255)
$clrSurface = [System.Drawing.Color]::FromArgb(255, 255, 255)
$clrSurfaceAlt = [System.Drawing.Color]::FromArgb(248, 249, 251)
$clrBorder = [System.Drawing.Color]::FromArgb(211, 216, 224)
$clrAccent = [System.Drawing.Color]::FromArgb(255, 102, 0)
$clrAccentDark = [System.Drawing.Color]::FromArgb(204, 82, 0)
$clrAccentLight = [System.Drawing.Color]::FromArgb(255, 179, 128)
$clrNavy = [System.Drawing.Color]::FromArgb(30, 36, 48)
$clrSky = [System.Drawing.Color]::FromArgb(139, 63, 153)
$clrText = [System.Drawing.Color]::FromArgb(30, 36, 48)
$clrMuted = [System.Drawing.Color]::FromArgb(96, 105, 120)
$clrSuccess = [System.Drawing.Color]::FromArgb(34, 134, 58)
$clrWarning = [System.Drawing.Color]::FromArgb(255, 243, 224)
$clrDanger = [System.Drawing.Color]::FromArgb(214, 66, 66)

$fontBase = New-Object System.Drawing.Font('Segoe UI', 9)
$fontSmall = New-Object System.Drawing.Font('Segoe UI', 8)
$fontBold = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$fontH2 = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
$fontHero = New-Object System.Drawing.Font('Segoe UI', 20, [System.Drawing.FontStyle]::Bold)
$fontKpi = New-Object System.Drawing.Font('Segoe UI', 18, [System.Drawing.FontStyle]::Bold)
$fontSection = New-Object System.Drawing.Font('Segoe UI Semibold', 10)

# ── Helper factories ──────────────────────────────────────────────────────────
function New-Label {
    param($Text, $X, $Y, [switch]$Bold)
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Text
    $l.Location = New-Object System.Drawing.Point($X, $Y)
    $l.AutoSize = $true
    $l.Font = if ($Bold) { $fontBold } else { $fontBase }
    $l.ForeColor = $clrText
    return $l
}

function New-TextBox {
    param($X, $Y, $W = 300, [switch]$Password)
    $t = New-Object System.Windows.Forms.TextBox
    $t.Location = New-Object System.Drawing.Point($X, $Y)
    $t.Size = New-Object System.Drawing.Size($W, 22)
    $t.Font = $fontBase
    $t.BackColor = $clrSurface
    $t.ForeColor = $clrText
    $t.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    if ($Password) { $t.UseSystemPasswordChar = $true }
    return $t
}

function Set-ButtonStyle {
    param($Button, [switch]$Primary)
    $Button.FlatStyle = 'Flat'
    $Button.FlatAppearance.BorderSize = 1
    $Button.Cursor = [System.Windows.Forms.Cursors]::Hand
    $Button.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    if ($Primary) {
        $Button.BackColor = $clrAccent
        $Button.ForeColor = [System.Drawing.Color]::White
        $Button.Font = $fontBold
        $Button.FlatAppearance.BorderColor = $clrAccentDark
        $Button.FlatAppearance.MouseOverBackColor = $clrAccentDark
        $Button.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(179, 71, 0)
    }
    else {
        $Button.BackColor = $clrSurface
        $Button.ForeColor = $clrText
        $Button.Font = $fontBase
        $Button.FlatAppearance.BorderColor = $clrBorder
        $Button.FlatAppearance.MouseOverBackColor = $clrSurfaceAlt
        $Button.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(238, 241, 245)
    }

    $Button.Add_EnabledChanged({
            param($s, $e)
            if ($s.Enabled) {
                if ($Primary) {
                    $s.BackColor = $clrAccent
                    $s.ForeColor = [System.Drawing.Color]::White
                    $s.FlatAppearance.BorderColor = $clrAccentDark
                }
                else {
                    $s.BackColor = $clrSurface
                    $s.ForeColor = $clrText
                    $s.FlatAppearance.BorderColor = $clrBorder
                }
            }
            else {
                $s.BackColor = [System.Drawing.Color]::FromArgb(230, 232, 237)
                $s.ForeColor = [System.Drawing.Color]::FromArgb(154, 163, 178)
                $s.FlatAppearance.BorderColor = $clrBorder
            }
        })

    if (-not $Primary) {
        $Button.Add_MouseEnter({
                param($s, $e)
                if ($s.Enabled) {
                    $s.FlatAppearance.BorderColor = $clrAccent
                }
            })
        $Button.Add_MouseLeave({
                param($s, $e)
                if ($s.Enabled) {
                    $s.FlatAppearance.BorderColor = $clrBorder
                }
            })
    }
}

function Set-PanelBorder {
    param($Panel)
    $Panel.Add_Paint({
            param($s, $e)
            $rect = New-Object System.Drawing.Rectangle(0, 0, ($s.Width - 1), ($s.Height - 1))
            $pen = [System.Drawing.Pen]::new([System.Drawing.Color]$clrBorder)
            try { $e.Graphics.DrawRectangle($pen, $rect) } finally { $pen.Dispose() }
        })
}

function Add-AccentStrip {
    param($Panel, [System.Drawing.Color]$Color = $clrAccent)
    $strip = New-Object System.Windows.Forms.Panel
    $strip.Dock = 'Left'
    $strip.Width = 5
    $strip.BackColor = $Color
    $Panel.Controls.Add($strip)
    $strip.BringToFront()
    return $strip
}

function Set-TabControlBranding {
    param($TabControl)
    $TabControl.DrawMode = [System.Windows.Forms.TabDrawMode]::OwnerDrawFixed
    $TabControl.SizeMode = [System.Windows.Forms.TabSizeMode]::Fixed
    $TabControl.ItemSize = New-Object System.Drawing.Size(172, 30)
    $TabControl.Padding = New-Object System.Drawing.Point(14, 4)
    $TabControl.BackColor = $clrSurfaceAlt

    $TabControl.Add_DrawItem({
            param($s, $e)
            if ($e.Index -lt 0 -or $e.Index -ge $s.TabPages.Count) { return }

            $tabPage = $s.TabPages[$e.Index]
            $isSelected = ($s.SelectedIndex -eq $e.Index)
            $bounds = $e.Bounds

            $fillColor = if ($isSelected) { $clrSky } else { $clrSurfaceAlt }
            $textColor = if ($isSelected) { [System.Drawing.Color]::White } else { $clrText }
            $borderColor = [System.Drawing.Color]::FromArgb(110, 46, 121)

            $bgBrush = New-Object System.Drawing.SolidBrush($fillColor)
            $borderPen = New-Object System.Drawing.Pen($borderColor)
            $textBrush = New-Object System.Drawing.SolidBrush($textColor)
            $format = New-Object System.Drawing.StringFormat
            $format.Alignment = [System.Drawing.StringAlignment]::Center
            $format.LineAlignment = [System.Drawing.StringAlignment]::Center

            try {
                $e.Graphics.FillRectangle($bgBrush, $bounds)
                if ($isSelected) {
                    $e.Graphics.DrawRectangle($borderPen, ($bounds.X + 1), ($bounds.Y + 1), ($bounds.Width - 2), ($bounds.Height - 2))
                }
                $rectF = New-Object System.Drawing.RectangleF([single]$bounds.X, [single]$bounds.Y, [single]$bounds.Width, [single]$bounds.Height)
                $e.Graphics.DrawString($tabPage.Text, $fontBase, $textBrush, $rectF, $format)
            }
            finally {
                $bgBrush.Dispose()
                $borderPen.Dispose()
                $textBrush.Dispose()
                $format.Dispose()
            }
        })
}

function Set-GroupBoxStyle {
    param(
        $GroupBox,
        [System.Drawing.Color]$AccentColor = $clrAccent
    )

    $GroupBox.BackColor = $clrSurface
    $GroupBox.ForeColor = $clrText
    $GroupBox.Font = $fontBold

    $resolvedAccentColor = if ($AccentColor -and $AccentColor -ne [System.Drawing.Color]::Empty) {
        $AccentColor
    }
    else {
        $clrAccent
    }

    $GroupBox.Add_Paint({
            param($s, $e)
            $e.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias

            $titleSize = $e.Graphics.MeasureString($s.Text, $s.Font)
            $titleWidth = [int][Math]::Ceiling($titleSize.Width)

            $borderPen = $null
            $accentPen = $null
            try {
                $borderPen = [System.Drawing.Pen]::new([System.Drawing.Color]$clrBorder)
                $accentPen = [System.Drawing.Pen]::new([System.Drawing.Color]$resolvedAccentColor, [float]2)
                $e.Graphics.DrawLine($borderPen, 1, 10, 10, 10)
                $e.Graphics.DrawLine($borderPen, (24 + $titleWidth), 10, ($s.Width - 2), 10)
                $e.Graphics.DrawRectangle($borderPen, 1, 10, ($s.Width - 3), ($s.Height - 12))
                $e.Graphics.DrawLine($accentPen, 12, 12, [Math]::Min((46 + $titleWidth), ($s.Width - 14)), 12)
            }
            finally {
                if ($borderPen) { $borderPen.Dispose() }
                if ($accentPen) { $accentPen.Dispose() }
            }
        }.GetNewClosure())
}

function New-SectionTitle {
    param([string]$Text, [int]$X, [int]$Y, [int]$W = 260)
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.SetBounds($X, $Y, $W, 22)
    $label.Font = $fontSection
    $label.ForeColor = $clrNavy
    return $label
}

function New-InfoPill {
    param([string]$Text, [int]$X, [int]$Y, [int]$W = 140)
    $pill = New-Object System.Windows.Forms.Label
    $pill.Text = $Text
    $pill.SetBounds($X, $Y, $W, 24)
    $pill.Font = $fontSmall
    $pill.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $pill.BackColor = $clrAccentLight
    $pill.ForeColor = $clrAccentDark
    $pill.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    return $pill
}

function New-DashboardHeader {
    param([string]$Title, [string]$Subtitle, [string]$VersionText)
    $p = New-Object System.Windows.Forms.Panel
    $p.Location = New-Object System.Drawing.Point(10, 10)
    $p.Size = New-Object System.Drawing.Size(988, 96)
    $p.Anchor = 'Top,Left,Right'
    $p.BackColor = $clrAccent

    $updateHeaderGradient = {
        param($Panel)
        if (-not $Panel -or $Panel.Width -lt 2 -or $Panel.Height -lt 2) { return }

        $previousImage = $Panel.BackgroundImage
        $bmp = New-Object System.Drawing.Bitmap($Panel.Width, $Panel.Height)
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        try {
            $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $rect = New-Object System.Drawing.Rectangle(0, 0, $Panel.Width, $Panel.Height)
            $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
                $rect,
                [System.Drawing.Color]::FromArgb(255, 102, 0),
                [System.Drawing.Color]::FromArgb(137, 0, 120),
                [System.Drawing.Drawing2D.LinearGradientMode]::Horizontal
            )
            try {
                $blend = New-Object System.Drawing.Drawing2D.ColorBlend
                $blend.Colors = @(
                    [System.Drawing.Color]::FromArgb(255, 102, 0),
                    [System.Drawing.Color]::FromArgb(255, 88, 0),
                    [System.Drawing.Color]::FromArgb(255, 69, 0),
                    [System.Drawing.Color]::FromArgb(232, 59, 107),
                    [System.Drawing.Color]::FromArgb(184, 53, 122),
                    [System.Drawing.Color]::FromArgb(137, 0, 120)
                )
                $blend.Positions = @(0.0, 0.18, 0.35, 0.58, 0.78, 1.0)
                $brush.InterpolationColors = $blend
                $g.FillRectangle($brush, $rect)
            }
            finally {
                $brush.Dispose()
            }
        }
        finally {
            $g.Dispose()
        }

        $Panel.BackgroundImageLayout = [System.Windows.Forms.ImageLayout]::Stretch
        $Panel.BackgroundImage = $bmp
        if ($previousImage) { $previousImage.Dispose() }
    }

    $brandRight = 220
    $brandIconPath = @(
        (Join-Path $ScriptRoot 'AvanadeMove.ico'),
        (Join-Path $ScriptRoot 'Avanade.ico')
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1

    if ($brandIconPath) {
        try {
            $iconBitmap = ([System.Drawing.Icon]::ExtractAssociatedIcon($brandIconPath)).ToBitmap()
            $brandIcon = New-Object System.Windows.Forms.PictureBox
            $brandIcon.Image = $iconBitmap
            $brandIcon.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
            $brandIcon.SetBounds(22, 24, 42, 42)
            $p.Controls.Add($brandIcon)
            $brandRight = 220
        }
        catch {
            $brandBar = New-Object System.Windows.Forms.Panel
            $brandBar.BackColor = $clrAccent
            $brandBar.SetBounds(22, 22, 6, 54)
            $p.Controls.Add($brandBar)
        }
    }
    else {
        $brandBar = New-Object System.Windows.Forms.Panel
        $brandBar.BackColor = $clrAccent
        $brandBar.SetBounds(22, 22, 6, 54)
        $p.Controls.Add($brandBar)
    }

    $brandWord = New-Object System.Windows.Forms.Label
    $brandWord.Text = 'AVANADE'
    $brandWord.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
    $brandWord.ForeColor = [System.Drawing.Color]::White
    $brandWord.BackColor = [System.Drawing.Color]::Transparent
    $brandWord.AutoSize = $true
    $brandWord.Location = New-Object System.Drawing.Point(74, 22)
    $p.Controls.Add($brandWord)

    $brandSub = New-Object System.Windows.Forms.Label
    $brandSub.Text = 'MOVE OPS'
    $brandSub.Font = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Regular)
    $brandSub.ForeColor = [System.Drawing.Color]::FromArgb(232, 236, 244)
    $brandSub.BackColor = [System.Drawing.Color]::Transparent
    $brandSub.AutoSize = $true
    $brandSub.Location = New-Object System.Drawing.Point(74, 44)
    $p.Controls.Add($brandSub)

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = $Title
    $titleLabel.Font = New-Object System.Drawing.Font('Segoe UI', 17, [System.Drawing.FontStyle]::Bold)
    $titleLabel.ForeColor = [System.Drawing.Color]::White
    $titleLabel.BackColor = [System.Drawing.Color]::Transparent
    $titleLabel.AutoSize = $true
    $titleLabel.Location = New-Object System.Drawing.Point($brandRight, 10)
    $p.Controls.Add($titleLabel)

    $subLabel = New-Object System.Windows.Forms.Label
    $subLabel.Text = $Subtitle
    $subLabel.Font = $fontBase
    $subLabel.ForeColor = [System.Drawing.Color]::FromArgb(248, 250, 253)
    $subLabel.BackColor = [System.Drawing.Color]::Transparent
    $subLabel.AutoSize = $false
    $subLabel.AutoEllipsis = $true
    $subLabel.SetBounds(($brandRight + 2), 42, 600, 18)
    $p.Controls.Add($subLabel)

    $pillLabel = New-Object System.Windows.Forms.Label
    $pillLabel.Text = 'Native PowerShell WinForms'
    $pillLabel.Font = $fontSmall
    $pillLabel.ForeColor = [System.Drawing.Color]::FromArgb(240, 244, 252)
    $pillLabel.BackColor = [System.Drawing.Color]::Transparent
    $pillLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $pillLabel.SetBounds(($brandRight + 2), 62, 180, 18)
    $p.Controls.Add($pillLabel)

    $versionLabel = New-Object System.Windows.Forms.Label
    $versionLabel.Text = $VersionText
    $versionLabel.Font = $fontBold
    $versionLabel.ForeColor = [System.Drawing.Color]::White
    $versionLabel.BackColor = [System.Drawing.Color]::Transparent
    $versionLabel.AutoSize = $false
    $versionLabel.Size = New-Object System.Drawing.Size(140, 24)
    $versionLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $versionLabel.Anchor = 'Top,Right'
    $versionLabel.Location = New-Object System.Drawing.Point(($p.Width - 162), 14)
    $p.Controls.Add($versionLabel)

    $p.Add_Resize({
            param($s, $e)
            try {
                $subLabel.Width = [Math]::Max(220, ($s.Width - ($brandRight + 180)))
                $versionLabel.Location = New-Object System.Drawing.Point(($s.Width - 162), 14)
                & $updateHeaderGradient $s
            }
            catch {}
        }.GetNewClosure())

    & $updateHeaderGradient $p

    return $p
}

function New-CardPanel {
    param([int]$X, [int]$Y, [int]$W, [int]$H)
    $p = New-Object System.Windows.Forms.Panel
    $p.Location = New-Object System.Drawing.Point($X, $Y)
    $p.Size = New-Object System.Drawing.Size($W, $H)
    $p.BackColor = $clrSurface
    Set-PanelBorder $p
    return $p
}

function New-MetricTile {
    param([string]$Title, [string]$Value, [string]$Hint, [int]$X, [int]$Y, [int]$TileWidth = 182)
    $tile = New-CardPanel $X $Y $TileWidth 64
    [void](Add-AccentStrip $tile $clrAccent)
    $lblTitle = New-Object System.Windows.Forms.Label
    $lblTitle.Text = $Title
    $lblTitle.Font = $fontSmall
    $lblTitle.ForeColor = $clrMuted
    $lblTitle.SetBounds(12, 8, ($TileWidth - 24), 16)
    $tile.Controls.Add($lblTitle)

    $lblValue = New-Object System.Windows.Forms.Label
    $lblValue.Text = $Value
    $lblValue.Font = $fontKpi
    $lblValue.ForeColor = $clrAccentDark
    $lblValue.SetBounds(16, 24, 80, 32)
    $tile.Controls.Add($lblValue)

    $lblHint = New-Object System.Windows.Forms.Label
    $lblHint.Text = $Hint
    $lblHint.Font = $fontSmall
    $lblHint.ForeColor = $clrMuted
    $lblHint.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $lblHint.SetBounds(($TileWidth - 104), 32, 92, 18)
    $tile.Controls.Add($lblHint)

    return [PSCustomObject]@{ Panel = $tile; ValueLabel = $lblValue; HintLabel = $lblHint }
}

function New-BrowseFileButton {
    param($TargetTextBox, $X, $Y, $Filter = 'All Files (*.*)|*.*')
    $b = New-Object System.Windows.Forms.Button
    $b.Text = '...'
    $b.Size = New-Object System.Drawing.Size(28, 22)
    $b.Location = New-Object System.Drawing.Point($X, $Y)
    $b.Tag = @{ TextBox = $TargetTextBox; Filter = $Filter }
    $b.Add_Click({
            param($s, $e)
            try {
                $dlg = New-Object System.Windows.Forms.OpenFileDialog
                $dlg.Filter = $s.Tag.Filter
                if ($s.Tag.TextBox.Text -and (Test-Path (Split-Path $s.Tag.TextBox.Text -Parent -ErrorAction SilentlyContinue))) {
                    $dlg.InitialDirectory = Split-Path $s.Tag.TextBox.Text -Parent
                }
                if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                    $s.Tag.TextBox.Text = $dlg.FileName
                }
            }
            catch {}
        })
    Set-ButtonStyle $b
    return $b
}

function New-BrowseFolderButton {
    param($TargetTextBox, $X, $Y, $Description = 'Select Folder')
    $b = New-Object System.Windows.Forms.Button
    $b.Text = '...'
    $b.Size = New-Object System.Drawing.Size(28, 22)
    $b.Location = New-Object System.Drawing.Point($X, $Y)
    $b.Tag = @{ TextBox = $TargetTextBox; Description = $Description }
    $b.Add_Click({
            param($s, $e)
            try {
                $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
                $dlg.Description = $s.Tag.Description
                if ($s.Tag.TextBox.Text -and (Test-Path $s.Tag.TextBox.Text)) {
                    $dlg.SelectedPath = $s.Tag.TextBox.Text
                }
                if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                    $s.Tag.TextBox.Text = $dlg.SelectedPath
                }
            }
            catch {}
        })
    Set-ButtonStyle $b
    return $b
}

# ── DPAPI encryption helpers (CurrentUser scope, CMSLibrary-compatible) ───────
function Protect-StringDPAPI {
    param([string]$PlainText)
    $bytes = [System.Text.Encoding]::Unicode.GetBytes($PlainText)
    $encrypted = [System.Security.Cryptography.ProtectedData]::Protect(
        $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
    return [System.Convert]::ToBase64String($encrypted)
}

function Unprotect-StringDPAPI {
    param([string]$Base64Cipher)
    try {
        $bytes = [System.Convert]::FromBase64String($Base64Cipher)
        $decrypted = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        return [System.Text.Encoding]::Unicode.GetString($decrypted)
    }
    catch { return $null }
}

# ── Main form ─────────────────────────────────────────────────────────────────
function Get-AppWindowIcon {
    $iconCandidates = @(
        (Join-Path $ScriptRoot 'AvanadeMove.ico'),
        (Join-Path $ScriptRoot 'Avanade.ico')
    )

    foreach ($iconPath in $iconCandidates) {
        if (-not (Test-Path -LiteralPath $iconPath)) { continue }
        try {
            return New-Object System.Drawing.Icon($iconPath)
        }
        catch {}
    }

    try {
        $currentExe = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        if (-not [string]::IsNullOrWhiteSpace([string]$currentExe) -and (Test-Path -LiteralPath $currentExe)) {
            return [System.Drawing.Icon]::ExtractAssociatedIcon($currentExe)
        }
    }
    catch {}

    return $null
}

$form = New-Object System.Windows.Forms.Form
$form.Text = $GUITitle
$form.Size = New-Object System.Drawing.Size(1024, 768)
$form.MinimumSize = New-Object System.Drawing.Size(960, 700)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $clrBackground
$form.Font = $fontBase

$AppWindowIcon = Get-AppWindowIcon
$form.Icon = $AppWindowIcon
if ($AppWindowIcon) {
    $form.ShowIcon = $true
}

$headerPanel = New-DashboardHeader `
    -Title 'Avanade Cloud Impact MOVE - Client Discovery Dashboard' `
    -Subtitle 'Collect server inventory, validate access, generate artifact reports, and package outputs — all with native PowerShell WinForms.' `
    -VersionText "v$ScriptVersion"
$form.Controls.Add($headerPanel)

# Status strip
$statusStrip = New-Object System.Windows.Forms.StatusStrip
$statusStrip.BackColor = $clrSurfaceAlt
$statusStrip.ForeColor = $clrText
$statusStrip.SizingGrip = $false
$statusStrip.Dock = 'Bottom'
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel -Property @{ Text = 'Ready' }
$statusLabel.ForeColor = $clrAccentDark
$collectionProgressBar = New-Object System.Windows.Forms.ToolStripProgressBar
$collectionProgressBar.Minimum = 0
$collectionProgressBar.Maximum = 100
$collectionProgressBar.Value = 0
$collectionProgressBar.Width = 180
$collectionProgressBar.Visible = $false
$serverCountStatusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel -Property @{ Text = 'No CSV loaded.' }
$serverCountStatusLabel.ForeColor = $clrMuted
$serverCountStatusLabel.Spring = $true
$serverCountStatusLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
[void]$statusStrip.Add_Paint({
        param($s, $e)
        $pen = [System.Drawing.Pen]::new([System.Drawing.Color]$clrBorder)
        try {
            $e.Graphics.DrawLine($pen, 0, 0, $s.Width, 0)
        }
        finally {
            $pen.Dispose()
        }
    })
[void]$statusStrip.Items.Add($statusLabel)
[void]$statusStrip.Items.Add($collectionProgressBar)
[void]$statusStrip.Items.Add($serverCountStatusLabel)
$form.Controls.Add($statusStrip)
function Set-Status { param([string]$Text) try { $statusLabel.Text = $Text } catch {} }
function Set-ServerCountStatus { param([string]$Text) try { $serverCountStatusLabel.Text = $Text } catch {} }

$script:CollectionProgressStatusPath = $null
$script:CollectionProgressProcess = $null
$script:CollectionProgressTimer = New-Object System.Windows.Forms.Timer
$script:CollectionProgressTimer.Interval = 1500

function Stop-CollectionProgressMonitor {
    param([string]$FinalMessage = '')
    try { $script:CollectionProgressTimer.Stop() } catch {}
    try { $collectionProgressBar.Visible = $false; $collectionProgressBar.Value = 0 } catch {}
    $script:CollectionProgressStatusPath = $null
    $script:CollectionProgressProcess = $null
    if ($FinalMessage) { Set-Status $FinalMessage }
}

function Update-CollectionProgressFromStatusFile {
    if ([string]::IsNullOrWhiteSpace([string]$script:CollectionProgressStatusPath)) { return }

    $status = $null
    if (Test-Path -LiteralPath $script:CollectionProgressStatusPath -PathType Leaf) {
        try {
            $raw = Get-Content -LiteralPath $script:CollectionProgressStatusPath -Raw -ErrorAction Stop
            if (-not [string]::IsNullOrWhiteSpace($raw)) {
                $status = $raw | ConvertFrom-Json -ErrorAction Stop
            }
        }
        catch {
            Write-GuiLog "Failed to read progress status: $($_.Exception.Message)" 'WARN'
        }
    }

    if ($status) {
        $percent = [Math]::Min(100, [Math]::Max(0, [int]$status.Percent))
        try { $collectionProgressBar.Value = $percent } catch {}
        $message = if ($status.Message) { [string]$status.Message } elseif ($status.CurrentServer) { "Scanning $($status.CurrentServer)" } else { [string]$status.State }
        Set-Status "Collection: $message"
        Set-ServerCountStatus "Servers: $($status.Completed)/$($status.Total) complete | Failed: $($status.Failed)"

        if ($status.State -eq 'Complete') {
            Stop-CollectionProgressMonitor -FinalMessage "Collection complete. Diagnostics: $($status.LogFile)"
            return
        }
    }

    if ($script:CollectionProgressProcess -and $script:CollectionProgressProcess.HasExited) {
        Stop-CollectionProgressMonitor -FinalMessage 'Collection process exited. Check OutputDir\Logs for diagnostics.'
    }
}

$script:CollectionProgressTimer.Add_Tick({ Update-CollectionProgressFromStatusFile })

function Start-CollectionProgressMonitor {
    param([string]$StatusPath, $Process)
    if ([string]::IsNullOrWhiteSpace([string]$StatusPath)) { return }
    $script:CollectionProgressStatusPath = $StatusPath
    $script:CollectionProgressProcess = $Process
    try {
        $collectionProgressBar.Visible = $true
        $collectionProgressBar.Value = 0
    }
    catch {}
    Set-Status 'Collection launched. Waiting for progress updates...'
    Set-ServerCountStatus 'Collection starting...'
    try { $script:CollectionProgressTimer.Start() } catch {}
}

# ── TabControl ────────────────────────────────────────────────────────────────
$tabControl = New-Object System.Windows.Forms.TabControl
$tabControl.Location = New-Object System.Drawing.Point(10, 116)
$tabControl.Anchor = 'Top,Left,Right,Bottom'
$tabControl.Size = New-Object System.Drawing.Size(988, 612)
$tabControl.Font = $fontBase
Set-TabControlBranding $tabControl
$form.Controls.Add($tabControl)

function Update-MainLayout {
    try {
        $leftPad = 10
        $topPad = 116
        $rightPad = 10
        $bottomGap = 6
        $availableWidth = [Math]::Max(900, ($form.ClientSize.Width - $leftPad - $rightPad))
        $statusTop = if ($statusStrip -and $statusStrip.Visible) { $statusStrip.Top } else { $form.ClientSize.Height }
        $availableHeight = [Math]::Max(460, ($statusTop - $topPad - $bottomGap))
        $tabControl.SetBounds($leftPad, $topPad, $availableWidth, $availableHeight)
    }
    catch {}
}

$form.Add_Resize({ Update-MainLayout })
$form.Add_Shown({ Update-MainLayout })
Update-MainLayout

function New-Tab {
    param($Title)
    $t = New-Object System.Windows.Forms.TabPage
    $t.Text = $Title
    $t.BackColor = $clrBackground
    $t.Padding = New-Object System.Windows.Forms.Padding(8)
    [void]$tabControl.TabPages.Add($t)
    return $t
}

$tabWelcome = New-Tab '1. Welcome'
$tabConfiguration = New-Tab '2. Configuration'
$tabServerList = New-Tab '3. Server List'

$tabWelcome.AutoScroll = $false
$tabConfiguration.AutoScroll = $false
$tabServerList.AutoScroll = $true
$tabServerList.AutoScrollMinSize = New-Object System.Drawing.Size(980, 700)

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1 — WELCOME
# ═══════════════════════════════════════════════════════════════════════════════
$lblWelcomeTitle = New-Object System.Windows.Forms.Label
$lblWelcomeTitle.Text = "Ready to collect migration discovery data"
$lblWelcomeTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 15)
$lblWelcomeTitle.ForeColor = $clrNavy
$lblWelcomeTitle.Location = New-Object System.Drawing.Point(12, 16)
$lblWelcomeTitle.AutoSize = $true
$tabWelcome.Controls.Add($lblWelcomeTitle)

$lblWelcomeVer = New-Object System.Windows.Forms.Label
$lblWelcomeVer.Text = "Version $ScriptVersion  •  client-safe package  •  no browser runtime required"
$lblWelcomeVer.Location = New-Object System.Drawing.Point(14, 48)
$lblWelcomeVer.AutoSize = $true
$lblWelcomeVer.ForeColor = $clrMuted
$tabWelcome.Controls.Add($lblWelcomeVer)

$welcomeCard = New-CardPanel 12 82 952 410
$welcomeCard.Anchor = 'Top,Left,Right'
$tabWelcome.Controls.Add($welcomeCard)

$workflowPanel = New-CardPanel 24 24 546 320
$workflowPanel.BackColor = $clrSurfaceAlt
$welcomeCard.Controls.Add($workflowPanel)
$workflowPanel.Controls.Add((New-SectionTitle 'Recommended workflow' 18 16 260))
$workflowRows = @(
    @{ Step = '01'; Title = 'Generate access report'; Text = 'Run Access Check first to validate WinRM/RDP/SSH and permissions for your server scope.' },
    @{ Step = '02'; Title = 'Collect all server data'; Text = 'Run All Data Collectors to gather baseline inventory and service details across selected servers.' },
    @{ Step = '03'; Title = 'Download Log Analytics data'; Text = 'Use Export Log Analytics to pull workspace insights for the same server scope.' },
    @{ Step = '04'; Title = 'Capture additional DNS data'; Text = 'Use Export DNS Data to collect all records from the local primary DNS server on the machine running the tool.' },
    @{ Step = '05'; Title = 'Generate artifact report'; Text = 'Build the Artifact Report HTML so results can be reviewed and handed off consistently.' },
    @{ Step = '06'; Title = 'ZIP report package'; Text = 'Use ZIP Output for Delivery to package artifacts, logs, and report outputs for submission.' }
)
$wy = 52
foreach ($row in $workflowRows) {
    $badge = New-Object System.Windows.Forms.Label
    $badge.Text = $row.Step
    $badge.SetBounds(18, $wy, 34, 28)
    $badge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $badge.Font = $fontBold
    $badge.BackColor = $clrAccent
    $badge.ForeColor = [System.Drawing.Color]::White
    $workflowPanel.Controls.Add($badge)

    $title = New-Object System.Windows.Forms.Label
    $title.Text = $row.Title
    $title.SetBounds(66, $wy - 2, 220, 18)
    $title.Font = $fontBold
    $title.ForeColor = $clrText
    $workflowPanel.Controls.Add($title)

    $copy = New-Object System.Windows.Forms.Label
    $copy.Text = $row.Text
    $copy.SetBounds(66, $wy + 18, 520, 28)
    $copy.Font = $fontBase
    $copy.ForeColor = $clrMuted
    $workflowPanel.Controls.Add($copy)
    $wy += 52
}

$readinessPanel = New-CardPanel 586 24 352 360
$readinessPanel.Anchor = 'Top,Right'
$welcomeCard.Controls.Add($readinessPanel)
$readinessPanel.Controls.Add((New-SectionTitle 'Before you begin' 18 18 260))
$readyItems = @(
    'CSV includes ServerName (or Server) and OSType columns.',
    'Windows targets allow WinRM/RDP connectivity and local admin rights.',
    'Linux targets allow SSH with an account that can read system configuration.',
    'Output directory is writable and has enough space for JSON, logs, and reports.',
    'Optional Azure Log Analytics workspace details are available if exporting LA data.',
    'Credentials are either entered interactively or saved with same-user DPAPI encryption.'
)
$readinessCheckLabels = @()
$readinessTextLabels = @()
$ry = 58
foreach ($item in $readyItems) {
    $check = New-Object System.Windows.Forms.Label
    $check.Text = '✓'
    $check.SetBounds(18, $ry, 22, 20)
    $check.Font = $fontBold
    $check.ForeColor = $clrSuccess
    $readinessPanel.Controls.Add($check)
    $readinessCheckLabels += $check

    $text = New-Object System.Windows.Forms.Label
    $text.Text = $item
    $text.SetBounds(44, $ry, 300, 38)
    $text.Font = $fontBase
    $text.ForeColor = $clrText
    $readinessPanel.Controls.Add($text)
    $readinessTextLabels += $text
    $ry += 50
}

$btnWelcomeNext = New-Object System.Windows.Forms.Button
$btnWelcomeNext.Text = "Next: Configuration →"
$btnWelcomeNext.Size = New-Object System.Drawing.Size(180, 32)
$btnWelcomeNext.Location = New-Object System.Drawing.Point(12, 508)
$btnWelcomeNext.Anchor = 'Top,Left'
Set-ButtonStyle $btnWelcomeNext -Primary
$btnWelcomeNext.Add_Click({ $tabControl.SelectedTab = $tabConfiguration })
$tabWelcome.Controls.Add($btnWelcomeNext)

$btnWelcomeInstructions = New-Object System.Windows.Forms.Button
$btnWelcomeInstructions.Text = 'Open Instructions Site'
$btnWelcomeInstructions.Size = New-Object System.Drawing.Size(180, 32)
$btnWelcomeInstructions.Location = New-Object System.Drawing.Point(200, 508)
$btnWelcomeInstructions.Anchor = 'Top,Left'
Set-ButtonStyle $btnWelcomeInstructions
$toolTip.SetToolTip($btnWelcomeInstructions, 'Open the local multi-page HTML instructions site in your default browser')
$btnWelcomeInstructions.Add_Click({
        try {
            $instructionsPath = Join-Path $ScriptRoot 'Instructions\index.html'
            if (Test-Path -LiteralPath $instructionsPath -PathType Leaf) {
                Start-Process -FilePath $instructionsPath | Out-Null
                Set-Status 'Opened instructions site.'
            }
            else {
                Set-Status "Instructions site not found: $instructionsPath"
                [System.Windows.Forms.MessageBox]::Show(
                    "Instructions site not found.`n$instructionsPath",
                    'Avanade Cloud Impact MOVE - Client Discovery',
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                ) | Out-Null
            }
        }
        catch {
            Set-Status "Unable to open instructions site: $($_.Exception.Message)"
        }
    })
$tabWelcome.Controls.Add($btnWelcomeInstructions)

function Update-WelcomeLayout {
    try {
        $clientW = [Math]::Max(940, ($tabWelcome.ClientSize.Width - 16))
        $clientH = [Math]::Max(520, ($tabWelcome.ClientSize.Height - 12))
        $isTight = ($clientH -lt 640)

        $nextHeight = 32
        $bottomBand = $nextHeight + 16
        $cardMax = if ($isTight) { 390 } else { 430 }
        $cardHeight = [Math]::Max(320, [Math]::Min($cardMax, ($clientH - 82 - $bottomBand)))

        $welcomeCard.SetBounds(12, 82, ($clientW - 24), $cardHeight)

        $rightWidth = if ($isTight) {
            [Math]::Min(320, [Math]::Max(270, [int]($welcomeCard.Width * 0.33)))
        }
        else {
            [Math]::Min(352, [Math]::Max(300, [int]($welcomeCard.Width * 0.36)))
        }
        $readinessX = $welcomeCard.Width - $rightWidth - 14
        $readinessPanelHeight = if ($isTight) { ($welcomeCard.Height - 64) } else { ($welcomeCard.Height - 48) }
        $readinessPanel.SetBounds($readinessX, 24, $rightWidth, $readinessPanelHeight)

        $maxRows = [Math]::Max(3, [Math]::Min($readyItems.Count, [Math]::Floor((($readinessPanel.Height - 72) / 50))))
        for ($i = 0; $i -lt $readyItems.Count; $i++) {
            $showRow = ($i -lt $maxRows)
            $y = 58 + ($i * 50)
            $readinessCheckLabels[$i].Visible = $showRow
            $readinessTextLabels[$i].Visible = $showRow
            if ($showRow) {
                $readinessCheckLabels[$i].Location = New-Object System.Drawing.Point(18, $y)
                $readinessTextLabels[$i].SetBounds(44, $y, ($readinessPanel.Width - 52), 38)
            }
        }

        $workflowWidth = [Math]::Max(420, ($readinessX - 40))
        $workflowTop = 24
        $workflowHeight = [Math]::Max(220, ($welcomeCard.Height - ($workflowTop + 22)))
        $workflowPanel.SetBounds(24, $workflowTop, $workflowWidth, $workflowHeight)

        $buttonY = $welcomeCard.Bottom + 10
        $btnWelcomeNext.Location = New-Object System.Drawing.Point(12, $buttonY)
        $btnWelcomeInstructions.Location = New-Object System.Drawing.Point(200, $buttonY)
    }
    catch {}
}

$tabWelcome.Add_Resize({ Update-WelcomeLayout })
$form.Add_Resize({ Update-WelcomeLayout })
Update-WelcomeLayout

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2 — CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════
$pnlConfig = New-Object System.Windows.Forms.Panel
$pnlConfig.Location = New-Object System.Drawing.Point(0, 0)
$pnlConfig.Dock = 'Fill'
$pnlConfig.AutoScroll = $true
$pnlConfig.AutoScrollMinSize = New-Object System.Drawing.Size(0, 0)
$pnlConfig.BackColor = $clrBackground
$tabConfiguration.Controls.Add($pnlConfig)

$cy = 12

# ── Section A: Output & Collection ────────────────────────────────────────────
$gbGeneral = New-Object System.Windows.Forms.GroupBox
$gbGeneral.Text = ''
$gbGeneral.Font = $fontBold
$gbGeneral.Location = New-Object System.Drawing.Point(12, $cy)
$gbGeneral.Size = New-Object System.Drawing.Size(948, 74)
Set-GroupBoxStyle -GroupBox $gbGeneral -AccentColor $clrSky
$pnlConfig.Controls.Add($gbGeneral)
[void](Add-AccentStrip $gbGeneral $clrSky)
# Overlay label for section title
$lblSectionOutput = New-Object System.Windows.Forms.Label
$lblSectionOutput.Text = 'Output & Collection'
$lblSectionOutput.Font = $fontBold
$lblSectionOutput.ForeColor = $clrText
$lblSectionOutput.BackColor = $clrBackground
$lblSectionOutput.AutoSize = $true
$lblSectionOutput.Location = New-Object System.Drawing.Point(24, ($cy - 4))
$pnlConfig.Controls.Add($lblSectionOutput)
$pnlConfig.Controls.SetChildIndex($lblSectionOutput, 0)

$gy = 28
$gbGeneral.Controls.Add((New-Label 'Output Directory:' 18 $gy))
$txtOutputDir = New-TextBox 156 $gy 560
$txtOutputDir.Text = "C:\Avanade\$env:USERNAME"
$gbGeneral.Controls.Add($txtOutputDir)
$gbGeneral.Controls.Add((New-BrowseFolderButton $txtOutputDir (156 + 566) $gy 'Select Output Directory'))
$cy += 86

# ── Section B: Log Analytics ─────────────────────────────────────────────────
$gbLAOpts = New-Object System.Windows.Forms.GroupBox
$gbLAOpts.Text = ''
$gbLAOpts.Font = $fontBold
$gbLAOpts.Location = New-Object System.Drawing.Point(12, $cy)
$gbLAOpts.Size = New-Object System.Drawing.Size(620, 120)
Set-GroupBoxStyle -GroupBox $gbLAOpts -AccentColor $clrAccent
$pnlConfig.Controls.Add($gbLAOpts)
[void](Add-AccentStrip $gbLAOpts $clrAccent)
# Overlay label for section title
$lblSectionLA = New-Object System.Windows.Forms.Label
$lblSectionLA.Text = 'Log Analytics Export Options'
$lblSectionLA.Font = $fontBold
$lblSectionLA.ForeColor = $clrText
$lblSectionLA.BackColor = $clrBackground
$lblSectionLA.AutoSize = $true
$lblSectionLA.Location = New-Object System.Drawing.Point(24, ($cy - 4))
$pnlConfig.Controls.Add($lblSectionLA)
$pnlConfig.Controls.SetChildIndex($lblSectionLA, 0)

$gy = 22
$gbLAOpts.Controls.Add((New-Label 'Subscription:' 10 $gy))
$txtLASubscriptionName = New-TextBox 112 $gy 494
$gbLAOpts.Controls.Add($txtLASubscriptionName)
$toolTip.SetToolTip($txtLASubscriptionName, 'Azure subscription name that contains the Log Analytics workspace')
$gy += 28

$gbLAOpts.Controls.Add((New-Label 'Workspace RG:' 10 $gy))
$txtLAWorkspaceRG = New-TextBox 112 $gy 178
$gbLAOpts.Controls.Add($txtLAWorkspaceRG)
$toolTip.SetToolTip($txtLAWorkspaceRG, 'Resource group that contains the Log Analytics workspace')

$gbLAOpts.Controls.Add((New-Label 'Workspace:' 300 $gy))
$txtLAWorkspaceName = New-TextBox 376 $gy 230
$gbLAOpts.Controls.Add($txtLAWorkspaceName)
$toolTip.SetToolTip($txtLAWorkspaceName, 'Log Analytics workspace name')
$gy += 28

$gbLAOpts.Controls.Add((New-Label 'Timespan:' 10 $gy))
$cmbLATimespan = New-Object System.Windows.Forms.ComboBox
$cmbLATimespan.DropDownStyle = 'DropDownList'
$cmbLATimespan.Location = New-Object System.Drawing.Point(120, $gy)
$cmbLATimespan.Size = New-Object System.Drawing.Size(120, 22)
$cmbLATimespan.Font = $fontBase
@('30d', '14d', '7d', '24h', '1h') | ForEach-Object { [void]$cmbLATimespan.Items.Add($_) }
$cmbLATimespan.SelectedItem = '30d'
$gbLAOpts.Controls.Add($cmbLATimespan)
$toolTip.SetToolTip($cmbLATimespan, 'How far back the Log Analytics query should look')

$gbLAOpts.Controls.Add((New-Label 'Requires active Azure login for workspace access.' 250 ($gy + 3)))
$cy += 132

# Hidden variables maintained for script compatibility
$cmbCheckType = New-Object System.Windows.Forms.ComboBox
$cmbCheckType.Visible = $false
@('Pre_Migration', 'Post_Migration', 'Test_Migration') | ForEach-Object { [void]$cmbCheckType.Items.Add($_) }
$cmbCheckType.SelectedIndex = 0
$pnlConfig.Controls.Add($cmbCheckType)

# chkScanIP, chkSkipEventLog, chkServerOnly are defined in the Server List tab sidebar

# ── Section C: Access Check Options ───────────────────────────────────────────
$gbAcOpts = New-Object System.Windows.Forms.GroupBox
$gbAcOpts.Text = ''
$gbAcOpts.Font = $fontBold
$gbAcOpts.Location = New-Object System.Drawing.Point(12, $cy)
$gbAcOpts.Size = New-Object System.Drawing.Size(316, 120)
Set-GroupBoxStyle -GroupBox $gbAcOpts -AccentColor $clrSky
$pnlConfig.Controls.Add($gbAcOpts)
[void](Add-AccentStrip $gbAcOpts $clrSky)
# Overlay label for section title
$lblSectionAC = New-Object System.Windows.Forms.Label
$lblSectionAC.Text = 'Access Check Options'
$lblSectionAC.Font = $fontBold
$lblSectionAC.ForeColor = $clrText
$lblSectionAC.BackColor = $clrBackground
$lblSectionAC.AutoSize = $true
$lblSectionAC.Location = New-Object System.Drawing.Point(24, ($cy - 4))
$pnlConfig.Controls.Add($lblSectionAC)
$pnlConfig.Controls.SetChildIndex($lblSectionAC, 0)

$gy = 22
$gbAcOpts.Controls.Add((New-Label 'RDP Port:' 8 $gy))
$numAcRdpPort = New-Object System.Windows.Forms.NumericUpDown
$numAcRdpPort.Location = New-Object System.Drawing.Point(122, $gy)
$numAcRdpPort.Size = New-Object System.Drawing.Size(70, 22)
$numAcRdpPort.Minimum = 1
$numAcRdpPort.Maximum = 65535
$numAcRdpPort.Value = 3389
$numAcRdpPort.Font = $fontBase
$gbAcOpts.Controls.Add($numAcRdpPort)
$toolTip.SetToolTip($numAcRdpPort, 'TCP port used to test RDP connectivity (default: 3389)')
$gy += 28

$gbAcOpts.Controls.Add((New-Label 'PS Timeout (sec):' 8 $gy))
$numAcPsTimeout = New-Object System.Windows.Forms.NumericUpDown
$numAcPsTimeout.Location = New-Object System.Drawing.Point(122, $gy)
$numAcPsTimeout.Size = New-Object System.Drawing.Size(60, 22)
$numAcPsTimeout.Minimum = 1
$numAcPsTimeout.Maximum = 120
$numAcPsTimeout.Value = 5
$numAcPsTimeout.Font = $fontBase
$gbAcOpts.Controls.Add($numAcPsTimeout)
$toolTip.SetToolTip($numAcPsTimeout, 'Seconds to wait for a PowerShell/WinRM response before timing out')
$gy += 28

$gbAcOpts.Controls.Add((New-Label 'Max Concurrent:' 8 $gy))
$numAcMaxConcurrent = New-Object System.Windows.Forms.NumericUpDown
$numAcMaxConcurrent.Location = New-Object System.Drawing.Point(122, $gy)
$numAcMaxConcurrent.Size = New-Object System.Drawing.Size(60, 22)
$numAcMaxConcurrent.Minimum = 1
$numAcMaxConcurrent.Maximum = 50
$numAcMaxConcurrent.Value = 8
$numAcMaxConcurrent.Font = $fontBase
$gbAcOpts.Controls.Add($numAcMaxConcurrent)
$toolTip.SetToolTip($numAcMaxConcurrent, 'Maximum number of servers to test simultaneously')

# Hidden — used by Invoke-RunAccessCheck but not set interactively
$chkAcUseCreds = New-Object System.Windows.Forms.CheckBox
$chkAcUseCreds.Visible = $false
$gbAcOpts.Controls.Add($chkAcUseCreds)

# FQDN suffix not exposed in the UI — assumed to be included in ServerName from the CMDB
$txtAcFqdnSuffix = New-Object System.Windows.Forms.TextBox
$txtAcFqdnSuffix.Visible = $false
$gbAcOpts.Controls.Add($txtAcFqdnSuffix)

$cy += 132

# ── Section D: Credentials ────────────────────────────────────────────────────
$gbCreds = New-Object System.Windows.Forms.GroupBox
$gbCreds.Text = ''
$gbCreds.Font = $fontBold
$gbCreds.Location = New-Object System.Drawing.Point(12, $cy)
$gbCreds.Size = New-Object System.Drawing.Size(948, 326)
Set-GroupBoxStyle -GroupBox $gbCreds -AccentColor $clrAccentDark
$pnlConfig.Controls.Add($gbCreds)
[void](Add-AccentStrip $gbCreds $clrAccentDark)
# Overlay label for section title
$lblSectionCreds = New-Object System.Windows.Forms.Label
$lblSectionCreds.Text = 'Credentials'
$lblSectionCreds.Font = $fontBold
$lblSectionCreds.ForeColor = $clrText
$lblSectionCreds.BackColor = $clrBackground
$lblSectionCreds.AutoSize = $true
$lblSectionCreds.Location = New-Object System.Drawing.Point(24, ($cy - 4))
$pnlConfig.Controls.Add($lblSectionCreds)
$pnlConfig.Controls.SetChildIndex($lblSectionCreds, 0)

$gy = 22
$rbAutoCredentialMode = New-Object System.Windows.Forms.RadioButton
$rbAutoCredentialMode.Text = 'Automatic — use pass-through on domain-joined VMs; use encrypted settings.json on workgroup VMs'
$rbAutoCredentialMode.Location = New-Object System.Drawing.Point(10, $gy)
$rbAutoCredentialMode.AutoSize = $true
$rbAutoCredentialMode.Font = $fontBase
$rbAutoCredentialMode.Checked = $true
$gbCreds.Controls.Add($rbAutoCredentialMode)
$gy += 26

$rbInteractive = New-Object System.Windows.Forms.RadioButton
$rbInteractive.Text = 'Interactive prompt — force alternate credentials each time the collector runs'
$rbInteractive.Location = New-Object System.Drawing.Point(10, $gy)
$rbInteractive.AutoSize = $true
$rbInteractive.Font = $fontBase
$gbCreds.Controls.Add($rbInteractive)
$gy += 26

$rbStoredSettings = New-Object System.Windows.Forms.RadioButton
$rbStoredSettings.Text = 'Encrypted settings.json — always use saved alternate credentials (Windows DPAPI, same user/machine only)'
$rbStoredSettings.Location = New-Object System.Drawing.Point(10, $gy)
$rbStoredSettings.AutoSize = $true
$rbStoredSettings.Font = $fontBase
$gbCreds.Controls.Add($rbStoredSettings)
$gy += 30

$pnlCreds = New-Object System.Windows.Forms.Panel
$pnlCreds.Location = New-Object System.Drawing.Point(10, $gy)
$pnlCreds.Size = New-Object System.Drawing.Size(916, 240)
$pnlCreds.BorderStyle = 'None'
$pnlCreds.BackColor = $clrSurfaceAlt
$pnlCreds.Enabled = $false
Set-PanelBorder $pnlCreds
$gbCreds.Controls.Add($pnlCreds)

$credTabCtrl = New-Object System.Windows.Forms.TabControl
$credTabCtrl.Location = New-Object System.Drawing.Point(6, 6)
$credTabCtrl.Size = New-Object System.Drawing.Size(900, 204)
$credTabCtrl.Font = $fontBase
Set-TabControlBranding $credTabCtrl
$credTabCtrl.ItemSize = New-Object System.Drawing.Size(160, 28)
$pnlCreds.Controls.Add($credTabCtrl)

function New-CredTab {
    param($Title)
    $t = New-Object System.Windows.Forms.TabPage
    $t.Text = $Title
    $t.BackColor = $clrSurfaceAlt
    $t.Padding = New-Object System.Windows.Forms.Padding(6)
    [void]$credTabCtrl.TabPages.Add($t)
    return $t
}

function Add-CredRow {
    param($Parent, $LabelText, $Y, [switch]$Password)
    $lbl = New-Label $LabelText 6 ($Y + 3)
    $Parent.Controls.Add($lbl)
    $tb = New-TextBox 200 $Y 320
    if ($Password) { $tb.UseSystemPasswordChar = $true }
    $Parent.Controls.Add($tb)
    return $tb
}

# Windows (WinRM) tab
$credTabWin = New-CredTab 'Windows (WinRM)'
$py = 16
$credTabWin.Controls.Add((New-Label 'Used for WinRM remoting to Windows servers. Corresponds to AlternateUsername / AlternatePassword in settings.json.' 6 $py))
$py += 26
$txtCredUsername = Add-CredRow $credTabWin 'Windows Username:' $py
$py += 28
$txtCredPassword = Add-CredRow $credTabWin 'Windows Password:' $py -Password
$py += 28
$txtCredPasswordConfirm = Add-CredRow $credTabWin 'Confirm Password:' $py -Password
$py += 28
$chkWinSameAsLinux = New-Object System.Windows.Forms.CheckBox
$chkWinSameAsLinux.Text = 'Copy these credentials to Linux and SQL tabs when saving'
$chkWinSameAsLinux.Location = New-Object System.Drawing.Point(6, $py)
$chkWinSameAsLinux.AutoSize = $true
$chkWinSameAsLinux.Font = $fontBase
$credTabWin.Controls.Add($chkWinSameAsLinux)

# Linux (SSH) tab
$credTabLinux = New-CredTab 'Linux (SSH)'
$py = 16
$credTabLinux.Controls.Add((New-Label 'Used for SSH connections to Linux servers. Corresponds to AlternateLinuxUsername / AlternateLinuxPassword in settings.json.' 6 $py))
$py += 26
$txtLinuxUsername = Add-CredRow $credTabLinux 'Linux SSH Username:' $py
$py += 28
$txtLinuxPassword = Add-CredRow $credTabLinux 'Linux SSH Password:' $py -Password
$py += 28
$txtLinuxPasswordConfirm = Add-CredRow $credTabLinux 'Confirm Password:' $py -Password

# SQL tab
$credTabSql = New-CredTab 'SQL'
$py = 16
$credTabSql.Controls.Add((New-Label 'Used for SQL Server connections via CollectSQLData.ps1. Corresponds to AlternateSqlUsername / AlternateSqlPassword in settings.json.' 6 $py))
$py += 26
$txtSqlUsername = Add-CredRow $credTabSql 'SQL Username:' $py
$py += 28
$txtSqlPassword = Add-CredRow $credTabSql 'SQL Password:' $py -Password
$py += 28
$txtSqlPasswordConfirm = Add-CredRow $credTabSql 'Confirm Password:' $py -Password

# Save / Load / Clear buttons inside pnlCreds
$btnSaveSettings = New-Object System.Windows.Forms.Button
$btnSaveSettings.Text = 'Save Settings'
$btnSaveSettings.Size = New-Object System.Drawing.Size(180, 28)
$btnSaveSettings.Location = New-Object System.Drawing.Point(12, $cy)
$toolTip.SetToolTip($btnSaveSettings, 'Save GUI defaults and encrypt credentials to settings.json using Windows DPAPI')
Set-ButtonStyle $btnSaveSettings -Primary
$pnlConfig.Controls.Add($btnSaveSettings)

$btnLoadSettings = New-Object System.Windows.Forms.Button
$btnLoadSettings.Text = 'Load Settings'
$btnLoadSettings.Size = New-Object System.Drawing.Size(150, 28)
$btnLoadSettings.Location = New-Object System.Drawing.Point(200, $cy)
$toolTip.SetToolTip($btnLoadSettings, 'Load saved GUI defaults and decrypt credentials from settings.json')
Set-ButtonStyle $btnLoadSettings
$pnlConfig.Controls.Add($btnLoadSettings)

$btnClearSettings = New-Object System.Windows.Forms.Button
$btnClearSettings.Text = 'Clear All'
$btnClearSettings.Size = New-Object System.Drawing.Size(80, 28)
$btnClearSettings.Location = New-Object System.Drawing.Point(360, $cy)
$toolTip.SetToolTip($btnClearSettings, 'Clear all credential fields in this form (does not delete settings.json)')
Set-ButtonStyle $btnClearSettings
$pnlConfig.Controls.Add($btnClearSettings)

$lblSettingsStatus = New-Object System.Windows.Forms.Label
$lblSettingsStatus.Location = New-Object System.Drawing.Point(10, 212)
$lblSettingsStatus.Size = New-Object System.Drawing.Size(820, 20)
$lblSettingsStatus.Font = $fontBase
$pnlCreds.Controls.Add($lblSettingsStatus)

$updateCredentialPanelState = {
    $pnlCreds.Enabled = ($rbStoredSettings.Checked -or $rbAutoCredentialMode.Checked)
}
$rbStoredSettings.Add_CheckedChanged($updateCredentialPanelState)
$rbAutoCredentialMode.Add_CheckedChanged($updateCredentialPanelState)
$rbInteractive.Add_CheckedChanged($updateCredentialPanelState)
& $updateCredentialPanelState

$cy += 338

# Compact flow: credentials first, then place LA + Access Check at the bottom.
$gbCreds.Location = New-Object System.Drawing.Point(12, ($gbGeneral.Bottom + 10))
$bottomY = $gbCreds.Bottom + 10
$gbLAOpts.Location = New-Object System.Drawing.Point(12, $bottomY)
$gbAcOpts.Location = New-Object System.Drawing.Point(644, $bottomY)
$lblSectionCreds.Location = New-Object System.Drawing.Point(($gbCreds.Left + 12), ($gbCreds.Top - 4))
$lblSectionLA.Location = New-Object System.Drawing.Point(($gbLAOpts.Left + 12), ($gbLAOpts.Top - 4))
$lblSectionAC.Location = New-Object System.Drawing.Point(($gbAcOpts.Left + 12), ($gbAcOpts.Top - 4))
$cy = [Math]::Max($gbLAOpts.Bottom, $gbAcOpts.Bottom) + 10

# Keep settings action buttons aligned with the final bottom action row.
$btnSaveSettings.Location = New-Object System.Drawing.Point(12, $cy)
$btnLoadSettings.Location = New-Object System.Drawing.Point(200, $cy)
$btnClearSettings.Location = New-Object System.Drawing.Point(360, $cy)

# "Next: Server List" button at bottom of config panel
$btnCfgNext = New-Object System.Windows.Forms.Button
$btnCfgNext.Text = 'Next: Server List →'
$btnCfgNext.Size = New-Object System.Drawing.Size(170, 32)
$btnCfgNext.Location = New-Object System.Drawing.Point(456, ($cy - 2))
Set-ButtonStyle $btnCfgNext -Primary
$btnCfgNext.Add_Click({ $tabControl.SelectedTab = $tabServerList })
$pnlConfig.Controls.Add($btnCfgNext)

# ── Credential helper ─────────────────────────────────────────────────────────
function Test-CredPair {
    param([string]$User, [string]$Pass, [string]$Confirm, [string]$Section)
    if ($User -and -not $Pass) { return "$Section password cannot be empty when username is provided." }
    if ($Pass -and $Pass -ne $Confirm) { return "$Section passwords do not match." }
    return $null
}

function Get-ClientDiscoveryDefaults {
    return [ordered]@{
        OutputDir          = $txtOutputDir.Text.Trim()
        MaxThreads         = [int]$numMaxThreads.Value
        JobTimeoutSeconds  = [int]$numJobTimeoutSeconds.Value
        CheckType          = [string]$cmbCheckType.SelectedItem
        ServerListCsv      = $txtSlCsvPath.Text.Trim()
        ScanIP             = [bool]$chkScanIP.Checked
        SkipEventLog       = [bool]$chkSkipEventLog.Checked
        ServerOnly         = [bool]$chkServerOnly.Checked
        EventLogMaxEvents  = [int]$numEventLogMaxEvents.Value
        LASubscriptionName = $txtLASubscriptionName.Text.Trim()
        LAWorkspaceRG      = $txtLAWorkspaceRG.Text.Trim()
        LAWorkspaceName    = $txtLAWorkspaceName.Text.Trim()
        LATimespan         = [string]$cmbLATimespan.SelectedItem
        AccessCheck        = [ordered]@{
            RdpPort       = [int]$numAcRdpPort.Value
            PsTimeoutSec  = [int]$numAcPsTimeout.Value
            MaxConcurrent = [int]$numAcMaxConcurrent.Value
            Diagnostics   = $false
            UseCreds      = [bool]$chkAcUseCreds.Checked
            FqdnSuffix    = $txtAcFqdnSuffix.Text.Trim()
        }
    }
}

function Set-NumericValueSafe {
    param($Control, $Value)
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return }
    $numericValue = [decimal]$Value
    if ($numericValue -lt $Control.Minimum) { $numericValue = $Control.Minimum }
    if ($numericValue -gt $Control.Maximum) { $numericValue = $Control.Maximum }
    $Control.Value = $numericValue
}

function Apply-ClientDiscoveryDefaults {
    param($Defaults)
    if (-not $Defaults) { return }

    if ($Defaults.OutputDir) { $txtOutputDir.Text = [string]$Defaults.OutputDir }
    Set-NumericValueSafe $numMaxThreads $Defaults.MaxThreads
    Set-NumericValueSafe $numJobTimeoutSeconds $Defaults.JobTimeoutSeconds
    if ($Defaults.CheckType -and $cmbCheckType.Items.Contains([string]$Defaults.CheckType)) {
        $cmbCheckType.SelectedItem = [string]$Defaults.CheckType
    }
    if ($Defaults.ServerListCsv) { $txtSlCsvPath.Text = [string]$Defaults.ServerListCsv }
    if ($null -ne $Defaults.ScanIP) { $chkScanIP.Checked = [bool]$Defaults.ScanIP }
    if ($null -ne $Defaults.SkipEventLog) { $chkSkipEventLog.Checked = [bool]$Defaults.SkipEventLog }
    if ($null -ne $Defaults.ServerOnly) { $chkServerOnly.Checked = [bool]$Defaults.ServerOnly }
    Set-NumericValueSafe $numEventLogMaxEvents $Defaults.EventLogMaxEvents
    if ($null -ne $Defaults.LASubscriptionName) { $txtLASubscriptionName.Text = [string]$Defaults.LASubscriptionName }
    if ($null -ne $Defaults.LAWorkspaceRG) { $txtLAWorkspaceRG.Text = [string]$Defaults.LAWorkspaceRG }
    if ($null -ne $Defaults.LAWorkspaceName) { $txtLAWorkspaceName.Text = [string]$Defaults.LAWorkspaceName }
    if ($Defaults.LATimespan -and $cmbLATimespan.Items.Contains([string]$Defaults.LATimespan)) {
        $cmbLATimespan.SelectedItem = [string]$Defaults.LATimespan
    }

    if ($Defaults.AccessCheck) {
        Set-NumericValueSafe $numAcRdpPort $Defaults.AccessCheck.RdpPort
        Set-NumericValueSafe $numAcPsTimeout $Defaults.AccessCheck.PsTimeoutSec
        Set-NumericValueSafe $numAcMaxConcurrent $Defaults.AccessCheck.MaxConcurrent
        if ($null -ne $Defaults.AccessCheck.UseCreds) { $chkAcUseCreds.Checked = [bool]$Defaults.AccessCheck.UseCreds }
        if ($null -ne $Defaults.AccessCheck.FqdnSuffix) { $txtAcFqdnSuffix.Text = [string]$Defaults.AccessCheck.FqdnSuffix }
    }
}

function Invoke-SaveSettings {
    param([switch]$Quiet)

    $winUser = $txtCredUsername.Text.Trim()
    $winPass = $txtCredPassword.Text
    $winConf = $txtCredPasswordConfirm.Text
    $lnxUser = $txtLinuxUsername.Text.Trim()
    $lnxPass = $txtLinuxPassword.Text
    $lnxConf = $txtLinuxPasswordConfirm.Text
    $sqlUser = $txtSqlUsername.Text.Trim()
    $sqlPass = $txtSqlPassword.Text
    $sqlConf = $txtSqlPasswordConfirm.Text

    if ($chkWinSameAsLinux.Checked) {
        if (-not $lnxUser) { $lnxUser = $winUser; $txtLinuxUsername.Text = $winUser }
        if (-not $lnxPass) { $lnxPass = $winPass; $lnxConf = $winConf; $txtLinuxPassword.Text = $winPass; $txtLinuxPasswordConfirm.Text = $winConf }
        if (-not $sqlUser) { $sqlUser = $winUser; $txtSqlUsername.Text = $winUser }
        if (-not $sqlPass) { $sqlPass = $winPass; $sqlConf = $winConf; $txtSqlPassword.Text = $winPass; $txtSqlPasswordConfirm.Text = $winConf }
    }

    $saveErrors = @(
        (Test-CredPair $winUser $winPass $winConf 'Windows'),
        (Test-CredPair $lnxUser $lnxPass $lnxConf 'Linux'),
        (Test-CredPair $sqlUser $sqlPass $sqlConf 'SQL')
    ) | Where-Object { $_ }

    if ($saveErrors) {
        if (-not $Quiet) {
            [System.Windows.Forms.MessageBox]::Show(($saveErrors -join "`n"), 'Save Settings', 'OK', 'Warning') | Out-Null
        }
        Write-GuiLog "Settings save skipped: $($saveErrors -join '; ')" 'WARN'
        return $false
    }
    try {
        $settings = [ordered]@{}
        $settings['ClientDiscoveryDefaults'] = Get-ClientDiscoveryDefaults
        if (-not [string]::IsNullOrWhiteSpace($txtLASubscriptionName.Text)) { $settings['LASubscriptionName'] = $txtLASubscriptionName.Text.Trim() }
        if (-not [string]::IsNullOrWhiteSpace($txtLAWorkspaceRG.Text)) { $settings['LAWorkspaceRG'] = $txtLAWorkspaceRG.Text.Trim() }
        if (-not [string]::IsNullOrWhiteSpace($txtLAWorkspaceName.Text)) { $settings['LAWorkspaceName'] = $txtLAWorkspaceName.Text.Trim() }
        if ($cmbLATimespan.SelectedItem) { $settings['LATimespan'] = [string]$cmbLATimespan.SelectedItem }
        if ($winUser) {
            $settings['AlternateUsername'] = $winUser
            $settings['AlternatePassword'] = Protect-StringDPAPI -PlainText $winPass
        }
        if ($lnxUser) {
            $settings['AlternateLinuxUsername'] = $lnxUser
            $settings['AlternateLinuxPassword'] = Protect-StringDPAPI -PlainText $lnxPass
        }
        if ($sqlUser) {
            $settings['AlternateSqlUsername'] = $sqlUser
            $settings['AlternateSqlPassword'] = Protect-StringDPAPI -PlainText $sqlPass
        }
        $settings | ConvertTo-Json -Depth 3 | Out-File -FilePath $SettingsFile -Encoding UTF8 -Force
        $savedSections = @(
            'Defaults'
            if ($winUser) { 'Windows' }
            if ($lnxUser) { 'Linux' }
            if ($sqlUser) { 'SQL' }
            if ($txtLASubscriptionName.Text.Trim() -or $txtLAWorkspaceRG.Text.Trim() -or $txtLAWorkspaceName.Text.Trim()) { 'Log Analytics' }
        )
        $lblSettingsStatus.Text = "✔  Saved ($($savedSections -join ', ')) → $SettingsFile"
        $lblSettingsStatus.ForeColor = [System.Drawing.Color]::DarkGreen
        Write-GuiLog "Settings saved to $SettingsFile ($($savedSections -join ', '))."
        if (-not $Quiet) {
            Set-Status "Settings saved."
        }
        return $true
    }
    catch {
        if (-not $Quiet) {
            [System.Windows.Forms.MessageBox]::Show("Failed to save settings: $($_.Exception.Message)", 'Save Settings', 'OK', 'Error') | Out-Null
        }
        Write-GuiLog "Failed to save settings: $($_.Exception.Message)" 'ERROR'
        return $false
    }
}

$btnSaveSettings.Add_Click({ [void](Invoke-SaveSettings) })

function Invoke-AutoSaveSettingsForCommand {
    param([string]$Label = 'Run')

    if (Invoke-SaveSettings) {
        return $true
    }

    [System.Windows.Forms.MessageBox]::Show(
        "Settings could not be saved. $Label was not launched so it does not run with stale settings.json values.",
        $Label, 'OK', 'Warning') | Out-Null
    return $false
}

function Test-LocalComputerDomainJoined {
    try {
        $computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
        return [bool]$computerSystem.PartOfDomain
    }
    catch {
        Write-GuiLog "Unable to determine local domain membership; assuming domain-joined for pass-through credential default. Details: $($_.Exception.Message)" 'WARN'
        return $true
    }
}

function Test-SettingsFileHasWindowsCredentials {
    if (-not (Test-Path -LiteralPath $SettingsFile -PathType Leaf)) { return $false }

    try {
        $settings = Get-Content -LiteralPath $SettingsFile -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        return ($settings.PSObject.Properties.Name -contains 'AlternateUsername' -and
            $settings.PSObject.Properties.Name -contains 'AlternatePassword' -and
            -not [string]::IsNullOrWhiteSpace([string]$settings.AlternateUsername) -and
            -not [string]::IsNullOrWhiteSpace([string]$settings.AlternatePassword))
    }
    catch {
        Write-GuiLog "Unable to inspect settings.json for Windows alternate credentials: $($_.Exception.Message)" 'WARN'
        return $false
    }
}

function Resolve-WindowsCredentialLaunchTokens {
    param(
        [string]$PersonalJsonParameterName = '-PersonalJSON',
        [string]$Label = 'Run'
    )

    if ($rbStoredSettings.Checked) {
        if (Test-SettingsFileHasWindowsCredentials) {
            return [PSCustomObject]@{ CanLaunch = $true; Tokens = @($PersonalJsonParameterName, $SettingsFile); Mode = 'Saved alternate credentials' }
        }

        [System.Windows.Forms.MessageBox]::Show(
            "Saved credentials were selected, but settings.json does not contain encrypted Windows credentials. Enter Windows credentials on the Configuration tab and click Save Settings before launching.",
            $Label, 'OK', 'Warning') | Out-Null
        Set-Status "Windows credentials are required in settings.json."
        return [PSCustomObject]@{ CanLaunch = $false; Tokens = @(); Mode = 'Missing saved credentials' }
    }

    if ($rbInteractive.Checked) {
        return [PSCustomObject]@{ CanLaunch = $true; Tokens = @('-UseCredential'); Mode = 'Interactive credential prompt' }
    }

    $isDomainJoined = Test-LocalComputerDomainJoined
    $hasSavedWindowsCreds = Test-SettingsFileHasWindowsCredentials
    if ($isDomainJoined) {
        if ($hasSavedWindowsCreds) {
            # Collectors prefer pass-through first on domain-joined machines, then use saved credentials as fallback.
            return [PSCustomObject]@{ CanLaunch = $true; Tokens = @($PersonalJsonParameterName, $SettingsFile); Mode = 'Pass-through with saved alternate fallback' }
        }
        return [PSCustomObject]@{ CanLaunch = $true; Tokens = @(); Mode = 'Pass-through current user' }
    }

    if ($hasSavedWindowsCreds) {
        return [PSCustomObject]@{ CanLaunch = $true; Tokens = @($PersonalJsonParameterName, $SettingsFile); Mode = 'Saved alternate credentials (workgroup/non-domain)' }
    }

    [System.Windows.Forms.MessageBox]::Show(
        "This machine does not appear to be domain-joined, so pass-through credentials will not work reliably. Enter Windows credentials in the Configuration tab, click Save Settings, then run $Label again.",
        $Label, 'OK', 'Warning') | Out-Null
    $rbAutoCredentialMode.Checked = $true
    $pnlCreds.Enabled = $true
    $tabControl.SelectedTab = $tabConfiguration
    $txtCredUsername.Focus()
    Set-Status "Save Windows credentials before launching from a non-domain-joined machine."
    return [PSCustomObject]@{ CanLaunch = $false; Tokens = @(); Mode = 'Missing saved credentials on non-domain machine' }
}

function Invoke-LoadSettings {
    if (-not (Test-Path $SettingsFile)) {
        $lblSettingsStatus.Text = "✘  settings.json not found at: $SettingsFile"
        $lblSettingsStatus.ForeColor = [System.Drawing.Color]::Red
        return
    }
    try {
        $d = Get-Content $SettingsFile -Raw | ConvertFrom-Json
        $loaded = @()
        $warnings = @()
        $autoLoadCsvPath = $null
        if ($d.PSObject.Properties['ClientDiscoveryDefaults']) {
            Apply-ClientDiscoveryDefaults -Defaults $d.ClientDiscoveryDefaults
            $loaded += 'Defaults'
            if ($d.ClientDiscoveryDefaults.ServerListCsv) {
                $autoLoadCsvPath = [string]$d.ClientDiscoveryDefaults.ServerListCsv
            }
        }
        if ($d.LASubscriptionName) { $txtLASubscriptionName.Text = [string]$d.LASubscriptionName }
        if ($d.LAWorkspaceRG) { $txtLAWorkspaceRG.Text = [string]$d.LAWorkspaceRG }
        if ($d.LAWorkspaceName) { $txtLAWorkspaceName.Text = [string]$d.LAWorkspaceName }
        if ($d.LATimespan -and $cmbLATimespan.Items.Contains([string]$d.LATimespan)) { $cmbLATimespan.SelectedItem = [string]$d.LATimespan }
        if ($d.LASubscriptionName -or $d.LAWorkspaceRG -or $d.LAWorkspaceName) { $loaded += 'Log Analytics' }
        if ($d.AlternateUsername) {
            $txtCredUsername.Text = $d.AlternateUsername
            $dec = Unprotect-StringDPAPI -Base64Cipher $d.AlternatePassword
            if ($dec) { $txtCredPassword.Text = $dec; $txtCredPasswordConfirm.Text = $dec; $loaded += 'Windows' }
            else { $warnings += 'Windows password could not be decrypted' }
        }
        if ($d.AlternateLinuxUsername) {
            $txtLinuxUsername.Text = $d.AlternateLinuxUsername
            $dec = Unprotect-StringDPAPI -Base64Cipher $d.AlternateLinuxPassword
            if ($dec) { $txtLinuxPassword.Text = $dec; $txtLinuxPasswordConfirm.Text = $dec; $loaded += 'Linux' }
            else { $warnings += 'Linux password could not be decrypted' }
        }
        if ($d.AlternateSqlUsername) {
            $txtSqlUsername.Text = $d.AlternateSqlUsername
            $dec = Unprotect-StringDPAPI -Base64Cipher $d.AlternateSqlPassword
            if ($dec) { $txtSqlPassword.Text = $dec; $txtSqlPasswordConfirm.Text = $dec; $loaded += 'SQL' }
            else { $warnings += 'SQL password could not be decrypted' }
        }
        $rbStoredSettings.Checked = $true
        $pnlCreds.Enabled = $true
        if ($autoLoadCsvPath -and (Test-Path -LiteralPath $autoLoadCsvPath)) {
            $txtSlCsvPath.Text = $autoLoadCsvPath
            Invoke-LoadCsv
        }
        elseif ($autoLoadCsvPath) {
            $warnings += "Saved CSV not found: $autoLoadCsvPath"
        }
        if ($warnings) {
            $lblSettingsStatus.Text = "⚠  Loaded ($($loaded -join ', ')) — Warnings: $($warnings -join '; ')"
            $lblSettingsStatus.ForeColor = [System.Drawing.Color]::DarkOrange
        }
        else {
            $lblSettingsStatus.Text = "✔  Loaded ($($loaded -join ', ')) from: $SettingsFile"
            $lblSettingsStatus.ForeColor = [System.Drawing.Color]::DarkGreen
        }
        Set-Status "Settings loaded."
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to load settings: $($_.Exception.Message)", 'Load Settings', 'OK', 'Error') | Out-Null
    }
}

$btnLoadSettings.Add_Click({ Invoke-LoadSettings })

$btnClearSettings.Add_Click({
        foreach ($tb in @($txtCredUsername, $txtCredPassword, $txtCredPasswordConfirm,
                $txtLinuxUsername, $txtLinuxPassword, $txtLinuxPasswordConfirm,
                $txtSqlUsername, $txtSqlPassword, $txtSqlPasswordConfirm)) {
            $tb.Text = ''
        }
        $lblSettingsStatus.Text = ''
        Set-Status "All credential fields cleared."
    })

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3 — SERVER LIST
# ═══════════════════════════════════════════════════════════════════════════════
$script:LoadedCsvPath = $null
$script:ReportGridColumns = @('ServerName', 'OSType', 'OverallStatus', 'DataCollection', 'SQLConfig', 'IISConfig', 'LogAnalytics', 'AccessCheck', 'Notes', 'DataCollectionPath', 'SQLConfigPath', 'IISConfigPath', 'LogAnalyticsPath', 'ReportPath')
$script:ArtifactResultColumns = @('DataCollection', 'SQLConfig', 'IISConfig', 'LogAnalytics')
$script:ArtifactReportTableCellCount = 9

# ── CSV Toolbar (full width, across the top) ───────────────────────────────────
$pnlToolbar = New-Object System.Windows.Forms.Panel
$pnlToolbar.Location = New-Object System.Drawing.Point(0, 0)
$pnlToolbar.Size = New-Object System.Drawing.Size(972, 44)
$pnlToolbar.Anchor = 'Top,Left,Right'
$pnlToolbar.BackColor = $clrSurfaceAlt
Set-PanelBorder $pnlToolbar
$tabServerList.Controls.Add($pnlToolbar)
[void](Add-AccentStrip $pnlToolbar $clrAccent)

$lblCsvCommand = New-Object System.Windows.Forms.Label
$lblCsvCommand.Text = 'Server source'
$lblCsvCommand.SetBounds(14, 12, 88, 20)
$lblCsvCommand.Font = $fontBold
$lblCsvCommand.ForeColor = $clrNavy
$pnlToolbar.Controls.Add($lblCsvCommand)

$btnBrowseSlCsv = New-Object System.Windows.Forms.Button
$btnBrowseSlCsv.Text = 'LoadCSV'
$btnBrowseSlCsv.Size = New-Object System.Drawing.Size(66, 24)
$btnBrowseSlCsv.Location = New-Object System.Drawing.Point(100, 10)
Set-ButtonStyle $btnBrowseSlCsv
$pnlToolbar.Controls.Add($btnBrowseSlCsv)

$txtSlCsvPath = New-TextBox 172 11 250
$pnlToolbar.Controls.Add($txtSlCsvPath)

$btnLoadResults = New-Object System.Windows.Forms.Button
$btnLoadResults.Text = 'Load Results'
$btnLoadResults.Size = New-Object System.Drawing.Size(84, 24)
$btnLoadResults.Location = New-Object System.Drawing.Point(428, 10)
Set-ButtonStyle $btnLoadResults
$pnlToolbar.Controls.Add($btnLoadResults)

$chkLoadResultsLatest = New-Object System.Windows.Forms.CheckBox
$chkLoadResultsLatest.Text = 'Latest'
$chkLoadResultsLatest.Checked = $true
$chkLoadResultsLatest.AutoSize = $true
$chkLoadResultsLatest.Font = $fontBase
$chkLoadResultsLatest.Location = New-Object System.Drawing.Point(518, 13)
$pnlToolbar.Controls.Add($chkLoadResultsLatest)

$chkLoadResultsAll = New-Object System.Windows.Forms.CheckBox
$chkLoadResultsAll.Text = 'All'
$chkLoadResultsAll.Checked = $false
$chkLoadResultsAll.AutoSize = $true
$chkLoadResultsAll.Font = $fontBase
$chkLoadResultsAll.Location = New-Object System.Drawing.Point(572, 13)
$pnlToolbar.Controls.Add($chkLoadResultsAll)

$btnSaveCsv = New-Object System.Windows.Forms.Button
$btnSaveCsv.Text = 'Save'
$btnSaveCsv.Size = New-Object System.Drawing.Size(54, 24)
$btnSaveCsv.Location = New-Object System.Drawing.Point(620, 10)
Set-ButtonStyle $btnSaveCsv
$pnlToolbar.Controls.Add($btnSaveCsv)

$btnOpenSample = New-Object System.Windows.Forms.Button
$btnOpenSample.Text = 'Sample'
$btnOpenSample.Size = New-Object System.Drawing.Size(60, 24)
$btnOpenSample.Location = New-Object System.Drawing.Point(680, 10)
Set-ButtonStyle $btnOpenSample
$pnlToolbar.Controls.Add($btnOpenSample)

$btnAddRow = New-Object System.Windows.Forms.Button
$btnAddRow.Text = '+ Row'
$btnAddRow.Size = New-Object System.Drawing.Size(54, 24)
$btnAddRow.Location = New-Object System.Drawing.Point(746, 10)
Set-ButtonStyle $btnAddRow
$pnlToolbar.Controls.Add($btnAddRow)

$btnDeleteRow = New-Object System.Windows.Forms.Button
$btnDeleteRow.Text = '- Row'
$btnDeleteRow.Size = New-Object System.Drawing.Size(54, 24)
$btnDeleteRow.Location = New-Object System.Drawing.Point(806, 10)
Set-ButtonStyle $btnDeleteRow
$pnlToolbar.Controls.Add($btnDeleteRow)

$btnSelectAll = New-Object System.Windows.Forms.Button
$btnSelectAll.Text = 'Select All'
$btnSelectAll.Size = New-Object System.Drawing.Size(50, 24)
$btnSelectAll.Location = New-Object System.Drawing.Point(866, 10)
Set-ButtonStyle $btnSelectAll
$pnlToolbar.Controls.Add($btnSelectAll)

$btnUnselectAll = New-Object System.Windows.Forms.Button
$btnUnselectAll.Text = 'Clear'
$btnUnselectAll.Size = New-Object System.Drawing.Size(50, 24)
$btnUnselectAll.Location = New-Object System.Drawing.Point(922, 10)
Set-ButtonStyle $btnUnselectAll
$pnlToolbar.Controls.Add($btnUnselectAll)

# ── Executive summary tiles ───────────────────────────────────────────────────
$pnlSummary = New-Object System.Windows.Forms.Panel
$pnlSummary.Location = New-Object System.Drawing.Point(0, 54)
$pnlSummary.Size = New-Object System.Drawing.Size(972, 78)
$pnlSummary.Anchor = 'Top,Left,Right'
$pnlSummary.BackColor = $clrBackground
$tabServerList.Controls.Add($pnlSummary)

$metricTotal = New-MetricTile 'Total servers' '0' 'loaded' 0 4
$metricWindows = New-MetricTile 'Windows' '0' 'WinRM' 194 4
$metricLinux = New-MetricTile 'Linux/Unknown' '0' 'SSH/unknown' 388 4
$metricComplete = New-MetricTile 'Complete' '0' 'results' 582 4
$metricIssues = New-MetricTile 'Needs attention' '0' 'review' 776 4
foreach ($metric in @($metricTotal, $metricWindows, $metricLinux, $metricComplete, $metricIssues)) {
    $pnlSummary.Controls.Add($metric.Panel)
}

function Set-MetricValue {
    param($Metric, [string]$Value, [string]$Hint = $null, [System.Drawing.Color]$Color = $null)
    if ($Metric -and $Metric.ValueLabel) { $Metric.ValueLabel.Text = $Value }
    if ($Metric -and $Metric.HintLabel -and $null -ne $Hint) { $Metric.HintLabel.Text = $Hint }
    if ($Metric -and $Metric.ValueLabel -and $null -ne $Color) { $Metric.ValueLabel.ForeColor = $Color }
}

function Update-DashboardMetrics {
    param(
        [int]$Total = 0,
        [int]$Windows = 0,
        [int]$Linux = 0,
        [int]$Complete = 0,
        [int]$Attention = 0,
        [string]$Mode = 'loaded'
    )
    Set-MetricValue $metricTotal ([string]$Total) $Mode $clrAccentDark
    Set-MetricValue $metricWindows ([string]$Windows) 'WinRM' $clrAccentDark
    Set-MetricValue $metricLinux ([string]$Linux) 'SSH/unknown' $clrAccentDark
    Set-MetricValue $metricComplete ([string]$Complete) 'results' $clrSuccess
    $attentionColor = if ($Attention -gt 0) { $clrDanger } else { $clrSuccess }
    Set-MetricValue $metricIssues ([string]$Attention) 'review' $attentionColor
}

function Update-DashboardMetricsFromGrid {
    if (-not $dgv -or -not $dgv.DataSource) {
        Update-DashboardMetrics
        return
    }

    $dt = $dgv.DataSource
    $total = 0
    $windows = 0
    $linuxOrUnknown = 0
    $complete = 0
    $attention = 0
    $hasStatusColumn = $false
    try { $hasStatusColumn = $dt.Columns.Contains('OverallStatus') } catch {}

    foreach ($row in @($dt.Rows)) {
        if ($row.RowState -eq [System.Data.DataRowState]::Deleted) { continue }
        $total++
        $osText = ''
        try {
            if ($dt.Columns.Contains('OSType')) { $osText = [string]$row['OSType'] }
            elseif ($dt.Columns.Contains('OS')) { $osText = [string]$row['OS'] }
        }
        catch {}

        if ($osText -imatch 'windows') { $windows++ }
        else { $linuxOrUnknown++ }

        if ($hasStatusColumn) {
            $status = [string]$row['OverallStatus']
            if ($status -ieq 'Complete') { $complete++ }
            elseif ($status -match '\S') { $attention++ }
        }
        elseif ([string]::IsNullOrWhiteSpace($osText)) {
            $attention++
        }
    }

    Update-DashboardMetrics -Total $total -Windows $windows -Linux $linuxOrUnknown -Complete $complete -Attention $attention -Mode 'editing'
}

# ── Left sidebar ───────────────────────────────────────────────────────────────
$pnlSidebar = New-Object System.Windows.Forms.Panel
$pnlSidebar.Location = New-Object System.Drawing.Point(0, 138)
$pnlSidebar.Size = New-Object System.Drawing.Size(230, 508)
$pnlSidebar.Anchor = 'Top,Left'
$pnlSidebar.BackColor = $clrSurfaceAlt
Set-PanelBorder $pnlSidebar
$tabServerList.Controls.Add($pnlSidebar)
[void](Add-AccentStrip $pnlSidebar $clrAccentDark)

$sy = 6

# ── Helper: full-width sidebar button ─────────────────────────────────────────
function New-StepButton {
    param([string]$Text, [switch]$Primary)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Size = New-Object System.Drawing.Size(216, 30)
    $b.Location = New-Object System.Drawing.Point(6, $sy)
    $b.Font = $fontBase
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 1
    $b.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $b.Padding = New-Object System.Windows.Forms.Padding(0)
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    if ($Primary) {
        $b.BackColor = $clrAccent
        $b.ForeColor = [System.Drawing.Color]::White
        $b.Font = $fontBold
        $b.FlatAppearance.BorderColor = $clrAccent
    }
    else {
        $b.BackColor = $clrSurfaceAlt
        $b.ForeColor = $clrText
        $b.FlatAppearance.BorderColor = $clrBorder
    }
    $pnlSidebar.Controls.Add($b)
    return $b
}

# ── Helper: half-width sidebar button (for pairs like SQL|IIS) ─────────────────
function New-AdditionalButton {
    param([string]$Text, [int]$Col)  # Col: 0 = left, 1 = right
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Size = New-Object System.Drawing.Size(104, 26)
    $b.Location = New-Object System.Drawing.Point((6 + $Col * 108), $sy)
    $b.Font = $fontBase
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 1
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $b.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $b.FlatAppearance.BorderColor = $clrBorder
    $b.BackColor = $clrSurfaceAlt
    $b.ForeColor = $clrText
    $pnlSidebar.Controls.Add($b)
    return $b
}

function New-WorkflowBadge {
    param([string]$NumberGlyph, [int]$Y)
    $badge = New-Object System.Windows.Forms.Label
    $badge.Text = $NumberGlyph
    $badge.SetBounds(6, ($Y + 1), 26, 28)
    $badge.Font = New-Object System.Drawing.Font('Segoe UI Symbol', 16, [System.Drawing.FontStyle]::Bold)
    $badge.ForeColor = $clrAccentDark
    $badge.BackColor = $clrSurfaceAlt
    $badge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $pnlSidebar.Controls.Add($badge)
    return $badge
}

# ── Options checkboxes (moved from Configuration tab) ─────────────────────────
$lblOptions = New-Label 'Options' 6 $sy -Bold
$pnlSidebar.Controls.Add($lblOptions)
$sy += 22

$chkScanIP = New-Object System.Windows.Forms.CheckBox
$chkScanIP.Text = 'Scan IP Addresses'
$chkScanIP.Location = New-Object System.Drawing.Point(6, $sy)
$chkScanIP.AutoSize = $true
$chkScanIP.Font = $fontBase
$pnlSidebar.Controls.Add($chkScanIP)
$toolTip.SetToolTip($chkScanIP, 'Scan for hardcoded IP addresses in server configuration files (-ScanIP)')
$sy += 24

$chkSkipEventLog = New-Object System.Windows.Forms.CheckBox
$chkSkipEventLog.Text = 'Skip Event Log'
$chkSkipEventLog.Location = New-Object System.Drawing.Point(6, $sy)
$chkSkipEventLog.AutoSize = $true
$chkSkipEventLog.Font = $fontBase
$pnlSidebar.Controls.Add($chkSkipEventLog)
$toolTip.SetToolTip($chkSkipEventLog, 'Skip Windows Event Log collection (-SkipEventLog). Default collects up to 1000 events per log.')
$sy += 28

$lblMaxThreads = New-Label 'Max Threads:' 6 $sy
$pnlSidebar.Controls.Add($lblMaxThreads)
$numMaxThreads = New-Object System.Windows.Forms.NumericUpDown
$numMaxThreads.Location = New-Object System.Drawing.Point(138, $sy)
$numMaxThreads.Size = New-Object System.Drawing.Size(70, 22)
$numMaxThreads.Minimum = 1
$numMaxThreads.Maximum = 50
$numMaxThreads.Value = 10
$numMaxThreads.Font = $fontBase
$pnlSidebar.Controls.Add($numMaxThreads)
$toolTip.SetToolTip($numMaxThreads, 'Concurrent connections per OS type. Keep this conservative for client networks.')
$sy += 24

$lblJobTimeout = New-Label 'Job Timeout (sec):' 6 $sy
$pnlSidebar.Controls.Add($lblJobTimeout)
$numJobTimeoutSeconds = New-Object System.Windows.Forms.NumericUpDown
$numJobTimeoutSeconds.Location = New-Object System.Drawing.Point(138, $sy)
$numJobTimeoutSeconds.Size = New-Object System.Drawing.Size(70, 22)
$numJobTimeoutSeconds.Minimum = 60
$numJobTimeoutSeconds.Maximum = 86400
$numJobTimeoutSeconds.Increment = 60
$numJobTimeoutSeconds.Value = 600
$numJobTimeoutSeconds.Font = $fontBase
$pnlSidebar.Controls.Add($numJobTimeoutSeconds)
$toolTip.SetToolTip($numJobTimeoutSeconds, 'Seconds to wait for each Windows remote collection job before it is terminated. Default: 600 seconds / 10 minutes.')
$sy += 24

# Hidden stubs kept for script compatibility
$chkServerOnly = New-Object System.Windows.Forms.CheckBox; $chkServerOnly.Visible = $false; $pnlSidebar.Controls.Add($chkServerOnly)
$txtScanIPPath = New-Object System.Windows.Forms.TextBox; $txtScanIPPath.Visible = $false; $pnlSidebar.Controls.Add($txtScanIPPath)
$numEventLogMaxEvents = New-Object System.Windows.Forms.NumericUpDown; $numEventLogMaxEvents.Visible = $false; $numEventLogMaxEvents.Minimum = 0; $numEventLogMaxEvents.Maximum = 100000; $numEventLogMaxEvents.Value = 1000; $pnlSidebar.Controls.Add($numEventLogMaxEvents)

$sy += 6
# ── Query Servers label ────────────────────────────────────────────────────────
$lblSteps = New-Label 'Query Servers' 6 $sy -Bold
$pnlSidebar.Controls.Add($lblSteps)
$sy += 22

$btnStepAccess = New-StepButton 'Access Check' -Primary
$toolTip.SetToolTip($btnStepAccess, 'Test WinRM/RDP/SSH connectivity and verify admin access. Uses selected rows, or all rows if none selected.')
$btnStepAccess.Location = New-Object System.Drawing.Point(34, $btnStepAccess.Location.Y)
$btnStepAccess.Size = New-Object System.Drawing.Size(188, $btnStepAccess.Height)
[void](New-WorkflowBadge '①' $btnStepAccess.Location.Y)
$sy += 34

$btnStepDataAll = New-StepButton 'Run All Data Collectors' -Primary
$toolTip.SetToolTip($btnStepDataAll, 'Run the full ServerDataCollector (Windows + Linux + SQL + IIS + EventLog). Uses selected rows, or all rows if none selected.')
$btnStepDataAll.Location = New-Object System.Drawing.Point(34, $btnStepDataAll.Location.Y)
$btnStepDataAll.Size = New-Object System.Drawing.Size(188, $btnStepDataAll.Height)
[void](New-WorkflowBadge '②' $btnStepDataAll.Location.Y)
$sy += 34

$sy += 6
$lblLogAnalytics = New-Label 'Collect Log Analytics Data' 6 $sy -Bold
$pnlSidebar.Controls.Add($lblLogAnalytics)
$sy += 22

$btnLogAnalytics = New-StepButton 'Export Log Analytics'
$toolTip.SetToolTip($btnLogAnalytics, 'Run Avanade-ExportLogAnalyticsData.ps1 for selected grid rows, or all rows if none are selected.')
$btnLogAnalytics.Location = New-Object System.Drawing.Point(34, $btnLogAnalytics.Location.Y)
$btnLogAnalytics.Size = New-Object System.Drawing.Size(188, $btnLogAnalytics.Height)
Set-ButtonStyle $btnLogAnalytics -Primary
[void](New-WorkflowBadge '③' $btnLogAnalytics.Location.Y)
$sy += 34

$sy += 6
$lblAdditionalData = New-Label 'Additonal Data' 6 $sy -Bold
$pnlSidebar.Controls.Add($lblAdditionalData)
$sy += 22

$btnDnsExport = New-StepButton 'Export DNS Data'
$toolTip.SetToolTip($btnDnsExport, 'Collect DNS zones and records from the local primary DNS server on this workstation and save them under Artifacts\AdditionalData\DNSExports.')
$btnDnsExport.Location = New-Object System.Drawing.Point(34, $btnDnsExport.Location.Y)
$btnDnsExport.Size = New-Object System.Drawing.Size(188, $btnDnsExport.Height)
Set-ButtonStyle $btnDnsExport -Primary
[void](New-WorkflowBadge '④' $btnDnsExport.Location.Y)
$sy += 34

# ── Reporting ──────────────────────────────────────────────────────────────────
$sy += 6
$lblReporting = New-Label 'Reporting' 6 $sy -Bold
$pnlSidebar.Controls.Add($lblReporting)
$sy += 22

$btnArtifactReport = New-StepButton 'Generate Artifact Report'
$toolTip.SetToolTip($btnArtifactReport, 'Generate a client-facing HTML report for selected grid rows, or all current grid rows if none are selected.')
$btnArtifactReport.Location = New-Object System.Drawing.Point(34, $btnArtifactReport.Location.Y)
$btnArtifactReport.Size = New-Object System.Drawing.Size(188, $btnArtifactReport.Height)
Set-ButtonStyle $btnArtifactReport -Primary
[void](New-WorkflowBadge '⑤' $btnArtifactReport.Location.Y)
$sy += 34

$btnZipOutput = New-StepButton 'ZIP Output for Delivery'
$toolTip.SetToolTip($btnZipOutput, 'Compress the entire Artifacts directory into a ZIP file ready to send to Avanade.')
$btnZipOutput.Location = New-Object System.Drawing.Point(34, $btnZipOutput.Location.Y)
$btnZipOutput.Size = New-Object System.Drawing.Size(188, $btnZipOutput.Height)
Set-ButtonStyle $btnZipOutput -Primary
[void](New-WorkflowBadge '⑥' $btnZipOutput.Location.Y)
$sy += 34

# ── Open Output Folder ─────────────────────────────────────────────────────────
$sy += 4
$btnOpenOutput = New-Object System.Windows.Forms.Button
$btnOpenOutput.Text = 'Open Output Folder'
$btnOpenOutput.Size = New-Object System.Drawing.Size(216, 28)
$btnOpenOutput.Location = New-Object System.Drawing.Point(6, $sy)
Set-ButtonStyle $btnOpenOutput
$pnlSidebar.Controls.Add($btnOpenOutput)
$sy += 32

$sy += 6
$lblAddData = New-Label 'Individual Data Collectors' 6 $sy -Bold
$pnlSidebar.Controls.Add($lblAddData)
$sy += 22

$btnStepDataLight = New-StepButton 'Server Data Only'
$toolTip.SetToolTip($btnStepDataLight, 'Collect basic server inventory only — skips SQL, IIS, EventLog. Runs against Windows and Linux. Uses selected rows, or all rows if none selected.')
$sy += 34

$btnCollectSQL = New-AdditionalButton 'Collect SQL' 0
$toolTip.SetToolTip($btnCollectSQL, 'Run CollectSQLData.ps1 to gather SQL Server configuration data.')
$btnCollectIIS = New-AdditionalButton 'Collect IIS' 1
$toolTip.SetToolTip($btnCollectIIS, 'Run CollectIISData.ps1 to gather IIS web server configuration data.')
$sy += 30
$btnEventLog = New-AdditionalButton 'Event Log'   0
$toolTip.SetToolTip($btnEventLog, 'Collect Windows Event Log data. Max events controlled in Configuration tab.')
$btnIPScan = New-AdditionalButton 'IP Scan'     1
$toolTip.SetToolTip($btnIPScan, 'Scan for hardcoded IP addresses in server configuration files.')
$sy += 34

$lblConfigInfo = New-Object System.Windows.Forms.Label
$lblConfigInfo.Text = 'If rows are selected, only those run. Otherwise all servers are used.'
$lblConfigInfo.Location = New-Object System.Drawing.Point(6, $sy)
$lblConfigInfo.Size = New-Object System.Drawing.Size(216, 36)
$lblConfigInfo.Font = $fontBase
$lblConfigInfo.ForeColor = $clrMuted
$pnlSidebar.Controls.Add($lblConfigInfo)

$pnlSidebar.Height = $lblConfigInfo.Bottom + 12

$toolTip.SetToolTip($btnOpenOutput, 'Open the configured output directory in Windows Explorer')

$btnOpenOutput.Add_Click({
        $od = $txtOutputDir.Text.Trim()
        if ($od -and (Test-Path $od)) { Start-Process explorer.exe $od }
        else { Set-Status "Output directory not found: $od" }
    })

function Get-ResultCellPalette {
    param([string]$ColumnName, [string]$Value)

    $v = ([string]$Value).Trim()
    if (-not $v) { return $null }

    $okBack = [System.Drawing.Color]::FromArgb(232, 245, 233)
    $okFore = [System.Drawing.Color]::FromArgb(34, 134, 58)
    $warnBack = [System.Drawing.Color]::FromArgb(255, 248, 225)
    $warnFore = [System.Drawing.Color]::FromArgb(183, 121, 31)
    $badBack = [System.Drawing.Color]::FromArgb(255, 235, 238)
    $badFore = [System.Drawing.Color]::FromArgb(214, 66, 66)

    if ($ColumnName -eq 'OverallStatus') {
        if ($v -imatch '^Complete$') { return @{ Back = $okBack; Fore = $okFore } }
        if ($v -imatch '^Partial$') { return @{ Back = $warnBack; Fore = $warnFore } }
        if ($v -imatch 'Access Failed|Failed|No Data') { return @{ Back = $badBack; Fore = $badFore } }
    }

    if ($ColumnName -in @('DataCollection', 'SQLConfig', 'IISConfig', 'LogAnalytics', 'AccessCheck')) {
        if ($v -imatch 'Collected|OK|Complete|Found') { return @{ Back = $okBack; Fore = $okFore } }
        if ($v -imatch 'Not Exported|N/A|Not Checked|Partial|Missing') { return @{ Back = $warnBack; Fore = $warnFore } }
        if ($v -imatch 'Failed|Error') { return @{ Back = $badBack; Fore = $badFore } }
    }

    return $null
}

function Get-ArtifactPathColumnName {
    param([string]$ArtifactColumn)
    switch ($ArtifactColumn) {
        'DataCollection' { return 'DataCollectionPath' }
        'SQLConfig' { return 'SQLConfigPath' }
        'IISConfig' { return 'IISConfigPath' }
        'LogAnalytics' { return 'LogAnalyticsPath' }
        default { return $null }
    }
}

# ── Right: DataGridView ────────────────────────────────────────────────────────
$dgv = New-Object System.Windows.Forms.DataGridView
$dgv.Location = New-Object System.Drawing.Point(242, 138)
$dgv.Size = New-Object System.Drawing.Size(730, 508)
$dgv.Anchor = 'Top,Left,Right'
$dgv.AllowUserToAddRows = $false
$dgv.AllowUserToDeleteRows = $false
$dgv.ReadOnly = $false
$dgv.AutoSizeColumnsMode = 'Fill'
$dgv.SelectionMode = 'FullRowSelect'
$dgv.MultiSelect = $true
$dgv.RowHeadersVisible = $false
$dgv.Font = $fontBase
$dgv.BackgroundColor = $clrSurface
$dgv.BorderStyle = 'None'
$dgv.CellBorderStyle = [System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal
$dgv.GridColor = $clrBorder
$dgv.EnableHeadersVisualStyles = $false
$dgv.ColumnHeadersDefaultCellStyle.BackColor = $clrSky
$dgv.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::White
$dgv.ColumnHeadersDefaultCellStyle.Font = $fontBold
$dgv.ColumnHeadersDefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(8, 0, 8, 0)
$dgv.ColumnHeadersHeight = 38
$dgv.DefaultCellStyle.BackColor = $clrSurface
$dgv.DefaultCellStyle.ForeColor = $clrText
$dgv.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(255, 236, 224)
$dgv.DefaultCellStyle.SelectionForeColor = $clrText
$dgv.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
$dgv.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(252, 248, 245)
$dgv.RowTemplate.Height = 30
$tabServerList.Controls.Add($dgv)

$serverListContentBottom = [Math]::Max(($pnlSidebar.Bottom + 12), ($dgv.Bottom + 12))
$dgv.Height = $serverListContentBottom - $dgv.Top
$tabServerList.AutoScrollMinSize = New-Object System.Drawing.Size(980, $serverListContentBottom)

$dgv.Add_DataBindingComplete({
        param($s, $e)
        try {
            $visibleOrder = @('ServerName', 'OSType', 'OverallStatus', 'DataCollection', 'SQLConfig', 'IISConfig', 'LogAnalytics', 'AccessCheck', 'Notes')
            for ($i = 0; $i -lt $visibleOrder.Count; $i++) {
                if ($s.Columns.Contains($visibleOrder[$i])) {
                    $s.Columns[$visibleOrder[$i]].DisplayIndex = $i
                }
            }

            $headerMap = @{
                'ServerName'     = 'Server'
                'OSType'         = 'OS Type'
                'OverallStatus'  = 'Overall Status'
                'DataCollection' = 'Data Collection'
                'SQLConfig'      = 'SQL Config'
                'IISConfig'      = 'IIS Config'
                'LogAnalytics'   = 'Log Analytics'
                'AccessCheck'    = 'Access'
                'Notes'          = 'Access Error'
            }
            foreach ($key in $headerMap.Keys) {
                if ($s.Columns.Contains($key)) {
                    $s.Columns[$key].HeaderText = $headerMap[$key]
                }
            }

            foreach ($hiddenCol in @('DataCollectionPath', 'SQLConfigPath', 'IISConfigPath', 'LogAnalyticsPath', 'ReportPath')) {
                if ($s.Columns.Contains($hiddenCol)) {
                    $s.Columns[$hiddenCol].Visible = $false
                }
            }
        }
        catch {}
        try {
            $s.ClearSelection()
            $s.CurrentCell = $null
        }
        catch {}
    })

$dgv.Add_CellFormatting({
        param($s, $e)
        if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) { return }

        try {
            $columnName = $s.Columns[$e.ColumnIndex].Name
            if (-not $columnName) { return }

            if ($script:ArtifactResultColumns -contains $columnName) {
                $pathCol = Get-ArtifactPathColumnName $columnName
                if ($pathCol -and $s.Columns.Contains($pathCol)) {
                    $artifactPath = [string]$s.Rows[$e.RowIndex].Cells[$pathCol].Value
                    if (-not [string]::IsNullOrWhiteSpace($artifactPath)) {
                        $e.CellStyle.Font = New-Object System.Drawing.Font($fontBase, [System.Drawing.FontStyle]::Underline)
                        $e.CellStyle.ForeColor = [System.Drawing.Color]::FromArgb(0, 102, 204)
                    }
                }
            }

            $palette = Get-ResultCellPalette -ColumnName $columnName -Value ([string]$e.Value)
            if ($palette) {
                $e.CellStyle.BackColor = $palette.Back
                $e.CellStyle.ForeColor = $palette.Fore
            }
        }
        catch {}
    })

$dgv.Add_CellClick({
        param($s, $e)
        if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) { return }
        try {
            $columnName = $s.Columns[$e.ColumnIndex].Name
            if (-not ($script:ArtifactResultColumns -contains $columnName)) { return }

            $pathCol = Get-ArtifactPathColumnName $columnName
            if (-not $pathCol -or -not $s.Columns.Contains($pathCol)) { return }

            $artifactPath = [string]$s.Rows[$e.RowIndex].Cells[$pathCol].Value
            if ([string]::IsNullOrWhiteSpace($artifactPath)) { return }

            if ($artifactPath -match '^(?i)https?://') {
                Start-Process -FilePath $artifactPath
                Set-Status "Opened artifact link: $artifactPath"
                return
            }

            if (Test-Path -LiteralPath $artifactPath -PathType Leaf) {
                Start-Process -FilePath $artifactPath
                Set-Status "Opened artifact file: $artifactPath"
            }
            else {
                [System.Windows.Forms.MessageBox]::Show("Artifact file not found:`n$artifactPath", 'Open Artifact', 'OK', 'Warning') | Out-Null
            }
        }
        catch {}
    })

# Ctrl+A / Ctrl+C keyboard support
$dgv.Add_KeyDown({
        param($s, $e)
        if ($e.Control -and $e.KeyCode -eq [System.Windows.Forms.Keys]::A) {
            $s.SelectAll(); $e.Handled = $true
        }
        if ($e.Control -and $e.KeyCode -eq [System.Windows.Forms.Keys]::C) {
            if ($s.SelectedRows.Count -gt 0) {
                $sb = New-Object System.Text.StringBuilder
                $cols = $s.Columns | Sort-Object DisplayIndex
                [void]$sb.AppendLine(($cols | ForEach-Object { $_.HeaderText }) -join "`t")
                foreach ($row in ($s.SelectedRows | Sort-Object { [int]$_.Index })) {
                    [void]$sb.AppendLine(($cols | ForEach-Object { $row.Cells[$_.Index].Value }) -join "`t")
                }
                [System.Windows.Forms.Clipboard]::SetText($sb.ToString())
            }
            $e.Handled = $true
        }
    })

# Right-click context menu
$dgvMenu = New-Object System.Windows.Forms.ContextMenuStrip
$miDelSel = New-Object System.Windows.Forms.ToolStripMenuItem 'Delete Selected Row(s)'
$miSelAll = New-Object System.Windows.Forms.ToolStripMenuItem 'Select All'
$miCopyRows = New-Object System.Windows.Forms.ToolStripMenuItem 'Copy'
$miPaste = New-Object System.Windows.Forms.ToolStripMenuItem 'Paste'

$miDelSel.Add_Click({
        if ($dgv.SelectedRows.Count -eq 0) { return }
        $res = [System.Windows.Forms.MessageBox]::Show("Delete $($dgv.SelectedRows.Count) selected row(s)?", 'Delete Rows', 'YesNo', 'Question')
        if ($res -eq [System.Windows.Forms.DialogResult]::Yes) {
            $dt = $dgv.DataSource
            $indices = @($dgv.SelectedRows | ForEach-Object { [int]$_.Index }) | Sort-Object -Descending
            foreach ($i in $indices) { $dt.Rows[$i].Delete() }
            $dt.AcceptChanges()
        }
    })
$miSelAll.Add_Click({ $dgv.SelectAll() })
$miCopyRows.Add_Click({
        if ($dgv.SelectedRows.Count -gt 0) {
            $sb = New-Object System.Text.StringBuilder
            $cols = $dgv.Columns | Sort-Object DisplayIndex
            [void]$sb.AppendLine(($cols | ForEach-Object { $_.HeaderText }) -join "`t")
            foreach ($row in ($dgv.SelectedRows | Sort-Object { [int]$_.Index })) {
                [void]$sb.AppendLine(($cols | ForEach-Object { $row.Cells[$_.Index].Value }) -join "`t")
            }
            [System.Windows.Forms.Clipboard]::SetText($sb.ToString())
        }
    })
$miPaste.Add_Click({
        if (-not $dgv.DataSource) { return }
        try {
            $clipText = [System.Windows.Forms.Clipboard]::GetText()
            if (-not $clipText) { return }
            $dt = $dgv.DataSource
            $lines = $clipText -split "`r?`n" | Where-Object { $_ -ne '' }
            foreach ($line in $lines) {
                $vals = $line -split "`t"
                $dr = $dt.NewRow()
                for ($i = 0; $i -lt [Math]::Min($vals.Count, $dt.Columns.Count); $i++) { $dr[$i] = $vals[$i] }
                [void]$dt.Rows.Add($dr)
            }
        }
        catch {}
    })

[void]$dgvMenu.Items.Add($miDelSel)
[void]$dgvMenu.Items.Add($miSelAll)
[void]$dgvMenu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
[void]$dgvMenu.Items.Add($miCopyRows)
[void]$dgvMenu.Items.Add($miPaste)
$dgv.ContextMenuStrip = $dgvMenu

# ── CSV load logic ─────────────────────────────────────────────────────────────
function Invoke-LoadCsv {
    $csvPath = $txtSlCsvPath.Text.Trim()
    if (-not $csvPath -or -not (Test-Path -LiteralPath $csvPath)) {
        [System.Windows.Forms.MessageBox]::Show("CSV file not found: $csvPath", 'Load CSV', 'OK', 'Warning') | Out-Null
        return
    }
    try {
        $rows = Import-Csv -Path $csvPath -ErrorAction Stop
        if (-not $rows -or $rows.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show('CSV is empty.', 'Load CSV', 'OK', 'Warning') | Out-Null
            return
        }
        $dt = New-Object System.Data.DataTable
        $headers = $rows[0].PSObject.Properties.Name
        foreach ($h in $headers) { [void]$dt.Columns.Add($h, [string]) }
        foreach ($r in $rows) {
            $dr = $dt.NewRow()
            foreach ($h in $headers) { $dr[$h] = $r.$h }
            [void]$dt.Rows.Add($dr)
        }
        $dgv.DataSource = $dt
        try {
            $dgv.ClearSelection()
            $dgv.CurrentCell = $null
        }
        catch {}
        $script:LoadedCsvPath = $csvPath

        $winCount = @($rows | Where-Object { $_.OSType -imatch 'windows' }).Count
        $linuxCount = @($rows | Where-Object { $_.OSType -and $_.OSType -notmatch 'windows' }).Count
        $unknownCount = @($rows | Where-Object { -not $_.OSType }).Count
        Set-ServerCountStatus "Servers: $($rows.Count)  |  Windows: $winCount  |  Linux: $linuxCount  |  Unknown OS: $unknownCount"
        Update-DashboardMetrics -Total $rows.Count -Windows $winCount -Linux ($linuxCount + $unknownCount) -Complete 0 -Attention $unknownCount -Mode 'loaded'

        $warnings = @()
        $nameCol = if ($headers -contains 'ServerName') { 'ServerName' } elseif ($headers -contains 'Server') { 'Server' } else { $null }
        if (-not $nameCol) { $warnings += "No 'ServerName' or 'Server' column found." }
        if ($headers -notcontains 'OSType') { $warnings += "No 'OSType' column — all servers will be treated as Linux." }
        if ($unknownCount -gt 0) { $warnings += "$unknownCount row(s) have no OSType value — they will be treated as Linux." }

        if ($warnings.Count -gt 0) {
            Set-Status ("Loaded $($rows.Count) servers. Warnings: " + ($warnings -join ' | '))
        }
        else {
            Set-Status "Loaded $($rows.Count) servers from CSV."
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to load CSV: $($_.Exception.Message)", 'Load CSV', 'OK', 'Error') | Out-Null
    }
}

function ConvertFrom-ReportHtmlCell {
    param([string]$Html)
    if ([string]::IsNullOrWhiteSpace($Html)) { return '' }
    # The artifact report is generated locally by Generate-ArtifactReport.ps1.
    # Decode table-cell content into plain WinForms grid text; do not render this as HTML.
    $text = $Html -replace '(?is)<script\b.*?</script>', '' -replace '(?is)<style\b.*?</style>', ''
    $text = $text -replace '(?is)<[^>]+>', ' '
    $text = [System.Net.WebUtility]::HtmlDecode($text)
    return (($text -replace '\s+', ' ').Trim())
}

function Get-ReportArtifactState {
    param([string]$Html)
    if ($Html -match 'artifact-na') { return 'N/A' }
    if ($Html -match 'artifact-found') { return 'Collected' }
    if ($Html -match 'artifact-missing') {
        $plain = ConvertFrom-ReportHtmlCell $Html
        if ($plain -imatch 'not exported') { return 'Not Exported' }
        return 'Missing'
    }
    return ConvertFrom-ReportHtmlCell $Html
}

function Get-ReportArtifactLink {
    param([string]$Html)
    if ([string]::IsNullOrWhiteSpace($Html)) { return '' }
    $m = [regex]::Match($Html, '(?is)<a\b[^>]*href=["'']([^"'']+)["'']')
    if ($m.Success) {
        return ([System.Net.WebUtility]::HtmlDecode($m.Groups[1].Value)).Trim()
    }
    return ''
}

function Resolve-ReportArtifactLinkPath {
    param([string]$ReportPath, [string]$LinkPath)
    if ([string]::IsNullOrWhiteSpace($LinkPath)) { return '' }
    $decodedLink = [System.Uri]::UnescapeDataString($LinkPath)
    if ($decodedLink -match '^(?i)https?://') { return $decodedLink }
    if ([System.IO.Path]::IsPathRooted($decodedLink)) { return $decodedLink }
    try {
        $baseDir = Split-Path -Parent $ReportPath
        return [System.IO.Path]::GetFullPath((Join-Path $baseDir $decodedLink))
    }
    catch {
        return $decodedLink
    }
}

function Get-ReportHeaderCellIndexMap {
    param([string]$Html)

    $map = @{}
    $theadMatch = [regex]::Match($Html, '(?is)<thead\b[^>]*>(.*?)</thead>')
    if (-not $theadMatch.Success) { return $map }

    $thMatches = [regex]::Matches($theadMatch.Groups[1].Value, '(?is)<th\b[^>]*>(.*?)</th>')
    for ($i = 0; $i -lt $thMatches.Count; $i++) {
        $headerText = ConvertFrom-ReportHtmlCell $thMatches[$i].Groups[1].Value
        if ([string]::IsNullOrWhiteSpace($headerText)) { continue }

        $normalized = ($headerText -replace '[^A-Za-z0-9]+', '').ToLower()
        $map[$normalized] = $i
    }

    return $map
}

function Normalize-ReportAccessStatus {
    param([string]$Text)
    if ($Text -imatch 'failed') { return 'Failed' }
    if ($Text -imatch '\bok\b') { return 'OK' }
    if ($Text -imatch 'not checked') { return 'Not Checked' }
    return $Text
}

function Normalize-ReportOverallStatus {
    param([string]$Text)
    if ($Text -imatch 'access failed') { return 'Access Failed' }
    if ($Text -imatch 'complete') { return 'Complete' }
    if ($Text -imatch 'partial') { return 'Partial' }
    if ($Text -imatch 'no data') { return 'No Data' }
    return $Text
}

function Get-LatestArtifactReportPath {
    param([switch]$IncludeAllArtifacts)

    $outDir = $txtOutputDir.Text.Trim()
    if (-not $outDir) { return $null }
    $reportDir = Join-Path $outDir 'Reports\ArtifactReport'
    if (-not (Test-Path -LiteralPath $reportDir -PathType Container)) { return $null }
    $latestFile = if ($IncludeAllArtifacts) { 'ArtifactReport-all-latest.html' } else { 'ArtifactReport-latest.html' }
    $latestPath = Join-Path $reportDir $latestFile
    if (Test-Path -LiteralPath $latestPath -PathType Leaf) { return $latestPath }
    return $null
}

function New-ArtifactReportForGrid {
    param([switch]$IncludeAllArtifacts)
    if (-not (Invoke-AutoSaveSettingsForCommand -Label 'Generate Artifact Report')) { return $null }

    $outDir = $txtOutputDir.Text.Trim()
    if (-not $outDir) {
        [System.Windows.Forms.MessageBox]::Show('Output directory is not set. Configure it on the Configuration tab.', 'Load Results', 'OK', 'Warning') | Out-Null
        return $null
    }
    if (-not (Test-Path -LiteralPath $outDir -PathType Container)) {
        try { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Could not create output directory:`n$outDir`n`n$($_.Exception.Message)", 'Load Results', 'OK', 'Error') | Out-Null
            return $null
        }
    }

    $reportScript = Join-Path $ScriptsDir 'Generate-ArtifactReport.ps1'
    $launchTarget = Resolve-ClientDiscoveryLaunchTarget -ScriptPath $reportScript -NoExit:$false
    if (-not $launchTarget.Exists) {
        [System.Windows.Forms.MessageBox]::Show("Generate-ArtifactReport not found at:`n$($launchTarget.ResolvedPath)", 'Load Results', 'OK', 'Error') | Out-Null
        return $null
    }

    $reportDir = Join-Path $outDir 'Reports\ArtifactReport'
    if (-not (Test-Path -LiteralPath $reportDir -PathType Container)) {
        New-Item -ItemType Directory -Path $reportDir -Force | Out-Null
    }
    $reportStem = if ($IncludeAllArtifacts) { 'ArtifactReport-all' } else { 'ArtifactReport' }
    $reportPath = Join-Path $reportDir ("{0}-{1}.html" -f $reportStem, (Get-Date -Format 'yyyyMMdd-HHmmss'))

    $csvPath = Get-CurrentCsvPath
    $tokens = @($launchTarget.PrefixTokens) + @(
        '-OutputDir', $outDir,
        '-ReportPath', $reportPath,
        '-NoOpen'
    )
    if (-not $IncludeAllArtifacts -and $csvPath -and (Test-Path -LiteralPath $csvPath -PathType Leaf)) {
        $tokens += @('-ServerList', $csvPath)
    }

    try {
        if ($IncludeAllArtifacts) {
            Set-Status 'Generating artifact report from all discovered artifact folders...'
        }
        else {
            Set-Status 'No report found. Generating artifact report...'
        }
        $form.UseWaitCursor = $true
        [System.Windows.Forms.Application]::DoEvents()
        $process = Invoke-ExternalLaunch -LaunchTarget $launchTarget -Arguments $tokens -Label 'Generate Artifact Report' -Wait -Hidden
        if ($process.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $reportPath -PathType Leaf)) {
            [System.Windows.Forms.MessageBox]::Show("Artifact report generation failed. Check logs in:`n$(Join-Path $outDir 'Logs')", 'Load Results', 'OK', 'Error') | Out-Null
            return $null
        }
        return $reportPath
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to generate artifact report: $($_.Exception.Message)", 'Load Results', 'OK', 'Error') | Out-Null
        return $null
    }
    finally {
        $form.UseWaitCursor = $false
    }
}

function Import-ArtifactReportRows {
    param([string]$ReportPath)
    if (-not $ReportPath -or -not (Test-Path -LiteralPath $ReportPath -PathType Leaf)) {
        [System.Windows.Forms.MessageBox]::Show("Report not found:`n$ReportPath", 'Load Results', 'OK', 'Warning') | Out-Null
        return $null
    }

    $html = Get-Content -LiteralPath $ReportPath -Raw
    # The GUI consumes the table emitted by Generate-ArtifactReport.ps1: <tbody id="tableBody">
    # with 9 cells ordered as Server, OS, artifact fields, access, notes, and overall status.
    $tbodyMatch = [regex]::Match($html, '(?is)<tbody[^>]*id=["'']tableBody["''][^>]*>(.*?)</tbody>')
    if (-not $tbodyMatch.Success) {
        [System.Windows.Forms.MessageBox]::Show('The selected artifact report does not contain a recognized results table.', 'Load Results', 'OK', 'Warning') | Out-Null
        return $null
    }

    $headerIndexMap = Get-ReportHeaderCellIndexMap -Html $html

    function Get-CellHtmlByHeader {
        param(
            [System.Text.RegularExpressions.MatchCollection]$CellMatches,
            [hashtable]$HeaderMap,
            [string[]]$HeaderKeys,
            [int]$FallbackIndex = -1
        )

        foreach ($key in $HeaderKeys) {
            $normalized = ($key -replace '[^A-Za-z0-9]+', '').ToLower()
            if ($HeaderMap.ContainsKey($normalized)) {
                $idx = [int]$HeaderMap[$normalized]
                if ($idx -ge 0 -and $idx -lt $CellMatches.Count) {
                    return $CellMatches[$idx].Groups[1].Value
                }
            }
        }

        if ($FallbackIndex -ge 0 -and $FallbackIndex -lt $CellMatches.Count) {
            return $CellMatches[$FallbackIndex].Groups[1].Value
        }

        return ''
    }

    $dt = New-Object System.Data.DataTable
    foreach ($columnName in $script:ReportGridColumns) {
        [void]$dt.Columns.Add($columnName, [string])
    }

    $rowMatches = [regex]::Matches($tbodyMatch.Groups[1].Value, '(?is)<tr\b[^>]*>(.*?)</tr>')
    foreach ($rowMatch in $rowMatches) {
        if ($rowMatch.Value -match 'empty-state') { continue }
        $cellMatches = [regex]::Matches($rowMatch.Groups[1].Value, '(?is)<td\b[^>]*>(.*?)</td>')
        if ($cellMatches.Count -lt $script:ArtifactReportTableCellCount) { continue }

        $serverHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('Server') -FallbackIndex 0
        $osHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('OS Type', 'OSType', 'OS') -FallbackIndex 1
        $overallHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('Overall Status', 'Status') -FallbackIndex 2
        $dataCollectionHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('Data Collection', 'Migration Data') -FallbackIndex 3
        $sqlHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('SQL Config', 'SQL') -FallbackIndex 4
        $iisHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('IIS Config', 'IIS') -FallbackIndex 5
        $logAnalyticsHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('Log Analytics', 'LogAnalytics') -FallbackIndex 6
        $accessHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('Access') -FallbackIndex 7
        $notesHtml = Get-CellHtmlByHeader -CellMatches $cellMatches -HeaderMap $headerIndexMap -HeaderKeys @('Access Error', 'Notes', 'Errors') -FallbackIndex 8

        $serverName = ConvertFrom-ReportHtmlCell $serverHtml
        if (-not $serverName) { continue }

        $access = Normalize-ReportAccessStatus (ConvertFrom-ReportHtmlCell $accessHtml)
        $status = Normalize-ReportOverallStatus (ConvertFrom-ReportHtmlCell $overallHtml)

        $dr = $dt.NewRow()
        $dr['ServerName'] = $serverName
        $dr['OSType'] = ConvertFrom-ReportHtmlCell $osHtml
        $dr['DataCollection'] = Get-ReportArtifactState $dataCollectionHtml
        $dr['SQLConfig'] = Get-ReportArtifactState $sqlHtml
        $dr['IISConfig'] = Get-ReportArtifactState $iisHtml
        $dr['LogAnalytics'] = Get-ReportArtifactState $logAnalyticsHtml
        $dr['DataCollectionPath'] = Resolve-ReportArtifactLinkPath -ReportPath $ReportPath -LinkPath (Get-ReportArtifactLink $dataCollectionHtml)
        $dr['SQLConfigPath'] = Resolve-ReportArtifactLinkPath -ReportPath $ReportPath -LinkPath (Get-ReportArtifactLink $sqlHtml)
        $dr['IISConfigPath'] = Resolve-ReportArtifactLinkPath -ReportPath $ReportPath -LinkPath (Get-ReportArtifactLink $iisHtml)
        $dr['LogAnalyticsPath'] = Resolve-ReportArtifactLinkPath -ReportPath $ReportPath -LinkPath (Get-ReportArtifactLink $logAnalyticsHtml)
        $dr['AccessCheck'] = $access
        $dr['OverallStatus'] = $status
        $dr['Notes'] = ConvertFrom-ReportHtmlCell $notesHtml
        $dr['ReportPath'] = $ReportPath
        [void]$dt.Rows.Add($dr)
    }

    Write-Output -NoEnumerate $dt
}

function Invoke-LoadResults {
    param(
        [bool]$UseLatest = $true,
        [bool]$UseAllArtifacts = $false
    )
    $reportPath = $null
    $generated = $false

    if ($UseAllArtifacts) {
        $reportPath = Get-LatestArtifactReportPath -IncludeAllArtifacts
        if (-not $reportPath) {
            $reportPath = New-ArtifactReportForGrid -IncludeAllArtifacts
            $generated = $true
        }
    }
    elseif ($UseLatest) {
        $reportPath = Get-LatestArtifactReportPath
        if (-not $reportPath) {
            $reportPath = New-ArtifactReportForGrid
            $generated = $true
        }
    }
    else {
        $outDir = $txtOutputDir.Text.Trim()
        $reportDir = if ($outDir) { Join-Path $outDir 'Reports\ArtifactReport' } else { $null }
        $initialDir = if ($reportDir -and (Test-Path -LiteralPath $reportDir -PathType Container)) {
            $reportDir
        }
        elseif ($outDir -and (Test-Path -LiteralPath $outDir -PathType Container)) {
            $outDir
        }
        else {
            $ScriptRoot
        }

        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Title = 'Select artifact report HTML'
        $dlg.Filter = 'HTML Files (*.html;*.htm)|*.html;*.htm|All Files (*.*)|*.*'
        $dlg.InitialDirectory = $initialDir
        $dlg.CheckFileExists = $true
        $dlg.Multiselect = $false
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $reportPath = $dlg.FileName
        }
        else {
            Set-Status 'Load Results canceled.'
            return
        }
    }

    if (-not $reportPath) { return }

    $prevWaitCursor = $form.UseWaitCursor
    $form.UseWaitCursor = $true
    [System.Windows.Forms.Application]::DoEvents()

    try {
        $imported = Import-ArtifactReportRows -ReportPath $reportPath
        $dt = $null
        if ($imported -is [System.Data.DataTable]) {
            $dt = $imported
        }
        elseif ($imported -is [System.Data.DataRow]) {
            $dt = $imported.Table
        }
        elseif ($imported -is [System.Array] -and $imported.Count -gt 0 -and $imported[0] -is [System.Data.DataRow]) {
            $dt = $imported[0].Table
        }

        if (-not $dt -or $dt.Rows.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show("No server rows were found in:`n$reportPath", 'Load Results', 'OK', 'Information') | Out-Null
            return
        }
        $dgv.DataSource = $dt
        try {
            $dgv.ClearSelection()
            $dgv.CurrentCell = $null
        }
        catch {}
        $script:LoadedCsvPath = $null

        $completeCount = ($dt.Select("OverallStatus = 'Complete'")).Count
        $partialCount = ($dt.Select("OverallStatus = 'Partial'")).Count
        $failedCount = ($dt.Select("OverallStatus = 'Access Failed'")).Count
        $winCount = ($dt.Select("OSType LIKE '%Windows%'")).Count
        $linuxCount = [Math]::Max(0, ($dt.Rows.Count - $winCount))
        Update-DashboardMetrics -Total $dt.Rows.Count -Windows $winCount -Linux $linuxCount -Complete $completeCount -Attention ($partialCount + $failedCount) -Mode 'results'
        Set-ServerCountStatus "Results: $($dt.Rows.Count)  |  Complete: $completeCount  |  Partial: $partialCount  |  Access Failed: $failedCount"
        $sourceText = if ($generated) {
            'Generated and loaded'
        }
        elseif ($UseLatest) {
            'Loaded latest'
        }
        else {
            'Loaded selected'
        }
        Set-Status "$sourceText artifact report: $reportPath"
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to load results: $($_.Exception.Message)", 'Load Results', 'OK', 'Error') | Out-Null
    }
    finally {
        $form.UseWaitCursor = $prevWaitCursor
    }
}

$btnBrowseSlCsv.Add_Click({
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = 'CSV Files (*.csv)|*.csv|All Files (*.*)|*.*'
        if ($txtSlCsvPath.Text -and (Test-Path (Split-Path $txtSlCsvPath.Text -Parent -ErrorAction SilentlyContinue))) {
            $dlg.InitialDirectory = Split-Path $txtSlCsvPath.Text -Parent
        }
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $txtSlCsvPath.Text = $dlg.FileName
            Invoke-LoadCsv
        }
    })

$chkLoadResultsAll.Add_CheckedChanged({
        try {
            if ($chkLoadResultsAll.Checked) {
                $chkLoadResultsLatest.Enabled = $false
            }
            else {
                $chkLoadResultsLatest.Enabled = $true
            }
        }
        catch {}
    })

$btnLoadResults.Add_Click({ Invoke-LoadResults -UseLatest:$chkLoadResultsLatest.Checked -UseAllArtifacts:$chkLoadResultsAll.Checked })

$btnSaveCsv.Add_Click({
        if (-not $dgv.DataSource) { Set-Status 'No grid data to save.'; return }
        $savePath = $txtSlCsvPath.Text.Trim()
        if ($savePath -and (Test-Path -LiteralPath $savePath)) {
            $res = [System.Windows.Forms.MessageBox]::Show("Overwrite existing file?`n$savePath", 'Save CSV', 'YesNo', 'Question')
            if ($res -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        }
        else {
            $dlg = New-Object System.Windows.Forms.SaveFileDialog
            $dlg.Filter = 'CSV Files (*.csv)|*.csv'
            $dlg.FileName = 'serverlist-edited.csv'
            if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
            $savePath = $dlg.FileName
        }
        try {
            $dt = $dgv.DataSource
            $rows = foreach ($dr in $dt.Rows) {
                $obj = [ordered]@{}
                foreach ($col in $dt.Columns) { $obj[$col.ColumnName] = $dr[$col.ColumnName] }
                [PSCustomObject]$obj
            }
            $rows | Export-Csv -Path $savePath -NoTypeInformation -Encoding UTF8
            $script:LoadedCsvPath = $savePath
            $txtSlCsvPath.Text = $savePath
            Set-Status "Saved CSV to: $savePath"
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Save failed: $($_.Exception.Message)", 'Save CSV', 'OK', 'Error') | Out-Null
        }
    })

$btnOpenSample.Add_Click({
        if (Test-Path $SampleCsvPath) {
            $txtSlCsvPath.Text = $SampleCsvPath
            Invoke-LoadCsv
        }
        else {
            [System.Windows.Forms.MessageBox]::Show("Sample CSV not found at: $SampleCsvPath", 'Sample CSV', 'OK', 'Warning') | Out-Null
        }
    })

$btnAddRow.Add_Click({
        if (-not $dgv.DataSource) {
            $dt = New-Object System.Data.DataTable
            [void]$dt.Columns.Add('ServerName', [string])
            [void]$dt.Columns.Add('OSType', [string])
            $dgv.DataSource = $dt
            $script:LoadedCsvPath = $null
        }
        $dt = $dgv.DataSource
        [void]$dt.Rows.Add($dt.NewRow())
        $dgv.FirstDisplayedScrollingRowIndex = $dgv.RowCount - 1
        $dgv.CurrentCell = $dgv.Rows[$dgv.RowCount - 1].Cells[0]
        Update-DashboardMetricsFromGrid
        Set-Status "New row added."
    })

$btnDeleteRow.Add_Click({
        if ($dgv.SelectedRows.Count -eq 0) { Set-Status 'No rows selected.'; return }
        $res = [System.Windows.Forms.MessageBox]::Show("Delete $($dgv.SelectedRows.Count) selected row(s)?", 'Delete Rows', 'YesNo', 'Question')
        if ($res -eq [System.Windows.Forms.DialogResult]::Yes) {
            $dt = $dgv.DataSource
            $indices = @($dgv.SelectedRows | ForEach-Object { [int]$_.Index }) | Sort-Object -Descending
            foreach ($i in $indices) { $dt.Rows[$i].Delete() }
            $dt.AcceptChanges()
            Update-DashboardMetricsFromGrid
            Set-Status "Deleted $($indices.Count) row(s)."
        }
    })

$btnSelectAll.Add_Click({
        if (-not $dgv.DataSource) { Set-Status 'No rows to select.'; return }
        $dgv.SelectAll()
        Set-Status 'All rows selected.'
    })

$btnUnselectAll.Add_Click({
        $dgv.ClearSelection()
        Set-Status 'Selection cleared.'
    })

# ── Toolbar button tooltips ────────────────────────────────────────────────────
$toolTip.SetToolTip($btnBrowseSlCsv, 'Pick a server list CSV file and load it into the grid')
$toolTip.SetToolTip($txtSlCsvPath, 'Path to the server list CSV file')
$toolTip.SetToolTip($btnLoadResults, 'Load results into the grid. When Latest is checked, use the newest report behavior; otherwise pick an HTML report file.')
$toolTip.SetToolTip($chkLoadResultsLatest, 'When checked, Load Results uses the latest/generate behavior. Uncheck to pick an HTML report manually.')
$toolTip.SetToolTip($chkLoadResultsAll, 'Generate and load a report from all discovered server artifact folders under the output directory, ignoring the current server list.')
$toolTip.SetToolTip($btnSaveCsv, 'Save the current grid contents back to CSV')
$toolTip.SetToolTip($btnOpenSample, 'Open the sample CSV file to see the required format')
$toolTip.SetToolTip($btnAddRow, 'Add a new blank row to the grid')
$toolTip.SetToolTip($btnDeleteRow, 'Delete all selected rows from the grid')
$toolTip.SetToolTip($btnSelectAll, 'Select all rows in the grid')
$toolTip.SetToolTip($btnUnselectAll, 'Clear row selection in the grid')

# ── Collection builder functions ───────────────────────────────────────────────

# Export selected rows to a temp CSV. $DefaultCsvPath is optional because report-loaded
# grids have no source CSV; collection scripts only require server and OS columns.
function Export-SelectedOrFullCsv {
    param([string]$DefaultCsvPath)
    if (-not $dgv.DataSource) {
        [System.Windows.Forms.MessageBox]::Show('No grid data loaded. Load a server list or results first.', 'No Grid Data', 'OK', 'Warning') | Out-Null
        return $null
    }

    $selectedCount = 0
    $totalCount = 0
    try {
        if ($dgv.SelectedRows -and $dgv.SelectedRows.Count -gt 0) {
            $selectedCount = $dgv.SelectedRows.Count
        }
        elseif ($dgv.SelectedCells -and $dgv.SelectedCells.Count -gt 0) {
            $rowIndexSet = @{}
            foreach ($cell in $dgv.SelectedCells) {
                try { $ri = $cell.RowIndex; if ($null -ne $ri) { $rowIndexSet[$ri] = $true } } catch {}
            }
            $selectedCount = $rowIndexSet.Keys.Count
        }
        $totalCount = if ($dgv.Rows) { $dgv.Rows.Count } else { 0 }
    }
    catch {}

    # Nothing selected → export all current grid rows so edits are captured
    if ($selectedCount -eq 0) {
        $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
        $tmpPath = Join-Path $env:TEMP "clientdiscovery_all_$stamp.csv"
        try {
            $dt = $dgv.DataSource
            $allRows = 0..($dgv.Rows.Count - 1) | Where-Object { -not $dgv.Rows[$_].IsNewRow } | ForEach-Object {
                $row = $dgv.Rows[$_]
                $obj = [ordered]@{}
                foreach ($col in $dt.Columns) { $obj[$col.ColumnName] = $row.Cells[$col.ColumnName].Value }
                [PSCustomObject]$obj
            }
            $allRows | Export-Csv -Path $tmpPath -NoTypeInformation -Encoding UTF8
            return $tmpPath
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Failed to export grid to CSV: $($_.Exception.Message)", 'Export Error', 'OK', 'Error') | Out-Null
            return $null
        }
    }

    # All rows selected → same as "all", export from grid
    if ($selectedCount -eq $totalCount) {
        $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
        $tmpPath = Join-Path $env:TEMP "clientdiscovery_all_$stamp.csv"
        try {
            $dt = $dgv.DataSource
            $allRows = 0..($dgv.Rows.Count - 1) | Where-Object { -not $dgv.Rows[$_].IsNewRow } | ForEach-Object {
                $row = $dgv.Rows[$_]
                $obj = [ordered]@{}
                foreach ($col in $dt.Columns) { $obj[$col.ColumnName] = $row.Cells[$col.ColumnName].Value }
                [PSCustomObject]$obj
            }
            $allRows | Export-Csv -Path $tmpPath -NoTypeInformation -Encoding UTF8
            return $tmpPath
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Failed to export grid to CSV: $($_.Exception.Message)", 'Export Error', 'OK', 'Error') | Out-Null
            return $null
        }
    }

    # Export selected rows to a timestamped temp file
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $tmpPath = Join-Path $env:TEMP "clientdiscovery_selected_$stamp.csv"
    try {
        $dt = $dgv.DataSource
        $rows = if ($dgv.SelectedRows -and $dgv.SelectedRows.Count -gt 0) {
            $dgv.SelectedRows | Sort-Object { [int]$_.Index } | ForEach-Object {
                $obj = [ordered]@{}
                foreach ($col in $dt.Columns) { $obj[$col.ColumnName] = $_.Cells[$col.ColumnName].Value }
                [PSCustomObject]$obj
            }
        }
        else {
            $rowIndexSet = @{}
            foreach ($cell in $dgv.SelectedCells) {
                try { $ri = $cell.RowIndex; if ($null -ne $ri) { $rowIndexSet[$ri] = $true } } catch {}
            }
            $rowIndexSet.Keys | Sort-Object | ForEach-Object {
                $row = $dgv.Rows[$_]
                $obj = [ordered]@{}
                foreach ($col in $dt.Columns) { $obj[$col.ColumnName] = $row.Cells[$col.ColumnName].Value }
                [PSCustomObject]$obj
            }
        }
        $rows | Export-Csv -Path $tmpPath -NoTypeInformation -Encoding UTF8
        return $tmpPath
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to write selection CSV: $($_.Exception.Message)", 'Export Error', 'OK', 'Error') | Out-Null
        return $null
    }
}

function Get-CurrentCsvPath {
    if ($script:LoadedCsvPath) { return $script:LoadedCsvPath }
    return $txtSlCsvPath.Text.Trim()
}

function Get-CsvServerCount {
    param([string]$CsvPath)
    if (-not $CsvPath -or -not (Test-Path -LiteralPath $CsvPath -PathType Leaf)) {
        return $null
    }
    try {
        $rows = @(Import-Csv -Path $CsvPath -ErrorAction Stop)
        return $rows.Count
    }
    catch {
        return $null
    }
}

function Resolve-ClientDiscoveryLaunchTarget {
    param(
        [string]$ScriptPath,
        [switch]$NoExit,
        [switch]$PreferScript
    )

    $nativeScriptPath = Normalize-NativePath -Path $ScriptPath
    $exePath = [System.IO.Path]::ChangeExtension($nativeScriptPath, '.exe')
    $workingDir = Normalize-NativePath -Path $ScriptRoot
    if ($PreferScript -and -not $script:IsCompiledExeHost -and (Test-Path -LiteralPath $nativeScriptPath -PathType Leaf)) {
        $prefixTokens = @('-ExecutionPolicy', 'Bypass')
        if ($NoExit) { $prefixTokens += '-NoExit' }
        $prefixTokens += @('-File', $nativeScriptPath)

        return [PSCustomObject]@{
            FilePath         = $script:PowerShellHostPath
            PrefixTokens     = $prefixTokens
            DisplayCommand   = [System.IO.Path]::GetFileName($script:PowerShellHostPath)
            Exists           = $true
            ResolvedPath     = $nativeScriptPath
            WorkingDirectory = $workingDir
        }
    }

    if ($script:IsCompiledExeHost) {
        $launchPath = Convert-ToLaunchRelativePath -TargetPath $exePath

        return [PSCustomObject]@{
            FilePath         = $launchPath
            PrefixTokens     = @()
            DisplayCommand   = "`"$launchPath`""
            Exists           = (Test-Path -LiteralPath $exePath -PathType Leaf)
            ResolvedPath     = $launchPath
            WorkingDirectory = $workingDir
        }
    }

    if (-not $PreferScript -and (Test-Path -LiteralPath $exePath -PathType Leaf)) {
        return [PSCustomObject]@{
            FilePath         = $exePath
            PrefixTokens     = @()
            DisplayCommand   = "`"$exePath`""
            Exists           = $true
            ResolvedPath     = $exePath
            WorkingDirectory = $workingDir
        }
    }

    $prefixTokens = @('-ExecutionPolicy', 'Bypass')
    if ($NoExit) { $prefixTokens += '-NoExit' }
    $prefixTokens += @('-File', $nativeScriptPath)

    return [PSCustomObject]@{
        FilePath         = $script:PowerShellHostPath
        PrefixTokens     = $prefixTokens
        DisplayCommand   = [System.IO.Path]::GetFileName($script:PowerShellHostPath)
        Exists           = (Test-Path -LiteralPath $nativeScriptPath -PathType Leaf)
        ResolvedPath     = $nativeScriptPath
        WorkingDirectory = $workingDir
    }
}

function Format-LaunchArgument {
    param([string]$Argument)

    if ($null -eq $Argument) { return '""' }
    if ($Argument -eq '') { return '""' }
    if ($Argument -notmatch '[\s"]') { return $Argument }
    return '"' + ($Argument -replace '"', '\"') + '"'
}

function Join-LaunchCommandLine {
    param(
        [string]$FilePath,
        [string[]]$Arguments = @()
    )

    $parts = @((Format-LaunchArgument -Argument $FilePath))
    foreach ($argument in $Arguments) {
        $parts += (Format-LaunchArgument -Argument $argument)
    }
    return ($parts -join ' ')
}

function Join-LaunchArguments {
    param([string[]]$Arguments = @())

    $parts = @()
    foreach ($argument in $Arguments) {
        $parts += (Format-LaunchArgument -Argument $argument)
    }
    return ($parts -join ' ')
}

function Resolve-LaunchFilePath {
    param($LaunchTarget)
    $filePath = Normalize-NativePath -Path $LaunchTarget.FilePath
    if ([string]::IsNullOrWhiteSpace([string]$filePath)) { return $filePath }
    if ([System.IO.Path]::IsPathRooted($filePath)) { return $filePath }
    $wd = Normalize-NativePath -Path $LaunchTarget.WorkingDirectory
    if ([string]::IsNullOrWhiteSpace([string]$wd)) { $wd = (Get-Location).Path }
    return [System.IO.Path]::GetFullPath((Join-Path $wd $filePath))
}

function Write-LaunchDiagnostics {
    param(
        [string]$Label,
        $LaunchTarget,
        [string[]]$Arguments = @()
    )
    try {
        $resolvedExe = Resolve-LaunchFilePath -LaunchTarget $LaunchTarget
        $workingDir = Normalize-NativePath -Path $LaunchTarget.WorkingDirectory
        $exists = $false
        if ($resolvedExe) { $exists = Test-Path -LiteralPath $resolvedExe -PathType Leaf }
        $displayCommand = Join-LaunchCommandLine -FilePath $LaunchTarget.FilePath -Arguments $Arguments

        Write-GuiLog "DIAG [$Label] IsCompiledExeHost=$script:IsCompiledExeHost"
        Write-GuiLog "DIAG [$Label] ScriptRoot=$ScriptRoot"
        Write-GuiLog "DIAG [$Label] WorkingDirectory=$workingDir"
        Write-GuiLog "DIAG [$Label] LaunchTarget.FilePath=$($LaunchTarget.FilePath)"
        Write-GuiLog "DIAG [$Label] LaunchTarget.ResolvedPath=$($LaunchTarget.ResolvedPath)"
        Write-GuiLog "DIAG [$Label] ResolvedExecutable=$resolvedExe"
        Write-GuiLog "DIAG [$Label] ExecutableExists=$exists"
        Write-GuiLog "DIAG [$Label] ArgumentString=$displayCommand"
    }
    catch {
        Write-GuiLog "DIAG [$Label] Failed to write diagnostics: $($_.Exception.Message)" 'ERROR'
    }
}

function Invoke-ExternalLaunch {
    param(
        [Parameter(Mandatory = $true)]
        $LaunchTarget,

        [string[]]$Arguments = @(),

        [string]$Label = 'External Command',
        [string]$StatusMessage = '',
        [switch]$Wait,
        [switch]$Hidden
    )

    $resolvedExe = Resolve-LaunchFilePath -LaunchTarget $LaunchTarget
    $workingDir = Normalize-NativePath -Path $LaunchTarget.WorkingDirectory
    if ([string]::IsNullOrWhiteSpace([string]$workingDir)) {
        $workingDir = (Get-Location).Path
    }

    $displayCommand = Join-LaunchCommandLine -FilePath $LaunchTarget.FilePath -Arguments $Arguments
    Write-LaunchDiagnostics -Label $Label -LaunchTarget $LaunchTarget -Arguments $Arguments

    $startInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $filePath = if ($resolvedExe) { $resolvedExe } else { Normalize-NativePath -Path $LaunchTarget.FilePath }
    $startInfo.WorkingDirectory = $workingDir
    # Use UseShellExecute = $true to spawn truly independent process in separate session
    $startInfo.UseShellExecute = $true
    $startInfo.CreateNoWindow = $false
    if ($Hidden) {
        $startInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Minimized
    }

    # Determine launch mode:
    # - Raw compiled EXE (PrefixTokens is empty): launch the EXE directly; do not require pwsh.
    # - Script-backed launch (PrefixTokens present): FilePath is the available PowerShell host and
    #   Arguments already contain -ExecutionPolicy, -File, etc.
    $isExe = $filePath -match '\.exe$'
    $isRawExe = $isExe -and ($LaunchTarget.PrefixTokens.Count -eq 0)

    if ($isRawExe) {
        # Standalone compiled EXE — launch directly so client VMs do not need PowerShell 7.
        $startInfo.FileName = $filePath
        $startInfo.Arguments = Join-LaunchArguments -Arguments $Arguments
    }
    else {
        # A PowerShell host is already selected (prefix tokens include -ExecutionPolicy -File ...).
        # Pass FileName directly and the full pre-built argument list.
        $startInfo.FileName = $filePath
        $startInfo.Arguments = Join-LaunchArguments -Arguments $Arguments
    }

    $process = [System.Diagnostics.Process]::Start($startInfo)
    if ($Wait -and $process) {
        $process.WaitForExit()
    }
    Write-GuiLaunch $Label $displayCommand
    if ($StatusMessage) { Set-Status $StatusMessage }
    return $process
}

function Get-DiscoveryArtifactsDir {
    param([string]$BaseOutputDir)
    if ([string]::IsNullOrWhiteSpace($BaseOutputDir)) { return $BaseOutputDir }
    return (Join-Path $BaseOutputDir 'Artifacts')
}

function Build-CollectionArgs {
    param([string]$CsvOverride = '', [switch]$ServerOnlyData)
    $collectorScript = Join-Path $ScriptsDir 'ServerDataCollector.ps1'
    $launchTarget = Resolve-ClientDiscoveryLaunchTarget -ScriptPath $collectorScript -NoExit -PreferScript
    $csvPath = if ($CsvOverride) { $CsvOverride } else { Get-CurrentCsvPath }
    $outputDir = $txtOutputDir.Text.Trim()
    $artifactsDir = Get-DiscoveryArtifactsDir -BaseOutputDir $outputDir
    $maxThreads = [int]$numMaxThreads.Value
    $jobTimeoutSeconds = [int]$numJobTimeoutSeconds.Value
    $logsDir = Join-Path $outputDir 'Logs'
    if (-not (Test-Path -LiteralPath $logsDir)) {
        try { New-Item -ItemType Directory -Path $logsDir -Force | Out-Null } catch {}
    }
    $progressStatusPath = Join-Path $logsDir ("ClientDiscovery-Progress-{0}.json" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))

    $argTokens = @($launchTarget.PrefixTokens) + @(
        '-CheckType', 'Pre_Migration',
        '-ServerList', $csvPath,
        '-OutputDir', $outputDir,
        '-MaxThreads', [string]$maxThreads,
        '-JobTimeoutSeconds', [string]$jobTimeoutSeconds,
        '-ProgressStatusPath', $progressStatusPath
    )

    $credentialLaunch = Resolve-WindowsCredentialLaunchTokens -PersonalJsonParameterName '-PersonalJSON' -Label 'Run Collection'
    if (-not $credentialLaunch.CanLaunch) {
        return [PSCustomObject]@{ CanLaunch = $false; LaunchTarget = $launchTarget; ArgTokens = $argTokens; SourcePath = $collectorScript }
    }
    $argTokens += $credentialLaunch.Tokens
    Write-GuiLog "Credential mode for Run Collection: $($credentialLaunch.Mode)"

    if ($chkScanIP.Checked) { $argTokens += '-ScanIP' }
    if ($chkSkipEventLog.Checked) { $argTokens += '-SkipEventLog' }
    else { $argTokens += @('-EventLogMaxEvents', '1000') }

    if ($ServerOnlyData) { $argTokens += '-ServerOnlyData' }

    return [PSCustomObject]@{
        CanLaunch          = $true
        LaunchTarget       = $launchTarget
        ArgTokens          = $argTokens
        SourcePath         = $collectorScript
        ProgressStatusPath = $progressStatusPath
    }
}

# ── Show-ConfirmCommand ────────────────────────────────────────────────────────
# Shows the full command string in a read-only dialog with OK / Cancel.
# Returns [System.Windows.Forms.DialogResult]::OK if user confirms.
function Show-ConfirmCommand {
    param(
        [string]$Command,
        [string]$CsvPath = ''
    )
    # Format: split on space-dash to put each parameter on its own indented line
    $parts = $Command -split '(?<=\s)(?=-[A-Za-z])'
    $formatted = ($parts | ForEach-Object { $_.TrimEnd() }) -join "`r`n    "

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Confirm Command'
    $dlg.Size = New-Object System.Drawing.Size(820, 420)
    $dlg.StartPosition = 'CenterScreen'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.Font = New-Object System.Drawing.Font('Consolas', 9)

    $toolbar = New-Object System.Windows.Forms.Panel
    $toolbar.SetBounds(8, 8, 798, 28)
    $toolbar.BackColor = [System.Drawing.Color]::FromArgb(242, 245, 249)
    $dlg.Controls.Add($toolbar)

    $csvInfo = New-Object System.Windows.Forms.Label
    $csvInfo.AutoSize = $false
    $csvInfo.SetBounds(8, 5, 520, 18)
    $csvInfo.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $csvInfo.ForeColor = [System.Drawing.Color]::FromArgb(27, 36, 48)
    if ($CsvPath) {
        $csvInfo.Text = "CSV: $CsvPath"
    }
    else {
        $csvInfo.Text = 'CSV: (not specified)'
    }
    $toolbar.Controls.Add($csvInfo)

    $countLabel = New-Object System.Windows.Forms.Label
    $countLabel.AutoSize = $false
    $countLabel.SetBounds(530, 5, 260, 18)
    $countLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $countLabel.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
    $countLabel.ForeColor = [System.Drawing.Color]::FromArgb(20, 42, 74)
    $serverCount = Get-CsvServerCount -CsvPath $CsvPath
    if ($null -ne $serverCount) {
        $countLabel.Text = "Servers in run CSV: $serverCount"
    }
    else {
        $countLabel.Text = 'Servers in run CSV: unknown'
    }
    $toolbar.Controls.Add($countLabel)

    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Multiline = $true
    $txt.ReadOnly = $true
    $txt.WordWrap = $false
    $txt.ScrollBars = 'Both'
    $txt.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $txt.ForeColor = [System.Drawing.Color]::FromArgb(200, 230, 200)
    $txt.Text = $formatted
    $txt.SetBounds(8, 40, 798, 288)
    $dlg.Controls.Add($txt)

    $pnl = New-Object System.Windows.Forms.Panel
    $pnl.SetBounds(0, 330, 820, 50)
    $dlg.Controls.Add($pnl)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = 'Run'
    $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $btnOK.SetBounds(290, 10, 100, 28)
    $btnOK.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 212)
    $btnOK.ForeColor = [System.Drawing.Color]::White
    $btnOK.FlatStyle = 'Flat'
    $pnl.Controls.Add($btnOK)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $btnCancel.SetBounds(400, 10, 100, 28)
    $pnl.Controls.Add($btnCancel)

    $dlg.AcceptButton = $btnOK
    $dlg.CancelButton = $btnCancel
    return $dlg.ShowDialog()
}


function Invoke-RunCollection {
    param([string]$CsvPath, [switch]$ServerOnlyData)
    if (-not (Invoke-AutoSaveSettingsForCommand -Label 'Run Collection')) { return }

    $issues = @()
    if (-not $CsvPath -or -not (Test-Path -LiteralPath $CsvPath -ErrorAction SilentlyContinue)) { $issues += 'No valid CSV file.' }
    if (-not $txtOutputDir.Text.Trim()) { $issues += 'Output directory is required (set in Configuration tab).' }
    if ($issues.Count -gt 0) {
        [System.Windows.Forms.MessageBox]::Show(($issues -join "`n"), 'Cannot Run', 'OK', 'Warning') | Out-Null
        return
    }
    $outDir = $txtOutputDir.Text.Trim()
    if (-not (Test-Path $outDir)) {
        try { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
        catch { [System.Windows.Forms.MessageBox]::Show("Could not create output directory: $($_.Exception.Message)", 'Run', 'OK', 'Error') | Out-Null; return }
    }
    $command = Build-CollectionArgs -CsvOverride $CsvPath -ServerOnlyData:$ServerOnlyData
    if (-not $command.CanLaunch) { return }
    if (-not $command.LaunchTarget.Exists) {
        [System.Windows.Forms.MessageBox]::Show("ServerDataCollector not found at:`n$($command.LaunchTarget.ResolvedPath)", 'Run', 'OK', 'Error') | Out-Null
        return
    }
    $displayCommand = Join-LaunchCommandLine -FilePath $command.LaunchTarget.FilePath -Arguments $command.ArgTokens
    if ((Show-ConfirmCommand $displayCommand -CsvPath $CsvPath) -ne [System.Windows.Forms.DialogResult]::OK) { return }
    try {
        $minimizeConsole = -not $rbInteractive.Checked
        $process = Invoke-ExternalLaunch -LaunchTarget $command.LaunchTarget -Arguments $command.ArgTokens -Label 'Run Collection' -StatusMessage "Collection launched. Progress is shown in the status bar; diagnostics are in OutputDir\Logs." -Hidden:$minimizeConsole
        Start-CollectionProgressMonitor -StatusPath $command.ProgressStatusPath -Process $process
    }
    catch {
        $resolvedExe = Resolve-LaunchFilePath -LaunchTarget $command.LaunchTarget
        $debugMsg = @(
            "Failed to launch collection: $($_.Exception.Message)",
            "",
            "WorkingDirectory: $($command.LaunchTarget.WorkingDirectory)",
            "Executable: $($command.LaunchTarget.FilePath)",
            "Executable (full): $resolvedExe",
            "Executable exists: $(if ($resolvedExe) { Test-Path -LiteralPath $resolvedExe -PathType Leaf } else { $false })",
            "",
            "Arguments:",
            $displayCommand,
            "",
            "See OutputDir\\Logs\\ClientDiscovery-GUI-*.log for diagnostics."
        ) -join "`r`n"
        [System.Windows.Forms.MessageBox]::Show($debugMsg, 'Run', 'OK', 'Error') | Out-Null
    }
}

function Invoke-RunAccessCheck {
    param([string]$CsvPath)
    if (-not (Invoke-AutoSaveSettingsForCommand -Label 'Access Check')) { return }

    if (-not $CsvPath -or -not (Test-Path -LiteralPath $CsvPath -ErrorAction SilentlyContinue)) {
        [System.Windows.Forms.MessageBox]::Show('No valid server list CSV. Load a CSV first.', 'Access Check', 'OK', 'Warning') | Out-Null
        return
    }
    $accessScript = Join-Path $ScriptsDir 'AdminAccessAndRDPCheck.ps1'
    $launchTarget = Resolve-ClientDiscoveryLaunchTarget -ScriptPath $accessScript -NoExit -PreferScript
    if (-not $launchTarget.Exists) {
        [System.Windows.Forms.MessageBox]::Show("AdminAccessAndRDPCheck not found at:`n$($launchTarget.ResolvedPath)", 'Access Check', 'OK', 'Error') | Out-Null
        return
    }
    $outDir = $txtOutputDir.Text.Trim()
    if ($outDir -and -not (Test-Path $outDir)) {
        try { New-Item -ItemType Directory -Path $outDir -Force | Out-Null } catch {}
    }
    $tokens = @($launchTarget.PrefixTokens) + @(
        '-ServerList', $CsvPath,
        '-OutputDir', $outDir,
        '-RdpPort', [string][int]$numAcRdpPort.Value,
        '-PsTimeoutSec', [string][int]$numAcPsTimeout.Value,
        '-MaxConcurrent', [string][int]$numAcMaxConcurrent.Value
    )
    # Honor either explicit AccessCheck setting or the selected credential mode.
    if ($chkAcUseCreds.Checked) {
        $tokens += '-UseCreds'
        Write-GuiLog "Credential mode for Access Check: Forced interactive credential prompt"
    }
    else {
        $credentialLaunch = Resolve-WindowsCredentialLaunchTokens -PersonalJsonParameterName '-PersonalJson' -Label 'Access Check'
        if (-not $credentialLaunch.CanLaunch) { return }
        $tokens += $credentialLaunch.Tokens
        Write-GuiLog "Credential mode for Access Check: $($credentialLaunch.Mode)"
    }
    $fqdn = $txtAcFqdnSuffix.Text.Trim()
    if ($fqdn) { $tokens += @('-FqdnSuffix', $fqdn) }
    $displayCommand = Join-LaunchCommandLine -FilePath $launchTarget.FilePath -Arguments $tokens
    if ((Show-ConfirmCommand $displayCommand -CsvPath $CsvPath) -ne [System.Windows.Forms.DialogResult]::OK) { return }
    try {
        Invoke-ExternalLaunch -LaunchTarget $launchTarget -Arguments $tokens -Label 'Access Check' -StatusMessage "Access Check launched."
    }
    catch {
        $resolvedExe = Resolve-LaunchFilePath -LaunchTarget $launchTarget
        $debugMsg = @(
            "Failed to launch Access Check: $($_.Exception.Message)",
            "",
            "WorkingDirectory: $($launchTarget.WorkingDirectory)",
            "Executable: $($launchTarget.FilePath)",
            "Executable (full): $resolvedExe",
            "Executable exists: $(if ($resolvedExe) { Test-Path -LiteralPath $resolvedExe -PathType Leaf } else { $false })",
            "",
            "Arguments:",
            $displayCommand,
            "",
            "See OutputDir\\Logs\\ClientDiscovery-GUI-*.log for diagnostics."
        ) -join "`r`n"
        [System.Windows.Forms.MessageBox]::Show($debugMsg, 'Access Check', 'OK', 'Error') | Out-Null
    }
}

# Launch an individual sub-collector script directly (SQL, IIS, Linux, EventLog, ScanIP)
# NOTE: CollectSQLData.ps1 and CollectIISData.ps1 use -OutputPath, not -OutputDir.
#       ServerDataCollector / MigrationCheck use -OutputDir. We detect by script name.
function Invoke-DirectScript {
    param([string]$CsvPath, [string]$ScriptRelPath, [string[]]$ExtraArgs = @(), [string]$Label = 'Collector')
    if (-not (Invoke-AutoSaveSettingsForCommand -Label $Label)) { return }

    if (-not $CsvPath -or -not (Test-Path -LiteralPath $CsvPath -ErrorAction SilentlyContinue)) {
        [System.Windows.Forms.MessageBox]::Show('No valid CSV. Load a server list first.', $Label, 'OK', 'Warning') | Out-Null
        return
    }
    $scriptPath = Join-Path $ScriptsDir $ScriptRelPath
    $launchTarget = Resolve-ClientDiscoveryLaunchTarget -ScriptPath $scriptPath -NoExit -PreferScript
    if (-not $launchTarget.Exists) {
        [System.Windows.Forms.MessageBox]::Show("Script not found:`n$($launchTarget.ResolvedPath)", $Label, 'OK', 'Error') | Out-Null
        return
    }
    $outDir = $txtOutputDir.Text.Trim()
    $artifactsDir = Get-DiscoveryArtifactsDir -BaseOutputDir $outDir
    if ($outDir -and -not (Test-Path $outDir)) {
        try { New-Item -ItemType Directory -Path $outDir -Force | Out-Null } catch {}
    }
    if ($artifactsDir -and -not (Test-Path $artifactsDir)) {
        try { New-Item -ItemType Directory -Path $artifactsDir -Force | Out-Null } catch {}
    }

    # CollectSQLData and CollectIISData use -OutputPath; all others use -OutputDir
    $scriptLeaf = [System.IO.Path]::GetFileName($ScriptRelPath)
    $outParam = if ($scriptLeaf -in @('CollectSQLData.ps1', 'CollectIISData.ps1')) { '-OutputPath' } else { '-OutputDir' }

    $tokens = @($launchTarget.PrefixTokens) + @(
        '-CheckType', 'Pre_Migration',
        '-ServerList', $CsvPath,
        $outParam, $artifactsDir
    )
    $credentialLaunch = Resolve-WindowsCredentialLaunchTokens -PersonalJsonParameterName '-PersonalJson' -Label $Label
    if (-not $credentialLaunch.CanLaunch) { return }
    $tokens += $credentialLaunch.Tokens
    Write-GuiLog "Credential mode for ${Label}: $($credentialLaunch.Mode)"
    $tokens += $ExtraArgs
    $displayCommand = Join-LaunchCommandLine -FilePath $launchTarget.FilePath -Arguments $tokens
    if ((Show-ConfirmCommand $displayCommand -CsvPath $CsvPath) -ne [System.Windows.Forms.DialogResult]::OK) { return }
    try {
        Invoke-ExternalLaunch -LaunchTarget $launchTarget -Arguments $tokens -Label $Label -StatusMessage "$Label launched."
    }
    catch {
        $resolvedExe = Resolve-LaunchFilePath -LaunchTarget $launchTarget
        $debugMsg = @(
            "Failed to launch $Label`: $($_.Exception.Message)",
            "",
            "WorkingDirectory: $($launchTarget.WorkingDirectory)",
            "Executable: $($launchTarget.FilePath)",
            "Executable (full): $resolvedExe",
            "Executable exists: $(if ($resolvedExe) { Test-Path -LiteralPath $resolvedExe -PathType Leaf } else { $false })",
            "",
            "Arguments:",
            $displayCommand,
            "",
            "See OutputDir\\Logs\\ClientDiscovery-GUI-*.log for diagnostics."
        ) -join "`r`n"
        [System.Windows.Forms.MessageBox]::Show($debugMsg, $Label, 'OK', 'Error') | Out-Null
    }
}

function Resolve-MoveOpsScriptPath {
    param([string]$ScriptName)

    $candidates = @(
        (Join-Path $ScriptsDir $ScriptName),
        (Join-Path (Split-Path $ScriptRoot -Parent) (Join-Path 'Scripts' $ScriptName)),
        (Join-Path $ScriptRoot (Join-Path 'Scripts' $ScriptName))
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            return (Normalize-NativePath -Path ((Resolve-Path -LiteralPath $candidate).Path))
        }
    }

    return $null
}

function Get-LogAnalyticsCheckType {
    $checkType = [string]$cmbCheckType.SelectedItem
    switch -Regex ($checkType) {
        '^Post' { return 'Post' }
        '^Dashboard' { return 'Dashboard' }
        '^Verify' { return 'Verify' }
        default { return 'Pre' }
    }
}

function Invoke-LogAnalyticsExport {
    param([string]$CsvPath)
    if (-not (Invoke-AutoSaveSettingsForCommand -Label 'Export Log Analytics')) { return }

    if (-not $CsvPath -or -not (Test-Path -LiteralPath $CsvPath -ErrorAction SilentlyContinue)) {
        [System.Windows.Forms.MessageBox]::Show('No valid server list CSV. Load a CSV first.', 'Export Log Analytics', 'OK', 'Warning') | Out-Null
        return
    }

    $laScript = Resolve-MoveOpsScriptPath -ScriptName 'Avanade-ExportLogAnalyticsData.ps1'
    if (-not $laScript) {
        [System.Windows.Forms.MessageBox]::Show('Avanade-ExportLogAnalyticsData.ps1 was not found in the ClientDiscovery Scripts folder or the MOVEOPS Scripts folder.', 'Export Log Analytics', 'OK', 'Error') | Out-Null
        return
    }

    $outDir = $txtOutputDir.Text.Trim()
    if (-not $outDir) {
        [System.Windows.Forms.MessageBox]::Show('Output directory is required. Set it on the Configuration tab.', 'Export Log Analytics', 'OK', 'Warning') | Out-Null
        return
    }
    if (-not (Test-Path $outDir)) {
        try { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
        catch { [System.Windows.Forms.MessageBox]::Show("Could not create output directory: $($_.Exception.Message)", 'Export Log Analytics', 'OK', 'Error') | Out-Null; return }
    }

    $subscriptionName = $txtLASubscriptionName.Text.Trim()
    $workspaceRG = $txtLAWorkspaceRG.Text.Trim()
    $workspaceName = $txtLAWorkspaceName.Text.Trim()
    $timespan = if ($cmbLATimespan.SelectedItem) { [string]$cmbLATimespan.SelectedItem } else { '30d' }

    $issues = @()
    if (-not $subscriptionName) { $issues += 'Log Analytics subscription name is required.' }
    if (-not $workspaceRG) { $issues += 'Log Analytics workspace resource group is required.' }
    if (-not $workspaceName) { $issues += 'Log Analytics workspace name is required.' }
    if ($issues.Count -gt 0) {
        [System.Windows.Forms.MessageBox]::Show(($issues -join "`n"), 'Export Log Analytics', 'OK', 'Warning') | Out-Null
        return
    }

    $launchTarget = [PSCustomObject]@{
        FilePath         = $script:PowerShellHostPath
        PrefixTokens     = @()
        DisplayCommand   = [System.IO.Path]::GetFileName($script:PowerShellHostPath)
        Exists           = $true
        ResolvedPath     = $script:PowerShellHostPath
        WorkingDirectory = (Normalize-NativePath -Path $ScriptRoot)
    }

    $tokens = @(
        '-ExecutionPolicy', 'Bypass',
        '-NoExit',
        '-File', $laScript,
        '-ServerList', $CsvPath,
        '-OutputDir', $outDir,
        '-CheckType', (Get-LogAnalyticsCheckType),
        '-Timespan', $timespan,
        '-SubscriptionName', $subscriptionName,
        '-WorkspaceRG', $workspaceRG,
        '-WorkspaceName', $workspaceName
    )

    if ($rbStoredSettings.Checked -and (Test-Path $SettingsFile)) {
        $tokens += @('-JsonProject', $SettingsFile)
        $tokens += @('-JsonPersonal', $SettingsFile)
    }

    $displayCommand = Join-LaunchCommandLine -FilePath $launchTarget.FilePath -Arguments $tokens
    if ((Show-ConfirmCommand $displayCommand -CsvPath $CsvPath) -ne [System.Windows.Forms.DialogResult]::OK) { return }

    try {
        Invoke-ExternalLaunch -LaunchTarget $launchTarget -Arguments $tokens -Label 'Export Log Analytics' -StatusMessage "Log Analytics export launched."
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to launch Log Analytics export: $($_.Exception.Message)", 'Export Log Analytics', 'OK', 'Error') | Out-Null
    }
}

function Invoke-DnsExport {
    if (-not (Invoke-AutoSaveSettingsForCommand -Label 'Export DNS Data')) { return }

    $dnsScript = Join-Path $ScriptsDir 'WindowsDNSExport.ps1'
    $launchTarget = Resolve-ClientDiscoveryLaunchTarget -ScriptPath $dnsScript -NoExit -PreferScript
    if (-not $launchTarget.Exists) {
        [System.Windows.Forms.MessageBox]::Show("WindowsDNSExport was not found at:`n$($launchTarget.ResolvedPath)", 'Export DNS Data', 'OK', 'Error') | Out-Null
        return
    }

    $outDir = $txtOutputDir.Text.Trim()
    if (-not $outDir) {
        [System.Windows.Forms.MessageBox]::Show('Output directory is required. Set it on the Configuration tab.', 'Export DNS Data', 'OK', 'Warning') | Out-Null
        return
    }

    $artifactsDir = Get-DiscoveryArtifactsDir -BaseOutputDir $outDir
    $dnsOutputDir = Join-Path $artifactsDir 'AdditionalData\DNSExports'
    foreach ($dirPath in @($outDir, $artifactsDir, $dnsOutputDir)) {
        if (-not (Test-Path -LiteralPath $dirPath)) {
            try { New-Item -ItemType Directory -Path $dirPath -Force | Out-Null }
            catch {
                [System.Windows.Forms.MessageBox]::Show("Could not create output directory:`n$dirPath`n`n$($_.Exception.Message)", 'Export DNS Data', 'OK', 'Error') | Out-Null
                return
            }
        }
    }

    $tokens = @($launchTarget.PrefixTokens) + @(
        '-OutputDir', $dnsOutputDir
    )

    $displayCommand = Join-LaunchCommandLine -FilePath $launchTarget.FilePath -Arguments $tokens
    if ((Show-ConfirmCommand $displayCommand) -ne [System.Windows.Forms.DialogResult]::OK) { return }

    try {
        Invoke-ExternalLaunch -LaunchTarget $launchTarget -Arguments $tokens -Label 'Export DNS Data' -StatusMessage "DNS export launched. Output will be written to $dnsOutputDir"
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to launch DNS export: $($_.Exception.Message)", 'Export DNS Data', 'OK', 'Error') | Out-Null
    }
}

# ── Step / action button handlers ─────────────────────────────────────────────
# Each button: if rows selected → run against selection; else → run against all.

$btnStepAccess.Add_Click({
        $csv = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if ($csv) { Invoke-RunAccessCheck -CsvPath $csv }
    })

$btnStepDataAll.Add_Click({
        $csv = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if ($csv) { Invoke-RunCollection -CsvPath $csv }
    })

$btnStepDataLight.Add_Click({
        $csv = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if ($csv) { Invoke-RunCollection -CsvPath $csv -ServerOnlyData }
    })

$btnWinFullScan = New-Object System.Windows.Forms.Button; $btnWinFullScan.Visible = $false
$btnLinuxCollector = New-Object System.Windows.Forms.Button; $btnLinuxCollector.Visible = $false
$pnlSidebar.Controls.Add($btnWinFullScan); $pnlSidebar.Controls.Add($btnLinuxCollector)

$btnWinFullScan.Add_Click({})
$btnLinuxCollector.Add_Click({})

$btnCollectSQL.Add_Click({
        $csv = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if ($csv) { Invoke-DirectScript -CsvPath $csv -ScriptRelPath 'WindowsVM\CollectSQLData.ps1' -Label 'Collect SQL' }
    })

$btnCollectIIS.Add_Click({
        $csv = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if ($csv) { Invoke-DirectScript -CsvPath $csv -ScriptRelPath 'WindowsVM\CollectIISData.ps1' -Label 'Collect IIS' }
    })

$btnEventLog.Add_Click({
        $csv = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if ($csv) {
            $extra = @('-EventLogMaxEvents', '1000')
            Invoke-DirectScript -CsvPath $csv -ScriptRelPath 'WindowsVM\MigrationCheck-DataCollector.ps1' -ExtraArgs $extra -Label 'Event Log'
        }
    })

$btnIPScan.Add_Click({
        $csv = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if ($csv) {
            Invoke-DirectScript -CsvPath $csv -ScriptRelPath 'WindowsVM\MigrationCheck-ScanIP.ps1' -Label 'IP Scan'
        }
    })

$btnLogAnalytics.Add_Click({
        $csv = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if ($csv) { Invoke-LogAnalyticsExport -CsvPath $csv }
    })

$btnDnsExport.Add_Click({
        Invoke-DnsExport
    })

$btnArtifactReport.Add_Click({
        if (-not (Invoke-AutoSaveSettingsForCommand -Label 'Artifact Report')) { return }

        $outDir = $txtOutputDir.Text.Trim()
        if (-not $outDir) {
            [System.Windows.Forms.MessageBox]::Show('Output directory is not set. Configure it on the Configuration tab.', 'Artifact Report', 'OK', 'Warning') | Out-Null
            return
        }
        if (-not (Test-Path $outDir)) {
            [System.Windows.Forms.MessageBox]::Show("Output directory not found:`n$outDir`n`nRun data collection first.", 'Artifact Report', 'OK', 'Warning') | Out-Null
            return
        }
        $reportScript = Join-Path $ScriptsDir 'Generate-ArtifactReport.ps1'
        $launchTarget = Resolve-ClientDiscoveryLaunchTarget -ScriptPath $reportScript -NoExit -PreferScript
        if (-not $launchTarget.Exists) {
            [System.Windows.Forms.MessageBox]::Show("Generate-ArtifactReport not found at:`n$($launchTarget.ResolvedPath)", 'Artifact Report', 'OK', 'Error') | Out-Null
            return
        }
        $csvArg = Export-SelectedOrFullCsv -DefaultCsvPath (Get-CurrentCsvPath)
        if (-not $csvArg) { return }
        # Pass the root output dir, not Artifacts. Generate-ArtifactReport auto-detects the
        # Artifacts sub-folder itself, and also searches <root>\Reports\Access for the access
        # check CSV — which is where AdminAccessAndRDPCheck writes it.
        $tokens = @($launchTarget.PrefixTokens) + @(
            '-OutputDir', $outDir,
            '-ServerList', $csvArg
        )
        $displayCommand = Join-LaunchCommandLine -FilePath $launchTarget.FilePath -Arguments $tokens
        if ((Show-ConfirmCommand $displayCommand -CsvPath $csvArg) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        try {
            Invoke-ExternalLaunch -LaunchTarget $launchTarget -Arguments $tokens -Label 'Artifact Report' -StatusMessage "Artifact Report generation launched - check terminal for progress."
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Failed to launch report: $($_.Exception.Message)", 'Artifact Report', 'OK', 'Error') | Out-Null
        }
    })

$btnZipOutput.Add_Click({
        if (-not (Invoke-AutoSaveSettingsForCommand -Label 'ZIP Output')) { return }

        $outDir = $txtOutputDir.Text.Trim()
        if (-not $outDir -or -not (Test-Path $outDir)) {
            [System.Windows.Forms.MessageBox]::Show("Output directory not found:`n$outDir`n`nRun data collection first.", 'ZIP Output', 'OK', 'Warning') | Out-Null
            return
        }
        $zipScript = Join-Path $ScriptsDir 'ZipOutput.ps1'
        $launchTarget = Resolve-ClientDiscoveryLaunchTarget -ScriptPath $zipScript -NoExit -PreferScript
        if (-not $launchTarget.Exists) {
            [System.Windows.Forms.MessageBox]::Show("ZipOutput not found at:`n$($launchTarget.ResolvedPath)", 'ZIP Output', 'OK', 'Error') | Out-Null
            return
        }
        $destDir = Join-Path $outDir 'ZIPFiles'
        $artifactsDir = Join-Path $outDir 'Artifacts'
        if (-not (Test-Path -LiteralPath $artifactsDir -PathType Container)) {
            [System.Windows.Forms.MessageBox]::Show("Artifacts directory not found:`n$artifactsDir`n`nRun data collection first.", 'ZIP Output', 'OK', 'Warning') | Out-Null
            return
        }

        $tokens = @($launchTarget.PrefixTokens) + @(
            '-OutputDir', $artifactsDir,
            '-DestinationDirectory', $destDir
        )

        $displayCommand = Join-LaunchCommandLine -FilePath $launchTarget.FilePath -Arguments $tokens
        if ((Show-ConfirmCommand $displayCommand) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        try {
            Invoke-ExternalLaunch -LaunchTarget $launchTarget -Arguments $tokens -Label 'ZIP Output' -StatusMessage "ZIP launched - output will be saved to $destDir"
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Failed to launch ZIP: $($_.Exception.Message)", 'ZIP Output', 'OK', 'Error') | Out-Null
        }
    })

$script:PreviousSelectedTab = $tabControl.SelectedTab

# ── Tab change handler ─────────────────────────────────────────────────────────
$tabControl.Add_SelectedIndexChanged({
        if ($script:PreviousSelectedTab -eq $tabConfig) {
            [void](Invoke-SaveSettings -Quiet)
        }

        if ($tabControl.SelectedTab -eq $tabServerList) {
            Set-Status "Server List — load a CSV, edit the grid, then run collectors."
        }

        $script:PreviousSelectedTab = $tabControl.SelectedTab
    })

$form.Add_FormClosing({
        [void](Invoke-SaveSettings -Quiet)
    })

# ── Initial load ───────────────────────────────────────────────────────────────
if (Test-Path $SettingsFile) {
    try { Invoke-LoadSettings } catch { <# ignore on startup #> }
}

if (-not (Test-Path $ScriptsDir)) {
    [System.Windows.Forms.MessageBox]::Show(
        "Scripts directory not found:`n$ScriptsDir`n`nEnsure this GUI is run from the ClientDiscovery folder.",
        'Missing Scripts', 'OK', 'Warning') | Out-Null
}

[void]$form.ShowDialog()
