<#
.SYNOPSIS
    Enumerate DNS zones on a Windows DNS server and export selected DNS record types (A + CNAME by default) to per-zone CSV files.

.DESCRIPTION
    This script connects to a specified Windows DNS server, enumerates all DNS zones, and exports DNS records for each zone to CSV files. By default it exports both A and CNAME records, but additional record types can be specified via the RecordTypes parameter (any value returned in RecordType from Get-DnsServerResourceRecord). Each zone is written to its own CSV in the DNSExports directory (auto-created locally). The CSV contains: HostName, RecordType, RecordClass, TimeToLive, Timestamp, RecordData (IP for A, target alias for CNAME, fallback ToString() for others). The root cache zone '.' is skipped automatically.

.PARAMETER DnsServer
    The IP address or hostname of the DNS server to connect to. If omitted, the script first prefers the local machine when the DNS Server service is installed, then falls back to the first configured DNS client server address, and finally to '127.0.0.1' if detection fails.

.PARAMETER RecordTypes
    Array of record types to include in the export (as reported by Get-DnsServerResourceRecord.RecordType). Defaults to A and CNAME. Example: -RecordTypes A,CNAME,MX

.PARAMETER RemoveDuplicates
    Remove duplicate FQDN entries that appear as both relative and absolute hostnames. Defaults to $true.

.PARAMETER OutputDir
    The directory path where DNS export CSV files will be saved. Defaults to ".\DNSExports" in the current directory. The directory will be created if it doesn't exist.

.PARAMETER ZoneName
    The name of the DNS zone to export records for. This parameter is used within the Export-DnsRecords function.

.EXAMPLE
    .\WindowsDNSExport.ps1 -DnsServer "192.168.1.1"
    Enumerates all zones on the server and exports A and CNAME records to CSVs.

.EXAMPLE
    .\WindowsDNSExport.ps1 -RecordTypes A,CNAME,MX -DnsServer core-dns01.contoso.com
    Remotely exports A, CNAME and MX records for every zone from the specified AD DNS server.

.EXAMPLE
    .\WindowsDNSExport.ps1 -OutputDir "C:\temp\dns" -DnsServer "192.168.1.1"
    Exports DNS records to the specified output directory.

.NOTES
    Author: Ryan Ferguson
.Link
    Repo Link to this Script: https://dev.azure.com/CMSMigrations/AMDM%20-%20LiftAndShift/_git/AMDM%20-%20LiftAndShift?version=GBmain&path=05%20-%20Migration/04%20-%20DNS/WindowsDNSExport.ps1
#>
#Requires -Version 5.1

# Define the DNS server as a parameter
param (
    [string]$DnsServer,
    [string[]]$RecordTypes = @('A', 'CNAME'),
    [bool]$RemoveDuplicates = $true,
    [Alias('OutputDirectory')]
    [string]$OutputDir = ".\DNSExports"
)
$ScriptVersion = "26.07.18"

function Write-Info {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Cyan
}

function Write-Warn {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Yellow
}

function Write-Err {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Red
}

function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-LocalDnsServerInstalled {
    try {
        $dnsService = Get-Service -Name 'DNS' -ErrorAction SilentlyContinue
        if ($dnsService) {
            return $true
        }
    }
    catch {}

    return $false
}

function Resolve-DefaultDnsServer {
    if (Test-LocalDnsServerInstalled) {
        Write-Info "Detected local DNS Server service. Using local server: $env:COMPUTERNAME"
        return $env:COMPUTERNAME
    }

    try {
        $dnsInfo = Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.ServerAddresses -and $_.ServerAddresses.Count -gt 0 }
        $candidate = $null
        foreach ($entry in $dnsInfo) {
            foreach ($addr in $entry.ServerAddresses) {
                if ($addr -and $addr.Trim()) {
                    $candidate = $addr
                    break
                }
            }
            if ($candidate) { break }
        }

        if ($candidate) {
            Write-Warn "Local DNS Server role was not detected. Falling back to configured DNS server: $candidate"
            return $candidate
        }

        Write-Warn "Unable to detect a DNS server from client settings; defaulting to 127.0.0.1"
        return '127.0.0.1'
    }
    catch {
        Write-Warn "DNS server auto-detection failed: $($_.Exception.Message). Using 127.0.0.1"
        return '127.0.0.1'
    }
}

function Ensure-DnsToolingAvailable {
    $dnsCmd = Get-Command -Name 'dnscmd.exe' -ErrorAction SilentlyContinue
    $dnsRecordCmd = Get-Command -Name 'Get-DnsServerResourceRecord' -ErrorAction SilentlyContinue
    if ($dnsCmd -and $dnsRecordCmd) {
        return
    }

    try {
        Import-Module DnsServer -ErrorAction SilentlyContinue | Out-Null
    }
    catch {}

    $dnsCmd = Get-Command -Name 'dnscmd.exe' -ErrorAction SilentlyContinue
    $dnsRecordCmd = Get-Command -Name 'Get-DnsServerResourceRecord' -ErrorAction SilentlyContinue
    if ($dnsCmd -and $dnsRecordCmd) {
        return
    }

    Write-Warn "DNSCMD was not found. I am going to enable the DNS Server Tools feature now..."

    if (-not (Test-Administrator)) {
        throw "Administrator privileges are required to enable DNS Server Tools automatically. Please rerun this script as Administrator."
    }

    $installSucceeded = $false

    if (Get-Command -Name 'Get-WindowsCapability' -ErrorAction SilentlyContinue) {
        $dnsFeature = Get-WindowsCapability -Online | Where-Object Name -like 'Rsat.Dns.Tools*' | Select-Object -First 1
        if ($dnsFeature -and $dnsFeature.State -eq 'Installed') {
            Write-Info 'DNS Server Tools are already installed.'
            $installSucceeded = $true
        }
        elseif ($dnsFeature) {
            Write-Info 'Installing DNS Server Tools (RSAT)...'
            Add-WindowsCapability -Online -Name 'Rsat.Dns.Tools~~~~0.0.1.0' -ErrorAction Stop | Out-Null
            $installSucceeded = $true
        }
    }
    elseif (Get-Command -Name 'Install-WindowsFeature' -ErrorAction SilentlyContinue) {
        Write-Info 'Installing DNS Server Tools via Windows Feature management...'
        try {
            Install-WindowsFeature -Name 'RSAT-DNS-Server' -IncludeManagementTools -ErrorAction Stop | Out-Null
            $installSucceeded = $true
        }
        catch {
            Install-WindowsFeature -Name 'DNS' -IncludeManagementTools -ErrorAction Stop | Out-Null
            $installSucceeded = $true
        }
    }

    if (-not $installSucceeded) {
        throw 'Unable to install DNS Server Tools automatically on this operating system.'
    }

    try {
        Import-Module DnsServer -ErrorAction SilentlyContinue | Out-Null
    }
    catch {}

    $dnsCmd = Get-Command -Name 'dnscmd.exe' -ErrorAction SilentlyContinue
    $dnsRecordCmd = Get-Command -Name 'Get-DnsServerResourceRecord' -ErrorAction SilentlyContinue
    if (-not $dnsCmd -or -not $dnsRecordCmd) {
        throw 'DNS Server Tools installation completed, but dnscmd or DnsServer cmdlets are still unavailable.'
    }

    Write-Info 'DNS Server Tools enabled successfully. Continuing DNS export...'
}

# If no DNS server specified, prefer the local DNS server role before client DNS settings.
if (-not $DnsServer -or -not $DnsServer.Trim()) {
    $DnsServer = Resolve-DefaultDnsServer
}

# Ensure the output directory exists
if (-not (Test-Path -Path $OutputDir)) {
    try {
        New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
        Write-Host "Created output directory: $OutputDir" -ForegroundColor Green
    }
    catch {
        Write-Error "Failed to create output directory '$OutputDir': $($_.Exception.Message)"
        exit 1
    }
}
else {
    Write-Host "Using existing output directory: $OutputDir" -ForegroundColor Green
}

try {
    Ensure-DnsToolingAvailable
}
catch {
    Write-Err "Failed to prepare DNS tooling: $($_.Exception.Message)"
    exit 1
}

# Function to enumerate all zones from the target DNS server
function Get-DnsZones {
    $zones = @()
    try {
        $dnsZones = @(Get-DnsServerZone -ComputerName $DnsServer -ErrorAction Stop)
        foreach ($zone in $dnsZones) {
            $zoneName = [string]$zone.ZoneName
            if ([string]::IsNullOrWhiteSpace($zoneName)) { continue }
            if ($zoneName -eq '.') { continue }
            $zones += $zoneName.Trim()
        }
    }
    catch {
        Write-Host "Error enumerating zones from '$DnsServer': $($_.Exception.Message)" -ForegroundColor Red
        return @()
    }

    return $zones
}

# Function to normalize hostname for deduplication
function Get-NormalizedHostname {
    param (
        [string]$HostName,
        [string]$ZoneName
    )
    
    if ($HostName -eq '@') {
        return '@'
    }
    
    # If hostname ends with the zone name, it's an FQDN
    if ($HostName.EndsWith(".$ZoneName", [StringComparison]::OrdinalIgnoreCase)) {
        # Remove the zone portion to get the relative name
        $relativeName = $HostName.Substring(0, $HostName.Length - $ZoneName.Length - 1)
        if ($relativeName) { 
            return $relativeName 
        }
        else { 
            return '@' 
        }
    }
    
    return $HostName
}

# Function to build DNS path from hostname
function Get-DnsPath {
    param (
        [string]$HostName,
        [string]$ZoneName
    )
    
    if ($HostName -eq '@') {
        return "/$ZoneName"
    }
    
    # Split the hostname by dots to build the path
    $parts = $HostName.Split('.')
    if ($parts.Count -eq 1) {
        # Single level record
        return "/$ZoneName/$HostName"
    }
    else {
        # Multi-level record - reverse the order to show hierarchy properly
        $reversedParts = $parts[($parts.Count - 1)..0]
        $path = "/$ZoneName"
        foreach ($part in $reversedParts) {
            $path += "/$part"
        }
        return $path
    }
}

# Export DNS records for a zone to a file
function Export-DnsRecords {
    param (
        [string]$ZoneName
    )

    $outputFile = Join-Path -Path $OutputDir -ChildPath "$ZoneName.csv"

    try {
        $records = Get-DnsServerResourceRecord -ComputerName $DnsServer -ZoneName $ZoneName -ErrorAction Stop
        if ($RecordTypes -and $RecordTypes.Count -gt 0) {
            $want = $RecordTypes | ForEach-Object { $_.ToUpperInvariant() }
            $records = $records | Where-Object { $want -contains ($_.RecordType.ToString().ToUpperInvariant()) }
        }

        if (-not $records -or $records.Count -eq 0) {
            Write-Host "No matching records ($($RecordTypes -join ',')) found for zone '$ZoneName'" -ForegroundColor Yellow
            return
        }

        $export = foreach ($rec in $records) {
            $data = $null
            switch ($rec.RecordType.ToString()) {
                'A' { try { $data = $rec.RecordData.IPv4Address.IPAddressToString } catch { $data = $rec.RecordData.ToString() } }
                'CNAME' { try { $data = $rec.RecordData.HostNameAlias } catch { $data = $rec.RecordData.ToString() } }
                default { try { $data = $rec.RecordData.ToString() } catch { $data = '' } }
            }
            
            $normalizedHostname = if ($RemoveDuplicates) { 
                Get-NormalizedHostname -HostName $rec.HostName -ZoneName $ZoneName 
            }
            else { 
                $rec.HostName 
            }
            
            # Build the DNS path to show hierarchical structure
            $dnsPath = Get-DnsPath -HostName $normalizedHostname -ZoneName $ZoneName
            
            [pscustomobject]@{
                Zone             = $ZoneName
                HostName         = $normalizedHostname
                Path             = $dnsPath
                OriginalHostName = $rec.HostName
                RecordType       = $rec.RecordType
                RecordClass      = $rec.RecordClass
                TimeToLive       = $rec.TimeToLive
                Timestamp        = $rec.Timestamp
                RecordData       = $data
            }
        }

        # Remove duplicates if requested
        if ($RemoveDuplicates) {
            $duplicatesRemoved = 0
            
            # Group by normalized hostname, record type, and record data
            $grouped = $export | Group-Object HostName, RecordType, RecordData
            
            $export = foreach ($group in $grouped) {
                if ($group.Count -gt 1) {
                    $duplicatesRemoved += ($group.Count - 1)
                    # Prefer the shorter hostname (relative over FQDN)
                    $group.Group | Sort-Object { $_.OriginalHostName.Length } | Select-Object -First 1
                }
                else {
                    $group.Group[0]
                }
            }
            
            if ($duplicatesRemoved -gt 0) {
                Write-Host "Removed $duplicatesRemoved duplicate entries for zone '$ZoneName'" -ForegroundColor Yellow
            }
        }

        # Identify folder entries (subdomains that contain other records)
        $allHostnames = $export | ForEach-Object { $_.HostName }
        foreach ($record in $export) {
            # Check if this hostname is a "parent" of other hostnames
            $isFolder = $false
            if ($record.HostName -ne '@') {
                $childPattern = $record.HostName + "."
                $hasChildren = $allHostnames | Where-Object { 
                    $_ -ne $record.HostName -and $_.StartsWith($childPattern, [StringComparison]::OrdinalIgnoreCase) 
                }
                if ($hasChildren) {
                    $isFolder = $true
                }
            }
            
            # Add IsFolder property
            $record | Add-Member -NotePropertyName "IsFolder" -NotePropertyValue $isFolder -Force
            
            # Modify the Path to indicate if it's a folder
            if ($isFolder) {
                $record.Path = $record.Path + "/ (folder)"
            }
        }

        # Remove the OriginalHostName column for cleaner output
        $finalExport = $export | Select-Object Zone, HostName, Path, IsFolder, RecordType, RecordClass, TimeToLive, Timestamp, RecordData

        $finalExport | Export-Csv -Path $outputFile -NoTypeInformation -Force
        Write-Host "Exported zone '$ZoneName' ($($finalExport.Count) records) to '$outputFile'" -ForegroundColor Green
    }
    catch {
        Write-Host "Failed to export records for zone '$ZoneName': $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Main logic
Write-Host "WindowsDNSExport v$ScriptVersion - Enumerating zones on DNS server $DnsServer (remote-capable)..." -ForegroundColor Cyan
$zones = Get-DnsZones

if ($zones.Count -eq 0) {
    Write-Host "No zones found or unable to enumerate zones." -ForegroundColor Red
    exit 1
}

Write-Host "Found $($zones.Count) zones. Starting export..." -ForegroundColor Cyan
foreach ($zone in $zones) {
    Export-DnsRecords -ZoneName $zone
}

Write-Host "Export complete. Files saved in $OutputDir" -ForegroundColor Cyan
